# Survey instrument

## Background (once)

1. Random participant code: ______
2. Graph-query experience: `<1 year`, `1--3 years`, `4--7 years`, `8+ years`
3. Cypher familiarity: `none`, `basic`, `regular`, `expert`
4. Consent: `yes/no`

## Per task

Read the original query, its observed outcome, and the requested outcome. Then inspect panels A and B without trying to identify their source.

1. Which panel would be more useful for deciding what to do next? `A`, `B`, or `tie`
2. Panel A clarity: `1` (very unclear) to `5` (very clear)
3. Panel B clarity: `1` to `5`
4. Panel A actionability: `1` (not actionable) to `5` (immediately actionable)
5. Panel B actionability: `1` to `5`
6. Panel A trust: `1` (would not rely on it) to `5` (would rely on it)
7. Panel B trust: `1` to `5`
8. In one sentence, what would you change in the query, if anything?
9. Optional: what information was missing or misleading?
10. Elapsed seconds for this task: ______

Do not reveal the panel key to participants until their responses are locked.

