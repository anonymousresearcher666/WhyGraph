# Participant information and consent

You are invited to evaluate explanations for unexpected graph-query cardinalities. You will review 12 short cases and compare two anonymized forms of feedback. The session should take about 20--30 minutes.

Participation is voluntary. You may stop at any time without giving a reason. The study records a random participant code, broad graph-query experience, task choices, ratings, elapsed time, and optional comments. It must not record your name, employer, email address, IP address, or other direct identifier. Study data will be reported only in aggregate; optional quotations require a separate explicit permission field.

The foreseeable risk is no greater than ordinary professional software evaluation. There is no direct personal benefit. Contact and ethics-review details must be inserted by the investigators before this form is used.

By marking `consent=yes` in the response sheet, you confirm that you are at least 18, have read this information, have had an opportunity to ask questions, and voluntarily agree to participate.

Investigator contact: **TO BE COMPLETED BEFORE RECRUITMENT**  
Ethics/IRB reference or exemption: **TO BE COMPLETED BEFORE RECRUITMENT**

