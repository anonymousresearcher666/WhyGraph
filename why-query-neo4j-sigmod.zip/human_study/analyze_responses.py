#!/usr/bin/env python3
"""Validate and summarize genuine responses from the WhyGraph usefulness study."""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from pathlib import Path


def exact_two_sided_binomial(k: int, n: int, p: float = 0.5) -> float:
    if n == 0:
        return math.nan
    observed = math.comb(n, k) * p**k * (1 - p) ** (n - k)
    return min(1.0, sum(
        math.comb(n, i) * p**i * (1 - p) ** (n - i)
        for i in range(n + 1)
        if math.comb(n, i) * p**i * (1 - p) ** (n - i) <= observed + 1e-15
    ))


def wilson(k: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if n == 0:
        return (math.nan, math.nan)
    phat = k / n
    den = 1 + z * z / n
    center = (phat + z * z / (2 * n)) / den
    half = z * math.sqrt(phat * (1 - phat) / n + z * z / (4 * n * n)) / den
    return center - half, center + half


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("responses", type=Path)
    parser.add_argument("--answer-key", type=Path, default=Path("packets/answer_key.json"))
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    args = parser.parse_args()

    key_data = json.loads(args.answer_key.read_text(encoding="utf-8"))
    lookup = {
        (str(variant), item["task_id"]): item[f"packet_{variant}_whygraph_panel"]
        for item in key_data["tasks"] for variant in (1, 2)
    }
    with args.responses.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise SystemExit("no participant responses; the empty template is not evidence")

    seen: set[tuple[str, str]] = set()
    preferences: list[bool] = []
    ratings = {metric: {"whygraph": [], "control": []} for metric in ("clarity", "actionability", "trust")}
    participants: set[str] = set()
    durations: list[float] = []
    for line, row in enumerate(rows, 2):
        participant = row["participant_code"].strip()
        task_id = row["task_id"].strip()
        if not participant or participant.lower().startswith("participant"):
            raise SystemExit(f"line {line}: missing or placeholder participant code")
        if row["consent"].strip().lower() != "yes":
            raise SystemExit(f"line {line}: consent must be yes")
        pair = (participant, task_id)
        if pair in seen:
            raise SystemExit(f"line {line}: duplicate participant/task pair {pair}")
        seen.add(pair)
        participants.add(participant)
        variant = row["packet_variant"].strip()
        why_panel = lookup.get((variant, task_id))
        if why_panel is None:
            raise SystemExit(f"line {line}: task/packet not in answer key")
        preferred = row["preferred_panel"].strip().upper()
        if preferred not in {"A", "B", "TIE"}:
            raise SystemExit(f"line {line}: preferred_panel must be A, B, or tie")
        if preferred != "TIE":
            preferences.append(preferred == why_panel)
        for metric in ratings:
            a = int(row[f"{metric}_a"])
            b = int(row[f"{metric}_b"])
            if not (1 <= a <= 5 and 1 <= b <= 5):
                raise SystemExit(f"line {line}: {metric} ratings must be 1--5")
            ratings[metric]["whygraph"].append(a if why_panel == "A" else b)
            ratings[metric]["control"].append(b if why_panel == "A" else a)
        elapsed = float(row["elapsed_seconds"])
        if elapsed <= 0:
            raise SystemExit(f"line {line}: elapsed_seconds must be positive")
        durations.append(elapsed)

    wins = sum(preferences)
    n = len(preferences)
    lo, hi = wilson(wins, n)
    result = {
        "participants": len(participants),
        "task_responses": len(rows),
        "non_tie_preferences": n,
        "whygraph_preferences": wins,
        "whygraph_preference_rate": wins / n if n else None,
        "wilson_95": [lo, hi] if n else None,
        "exact_two_sided_binomial_p": exact_two_sided_binomial(wins, n) if n else None,
        "median_elapsed_seconds": statistics.median(durations),
        "ratings": {
            metric: {panel: {"median": statistics.median(values), "mean": statistics.fmean(values)}
                     for panel, values in panels.items()}
            for metric, panels in ratings.items()
        },
    }
    args.output_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Human-usefulness study analysis",
        "",
        f"Participants: {result['participants']}; task responses: {result['task_responses']}.",
        "",
        f"WhyGraph was preferred in {wins}/{n} non-tie comparisons "
        + (f"({wins/n:.1%}; 95% Wilson CI {lo:.1%}--{hi:.1%}; exact two-sided p={result['exact_two_sided_binomial_p']:.4g})." if n else "(no non-tie comparisons)."),
        "",
        "| Measure | WhyGraph median | Control median |",
        "|---|---:|---:|",
    ]
    for metric, panels in result["ratings"].items():
        lines.append(f"| {metric.title()} | {panels['whygraph']['median']:.1f} | {panels['control']['median']:.1f} |")
    lines += ["", "These are descriptive results from a small study; inspect free-text failure modes before drawing conclusions.", ""]
    args.output_md.write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

