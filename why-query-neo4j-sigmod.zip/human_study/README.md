# WhyGraph human-usefulness study

This directory contains a preregistration-style protocol and executable materials for a small, blinded, within-subject usefulness study. It is intentionally a **study package, not a claim of completed human-subject evidence**. No synthetic participant responses are included or accepted by the analysis script.

## Research question

Does a WhyGraph explanation help graph-query users diagnose and repair cardinality surprises more effectively than cardinality-only feedback?

## Design

- Population: 12 practitioners who have written Cypher or another graph query language. Record experience bands; do not collect names, employers, or contact details in the response file.
- Tasks: 12 successful, exactly post-validated cases drawn deterministically from the hardened YAGO/Protocol/Adversarial rerun, balanced across empty, too-few, and too-many modes when the evidence permits.
- Intervention: the original query and observed/desired cardinality, followed by two anonymized panels. One panel contains WhyGraph's proposed rewrite and edit trace; the other contains cardinality-only feedback.
- Blinding/counterbalancing: system names are removed. Panel A/B order is randomized per task and complemented between packet variants 1 and 2.
- Primary endpoint: proportion of tasks on which the participant prefers the WhyGraph panel for deciding what to do next.
- Secondary endpoints: 1--5 clarity, actionability, and trust ratings for each panel; completion time; free-text failure modes.
- Analysis: exact two-sided binomial test against 0.5 for the primary endpoint, with a 95% Wilson interval. Secondary statistics are descriptive because the study is deliberately small.

The intended claim is limited: this study probes perceived usefulness on the selected tasks. It does not establish population-wide usability or compare against a full interactive debugger.

## Runbook

1. Confirm local ethics/IRB requirements before recruiting participants.
2. Generate blinded materials after the hardened experiment:

   ```bash
   python3 build_study_packets.py \
     --results ../vldb/results_ft_exec_yago_HARDENED_20260903.jsonl \
     --results ../vldb/results_ft_exec_protocol_HARDENED_20260903.jsonl \
     --results ../vldb/results_ft_exec_adversarial_HARDENED_20260903.jsonl \
     --output-dir packets
   ```

3. Give each participant `consent.md`, `survey_instrument.md`, and one packet variant. Alternate packet variants by participant number.
4. Store one row per task in a private copy of `responses_template.csv`. Use random participant codes. Do not commit completed responses unless ethics approval and consent explicitly permit it.
5. Analyze real responses:

   ```bash
   python3 analyze_responses.py responses.csv --output-json analysis.json --output-md analysis.md
   ```

The analyzer rejects the template, duplicate participant/task pairs, invalid ratings, nonpositive durations, and responses that do not match the generated task key.

