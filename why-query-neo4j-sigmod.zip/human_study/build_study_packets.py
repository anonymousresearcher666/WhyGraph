#!/usr/bin/env python3
"""Build deterministic, blinded human-study packets from hardened JSONL results."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path

MODES = ("empty", "so_few", "so_many")


def load_rows(paths: list[Path]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                row = json.loads(line)
                row["_source"] = path.name
                rows.append(row)
    return rows


def primary_rewrite(row: dict) -> dict:
    rewrites = row.get("rewrites") or []
    return rewrites[0] if rewrites else {}


def whygraph_panel(row: dict) -> str:
    rewrite = primary_rewrite(row)
    steps = rewrite.get("modification_steps") or []
    edits = [str(step.get("description") or step.get("operation") or "unspecified edit") for step in steps]
    parts = [
        "Proposed query:\n```cypher\n" + str(rewrite.get("query") or "No rewrite available") + "\n```",
        "Suggested edit(s): " + ("; ".join(edits) if edits else "No syntactic edit reported."),
    ]
    if row.get("rewrite_actual_cardinality") is not None:
        parts.append(f"Post-validation cardinality: {row['rewrite_actual_cardinality']}")
    if row.get("bound") is not None:
        parts.append(f"Certified bound: {row['bound']}")
    blockers = row.get("why_not_blockers") or []
    if blockers:
        parts.append("Reported blockers: " + "; ".join(map(str, blockers)))
    return "\n\n".join(parts)


def control_panel(row: dict) -> str:
    observed = row.get("actual_cardinality")
    target = row.get("threshold")
    mode = row.get("type")
    request = {
        "empty": "Return at least one row.",
        "so_few": f"Return at least {target} rows.",
        "so_many": f"Return at most {target} rows.",
    }.get(mode, "Change the result cardinality.")
    return f"Observed cardinality: {observed}.\n\nRequested outcome: {request}\n\nNo query change is proposed."


def render_packet(variant: int, tasks: list[dict], assignments: dict[str, str]) -> str:
    lines = [
        f"# WhyGraph usefulness study -- packet {variant}",
        "",
        "Follow `survey_instrument.md`. Record one response row for every task.",
        "",
    ]
    for index, row in enumerate(tasks, 1):
        task_id = str(row["id"])
        why_label = assignments[task_id]
        panels = {why_label: whygraph_panel(row), "B" if why_label == "A" else "A": control_panel(row)}
        threshold = row.get("threshold")
        lines += [
            f"## Task {index}: {task_id}",
            "",
            f"Mode: `{row.get('type')}`" + (f"; threshold: `{threshold}`" if threshold is not None else ""),
            "",
            "Original query:",
            "",
            "```cypher",
            str(row.get("query") or ""),
            "```",
            "",
            "### Panel A",
            "",
            panels["A"],
            "",
            "### Panel B",
            "",
            panels["B"],
            "",
        ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, action="append", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260903)
    parser.add_argument("--per-mode", type=int, default=4)
    args = parser.parse_args()

    eligible = [
        row for row in load_rows(args.results)
        if row.get("profile") == "full-theory"
        and row.get("status") == "SUCCESS"
        and row.get("rewrite_actual_success") is True
        and primary_rewrite(row).get("query")
    ]
    by_mode: dict[str, list[dict]] = defaultdict(list)
    for row in eligible:
        by_mode[str(row.get("type"))].append(row)
    missing = {mode: args.per_mode - len(by_mode[mode]) for mode in MODES if len(by_mode[mode]) < args.per_mode}
    if missing:
        raise SystemExit(f"insufficient eligible tasks for balanced packet: {missing}")

    rng = random.Random(args.seed)
    tasks: list[dict] = []
    for mode in MODES:
        candidates = sorted(by_mode[mode], key=lambda row: (str(row["id"]), str(row["_source"])))
        rng.shuffle(candidates)
        tasks.extend(candidates[: args.per_mode])
    rng.shuffle(tasks)

    assignment1 = {str(row["id"]): rng.choice(("A", "B")) for row in tasks}
    assignment2 = {task_id: ("B" if label == "A" else "A") for task_id, label in assignment1.items()}
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "packet_1.md").write_text(render_packet(1, tasks, assignment1), encoding="utf-8")
    (args.output_dir / "packet_2.md").write_text(render_packet(2, tasks, assignment2), encoding="utf-8")

    key = {
        "seed": args.seed,
        "inputs": [
            {"file": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in args.results
        ],
        "tasks": [
            {
                "task_id": str(row["id"]),
                "mode": row.get("type"),
                "packet_1_whygraph_panel": assignment1[str(row["id"])],
                "packet_2_whygraph_panel": assignment2[str(row["id"])],
            }
            for row in tasks
        ],
    }
    (args.output_dir / "answer_key.json").write_text(json.dumps(key, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(tasks)} tasks in two counterbalanced packets to {args.output_dir}")


if __name__ == "__main__":
    main()

