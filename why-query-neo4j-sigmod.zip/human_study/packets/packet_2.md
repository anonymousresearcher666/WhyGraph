# WhyGraph usefulness study -- packet 2

Follow `survey_instrument.md`. Record one response row for every task.

## Task 1: yago-so-few-bornin-specific

Mode: `so_few`; threshold: `25`

Original query:

```cypher
MATCH (p:NRPerson {name:'Benazir_Bhutto'})-[:ERwasBornIn]->(c:NRCity {name:'Karachi'}) RETURN p, c
```

### Panel A

Proposed query:
```cypher
MATCH (p:NRPerson)-[:ERwasBornIn]->(c:NRCity) RETURN p, c
```

Suggested edit(s): DELETE_PREDICATE on node_11 (label: NRPerson) (property: name); DELETE_PREDICATE on node_14 (label: NRCity) (property: name)

Post-validation cardinality: 25

### Panel B

Observed cardinality: 1.

Requested outcome: Return at least 25 rows.

No query change is proposed.

## Task 2: proto-star-k6-empty

Mode: `empty`

Original query:

```cypher
MATCH (c:NRCountry)-[:ERdealsWith]->(v1:NRCountry)
MATCH (c)-[:ERdealsWith]->(v2:NRCountry)
MATCH (c)-[:ERdealsWith]->(v3:NRCountry)
MATCH (c)-[:ERdealsWith]->(v4:NRCountry)
MATCH (c)-[:ERdealsWith]->(v5:NRCountry)
MATCH (c)-[:ERdealsWith]->(v6:NRCountry)
WHERE c.name = 'Iraq' AND v1.name = 'XX_NON_EXISTING'
RETURN c, v1, v2, v3, v4, v5, v6

```

### Panel A

Observed cardinality: None.

Requested outcome: Return at least one row.

No query change is proposed.

### Panel B

Proposed query:
```cypher
MATCH (c:NRCountry)-[:ERdealsWith]->(v1:NRCountry), (c)-[:ERdealsWith]->(v2:NRCountry), (c)-[:ERdealsWith]->(v3:NRCountry), (c)-[:ERdealsWith]->(v4:NRCountry), (c)-[:ERdealsWith]->(v5:NRCountry), (c)-[:ERdealsWith]->(v6:NRCountry) WHERE c.name = 'Iraq'  RETURN c, v1, v2, v3, v4, v5, v6
```

Suggested edit(s): DELETE_PREDICATE on node_27 (label: NRCountry) (property: name)

Post-validation cardinality: 1

## Task 3: proto-zigzag-k8-empty

Mode: `empty`

Original query:

```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry)
MATCH (v2:NRCountry)-[:ERisConnectedTo]->(v1)
MATCH (v2)-[:ERisConnectedTo]->(v3:NRCountry)
MATCH (v4:NRCountry)-[:ERisConnectedTo]->(v3)
MATCH (v4)-[:ERisConnectedTo]->(v5:NRCountry)
MATCH (v6:NRCountry)-[:ERisConnectedTo]->(v5)
MATCH (v6)-[:ERisConnectedTo]->(v7:NRCountry)
MATCH (v8:NRCountry)-[:ERisConnectedTo]->(v7)
WHERE v2.name = 'XX_NON_EXISTING'
RETURN v0, v1, v2, v3, v4, v5, v6, v7, v8

```

### Panel A

Observed cardinality: None.

Requested outcome: Return at least one row.

No query change is proposed.

### Panel B

Proposed query:
```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry), (v2:NRCountry)-[:ERisConnectedTo]->(v1), (v2)-[:ERisConnectedTo]->(v3:NRCountry), (v4:NRCountry)-[:ERisConnectedTo]->(v3), (v4)-[:ERisConnectedTo]->(v5:NRCountry), (v6:NRCountry)-[:ERisConnectedTo]->(v5), (v6)-[:ERisConnectedTo]->(v7:NRCountry), (v8:NRCountry)-[:ERisConnectedTo]->(v7) RETURN v0, v1, v2, v3, v4, v5, v6, v7, v8
```

Suggested edit(s): DELETE_PREDICATE on node_29 (label: NRCountry) (property: name)

Post-validation cardinality: 1

## Task 4: proto-path-k3-so-many

Mode: `so_many`; threshold: `1000`

Original query:

```cypher
MATCH (v0:NRPerson)-[:ERinfluences]->(v1:NRPerson)
MATCH (v1)-[:ERinfluences]->(v2:NRPerson)
MATCH (v2)-[:ERinfluences]->(v3:NRPerson)
RETURN v0, v1, v2, v3

```

### Panel A

Proposed query:
```cypher
MATCH (v0:NRPerson)-[:ERinfluences]->(v1:NRPerson)
MATCH (v1)-[:ERinfluences]->(v2:NRPerson)
MATCH (v2)-[:ERinfluences]->(v3:NRPerson) WHERE v0.name = 'Worcester,_Massachusetts' AND v1.name = 'Worcester,_Massachusetts' AND v3.name = 'Worcester,_Massachusetts' RETURN v0, v1, v2, v3

```

Suggested edit(s): ADD_PREDICATE on v0 (label: NRPerson) (property: name) (values: EQUALS, Worcester,_Massachusetts); ADD_PREDICATE on v1 (label: NRPerson) (property: name) (values: EQUALS, Worcester,_Massachusetts); ADD_PREDICATE on v3 (label: NRPerson) (property: name) (values: EQUALS, Worcester,_Massachusetts)

Post-validation cardinality: 0

Certified bound: 40.0

### Panel B

Observed cardinality: None.

Requested outcome: Return at most 1000 rows.

No query change is proposed.

## Task 5: proto-zigzag-k8-so-few

Mode: `so_few`; threshold: `25`

Original query:

```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry)
MATCH (v2:NRCountry)-[:ERisConnectedTo]->(v1)
MATCH (v2)-[:ERisConnectedTo]->(v3:NRCountry)
MATCH (v4:NRCountry)-[:ERisConnectedTo]->(v3)
MATCH (v4)-[:ERisConnectedTo]->(v5:NRCountry)
MATCH (v6:NRCountry)-[:ERisConnectedTo]->(v5)
MATCH (v6)-[:ERisConnectedTo]->(v7:NRCountry)
MATCH (v8:NRCountry)-[:ERisConnectedTo]->(v7)
WHERE v0.name = 'Karachi' AND v8.name = 'Karachi'
RETURN v0, v1, v2, v3, v4, v5, v6, v7, v8

```

### Panel A

Proposed query:
```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry), (v2:NRCountry)-[:ERisConnectedTo]->(v1), (v2)-[:ERisConnectedTo]->(v3:NRCountry), (v4:NRCountry)-[:ERisConnectedTo]->(v3), (v4)-[:ERisConnectedTo]->(v5:NRCountry), (v6:NRCountry)-[:ERisConnectedTo]->(v5), (v6)-[:ERisConnectedTo]->(v7:NRCountry), (v8:NRCountry)-[:ERisConnectedTo]->(v7)  RETURN v0, v1, v2, v3, v4, v5, v6, v7, v8
```

Suggested edit(s): DELETE_PREDICATE on node_33 (property: name); DELETE_PREDICATE on node_30 (property: name)

Post-validation cardinality: 25

### Panel B

Observed cardinality: None.

Requested outcome: Return at least 25 rows.

No query change is proposed.

## Task 6: proto-zigzag-k4-so-few

Mode: `so_few`; threshold: `25`

Original query:

```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry)
MATCH (v2:NRCountry)-[:ERisConnectedTo]->(v1)
MATCH (v2)-[:ERisConnectedTo]->(v3:NRCountry)
MATCH (v4:NRCountry)-[:ERisConnectedTo]->(v3)
WHERE v0.name = 'Karachi' AND v4.name = 'Karachi'
RETURN v0, v1, v2, v3, v4

```

### Panel A

Observed cardinality: None.

Requested outcome: Return at least 25 rows.

No query change is proposed.

### Panel B

Proposed query:
```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry), (v2:NRCountry)-[:ERisConnectedTo]->(v1), (v2)-[:ERisConnectedTo]->(v3:NRCountry), (v4:NRCountry)-[:ERisConnectedTo]->(v3)  RETURN v0, v1, v2, v3, v4
```

Suggested edit(s): DELETE_PREDICATE on node_18 (property: name); DELETE_PREDICATE on node_21 (property: name)

Post-validation cardinality: 25

## Task 7: yago-so-many-is-married-to

Mode: `so_many`; threshold: `1000`

Original query:

```cypher
MATCH (p:NRPerson)-[:ERisMarriedTo]->(s:NRPerson) RETURN p, s
```

### Panel A

Observed cardinality: None.

Requested outcome: Return at most 1000 rows.

No query change is proposed.

### Panel B

Proposed query:
```cypher
MATCH (p:NRPerson)-[:ERisMarriedTo]->(s:NRPerson) WHERE p.name = 'Worcester,_Massachusetts' RETURN p, s
```

Suggested edit(s): ADD_PREDICATE on p (label: NRPerson) (property: name) (values: EQUALS, Worcester,_Massachusetts)

Post-validation cardinality: 0

Certified bound: 14.0

## Task 8: adv-label-mismatch-empty

Mode: `empty`

Original query:

```cypher
MATCH (m:NRMovie)-[:ERwasBornIn]->(c:NRCity)
RETURN m, c

```

### Panel A

Observed cardinality: None.

Requested outcome: Return at least one row.

No query change is proposed.

### Panel B

Proposed query:
```cypher
MATCH (m:NRPerson)-[:ERwasBornIn]->(c:NRCity)  RETURN m, c
```

Suggested edit(s): REPAIR_END_LABEL on node_4 (label: NRPerson)

Post-validation cardinality: 1

## Task 9: yago-empty-typo-prop

Mode: `empty`

Original query:

```cypher
MATCH (p:NRPerson) WHERE p.naem = 'Billy_Graham' RETURN p
```

### Panel A

Observed cardinality: 0.

Requested outcome: Return at least one row.

No query change is proposed.

### Panel B

Proposed query:
```cypher
MATCH (p:NRPerson) RETURN p
```

Suggested edit(s): DELETE_PREDICATE on node_6 (label: NRPerson) (property: naem)

Post-validation cardinality: 1

## Task 10: yago-so-many-deals-with

Mode: `so_many`; threshold: `50`

Original query:

```cypher
MATCH (a:NRCountry)-[:ERdealsWith]->(b:NRCountry) RETURN a, b
```

### Panel A

Observed cardinality: 945.

Requested outcome: Return at most 50 rows.

No query change is proposed.

### Panel B

Proposed query:
```cypher
MATCH (a:NRCountry)-[:ERdealsWith]->(b:NRCountry) WHERE a.name = 'Winthrop,_Massachusetts' RETURN a, b
```

Suggested edit(s): ADD_PREDICATE on a (label: NRCountry) (property: name) (values: EQUALS, Winthrop,_Massachusetts)

Post-validation cardinality: 0

Certified bound: 13.0

## Task 11: proto-zigzag-k6-so-many

Mode: `so_many`; threshold: `1000`

Original query:

```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry)
MATCH (v2:NRCountry)-[:ERisConnectedTo]->(v1)
MATCH (v2)-[:ERisConnectedTo]->(v3:NRCountry)
MATCH (v4:NRCountry)-[:ERisConnectedTo]->(v3)
MATCH (v4)-[:ERisConnectedTo]->(v5:NRCountry)
MATCH (v6:NRCountry)-[:ERisConnectedTo]->(v5)
RETURN v0, v1, v2, v3, v4, v5, v6

```

### Panel A

Proposed query:
```cypher
MATCH (v0:NRCountry)-[:ERisConnectedTo]->(v1:NRCountry)
MATCH (v2:NRCountry)-[:ERisConnectedTo]->(v1)
MATCH (v2)-[:ERisConnectedTo]->(v3:NRCountry)
MATCH (v4:NRCountry)-[:ERisConnectedTo]->(v3)
MATCH (v4)-[:ERisConnectedTo]->(v5:NRCountry)
MATCH (v6:NRCountry)-[:ERisConnectedTo]->(v5) WHERE v0.name = 'Winthrop,_Massachusetts' AND v1.name = 'Winthrop,_Massachusetts' AND v2.name = 'Winthrop,_Massachusetts' AND v3.name = 'Winthrop,_Massachusetts' AND v4.name = 'Winthrop,_Massachusetts' AND v5.name = 'Winthrop,_Massachusetts' RETURN v0, v1, v2, v3, v4, v5, v6

```

Suggested edit(s): ADD_PREDICATE on v0 (label: NRCountry) (property: name) (values: EQUALS, Winthrop,_Massachusetts); ADD_PREDICATE on v1 (label: NRCountry) (property: name) (values: EQUALS, Winthrop,_Massachusetts); ADD_PREDICATE on v2 (label: NRCountry) (property: name) (values: EQUALS, Winthrop,_Massachusetts); ADD_PREDICATE on v3 (label: NRCountry) (property: name) (values: EQUALS, Winthrop,_Massachusetts); ADD_PREDICATE on v4 (label: NRCountry) (property: name) (values: EQUALS, Winthrop,_Massachusetts); ADD_PREDICATE on v5 (label: NRCountry) (property: name) (values: EQUALS, Winthrop,_Massachusetts)

Post-validation cardinality: 0

Certified bound: 179.0

### Panel B

Observed cardinality: None.

Requested outcome: Return at most 1000 rows.

No query change is proposed.

## Task 12: adv-optional-chain-so-few

Mode: `so_few`; threshold: `25`

Original query:

```cypher
MATCH (p:NRPerson)-[:ERhasAcademicAdvisor]->(a:NRPerson)
MATCH (a)-[:ERlivesIn]->(c:NRCity)
MATCH (c)-[:ERisLocatedIn]->(r:NRRegion)
RETURN p, a, c, r

```

### Panel A

Proposed query:
```cypher
MATCH (p:NRPerson)<-[:ERhasAcademicAdvisor]-(a:NRPerson), (a)-[:ERlivesIn]->(c:NRCity), (c)-[:ERisLocatedIn]->(r:NRRegion)  RETURN p, a, c, r
```

Suggested edit(s): FLIP_RELATIONSHIP_DIRECTION on node_5 (label: ERhasAcademicAdvisor)

Post-validation cardinality: 25

### Panel B

Observed cardinality: None.

Requested outcome: Return at least 25 rows.

No query change is proposed.
