package com.whyquery.neo4j.ranking;

import com.whyquery.neo4j.Neo4jTestSupport;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class RankingAnalyzerTest {

    private GraphDatabaseService db;

    private Transaction tx;

    private Neo4jStatistics statistics;

    private RankingAnalyzer analyzer;

    @BeforeEach
    void setUp() {
        tx = Neo4jTestSupport.transaction(query -> Neo4jTestSupport.emptyResult());
        db = Neo4jTestSupport.databaseService(() -> tx);
        statistics = new Neo4jStatistics(db);
        analyzer = new RankingAnalyzer(db, tx, statistics);
    }

    @Test
    void analyzeRankingExtractsOrderByExpressionAndDirection() {
        String query = "MATCH (m:Movie) RETURN m.title ORDER BY m.rating DESC";
        CypherAST ast = CypherASTBuilder.parseQuery(query);

        RankingAnalysis analysis = analyzer.analyzeRanking(ast, query);

        assertEquals(RankingType.EXPLICIT_ORDER_BY, analysis.getRankingType());
        assertTrue(analysis.hasExplicitRanking());
        assertEquals(1, analysis.getRankingFactors().size());

        RankingFactor factor = analysis.getRankingFactors().get(0);
        assertEquals(RankingFactorType.PROPERTY, factor.getType());
        assertEquals("m.rating", factor.getExpression());
        assertEquals("DESC", factor.getDirection());
    }

    @Test
    void analyzeRankingDetectsImplicitLimitWhenNoOrderByExists() {
        String query = "MATCH (m:Movie) RETURN m.title LIMIT 10";
        CypherAST ast = CypherASTBuilder.parseQuery(query);

        RankingAnalysis analysis = analyzer.analyzeRanking(ast, query);

        assertEquals(RankingType.IMPLICIT_LIMIT, analysis.getRankingType());
        assertEquals(1, analysis.getRankingFactors().size());
        assertEquals(RankingFactorType.INTERNAL_ID, analysis.getRankingFactors().get(0).getType());
    }

    @Test
    void analyzeRankingCapturesSampleValuesFromTransaction() {
        String query = "MATCH (m:Movie) RETURN m.title ORDER BY m.rating DESC";
        CypherAST ast = CypherASTBuilder.parseQuery(query);
        tx = Neo4jTestSupport.transaction(ignored -> Neo4jTestSupport.result(List.of(
            Map.of("factor_value", 8.5),
            Map.of("factor_value", 7.2)
        )));
        analyzer = new RankingAnalyzer(db, tx, statistics);

        RankingAnalysis analysis = analyzer.analyzeRanking(ast, query);

        RankingFactor factor = analysis.getRankingFactors().get(0);
        assertEquals(2, factor.getSampleValues().size());
        assertEquals(8.5, factor.getSampleValues().get(0).get("factor_value"));
        assertEquals(7.2, factor.getSampleValues().get(1).get("factor_value"));
    }
}
