package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.harness.Neo4j;
import org.neo4j.harness.Neo4jBuilders;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class QueryRewritingFreshnessGateTest {

    @Test
    void observedNumericExtremaDoNotBecomeHardDomainViolations() throws Exception {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction write = db.beginTx()) {
                write.execute("CREATE (:N {x:10}), (:N {x:20})");
                write.commit();
            }
            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            try (Transaction rebuild = db.beginTx()) {
                cache.rebuildSnapshotFromDatabase(rebuild, Map.of(
                    "preserve_structure", false,
                    "include_common_values", false,
                    "include_numeric_ranges", true,
                    "include_histograms", false,
                    "include_distinct_counts", false,
                    "include_properties", true,
                    "include_triples", false,
                    "persist_snapshot", false
                ));
                rebuild.commit();
            }
            RewritingConfig config = new RewritingConfig();
            config.setUseSchema(true);
            QueryRewritingAStar search = new QueryRewritingAStar(db, null, config, cache);
            CypherAST ast = CypherASTBuilder.parseQuery(
                "MATCH (n:N) WHERE n.x > -1 RETURN n"
            );
            Method check = QueryRewritingAStar.class.getDeclaredMethod(
                "checkSemanticConsistency", CypherAST.class);
            check.setAccessible(true);
            Object result = check.invoke(search, ast);
            Method consistent = result.getClass().getDeclaredMethod("isConsistent");
            consistent.setAccessible(true);
            assertTrue((boolean) consistent.invoke(result));
        }
    }

    @Test
    void staleSnapshotDisablesSchemaPruningAndDynamicFormalCertification() throws Exception {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction write = db.beginTx()) {
                write.execute("CREATE (:A)-[:R]->(:B)");
                write.commit();
            }

            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            rebuildWithoutPersistence(cache, db);
            RewritingConfig config = new RewritingConfig();
            config.setUseSchema(true);
            config.setUseFormalBounds(true);

            QueryRewritingAStar runningSearch = new QueryRewritingAStar(db, null, config, cache);
            assertTrue(booleanField(runningSearch, "useSchema"));
            assertTrue(runningSearch.mayUseFormalCertificate());
            assertTrue(runningSearch.mayUseWhyManyPredicateFallback());

            try (Transaction write = db.beginTx()) {
                write.execute("CREATE (:NewLabel)");
                write.commit();
            }
            // The dynamic acceptance gate closes even for a search that began
            // while the snapshot was fresh.
            assertFalse(runningSearch.mayUseFormalCertificate());

            QueryRewritingAStar searchStartedStale = new QueryRewritingAStar(db, null, config, cache);
            assertFalse(booleanField(searchStartedStale, "useSchema"));
            assertFalse(searchStartedStale.mayUseFormalCertificate());
            // Staleness must not silently convert a requested formal run into
            // a heuristic-success run.
            assertFalse(searchStartedStale.mayUseWhyManyPredicateFallback());

            RewritingConfig heuristicConfig = new RewritingConfig();
            heuristicConfig.setUseFormalBounds(false);
            QueryRewritingAStar heuristicSearch = new QueryRewritingAStar(db, null, heuristicConfig, cache);
            assertTrue(heuristicSearch.mayUseWhyManyPredicateFallback());
        }
    }

    @Test
    void formalKeyRestrictionShortcutRecordsTheComputedSafeUpperBound() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction write = db.beginTx()) {
                write.execute("UNWIND range(1, 3) AS i CREATE (:A {name: 'a' + i})-[:R]->(:B)");
                write.commit();
            }

            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            try (Transaction rebuild = db.beginTx()) {
                cache.rebuildSnapshotFromDatabase(rebuild, Map.of(
                    "preserve_structure", false,
                    "include_common_values", true,
                    "include_numeric_ranges", false,
                    "include_histograms", false,
                    "include_distinct_counts", true,
                    "include_properties", true,
                    "include_triples", true,
                    "persist_snapshot", false
                ));
                rebuild.commit();
            }

            assertTrue(cache.getLabelCount("A") == 3L);
            assertTrue(cache.isKeyProperty("A", "name"),
                "an exact, total, snapshot-unique property must receive the safe equality cap");
            assertFalse(cache.getPropertyDetailsForLabel("A").isEmpty());

            RewritingConfig config = new RewritingConfig();
            config.setUseSchema(true);
            config.setUsePlannerStats(false);
            config.setUseFormalBounds(true);
            config.setAllowDataQueries(false);
            config.setStrictEstimateOnly(true);
            config.setMaxIterations(0);

            QueryRewritingAStar search = new QueryRewritingAStar(
                db, new Neo4jStatistics(db, false, true), config, cache);
            RewritingResult result = search.rewriteQuery(
                "MATCH (a:A)-[:R]->(b:B) RETURN a, b",
                1L,
                new UserPreferences(),
                50.0,
                WhyMode.WHY_MANY,
                0L,
                1L
            );

            assertTrue(result.isSuccess(), () -> "errors=" + result.getErrors());
            assertNotNull(result.getTrace());
            RewritingResult.AStarTrace.Step goal = result.getTrace().getSteps().stream()
                .filter(step -> step.goal)
                .reduce((first, second) -> second)
                .orElseThrow();
            assertEquals("KEY_RESTRICTION_CERTIFICATE", goal.operationType);
            assertTrue(goal.boundUpper >= 0L && goal.boundUpper <= 1L,
                () -> "shortcut must record the computed certificate, got " + goal.boundUpper);
        }
    }

    @Test
    void formalUpperBoundRetainsEveryChainExpansionFactor() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction write = db.beginTx()) {
                write.execute("CREATE (:A)");
                write.execute("MATCH (a:A) UNWIND range(1, 2) AS i CREATE (a)-[:R]->(:B)");
                write.execute("MATCH (b:B) UNWIND range(1, 100) AS i CREATE (b)-[:S]->(:C)");
                write.commit();
            }

            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            try (Transaction rebuild = db.beginTx()) {
                cache.rebuildSnapshotFromDatabase(rebuild, Map.of(
                    "preserve_structure", false,
                    "include_common_values", false,
                    "include_numeric_ranges", false,
                    "include_histograms", false,
                    "include_distinct_counts", false,
                    "include_properties", false,
                    "include_triples", true,
                    "persist_snapshot", false
                ));
                rebuild.commit();
            }

            RewritingConfig config = new RewritingConfig();
            config.setUseSchema(true);
            config.setUsePlannerStats(false);
            config.setUseFormalBounds(true);
            config.setAllowDataQueries(false);
            config.setStrictEstimateOnly(true);
            config.setMaxIterations(0);

            QueryRewritingAStar search = new QueryRewritingAStar(
                db, new Neo4jStatistics(db, false, true), config, cache);
            RewritingResult result = search.rewriteQuery(
                "MATCH (a:A)-[:R]->(b:B)-[:S]->(c:C) RETURN a, b, c",
                1L,
                new UserPreferences(),
                50.0,
                WhyMode.WHY_MANY,
                0L,
                1L
            );

            RewritingResult.AStarTrace.Step initial = result.getTrace().getSteps().stream()
                .filter(step -> "INIT".equals(step.operationType))
                .findFirst()
                .orElseThrow();
            assertTrue(initial.boundUpper >= 200L,
                () -> "1 x max(R)=2 x max(S)=100 must remain in the safe product; got "
                    + initial.boundUpper);
        }
    }

    @Test
    void formalUpperBoundMultipliesDisconnectedLoneNodePopulations() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction write = db.beginTx()) {
                write.execute("UNWIND range(1, 10) AS i CREATE (:A {id:i})");
                write.execute("UNWIND range(1, 20) AS i CREATE (:B {id:i})");
                write.commit();
            }

            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            rebuildWithoutPersistence(cache, db);
            RewritingConfig config = new RewritingConfig();
            config.setUseSchema(true);
            config.setUsePlannerStats(false);
            config.setUseFormalBounds(true);
            config.setAllowDataQueries(false);
            config.setStrictEstimateOnly(true);
            config.setMaxIterations(0);

            QueryRewritingAStar search = new QueryRewritingAStar(
                db, new Neo4jStatistics(db, false, true), config, cache);
            RewritingResult result = search.rewriteQuery(
                "MATCH (a:A), (b:B) RETURN a, b",
                1L,
                new UserPreferences(),
                50.0,
                WhyMode.WHY_MANY,
                0L,
                1L
            );

            RewritingResult.AStarTrace.Step initial = result.getTrace().getSteps().stream()
                .filter(step -> "INIT".equals(step.operationType))
                .findFirst()
                .orElseThrow();
            assertTrue(initial.boundUpper >= 200L,
                () -> "10 x 20 disconnected bindings require an upper bound >= 200, got "
                    + initial.boundUpper);
        }
    }

    @Test
    void formalUpperBoundFailsClosedForDisconnectedEdgeComponents() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction write = db.beginTx()) {
                write.execute("CREATE (:A)-[:R]->(:B)");
                write.execute("CREATE (:C)-[:S]->(:D)");
                write.commit();
            }

            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            rebuildWithoutPersistence(cache, db);
            RewritingConfig config = new RewritingConfig();
            config.setUseSchema(true);
            config.setUsePlannerStats(false);
            config.setUseFormalBounds(true);
            config.setAllowDataQueries(false);
            config.setStrictEstimateOnly(true);
            config.setMaxIterations(0);

            QueryRewritingAStar search = new QueryRewritingAStar(
                db, new Neo4jStatistics(db, false, true), config, cache);
            RewritingResult result = search.rewriteQuery(
                "MATCH (a:A)-[:R]->(b:B), (c:C)-[:S]->(d:D) RETURN a, b, c, d",
                1L,
                new UserPreferences(),
                50.0,
                WhyMode.WHY_MANY,
                0L,
                1L
            );

            RewritingResult.AStarTrace.Step initial = result.getTrace().getSteps().stream()
                .filter(step -> "INIT".equals(step.operationType))
                .findFirst()
                .orElseThrow();
            assertEquals(Long.MAX_VALUE, initial.boundUpper,
                "a partial component tree must never become a finite certificate");
        }
    }

    private static boolean booleanField(QueryRewritingAStar value, String fieldName) throws Exception {
        Field field = QueryRewritingAStar.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getBoolean(value);
    }

    private static void rebuildWithoutPersistence(DatabaseSchemaCache cache, GraphDatabaseService db) {
        try (Transaction rebuild = db.beginTx()) {
            cache.rebuildSnapshotFromDatabase(rebuild, Map.of(
                "preserve_structure", false,
                "include_common_values", false,
                "include_numeric_ranges", false,
                "include_histograms", false,
                "include_distinct_counts", false,
                "include_properties", true,
                "include_triples", true,
                "persist_snapshot", false
            ));
            rebuild.commit();
        }
    }
}
