package com.whyquery.neo4j.paths;

import com.whyquery.neo4j.Neo4jTestSupport;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
class PathCostAnalyzerTest {

    private GraphDatabaseService db;

    private Transaction tx;

    private Neo4jStatistics statistics;

    private PathCostAnalyzer analyzer;

    @BeforeEach
    void setUp() {
        tx = Neo4jTestSupport.transaction(query -> Neo4jTestSupport.emptyResult());
        db = Neo4jTestSupport.databaseService(() -> tx);
        statistics = new Neo4jStatistics(db);
        analyzer = new PathCostAnalyzer(db, tx, statistics);
    }

    @Test
    void comparePathsComputesPerMetricWinners() {
        PathInstance pathA = path("A", 2, 5.0, "KNOWS", "FRIEND");
        PathInstance pathB = path("B", 3, 4.0, "KNOWS", "KNOWS", "WORKS_WITH");

        PathComparison comparison = analyzer.comparePaths(pathA, pathB, analysis(PathAlgorithmType.VARIABLE_LENGTH));

        assertEquals("A", comparison.getCostMetrics().get("Hop Count").getFavoredPath());
        assertEquals("B", comparison.getCostMetrics().get("Total Cost").getFavoredPath());
        assertNotNull(comparison.getSummary().mostSignificantMetric);
        assertTrue(comparison.getMetricsFavoringA().size() > 0 || comparison.getMetricsFavoringB().size() > 0);
    }

    @Test
    void analyzePathSelectionExplainsWhyShortestPathWasChosen() {
        PathInstance chosenPath = path("chosen", 2, 4.0, "KNOWS", "FRIEND");
        PathInstance alternative = path("alt", 4, 8.0, "KNOWS", "KNOWS", "FRIEND", "FRIEND");

        PathSelectionReason reason = analyzer.analyzePathSelection(
            chosenPath,
            List.of(alternative),
            analysis(PathAlgorithmType.SHORTEST_PATH)
        );

        assertEquals("Minimum hop count", reason.getPrimaryCriterion());
        assertTrue(reason.getDecisiveFactors().contains("Shortest path by hop count"));
        assertEquals(1, reason.getComparisons().size());
        assertTrue(reason.hasAlternatives());
    }

    @Test
    void generateAlternativeStrategiesAddsWeightedVariantWhenQuerySuggestsCosts() {
        PathAnalysis weightedAnalysis = analysis(PathAlgorithmType.VARIABLE_LENGTH);
        weightedAnalysis.setOriginalQuery("MATCH (a)-[:ROAD*1..4]-(b) RETURN a, b // cost");

        List<PathStrategy> strategies = analyzer.generateAlternativeStrategies(weightedAnalysis);

        assertTrue(strategies.stream().anyMatch(strategy -> "hop_count".equals(strategy.getCostFunction())));
        assertTrue(strategies.stream().anyMatch(strategy -> "total_weight".equals(strategy.getCostFunction())));
        assertTrue(strategies.stream().anyMatch(strategy -> "type_diversity".equals(strategy.getCostFunction())));
    }

    private PathAnalysis analysis(PathAlgorithmType type) {
        PathAnalysis analysis = new PathAnalysis();
        analysis.setAlgorithmType(type);
        analysis.setOriginalQuery("MATCH (a)-[*]-(b) RETURN a, b");
        return analysis;
    }

    private PathInstance path(String id, int length, double cost, String... relationshipTypes) {
        PathInstance path = new PathInstance();
        path.setPath(id);
        path.setLength(length);
        path.setCost(cost);
        for (int i = 0; i <= length; i++) {
            path.addNodeId(String.valueOf(i));
        }
        for (String relationshipType : relationshipTypes) {
            path.addRelationshipType(relationshipType);
        }
        return path;
    }
}
