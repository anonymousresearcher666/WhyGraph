package com.whyquery.neo4j;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class SafeLowerBoundEligibilityTest {

    @Test
    void acceptsOnlyThePredicateFreeSingleMatchCore() {
        assertNull(WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
            "MATCH (a:A)-[:R]->(b:B) RETURN a, b"));
    }

    @Test
    void rejectsCardinalityChangingClausesAndAggregations() {
        assertEquals("unsupported_clause:WHERE",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B) WHERE a.p = 1 RETURN a"));
        assertEquals("unsupported_clause:LIMIT",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B) RETURN a LIMIT 1"));
        assertEquals("unsupported_clause:SKIP",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B) RETURN a SKIP 1"));
        assertEquals("unsupported_clause:DISTINCT",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B) RETURN DISTINCT a"));
        assertEquals("unsupported_clause:OPTIONAL",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "OPTIONAL MATCH (a:A)-[:R]->(b:B) RETURN a"));
        assertEquals("aggregation:COUNT",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B) RETURN count(*)"));
        assertEquals("unsupported_clause:DELETE",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B) DELETE b RETURN a"));
    }

    @Test
    void rejectsVariableLengthAndMultipleMatchClauses() {
        assertEquals("variable_length_relationship",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R*1..3]->(b:B) RETURN a"));
        assertEquals("requires_single_match_clause",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B) MATCH (b)-[:S]->(c:C) RETURN a"));
        assertEquals("requires_single_return_clause",
            WhyQueryProcedures.safeLowerBoundSyntaxRejectionReason(
                "MATCH (a:A)-[:R]->(b:B)"));
    }

    @Test
    void rejectsEveryNonExactPatternAtomAndInlinePredicate() {
        QueryGraph multiLabel = graph(List.of("A"), List.of("B", "C"), "R", Map.of(), Map.of());
        assertEquals("node_requires_exactly_one_label",
            WhyQueryProcedures.safeLowerBoundPatternRejectionReason(multiLabel));

        QueryGraph unlabeled = graph(List.of("A"), List.of(), "R", Map.of(), Map.of());
        assertEquals("node_requires_exactly_one_label",
            WhyQueryProcedures.safeLowerBoundPatternRejectionReason(unlabeled));

        QueryGraph untyped = graph(List.of("A"), List.of("B"), null, Map.of(), Map.of());
        assertEquals("relationship_requires_one_fixed_type",
            WhyQueryProcedures.safeLowerBoundPatternRejectionReason(untyped));

        QueryGraph nodeProperty = graph(
            List.of("A"), List.of("B"), "R", Map.of("p", 1L), Map.of());
        assertEquals("inline_node_property_predicate",
            WhyQueryProcedures.safeLowerBoundPatternRejectionReason(nodeProperty));

        QueryGraph relProperty = graph(
            List.of("A"), List.of("B"), "R", Map.of(), Map.of("p", 1L));
        assertEquals("inline_relationship_property_predicate",
            WhyQueryProcedures.safeLowerBoundPatternRejectionReason(relProperty));
    }

    private static QueryGraph graph(List<String> leftLabels, List<String> rightLabels,
                                    String type, Map<String, Object> nodeProperties,
                                    Map<String, Object> relationshipProperties) {
        QueryGraph graph = new QueryGraph();
        graph.addVertex(0, "a", leftLabels, nodeProperties);
        graph.addVertex(1, "b", rightLabels, Map.of());
        graph.addEdge(0, 1, type, relationshipProperties);
        return graph;
    }
}
