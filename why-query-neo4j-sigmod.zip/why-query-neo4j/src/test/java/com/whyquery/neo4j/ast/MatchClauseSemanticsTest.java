package com.whyquery.neo4j.ast;

import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.Transaction;
import org.neo4j.harness.Neo4j;
import org.neo4j.harness.Neo4jBuilders;

import static org.junit.jupiter.api.Assertions.*;

class MatchClauseSemanticsTest {
    @Test
    void regenerationPreservesClauseScopedRelationshipReuseAndBagMultiplicity() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                tx.execute("CREATE (a:A {id:1}), (b:B {id:2}), (a)-[:R]->(b)").close();
                tx.commit();
            }
            String separate = "MATCH (a:A)-[r1:R]->(b:B) MATCH (a)-[r2:R]->(b) "
                + "WHERE a.id = 1 RETURN r1, r2";
            String combined = "MATCH (a:A)-[r1:R]->(b:B), (a)-[r2:R]->(b) RETURN r1, r2";
            CypherAST separateAst = CypherASTBuilder.parseQuery(separate);
            CypherAST combinedAst = CypherASTBuilder.parseQuery(combined);
            assertEquals(2, separateAst.getNodesByType(NodeType.MATCH).size());
            assertEquals(1, combinedAst.getNodesByType(NodeType.MATCH).size());
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                assertEquals(1, tx.execute(separate).stream().count());
                assertEquals(1, tx.execute(separateAst.generateCypher()).stream().count());
                assertEquals(0, tx.execute(combined).stream().count());
                assertEquals(0, tx.execute(combinedAst.generateCypher()).stream().count());
            }
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                tx.execute("MATCH (a:A), (b:B) CREATE (a)-[:R]->(b)").close();
                tx.commit();
            }
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                assertEquals(4, tx.execute(separate).stream().count());
                assertEquals(4, tx.execute(separateAst.generateCypher()).stream().count());
                assertEquals(2, tx.execute(combined).stream().count());
                assertEquals(2, tx.execute(combinedAst.generateCypher()).stream().count());
                CypherAST changed = ASTModificationOperations.deletePredicate(separateAst,
                    separateAst.getNodesByType(NodeType.EQUALS).get(0).getId()).getModifiedAST();
                assertNotNull(changed);
                assertEquals(2, changed.getNodesByType(NodeType.MATCH).size());
                assertEquals(4, tx.execute(changed.generateCypher()).stream().count());
            }
        }
    }

    @Test
    void filtersRemainInScopeAndQuotedWhitespaceSurvives() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                tx.execute("CREATE (:A {id:1, text:'MATCH  WHERE'}), (:B {id:2})").close();
                tx.commit();
            }
            String query = "MATCH (a:A) WHERE a.text = 'MATCH  WHERE' MATCH (b:B) RETURN a, b";
            CypherAST ast = CypherASTBuilder.parseQuery(query);
            ASTNode b = ast.getNodesByType(NodeType.NODE).stream()
                .filter(n -> "b".equals(n.getAttribute("variable"))).findFirst().orElseThrow();
            CypherAST changed = ASTModificationOperations.addPredicate(ast, b.getId(), "id",
                new Object[]{"EQUALS", 2L}).getModifiedAST();
            assertNotNull(changed);
            assertEquals(2, changed.getNodesByType(NodeType.WHERE).size());
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                assertEquals(1, tx.execute(ast.generateCypher()).stream().count());
                assertEquals(1, tx.execute(changed.generateCypher()).stream().count());
            }
            String optional = "MATCH (a:A) OPTIONAL MATCH (b:B) WHERE b.id = 99 "
                + "MATCH (c:A) RETURN a, b, c";
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                assertEquals(tx.execute(optional).stream().collect(java.util.stream.Collectors.toList()),
                    tx.execute(CypherASTBuilder.parseQuery(optional).generateCypher()).stream()
                        .collect(java.util.stream.Collectors.toList()));
            }
        }
    }
}
