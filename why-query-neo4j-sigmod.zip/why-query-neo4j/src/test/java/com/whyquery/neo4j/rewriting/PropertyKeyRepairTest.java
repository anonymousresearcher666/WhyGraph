package com.whyquery.neo4j.rewriting;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class PropertyKeyRepairTest {

    private static final Set<String> PERSON = Set.of("name", "person_id");
    private static final Set<String> POST = Set.of("length", "language", "id", "creationDate");

    @Test
    void transposedKeyIsRepaired() {
        assertEquals(List.of("name"), QueryRewritingAStar.propertyKeyRepairCandidates("naem", PERSON));
        assertEquals(List.of("length"), QueryRewritingAStar.propertyKeyRepairCandidates("lenght", POST));
    }

    @Test
    void caseAndSeparatorVariantsAreRepaired() {
        assertEquals(List.of("name"), QueryRewritingAStar.propertyKeyRepairCandidates("Name", PERSON));
        assertEquals(List.of("person_id"), QueryRewritingAStar.propertyKeyRepairCandidates("personid", PERSON));
    }

    @Test
    void validOrUnrelatedKeysAreNotRepaired() {
        assertTrue(QueryRewritingAStar.propertyKeyRepairCandidates("name", PERSON).isEmpty());
        assertTrue(QueryRewritingAStar.propertyKeyRepairCandidates("wg_missing_property", POST).isEmpty());
        assertTrue(QueryRewritingAStar.propertyKeyRepairCandidates(null, PERSON).isEmpty());
    }

    @Test
    void osaCountsAdjacentTranspositionOnce() {
        assertEquals(1, QueryRewritingAStar.osaDistance("naem", "name"));
        assertEquals(1, QueryRewritingAStar.osaDistance("nmae", "name"));
        assertEquals(3, QueryRewritingAStar.osaDistance("abc", ""));
    }
}
