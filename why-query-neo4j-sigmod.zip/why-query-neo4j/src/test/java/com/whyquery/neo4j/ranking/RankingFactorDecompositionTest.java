package com.whyquery.neo4j.ranking;

import com.whyquery.neo4j.Neo4jTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
class RankingFactorDecompositionTest {

    private GraphDatabaseService db;

    private Transaction tx;

    private RankingFactorDecomposition decomposition;

    @BeforeEach
    void setUp() {
        tx = Neo4jTestSupport.transaction(query -> emptyResult());
        db = Neo4jTestSupport.databaseService(() -> tx);
        decomposition = new RankingFactorDecomposition(db, tx);
    }

    @Test
    void compareEntitiesUsesAscendingFactorValues() {
        RankingAnalysis analysis = ascendingScoreAnalysis();
        tx = Neo4jTestSupport.transaction(query -> {
            if (query.contains("id(m) = 123")) {
                return resultWithValue(1.0);
            }
            if (query.contains("id(m) = 456")) {
                return resultWithValue(3.0);
            }
            return emptyResult();
        });
        decomposition = new RankingFactorDecomposition(db, tx);

        RankingComparison comparison = decomposition.compareEntities("123", "456", analysis);

        assertEquals("A", comparison.getFavoredEntity());
        assertTrue(comparison.isSignificantDifference());
        assertEquals(1, comparison.getFactorsFavoringA().size());
        assertEquals(0, comparison.getFactorsFavoringB().size());
    }

    @Test
    void generateAlternativeCompositionsIncludesOriginalWeightsAndDirectionChanges() {
        RankingAnalysis analysis = ascendingScoreAnalysis();
        RankingFactor tieBreaker = new RankingFactor();
        tieBreaker.setType(RankingFactorType.EXPRESSION);
        tieBreaker.setExpression("id(m)");
        tieBreaker.setDirection("ASC");
        tieBreaker.setWeight(0.5);
        analysis.addRankingFactor(tieBreaker);

        List<RankingComposition> alternatives = decomposition.generateAlternativeCompositions(analysis);

        assertTrue(alternatives.stream().anyMatch(composition -> "Original".equals(composition.getName())));
        assertTrue(alternatives.stream().anyMatch(composition -> composition.getName().startsWith("Emphasize Factor")));
        assertTrue(alternatives.stream().anyMatch(composition -> composition.getName().startsWith("Reverse Factor")));
    }

    private RankingAnalysis ascendingScoreAnalysis() {
        RankingAnalysis analysis = new RankingAnalysis();
        analysis.setOriginalQuery("MATCH (m:Movie) RETURN m ORDER BY m.score ASC");
        analysis.setRankingType(RankingType.EXPLICIT_ORDER_BY);

        RankingFactor factor = new RankingFactor();
        factor.setType(RankingFactorType.PROPERTY);
        factor.setVariable("m");
        factor.setProperty("score");
        factor.setExpression("m.score");
        factor.setDirection("ASC");
        factor.setWeight(1.0);
        analysis.addRankingFactor(factor);
        return analysis;
    }

    private org.neo4j.graphdb.Result resultWithValue(double value) {
        return Neo4jTestSupport.singleRowResult(Map.of("factor_value", value));
    }

    private org.neo4j.graphdb.Result emptyResult() {
        return Neo4jTestSupport.emptyResult();
    }
}
