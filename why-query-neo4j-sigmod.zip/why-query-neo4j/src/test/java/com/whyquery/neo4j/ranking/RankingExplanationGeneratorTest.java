package com.whyquery.neo4j.ranking;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RankingExplanationGeneratorTest {

    private RankingExplanationGenerator generator;

    @BeforeEach
    void setUp() {
        generator = new RankingExplanationGenerator();
    }

    @Test
    void explainRankingAnalysisDescribesExplicitOrderBy() {
        RankingAnalysis analysis = new RankingAnalysis();
        analysis.setOriginalQuery("MATCH (m:Movie) RETURN m.title ORDER BY m.rating DESC");
        analysis.setRankingType(RankingType.EXPLICIT_ORDER_BY);
        analysis.addRankingFactor(factor("m.rating", "DESC", 1.0));

        String explanation = generator.explainRankingAnalysis(analysis);

        assertTrue(explanation.contains("REAL Ranking Analysis"));
        assertTrue(explanation.contains("You're ranking by: m.rating desc"));
        assertTrue(explanation.contains("Good: Using DESC"));
    }

    @Test
    void explainRankingAnalysisFlagsLimitWithoutOrderBy() {
        RankingAnalysis analysis = new RankingAnalysis();
        analysis.setOriginalQuery("MATCH (m:Movie) RETURN m.title LIMIT 5");
        analysis.setRankingType(RankingType.IMPLICIT_LIMIT);

        String explanation = generator.explainRankingAnalysis(analysis);

        assertTrue(explanation.contains("LIMIT without ORDER BY"));
        assertTrue(explanation.contains("Add ORDER BY before LIMIT"));
    }

    @Test
    void explainRankingComparisonSummarizesFavoredEntity() {
        RankingComparison comparison = new RankingComparison("EntityA", "EntityB");
        FactorContribution contribution = new FactorContribution(factor("m.rating", "ASC", 1.0));
        contribution.setValueA(1.0);
        contribution.setValueB(3.0);
        contribution.setContributionDifference(2.0);
        contribution.setFavorsEntity("A");
        comparison.addFactorContribution(contribution);
        comparison.calculateOverallDifference();

        String explanation = generator.explainRankingComparison(comparison);

        assertTrue(explanation.contains("Entity EntityA ranks higher than Entity EntityB"));
        assertTrue(explanation.contains("m.rating"));
        assertTrue(explanation.contains("Summary: 1 factors favor EntityA"));
    }

    @Test
    void generateRankingSuggestionsIncludesAlternativeApproaches() {
        RankingComparison comparison = new RankingComparison("EntityA", "EntityB");
        comparison.calculateOverallDifference();

        RankingComposition original = new RankingComposition("Original");
        original.addFactor(factor("m.rating", "DESC", 1.0));

        RankingComposition reverse = new RankingComposition("Reverse Rating");
        reverse.addFactor(factor("m.rating", "ASC", 1.0));
        reverse.addFactor(factor("id(m)", "ASC", 0.5));

        String suggestions = generator.generateRankingSuggestions(comparison, List.of(original, reverse));

        assertTrue(suggestions.contains("Ranking Improvement Suggestions"));
        assertTrue(suggestions.contains("Alternative Ranking Approaches"));
        assertTrue(suggestions.contains("Original"));
        assertTrue(suggestions.contains("Reverse Rating"));
    }

    private RankingFactor factor(String expression, String direction, double weight) {
        RankingFactor factor = new RankingFactor();
        factor.setType(RankingFactorType.PROPERTY);
        factor.setExpression(expression);
        factor.setDirection(direction);
        factor.setWeight(weight);
        return factor;
    }
}
