package com.whyquery.neo4j.ast;

import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.Transaction;
import org.neo4j.harness.Neo4j;
import org.neo4j.harness.Neo4jBuilders;
import static org.junit.jupiter.api.Assertions.*;

class PredicateRangeExecutionTest {
    @Test
    void rangeRelaxationExecutesAndPreservesEveryOriginalMatch() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                tx.execute("UNWIND [-100, -30, -25, 0, 25, 30, 100] AS v CREATE (:Person {age:v})").close();
                tx.commit();
            }
            String[] operators = {"=", ">", ">=", "<", "<="};
            NodeType[] types = {NodeType.EQUALS, NodeType.GREATER_THAN,
                NodeType.GREATER_THAN_OR_EQUAL, NodeType.LESS_THAN, NodeType.LESS_THAN_OR_EQUAL};
            for (int i = 0; i < operators.length; i++) {
                String query = "MATCH (p:Person) WHERE p.age " + operators[i] + " 30 RETURN p.age AS age";
                CypherAST ast = CypherASTBuilder.parseQuery(query);
                String sourceRendering = ast.generateCypher();
                var result = ASTModificationOperations.relaxProperty(ast,
                    ast.getNodesByType(types[i]).get(0).getId(), new Object[]{25, 35});
                assertTrue(result.isSuccessful(), operators[i]);
                CypherAST changed = result.getModifiedAST();
                if (i == 0) assertTrue(changed.getNodesByType(NodeType.EQUALS).isEmpty(),
                    "Removed equality must not influence key-cap analysis");
                try (Transaction tx = neo4j.defaultDatabaseService().beginTx()) {
                    var original = tx.execute(query).columnAs("age").stream().collect(java.util.stream.Collectors.toList());
                    var rewritten = tx.execute(changed.generateCypher()).columnAs("age").stream().collect(java.util.stream.Collectors.toList());
                    assertTrue(rewritten.containsAll(original), changed.generateCypher());
                    assertFalse(rewritten.isEmpty());
                }
                assertEquals(sourceRendering, ast.generateCypher(), "Transformation must preserve source AST");
            }
        }
    }
}
