package com.whyquery.neo4j.integration;

import com.whyquery.neo4j.Neo4jTestSupport;
import com.whyquery.neo4j.rewriting.RewritingConfig;
import com.whyquery.neo4j.rewriting.QueryRewritingAStar;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class WhyRankPathIntegrationTest {

    private GraphDatabaseService db;

    private Transaction tx;

    private Neo4jStatistics statistics;

    private QueryRewritingAStar astarRewriter;

    private WhyRankPathIntegration integration;

    @BeforeEach
    void setUp() {
        tx = Neo4jTestSupport.transaction(query -> Neo4jTestSupport.emptyResult());
        db = Neo4jTestSupport.databaseService(() -> tx);
        statistics = new StubStatistics(db);
        astarRewriter = new QueryRewritingAStar(db, statistics, new RewritingConfig());
        integration = new WhyRankPathIntegration(db, tx, statistics, astarRewriter);
    }

    @Test
    void analyzeQueryCombinesRankingAnalysisAndOperations() {
        String query = "MATCH (m:Movie) RETURN m.title ORDER BY m.rating DESC LIMIT 10";

        UnifiedAnalysisResult result = integration.analyzeQuery(query, WhyRankPathIntegration.WhyQueryType.WHY_RANK);

        assertTrue(result.isSuccessful());
        assertTrue(result.hasRankingIssues());
        assertFalse(result.hasPathIssues());
        assertFalse(result.getRankingAlternatives().isEmpty());
        assertFalse(result.getModificationOperations().isEmpty());
        assertTrue(result.getUnifiedExplanation().contains("Ranking Analysis"));
    }

    @Test
    void analyzeQueryBuildsPathAlternativesAndSuggestions() {
        String query = "MATCH path = shortestPath((a:Person)-[*]-(b:Person)) " +
            "WHERE a.name = 'Alice' AND b.name = 'Bob' RETURN path";

        UnifiedAnalysisResult result = integration.analyzeQuery(query, WhyRankPathIntegration.WhyQueryType.WHY_PATH);

        assertTrue(result.isSuccessful());
        assertTrue(result.hasPathIssues());
        assertFalse(result.getPathAlternatives().isEmpty());
        assertTrue(result.getUnifiedExplanation().contains("Path Analysis"));
        assertFalse(integration.getImprovementSuggestions(result).isEmpty());
    }

    @Test
    void getSummaryReportsPresentAnalyses() {
        String query = "MATCH path = shortestPath((a:Person)-[*]-(b:Person)) " +
            "WHERE a.name = 'Alice' AND b.name = 'Bob' RETURN path";

        UnifiedAnalysisResult result = integration.analyzeQuery(query, WhyRankPathIntegration.WhyQueryType.WHY_PATH);
        UnifiedAnalysisResult.AnalysisSummary summary = result.getSummary();

        assertEquals(WhyRankPathIntegration.WhyQueryType.WHY_PATH, summary.queryType);
        assertFalse(summary.hasRankingAnalysis);
        assertTrue(summary.hasPathAnalysis);
        assertTrue(summary.pathAlternativeCount > 0);
    }

    private static class StubStatistics extends Neo4jStatistics {
        StubStatistics(GraphDatabaseService db) {
            super(db);
        }

        @Override
        public Set<String> getAllLabels() {
            return Set.of("Person");
        }

        @Override
        public long getNodeCount(String label) {
            return "Person".equals(label) ? 10L : 0L;
        }
    }
}
