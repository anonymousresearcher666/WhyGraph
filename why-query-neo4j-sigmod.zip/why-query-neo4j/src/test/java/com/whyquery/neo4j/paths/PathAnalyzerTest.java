package com.whyquery.neo4j.paths;

import com.whyquery.neo4j.Neo4jTestSupport;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.NodeType;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PathAnalyzerTest {

    private GraphDatabaseService db;

    private Transaction tx;

    private Neo4jStatistics statistics;

    private PathAnalyzer analyzer;

    @BeforeEach
    void setUp() {
        tx = Neo4jTestSupport.transaction(query -> Neo4jTestSupport.emptyResult());
        db = Neo4jTestSupport.databaseService(() -> tx);
        statistics = new Neo4jStatistics(db);
        analyzer = new PathAnalyzer(db, tx, statistics);
    }

    @Test
    void analyzePathsDetectsShortestPathAndSamplesReturnedPaths() {
        String query = "MATCH path = shortestPath((a)-[*]-(b)) " +
            "WHERE a.name = 'Alice' AND b.name = 'Bob' RETURN path";
        CypherAST ast = rootOnlyAst();
        tx = Neo4jTestSupport.transaction(ignored -> Neo4jTestSupport.result(List.of(
            Map.of("path", "p1", "pathLength", 2),
            Map.of("path", "p2", "pathLength", 3)
        )));
        analyzer = new PathAnalyzer(db, tx, statistics);

        PathAnalysis analysis = analyzer.analyzePaths(ast, query);

        assertEquals(PathAlgorithmType.SHORTEST_PATH, analysis.getAlgorithmType());
        assertEquals(2, analysis.getPathPatterns().size());
        PathPattern pattern = analysis.getPatternsByType(PathPatternType.SHORTEST_PATH).get(0);
        assertEquals(PathPatternType.SHORTEST_PATH, pattern.getType());
        assertEquals("a", pattern.getStartVariable());
        assertEquals("b", pattern.getEndVariable());
        assertEquals(2, analysis.getActualPaths().size());
        assertEquals(2, analysis.getPathStatistics().pathCount);
        assertEquals(2, analysis.getPathStatistics().minLength);
        assertEquals(3, analysis.getPathStatistics().maxLength);
    }

    @Test
    void analyzePathsExtractsVariableLengthConstraintsFromQuery() {
        String query = "MATCH (a)-[:KNOWS|FRIEND*2..5]-(b) RETURN a, b";

        PathAnalysis analysis = analyzer.analyzePaths(rootOnlyAst(), query);

        assertEquals(PathAlgorithmType.VARIABLE_LENGTH, analysis.getAlgorithmType());
        assertEquals(1, analysis.getPathPatterns().size());
        PathPattern pattern = analysis.getPathPatterns().get(0);
        assertTrue(pattern.isVariableLength());
        assertEquals(2, pattern.getMinLength());
        assertEquals(5, pattern.getMaxLength());
        assertTrue(analysis.getConstraints().getAllowedRelationshipTypes().contains("KNOWS"));
        assertTrue(analysis.getConstraints().getAllowedRelationshipTypes().contains("FRIEND"));
    }

    @Test
    void calculatePathComplexityIncreasesWithAlgorithmStrength() {
        PathAnalysis simple = new PathAnalysis();
        simple.setAlgorithmType(PathAlgorithmType.SIMPLE_TRAVERSAL);

        PathAnalysis complex = new PathAnalysis();
        complex.setAlgorithmType(PathAlgorithmType.SHORTEST_PATH);
        PathConstraints constraints = new PathConstraints();
        constraints.setMaxLength(12);
        constraints.setWeightProperty("cost");
        complex.setConstraints(constraints);

        assertTrue(analyzer.hasPathPatterns("MATCH path = shortestPath((a)-[*]-(b)) RETURN path"));
        assertFalse(analyzer.hasPathPatterns("MATCH (a:Person) RETURN a"));
        assertTrue(analyzer.calculatePathComplexity(complex) > analyzer.calculatePathComplexity(simple));
    }

    private CypherAST rootOnlyAst() {
        CypherAST ast = new CypherAST();
        String rootId = ast.addNode(NodeType.QUERY, new HashMap<>());
        ast.setRoot(rootId);
        return ast;
    }
}
