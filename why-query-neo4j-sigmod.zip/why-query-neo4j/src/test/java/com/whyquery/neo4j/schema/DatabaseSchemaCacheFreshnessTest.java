package com.whyquery.neo4j.schema;

import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.harness.Neo4j;
import org.neo4j.harness.Neo4jBuilders;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DatabaseSchemaCacheFreshnessTest {

    @Test
    void committedWriteInvalidatesSnapshotUntilExplicitRebuild() {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction write = db.beginTx()) {
                write.execute("CREATE (:A)-[:R]->(:B)");
                write.commit();
            }

            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            rebuildWithoutPersistence(cache, db);
            assertTrue(cache.getSnapshotTransactionId() >= 0L);
            assertEquals(cache.getSnapshotTransactionId(), cache.getCurrentTransactionId());
            assertTrue(cache.isSnapshotFresh());
            assertEquals("fresh", cache.getSnapshotFreshnessStatus());

            try (Transaction write = db.beginTx()) {
                write.execute("CREATE (:A)");
                write.commit();
            }
            assertFalse(cache.isSnapshotFresh());
            assertEquals("transaction_advanced", cache.getSnapshotFreshnessStatus());

            rebuildWithoutPersistence(cache, db);
            assertTrue(cache.isSnapshotFresh());
            assertEquals(cache.getSnapshotTransactionId(), cache.getCurrentTransactionId());
        }
    }

    private static void rebuildWithoutPersistence(DatabaseSchemaCache cache, GraphDatabaseService db) {
        try (Transaction rebuild = db.beginTx()) {
            cache.rebuildSnapshotFromDatabase(rebuild, Map.of(
                "preserve_structure", false,
                "include_common_values", false,
                "include_numeric_ranges", false,
                "include_histograms", false,
                "include_distinct_counts", false,
                "include_properties", true,
                "include_triples", true,
                "persist_snapshot", false
            ));
            rebuild.commit();
        }
    }
}
