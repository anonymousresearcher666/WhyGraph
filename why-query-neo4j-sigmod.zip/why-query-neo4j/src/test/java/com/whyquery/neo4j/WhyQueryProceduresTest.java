package com.whyquery.neo4j;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class WhyQueryProceduresTest {

    private GraphDatabaseService db;

    private Transaction tx;

    private Log log;

    private WhyQueryProcedures procedures;

    @BeforeEach
    void setUp() {
        tx = Neo4jTestSupport.transaction(query -> Neo4jTestSupport.emptyResult());
        db = Neo4jTestSupport.databaseService(() -> tx);
        log = Neo4jTestSupport.log();
        procedures = new WhyQueryProcedures();
        procedures.db = db;
        procedures.tx = tx;
        procedures.log = log;
    }

    @Test
    void explainRankingUsesParsedOrderByClauses() {
        String query = "MATCH (m:Movie) RETURN m.title ORDER BY m.rating DESC LIMIT 5";

        List<WhyQueryProcedures.WhyRankResult> results = procedures.explainRanking(
            query,
            "",
            "",
            Collections.emptyMap()
        ).collect(Collectors.toList());

        assertEquals(1, results.size());
        WhyQueryProcedures.WhyRankResult result = results.get(0);
        assertEquals("success", result.status);
        assertEquals("EXPLICIT_ORDER_BY", result.rankingType);
        assertTrue(result.explanation.contains("You're ranking by: m.rating desc"));
        assertTrue(result.alternativesCount > 0);
        assertNotNull(result.suggestedQuery);
    }

    @Test
    void explainPathReturnsShortestPathAnalysis() {
        String query = "MATCH path = shortestPath((a:Person)-[*]-(b:Person)) " +
            "WHERE a.name = 'Alice' AND b.name = 'Bob' RETURN path";

        List<WhyQueryProcedures.WhyPathResult> results = procedures.explainPath(
            query,
            Collections.emptyMap()
        ).collect(Collectors.toList());

        assertEquals(1, results.size());
        WhyQueryProcedures.WhyPathResult result = results.get(0);
        assertEquals("success", result.status);
        assertEquals("SHORTEST_PATH", result.algorithmType);
        assertTrue(result.explanation.contains("Path Analysis"));
        assertTrue(result.alternativesCount > 0);
        assertTrue(result.complexity >= 6.0);
    }

    @Test
    void explainIntegratedCombinesRankingAnalysis() {
        String query = "MATCH (m:Movie) RETURN m.title ORDER BY m.rating DESC LIMIT 5";

        List<WhyQueryProcedures.WhyIntegratedResult> results = procedures.explainIntegrated(
            query,
            "WHY_RANK",
            Collections.emptyMap()
        ).collect(Collectors.toList());

        assertEquals(1, results.size());
        WhyQueryProcedures.WhyIntegratedResult result = results.get(0);
        assertEquals("success", result.status);
        assertTrue(result.hasRankingIssues);
        assertFalse(result.hasPathIssues);
        assertTrue(result.explanation.contains("Ranking Analysis"));
        assertTrue(result.totalAlternatives > 0);
    }

    @Test
    void multiWitnessAcceptanceRequiresEveryWitness() throws Exception {
        Method accepts = WhyQueryProcedures.class.getDeclaredMethod(
            "likelyRecoversWhyNotTuple", Map.class);
        accepts.setAccessible(true);

        Map<String, Object> partial = Map.of(
            "likely_recovers_missing_item", true,
            "likely_recovers_all_witnesses", false);
        Map<String, Object> complete = Map.of(
            "likely_recovers_missing_item", true,
            "likely_recovers_all_witnesses", true);

        assertFalse((Boolean) accepts.invoke(procedures, partial));
        assertTrue((Boolean) accepts.invoke(procedures, complete));
    }
}
