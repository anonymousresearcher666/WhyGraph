package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.schema.SchemaGraph;
import com.whyquery.neo4j.schema.SchemaPattern;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.harness.Neo4j;
import org.neo4j.harness.Neo4jBuilders;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class MultigraphCertificateTest {
    @Test
    void executedKeyPassBindsARealMatchAndChecksTheRequestedInterval() throws Exception {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction tx = db.beginTx()) {
                tx.execute("CREATE (:A {id:0}), (a:A {id:1}), (b:B {id:2}), "
                    + "(a)-[:R]->(b), (a)-[:R]->(b), (a)-[:R]->(b)").close();
                tx.commit();
            }
            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            try (Transaction tx = db.beginTx()) {
                cache.rebuildSnapshotFromDatabase(tx, Map.of(
                    "preserve_structure", false, "include_common_values", true,
                    "include_distinct_counts", true, "include_properties", true,
                    "include_triples", true, "persist_snapshot", false));
                tx.commit();
            }
            RewritingConfig config = new RewritingConfig();
            config.setUseSchema(true);
            config.setUseFormalBounds(true);
            config.setUsePlannerStats(false);
            config.setAllowDataQueries(true);
            config.setStrictEstimateOnly(false);
            config.setDataDrivenTimeoutSeconds(15);
            QueryRewritingAStar search = new QueryRewritingAStar(db,
                new com.whyquery.neo4j.statistics.Neo4jStatistics(db, false, false), config, cache);
            RewritingResult result = search.rewriteQuery(
                "MATCH (a:A)-[:R]->(b:B) RETURN a, b", 3,
                new UserPreferences(), 50, WhyMode.WHY_MANY, 2, 3);
            assertTrue(result.isSuccess(), result.getErrors().toString());
            assertFalse(result.getModificationSteps().isEmpty());
            try (Transaction tx = db.beginTx()) {
                long n = ((Number) tx.execute("CALL { " + result.getRewrittenQuery()
                    + " } RETURN count(*) AS n").next().get("n")).longValue();
                assertEquals(3, n, "Parallel relationships must remain bag rows");
                assertEquals(n, result.getFinalCardinality());
            }
        }
    }

    @Test
    void certificatesCountRelationshipValuationsNotOnlyNodeAssignments() throws Exception {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction tx = db.beginTx()) {
                tx.execute("CREATE (a:A {id:1}), (b:B {id:2}), (c:C {id:3}), "
                    + "(a)-[:R]->(b), (b)-[:S]->(c), (c)-[:T]->(a), (c)-[:T]->(a), "
                    + "(a)-[:R]->(b), (a)-[:LOOP]->(a), (a)-[:LOOP]->(a)");
                tx.commit();
            }
            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            try (Transaction tx = db.beginTx()) {
                cache.rebuildSnapshotFromDatabase(tx, Map.of(
                    "preserve_structure", false, "include_common_values", true,
                    "include_distinct_counts", true, "include_properties", true,
                    "include_triples", true, "persist_snapshot", false));
                tx.commit();
            }
            assertTrue(cache.isKeyProperty("B", "id"));
            for (boolean calibrated : new boolean[]{false, true}) {
                RewritingConfig config = new RewritingConfig();
                config.setUseSchema(true);
                config.setUseFormalBounds(true);
                config.setUsePlannerStats(false);
                config.setUseCalibratedBounds(calibrated);
                QueryRewritingAStar search = new QueryRewritingAStar(db, null, config, cache);
                String[] patterns = {
                    "MATCH (a:A)-[:R]->(b:B)-[:S]->(c:C)-[:T]->(a)",
                    "MATCH (a:A)-[:R]->(b:B) WHERE b.id = 2",
                    "MATCH (a:A)-[:R]->(b:B), (a)-[:R]->(b)",
                    "MATCH (a:A)-[:LOOP]->(a)",
                    "MATCH (a:A)-[:LOOP]->(a)-[:LOOP]->(a)"
                };
                long[] expected = {4, 2, 2, 2, 2};
                Method build = QueryRewritingAStar.class.getDeclaredMethod("buildSchemaPattern", CypherAST.class);
                build.setAccessible(true);
                Method bound = QueryRewritingAStar.class.getDeclaredMethod("computeFormalBounds",
                    CypherAST.class, SchemaPattern.class, SchemaGraph.SchemaCompatibility.class);
                bound.setAccessible(true);
                for (int i = 0; i < patterns.length; i++) {
                    String query = patterns[i] + " RETURN a";
                    long exact;
                    try (Transaction tx = db.beginTx()) {
                        exact = ((Number)tx.execute(patterns[i] + " RETURN count(*) AS n").next().get("n")).longValue();
                    }
                    assertEquals(expected[i], exact, query);
                    CypherAST ast = CypherASTBuilder.parseQuery(query);
                    SchemaPattern pattern = (SchemaPattern)build.invoke(search, ast);
                    SchemaGraph.SchemaCompatibility compatibility = cache.buildSchemaGraph().analyzeCompatibility(pattern);
                    SchemaGraph.SchemaBounds bounds = (SchemaGraph.SchemaBounds)bound.invoke(search, ast, pattern, compatibility);
                    assertTrue(bounds.getUpperBound() >= exact,
                        query + " exact=" + exact + " upper=" + bounds.getUpperBound());
                }
                CypherAST ast = CypherASTBuilder.parseQuery("MATCH (a:A)-[:R]->(b:B) RETURN a");
                for (String name : new String[]{"whyMode", "minTarget", "maxTarget"}) {
                    Field field = QueryRewritingAStar.class.getDeclaredField(name);
                    field.setAccessible(true);
                    field.set(search, name.equals("whyMode") ? WhyMode.WHY_MANY
                        : name.equals("minTarget") ? 0L : Long.MAX_VALUE);
                }
                Method goal = QueryRewritingAStar.class.getDeclaredMethod("isGoal",
                    CypherAST.class, SchemaGraph.SchemaBounds.class, int.class, long.class);
                goal.setAccessible(true);
                assertFalse((boolean)goal.invoke(search, ast,
                    new SchemaGraph.SchemaBounds(0L, Long.MAX_VALUE), 1, Long.MAX_VALUE));
            }
        }
    }
    @Test
    void unsupportedSemanticsCannotReceiveBagCertificates() throws Exception {
        try (Neo4j neo4j = Neo4jBuilders.newInProcessBuilder().withDisabledServer().build()) {
            GraphDatabaseService db = neo4j.defaultDatabaseService();
            try (Transaction tx = db.beginTx()) {
                tx.execute("CREATE (a:A {id:1}), (c:A {id:3}), (b:B {id:2}), (a)-[:R]->(b), (c)-[:R]->(b)");
                tx.commit();
            }
            DatabaseSchemaCache cache = new DatabaseSchemaCache(db, false);
            try (Transaction tx = db.beginTx()) {
                cache.rebuildSnapshotFromDatabase(tx, Map.of("preserve_structure", false,
                    "include_distinct_counts", true, "include_properties", true,
                    "include_triples", true, "persist_snapshot", false));
                tx.commit();
            }
            assertTrue(cache.isKeyProperty("A", "id"));
            RewritingConfig config = new RewritingConfig();
            config.setUseFormalBounds(true);
            config.setUsePlannerStats(false);
            QueryRewritingAStar search = new QueryRewritingAStar(db, null, config, cache);
            Method semantic = QueryRewritingAStar.class.getDeclaredMethod("checkSemanticConsistency", CypherAST.class);
            semantic.setAccessible(true);
            Object consistent = semantic.invoke(search, CypherASTBuilder.parseQuery("MATCH (a:A) RETURN a"));
            Method impossible = QueryRewritingAStar.class.getDeclaredMethod("isCertifiablyImpossible",
                consistent.getClass(), SchemaGraph.SchemaBounds.class);
            impossible.setAccessible(true);
            assertFalse((boolean) impossible.invoke(search, consistent, new SchemaGraph.SchemaBounds(0, 0)),
                "A zero point estimate cannot certify impossibility for a nonempty label");
            Method build = QueryRewritingAStar.class.getDeclaredMethod("buildSchemaPattern", CypherAST.class);
            build.setAccessible(true);
            Method bound = QueryRewritingAStar.class.getDeclaredMethod("computeFormalBounds",
                CypherAST.class, SchemaPattern.class, SchemaGraph.SchemaCompatibility.class);
            bound.setAccessible(true);
            String disjunction = "MATCH (a:A)-[:R]->(b:B) WHERE a.id = 1 OR a.id = 3 RETURN a";
            try (Transaction tx = db.beginTx()) {
                assertEquals(2, ((Number)tx.execute("MATCH (a:A)-[:R]->(b:B) WHERE a.id = 1 OR a.id = 3 RETURN count(*) AS n").next().get("n")).intValue());
                assertEquals(1L, tx.execute("MATCH (a:A)-[:MISSING]->(b:B) RETURN count(*) AS n").stream().count());
            }
            for (String query : new String[]{disjunction,
                    "MATCH (a:A)-[:R]->(b:B) WHERE NOT a.id = 1 RETURN a",
                    "OPTIONAL MATCH (a:A)-[:MISSING]->(b:B) RETURN a",
                    "MATCH (a:A)-[:MISSING]->(b:B) RETURN count(*)"}) {
                CypherAST ast = CypherASTBuilder.parseQuery(query);
                SchemaPattern pattern = (SchemaPattern)build.invoke(search, ast);
                SchemaGraph.SchemaBounds ceiling = (SchemaGraph.SchemaBounds)bound.invoke(search, ast, pattern,
                    cache.buildSchemaGraph().analyzeCompatibility(pattern));
                assertEquals(Long.MAX_VALUE, ceiling.getUpperBound(), query);
            }
        }
    }

}
