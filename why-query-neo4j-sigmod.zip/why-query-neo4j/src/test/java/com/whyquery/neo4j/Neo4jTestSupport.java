package com.whyquery.neo4j;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;

public final class Neo4jTestSupport {

    private Neo4jTestSupport() {
    }

    public static GraphDatabaseService databaseService(Supplier<Transaction> txSupplier) {
        InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) {
                String name = method.getName();
                if ("beginTx".equals(name)) {
                    return txSupplier.get();
                }
                if ("isAvailable".equals(name)) {
                    return true;
                }
                return defaultValue(method.getReturnType());
            }
        };

        return (GraphDatabaseService) Proxy.newProxyInstance(
            GraphDatabaseService.class.getClassLoader(),
            new Class<?>[]{GraphDatabaseService.class},
            handler
        );
    }

    public static Log log() {
        InvocationHandler handler = (proxy, method, args) -> defaultValue(method.getReturnType());
        return (Log) Proxy.newProxyInstance(
            Log.class.getClassLoader(),
            new Class<?>[]{Log.class},
            handler
        );
    }

    public static Transaction transaction(Function<String, Result> executeHandler) {
        InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) {
                String name = method.getName();
                if ("execute".equals(name) && args != null && args.length > 0 && args[0] instanceof String) {
                    return executeHandler.apply((String) args[0]);
                }
                if ("execute".equals(name) && args != null && args.length > 1 && args[0] instanceof String && args[1] instanceof Map) {
                    return executeHandler.apply((String) args[0]);
                }
                if ("close".equals(name) || "commit".equals(name) || "rollback".equals(name) || "terminate".equals(name)) {
                    return null;
                }
                if ("isOpen".equals(name)) {
                    return true;
                }
                return defaultValue(method.getReturnType());
            }
        };

        return (Transaction) Proxy.newProxyInstance(
            Transaction.class.getClassLoader(),
            new Class<?>[]{Transaction.class},
            handler
        );
    }

    public static Result emptyResult() {
        return result(Collections.emptyList());
    }

    public static Result singleRowResult(Map<String, Object> row) {
        return result(Collections.singletonList(row));
    }

    public static Result result(List<Map<String, Object>> rows) {
        List<Map<String, Object>> storedRows = new ArrayList<>(rows);
        InvocationHandler handler = new InvocationHandler() {
            private int index = 0;

            @Override
            public Object invoke(Object proxy, Method method, Object[] args) {
                String name = method.getName();
                if ("hasNext".equals(name)) {
                    return index < storedRows.size();
                }
                if ("next".equals(name)) {
                    return storedRows.get(index++);
                }
                if ("close".equals(name)) {
                    return null;
                }
                if ("columns".equals(name)) {
                    if (storedRows.isEmpty()) {
                        return Collections.emptyList();
                    }
                    return new ArrayList<>(storedRows.get(0).keySet());
                }
                return defaultValue(method.getReturnType());
            }
        };

        return (Result) Proxy.newProxyInstance(
            Result.class.getClassLoader(),
            new Class<?>[]{Result.class},
            handler
        );
    }

    private static Object defaultValue(Class<?> returnType) {
        if (returnType == boolean.class) {
            return false;
        }
        if (returnType == int.class) {
            return 0;
        }
        if (returnType == long.class) {
            return 0L;
        }
        if (returnType == double.class) {
            return 0.0d;
        }
        if (returnType == float.class) {
            return 0.0f;
        }
        if (returnType == short.class) {
            return (short) 0;
        }
        if (returnType == byte.class) {
            return (byte) 0;
        }
        if (returnType == char.class) {
            return (char) 0;
        }
        if (returnType.isArray()) {
            return Array.newInstance(returnType.getComponentType(), 0);
        }
        return null;
    }
}
