package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.Neo4jTestSupport;
import com.whyquery.neo4j.ast.ASTModificationOperations;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.ast.NodeType;
import com.whyquery.neo4j.schema.SchemaGraph;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class QueryRewritingAStarEnhancementsTest {
    @Test
    void candidateCountBudgetCapsOnlyUncachedDataQueries() throws Exception {
        QueryRewritingAStar search = createRewriter(config -> {
            config.setAllowDataQueries(true);
            config.setStrictEstimateOnly(false);
            config.setMaxCandidateCountCalls(1);
        });
        long first = (long) invokePrivate(search, "countCandidateForGoal",
            new Class<?>[]{String.class, long.class},
            new Object[]{"MATCH (n) RETURN n", 1L});
        long second = (long) invokePrivate(search, "countCandidateForGoal",
            new Class<?>[]{String.class, long.class},
            new Object[]{"MATCH (m) RETURN m", 1L});
        Object diagnostics = getField(search, "diagnostics");
        assertEquals(0L, first, "The mocked empty result should be counted once");
        assertEquals(-1L, second, "An exhausted evidence budget must abstain, not guess");
        assertEquals(1L, ((Number) getField(diagnostics, "candidateCountCalls")).longValue());
        assertEquals(1L, ((Number) getField(diagnostics, "candidateCountBudgetSkips")).longValue());
    }

    @Test
    void boundGatedEvidenceSkipsOnlyWhenFreshFormalUpperBoundProvesImpossibility() throws Exception {
        QueryRewritingAStar search = createRewriter(config -> {
            config.setAllowDataQueries(true);
            config.setStrictEstimateOnly(false);
            config.setUseFormalBounds(true);
            config.setCandidateCountUpperBoundGate(true);
        });
        setField(search, "useFormalBounds", true);
        setField(search, "minTarget", 5L);
        assertFalse((boolean) invokePrivate(search, "shouldAcquireExactCandidateCount",
            new Class<?>[]{SchemaGraph.SchemaBounds.class},
            new Object[]{new SchemaGraph.SchemaBounds(0L, 4L)}));
        assertTrue((boolean) invokePrivate(search, "shouldAcquireExactCandidateCount",
            new Class<?>[]{SchemaGraph.SchemaBounds.class},
            new Object[]{new SchemaGraph.SchemaBounds(0L, 5L)}));
        assertTrue((boolean) invokePrivate(search, "shouldAcquireExactCandidateCount",
            new Class<?>[]{SchemaGraph.SchemaBounds.class}, new Object[]{null}),
            "Unknown bounds must fail open and request exact evidence");
        Object diagnostics = getField(search, "diagnostics");
        assertEquals(1L, ((Number) getField(diagnostics, "candidateCountUpperBoundSkips")).longValue());
    }

    @Test
    void selectiveHistogramRangeSupportsMixedWidthIntegerExtrema() throws Exception {
        QueryRewritingAStar search = createRewriter(c -> {});
        long maximum = 28_000_000_000_000L;
        Object[] range = (Object[]) invokePrivate(search, "calculateSelectiveRange",
            new Class<?>[]{Object.class, Object.class, double.class},
            new Object[]{Integer.valueOf(0), Long.valueOf(maximum), 0.5});
        long lower = ((Number) range[0]).longValue();
        long upper = ((Number) range[1]).longValue();
        assertTrue(lower >= 0 && upper <= maximum, "Endpoints must remain in the histogram domain");
        assertTrue(lower < upper, "A nonempty numeric histogram must not become an inverted interval");
        assertTrue(lower > Integer.MAX_VALUE && upper > Integer.MAX_VALUE,
            "Large LDBC identifiers must retain their 64-bit range");
    }

    @Test
    void keyPredicateAdditionCannotCertifyABoundedUpperBoundDecrease() throws Exception {
        QueryRewritingAStar search = createRewriter(c -> c.setAllowedOperations(
            java.util.Set.of(ModificationOperation.Type.ADD_PREDICATE)));
        Field mode = QueryRewritingAStar.class.getDeclaredField("whyMode");
        mode.setAccessible(true);
        mode.set(search, WhyMode.WHY_MANY);
        assertEquals(false, invokePrivate(search, "certifyGlobalRhoDecrease",
            new Class<?>[]{}, new Object[]{}),
            "A new key equality can reduce the population from millions to one");
    }

    @Test
    void malformedRangeComparisonIsRejectedBeforeItCanBecomeAGoal() {
        CypherAST ast = CypherASTBuilder.parseQuery("MATCH (p:Person) WHERE p.age > 25 RETURN p");
        String comparison = ast.getNodesByType(NodeType.GREATER_THAN).get(0).getId();
        ast.removeNode(ast.getChildren(comparison).get(0).getId());
        assertFalse(ast.validateTransformation().isValid());
    }


    @Test
    void makeOptionalMatchChangesClauseAndPreservesPattern() {
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (p:Person)-[:KNOWS]->(f:Person) RETURN p, f"
        );
        String matchId = ast.getNodesByType(NodeType.MATCH).get(0).getId();

        ASTModificationOperations.ModificationResult result =
            ASTModificationOperations.makeOptionalMatch(ast, matchId);

        assertTrue(result.isSuccessful());
        String rewritten = result.getModifiedAST().generateCypher();
        assertTrue(rewritten.startsWith("OPTIONAL MATCH"));
        assertTrue(rewritten.contains("(p:Person)-[:KNOWS]->(f:Person)"));
        assertTrue(rewritten.contains("RETURN p, f"));
        assertTrue(result.getModifiedAST().validateTransformation().isValid());
    }

    @Test
    void countAndImplicitGroupByRoundTripThroughAst() {
        CypherAST countAst = CypherASTBuilder.parseQuery(
            "MATCH (p:Person) RETURN COUNT(DISTINCT p) AS people"
        );
        assertEquals(1, countAst.getNodesByType(NodeType.COUNT).size());
        assertEquals("MATCH (p:Person) RETURN COUNT(DISTINCT p) AS people", countAst.generateCypher());
        assertTrue(countAst.validateTransformation().isValid());

        CypherAST groupedAst = CypherASTBuilder.parseQuery(
            "MATCH (p:Person)-[:KNOWS]->(f:Person) RETURN p.country, COUNT(f) AS friends"
        );
        assertEquals(
            "MATCH (p:Person)-[:KNOWS]->(f:Person) RETURN p.country, COUNT(f) AS friends",
            groupedAst.generateCypher()
        );
        assertTrue(groupedAst.validateTransformation().isValid());
    }

    @Test
    void histogramThresholdEditPreservesComparisonAndProperty() {
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (p:Person) WHERE p.age > 25 RETURN p"
        );
        String predicateId = ast.getNodesByType(NodeType.GREATER_THAN).get(0).getId();

        ASTModificationOperations.ModificationResult result =
            ASTModificationOperations.replacePredicateThreshold(ast, predicateId, 40.0);

        assertTrue(result.isSuccessful());
        String rewritten = result.getModifiedAST().generateCypher();
        assertTrue(rewritten.contains("p.age > 40"));
        assertFalse(rewritten.contains("p.age > 25"));
    }

    @Test
    void searchDiagnosticsExposeTimersFunnelAndBranchingSummary() {
        RewritingResult.SearchDiagnostics diagnostics = new RewritingResult.SearchDiagnostics();
        diagnostics.plannerCalls = 3;
        diagnostics.plannerTimeNanos = 2_500_000L;
        diagnostics.candidatesGenerated = 9;
        diagnostics.recordBranchingFactor(2);
        diagnostics.recordBranchingFactor(6);
        diagnostics.recordBranchingFactor(4);

        Map<String, Object> summary = diagnostics.asMap();

        assertEquals(3L, summary.get("plannerCalls"));
        assertEquals(2.5, (double) summary.get("plannerTimeMs"), 1e-9);
        assertEquals(9L, summary.get("candidatesGenerated"));
        assertEquals(4.0, (double) summary.get("branchingFactorMedian"), 1e-9);
        assertEquals(6, summary.get("branchingFactorMax"));
    }

    @AfterEach
    void resetSchemaSnapshotOnlyOverride() {
        System.clearProperty("why.schema.snapshot.only");
    }

    @Test
    void ftExecUsesBoundedActualCountWhileEstimateOnlyDoesNotExecute() throws Exception {
        System.setProperty("why.schema.snapshot.only", "false");
        AtomicReference<String> executed = new AtomicReference<>();
        Transaction tx = Neo4jTestSupport.transaction(query -> {
            executed.set(query);
            return Neo4jTestSupport.singleRowResult(Map.of("cnt", 3L));
        });
        GraphDatabaseService db = Neo4jTestSupport.databaseService(() -> tx);
        RewritingConfig execConfig = new RewritingConfig();
        execConfig.setAllowDataQueries(true);
        execConfig.setStrictEstimateOnly(false);
        QueryRewritingAStar exec = new QueryRewritingAStar(
            db, new Neo4jStatistics(db, false, false), execConfig);

        long actual = (long) invokePrivate(
            exec,
            "countCandidateForGoal",
            new Class[]{String.class, long.class},
            new Object[]{"MATCH (n) RETURN n", 4L}
        );
        assertEquals(3L, actual);
        assertTrue(executed.get().contains("LIMIT 4"));

        executed.set(null);
        RewritingConfig strictConfig = new RewritingConfig();
        QueryRewritingAStar strict = new QueryRewritingAStar(
            db, new Neo4jStatistics(db, false, false), strictConfig);
        executed.set(null);
        long blocked = (long) invokePrivate(
            strict,
            "countCandidateForGoal",
            new Class[]{String.class, long.class},
            new Object[]{"MATCH (n) RETURN n", 4L}
        );
        assertEquals(-1L, blocked);
        assertEquals(null, executed.get());
    }

    @Test
    void uncertaintyPenaltyIncreasesGuidedScoreMonotonically() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> {
            config.setUncertaintyAwareSearch(true);
            config.setUncertaintyPenaltyWeight(0.5);
            config.setWeightedAStarWeight(1.0);
        });

        double lowUncertainty = (double) invokePrivate(
            rewriter,
            "calculateGuidedFScore",
            new Class[]{double.class, double.class, double.class},
            new Object[]{2.0, 3.0, 0.0}
        );
        double mediumUncertainty = (double) invokePrivate(
            rewriter,
            "calculateGuidedFScore",
            new Class[]{double.class, double.class, double.class},
            new Object[]{2.0, 3.0, 10.0}
        );
        double highUncertainty = (double) invokePrivate(
            rewriter,
            "calculateGuidedFScore",
            new Class[]{double.class, double.class, double.class},
            new Object[]{2.0, 3.0, 100.0}
        );

        assertEquals(5.0, lowUncertainty, 1e-9);
        assertTrue(mediumUncertainty > lowUncertainty);
        assertTrue(highUncertainty > mediumUncertainty);
    }

    @Test
    void strictTheoremModeOverridesPracticalSearchGuidance() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> {
            config.setStrictTheoremMode(true);
            config.setWeightedAStarWeight(2.5);
            config.setAllowAddLimit(true);
            config.setUseAdmissibleHeuristic(false);
            config.setEnforceConnectedPatterns(false);
            config.setUncertaintyAwareSearch(true);
            config.setLearningGuidanceEnabled(true);
            config.setParetoFrontierEnabled(true);
        });

        assertEquals(1.0, doubleField(rewriter, "heuristicWeight"), 1e-9);
        assertTrue(booleanField(rewriter, "useAdmissibleHeuristic"));
        assertTrue(booleanField(rewriter, "enforceConnectedPatterns"));
        assertFalse(booleanField(rewriter, "allowAddLimit"));
        assertFalse(booleanField(rewriter, "uncertaintyAwareSearch"));
        assertFalse(booleanField(rewriter, "learningGuidanceEnabled"));
        assertFalse(booleanField(rewriter, "paretoFrontierEnabled"));
        assertFalse((boolean) invokePrivate(
            rewriter,
            "mayUseHeuristicFallbacks",
            new Class[]{},
            new Object[]{}
        ));
        double strictScore = (double) invokePrivate(
            rewriter,
            "calculateGuidedFScore",
            new Class[]{double.class, double.class, double.class},
            new Object[]{2.0, 3.0, 1000.0}
        );
        assertEquals(5.0, strictScore, 1e-9);
    }

    @Test
    void frontierOrderChangesOnlyQueueScoreAndStrictModeKeepsAStar() throws Exception {
        QueryRewritingAStar uniform = createRewriter(c -> c.setFrontierOrder("uniform"));
        QueryRewritingAStar greedy = createRewriter(c -> c.setFrontierOrder("greedy"));
        QueryRewritingAStar strict = createRewriter(c -> {
            c.setFrontierOrder("greedy");
            c.setStrictTheoremMode(true);
        });
        Class<?>[] types = {double.class, double.class, double.class};
        Object[] args = {2.0, 3.0, 1000.0};
        assertEquals(2.0, (double)invokePrivate(uniform, "calculateGuidedFScore", types, args));
        assertEquals(3.0, (double)invokePrivate(greedy, "calculateGuidedFScore", types, args));
        assertEquals(5.0, (double)invokePrivate(strict, "calculateGuidedFScore", types, args));
    }

    @Test
    void whyNotAutoModeGeneratesOnlyRelaxations() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> config.setOperationStrategy("AUTO"));
        Field whyModeField = QueryRewritingAStar.class.getDeclaredField("whyMode");
        whyModeField.setAccessible(true);
        whyModeField.set(rewriter, WhyMode.WHY_NOT);
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (p:Person)-[:KNOWS]->(f:Person) WHERE p.age > 30 RETURN p, f"
        );

        List<ModificationOperation> operations = getApplicableOperations(rewriter, ast);

        assertFalse(operations.stream().anyMatch(op ->
            op.getType() == ModificationOperation.Type.ADD_PREDICATE ||
            op.getType() == ModificationOperation.Type.ADD_LABEL ||
            op.getType() == ModificationOperation.Type.ADD_LIMIT
        ));
    }

    @Test
    void learningGuidanceFallsBackUntilMinSupportThenActivates() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> {
            config.setLearningGuidanceEnabled(true);
            config.setLearningGuidanceStrength(0.3);
            config.setLearningMinSupport(3);
        });
        ModificationOperation op = new ModificationOperation(
            ModificationOperation.Type.ADD_PREDICATE,
            "node_1",
            "NRCountry",
            "name",
            new Object[]{"A_Coruna"}
        );

        double noSupport = (double) invokePrivate(
            rewriter,
            "learningGuidanceAdjustment",
            new Class[]{ModificationOperation.class},
            new Object[]{op}
        );
        assertEquals(0.0, noSupport, 1e-9);

        invokePrivate(
            rewriter,
            "updateOperationFeedback",
            new Class[]{ModificationOperation.class, double.class, boolean.class},
            new Object[]{op, 0.2, true}
        );
        invokePrivate(
            rewriter,
            "updateOperationFeedback",
            new Class[]{ModificationOperation.class, double.class, boolean.class},
            new Object[]{op, 0.2, true}
        );

        double belowSupport = (double) invokePrivate(
            rewriter,
            "learningGuidanceAdjustment",
            new Class[]{ModificationOperation.class},
            new Object[]{op}
        );
        assertEquals(0.0, belowSupport, 1e-9);

        invokePrivate(
            rewriter,
            "updateOperationFeedback",
            new Class[]{ModificationOperation.class, double.class, boolean.class},
            new Object[]{op, 0.2, true}
        );

        double withSupport = (double) invokePrivate(
            rewriter,
            "learningGuidanceAdjustment",
            new Class[]{ModificationOperation.class},
            new Object[]{op}
        );
        assertNotEquals(0.0, withSupport, 1e-9);
        assertTrue(withSupport < 0.0);
    }

    @Test
    void paretoFrontierRejectsDominatedAndKeepsBestCandidate() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> config.setParetoFrontierEnabled(true));
        List<Object> frontier = new ArrayList<>();

        QueryAlternative first = candidate("q1", 1, 10, 1.0);
        QueryAlternative dominated = candidate("q2", 2, 10, 2.0);
        QueryAlternative dominating = candidate("q3", 1, 10, 0.5);

        invokePrivate(
            rewriter,
            "addToParetoFrontier",
            new Class[]{List.class, QueryAlternative.class, int.class},
            new Object[]{frontier, first, 10}
        );
        assertEquals(1, frontier.size());

        invokePrivate(
            rewriter,
            "addToParetoFrontier",
            new Class[]{List.class, QueryAlternative.class, int.class},
            new Object[]{frontier, dominated, 10}
        );
        assertEquals(1, frontier.size());

        invokePrivate(
            rewriter,
            "addToParetoFrontier",
            new Class[]{List.class, QueryAlternative.class, int.class},
            new Object[]{frontier, dominating, 10}
        );
        assertEquals(1, frontier.size());

        Object wrapped = frontier.get(0);
        Field alternativeField = wrapped.getClass().getDeclaredField("alternative");
        alternativeField.setAccessible(true);
        QueryAlternative best = (QueryAlternative) alternativeField.get(wrapped);
        assertEquals("q3", best.getRewrittenQuery());
        assertFalse(best.getModifications().isEmpty());
    }

    @Test
    void cycleBackboneKeepsOnlyNonBridgeRelationshipDeletionWhenGlobalDeletionDisabled() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> {
            config.setAllowRelationshipDeletionRelaxation(false);
            config.setAllowUnboundedOps(false);
        });
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (a:Person)-[r1:KNOWS]->(b:Person), " +
            "(b)-[r2:KNOWS]->(c:Person), " +
            "(c)-[r3:KNOWS]->(a) RETURN a"
        );

        List<ModificationOperation> operations = getApplicableOperations(rewriter, ast);

        List<ModificationOperation> relationshipDeletions = new ArrayList<>();
        for (ModificationOperation operation : operations) {
            if (operation.getType() == ModificationOperation.Type.DEL_EDGE ||
                operation.getType() == ModificationOperation.Type.DELETE_RELATIONSHIP) {
                relationshipDeletions.add(operation);
            }
        }
        assertEquals(1, relationshipDeletions.size());
        assertEquals("CYCLE_BACKBONE", relationshipDeletions.get(0).getTargetProperty());
    }

    @Test
    void cycleBackboneDoesNotInventDeletionForAcyclicPattern() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> {
            config.setAllowRelationshipDeletionRelaxation(false);
            config.setAllowUnboundedOps(false);
        });
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (a:Person)-[r1:KNOWS]->(b:Person)-[r2:KNOWS]->(c:Person) RETURN a"
        );

        List<ModificationOperation> operations = getApplicableOperations(rewriter, ast);

        assertFalse(operations.stream().anyMatch(op ->
            op.getType() == ModificationOperation.Type.DEL_EDGE ||
            op.getType() == ModificationOperation.Type.DELETE_RELATIONSHIP
        ));
    }

    @Test
    void cycleBackboneDetectsCyclesAcrossSeparateMatchClauses() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> {
            config.setAllowRelationshipDeletionRelaxation(false);
            config.setAllowUnboundedOps(false);
        });
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (a:NRPerson)-[:ERlivesIn]->(b:NRCountry) " +
            "MATCH (a)-[:ERwasBornIn]->(c:NRCountry) " +
            "MATCH (b)-[:ERisConnectedTo]->(c) RETURN a, b, c"
        );

        List<ModificationOperation> operations = getApplicableOperations(rewriter, ast);

        List<ModificationOperation> cycleRelaxations = new ArrayList<>();
        for (ModificationOperation operation : operations) {
            if ((operation.getType() == ModificationOperation.Type.DEL_EDGE ||
                 operation.getType() == ModificationOperation.Type.DELETE_RELATIONSHIP) &&
                "CYCLE_BACKBONE".equals(operation.getTargetProperty())) {
                cycleRelaxations.add(operation);
            }
        }
        assertEquals(1, cycleRelaxations.size());
    }

    @Test
    void endpointPredicateRelaxationsPreserveRelationshipPatternAndRankSelectiveEndpointFirst() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> config.setAllowUnboundedOps(false));
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (p:NRPerson {name:'Victor_Moore'})-[:ERactedIn]->" +
            "(m:NRMovie {name:'Dangerous_Nan_McGrew'}) RETURN p, m"
        );

        invokePrivate(
            rewriter,
            "normalizeInlineProperties",
            new Class[]{CypherAST.class},
            new Object[]{ast}
        );

        List<ModificationOperation> operations = getApplicableOperations(rewriter, ast);
        List<ModificationOperation> endpointRelaxations = new ArrayList<>();
        for (ModificationOperation operation : operations) {
            if (operation.getType() == ModificationOperation.Type.RELAX_ENDPOINT_PREDICATE) {
                endpointRelaxations.add(operation);
            }
        }

        assertEquals(2, endpointRelaxations.size());
        assertTrue(endpointRelaxations.stream().allMatch(op ->
            "name".equals(op.getTargetProperty()) &&
            op.getRange() != null &&
            "PRESERVE_RELATIONSHIP_PATTERN".equals(op.getRange()[0])
        ));
    }

    @Test
    void endpointLabelRepairRejectsSchemaWildcardSentinel() {
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (p)-[:ERactedIn]->(m) RETURN p, m"
        );
        String nodeId = ast.getNodesByType(NodeType.NODE).get(0).getId();

        ASTModificationOperations.ModificationResult result =
            ASTModificationOperations.repairEndLabel(ast, nodeId, "*");

        assertFalse(result.isSuccessful());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("Replacement label")));
    }

    @Test
    void repairBothEndLabelsSetsBothEndpointsInOneStep() {
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (a:Cat)-[:KNOWS]->(b:Fish) RETURN a, b"
        );
        List<com.whyquery.neo4j.ast.ASTNode> nodes = ast.getNodesByType(NodeType.NODE);
        String firstId = nodes.get(0).getId();
        String secondId = nodes.get(1).getId();

        ASTModificationOperations.ModificationResult result =
            ASTModificationOperations.repairBothEndLabels(ast, firstId, "Person", secondId, "Dog");

        assertTrue(result.isSuccessful());
        String rewritten = result.getModifiedAST().generateCypher();
        assertTrue(rewritten.contains("(a:Person)"));
        assertTrue(rewritten.contains("(b:Dog)"));
        assertEquals(2, result.getChanges().size());
    }

    @Test
    void repairBothEndLabelsRejectsBlankOrWildcardLabels() {
        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (a:Cat)-[:KNOWS]->(b:Fish) RETURN a, b"
        );
        List<com.whyquery.neo4j.ast.ASTNode> nodes = ast.getNodesByType(NodeType.NODE);
        String firstId = nodes.get(0).getId();
        String secondId = nodes.get(1).getId();

        ASTModificationOperations.ModificationResult result =
            ASTModificationOperations.repairBothEndLabels(ast, firstId, "Person", secondId, "*");

        assertFalse(result.isSuccessful());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("Both replacement labels")));
    }

    @Test
    void compoundWrongLabelsSeedsCombinedRepairWhenNoSingleSideFixExists() throws Exception {
        // Only (Person)-[:KNOWS]->(Dog) is a valid triple; the query has BOTH endpoints
        // wrong (Cat, Fish), so holding either side fixed at its wrong value matches no
        // triple in either direction -- neither single-endpoint REPAIR_END_LABEL can be
        // generated, which is exactly the compound-anomaly trap the paper describes.
        QueryRewritingAStar rewriter = createRewriter(config -> {});
        injectSchemaGraph(rewriter, "Person", "KNOWS", "Dog", 1000L);

        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (a:Cat)-[:KNOWS]->(b:Fish) RETURN a, b"
        );
        List<ModificationOperation> operations = getApplicableOperations(rewriter, ast);

        List<ModificationOperation> singleSideRepairs = operations.stream()
            .filter(op -> op.getType() == ModificationOperation.Type.REPAIR_END_LABEL)
            .collect(java.util.stream.Collectors.toList());
        assertTrue(singleSideRepairs.isEmpty(),
            "no single-endpoint repair should exist when both endpoints are simultaneously wrong");

        List<ModificationOperation> combinedRepairs = operations.stream()
            .filter(op -> op.getType() == ModificationOperation.Type.REPAIR_BOTH_END_LABELS)
            .collect(java.util.stream.Collectors.toList());
        assertEquals(1, combinedRepairs.size());
        ModificationOperation combined = combinedRepairs.get(0);
        assertEquals("Person", combined.getTargetLabel());
        assertEquals("Dog", combined.getRange()[1]);

        ASTModificationOperations.ModificationResult applied = ASTModificationOperations.repairBothEndLabels(
            ast, combined.getTargetId(), combined.getTargetLabel(),
            (String) combined.getRange()[0], (String) combined.getRange()[1]
        );
        assertTrue(applied.isSuccessful());
        String rewritten = applied.getModifiedAST().generateCypher();
        assertTrue(rewritten.contains("Person") && rewritten.contains("Dog"));
    }

    @Test
    void singleWrongLabelDoesNotSeedCombinedRepair() throws Exception {
        // Only the target label is wrong; a single-endpoint REPAIR_END_LABEL already
        // reaches a compatible triple, so the combined repair must not also fire --
        // it exists only to cover the case single-endpoint repair cannot reach.
        QueryRewritingAStar rewriter = createRewriter(config -> {});
        injectSchemaGraph(rewriter, "Person", "KNOWS", "Dog", 1000L);

        CypherAST ast = CypherASTBuilder.parseQuery(
            "MATCH (a:Person)-[:KNOWS]->(b:Fish) RETURN a, b"
        );
        List<ModificationOperation> operations = getApplicableOperations(rewriter, ast);

        boolean hasSingleSideRepair = operations.stream()
            .anyMatch(op -> op.getType() == ModificationOperation.Type.REPAIR_END_LABEL);
        assertTrue(hasSingleSideRepair);

        boolean hasCombinedRepair = operations.stream()
            .anyMatch(op -> op.getType() == ModificationOperation.Type.REPAIR_BOTH_END_LABELS);
        assertFalse(hasCombinedRepair);
    }

    @Test
    void countedWhyManyGoalRequiresNonemptyResult() throws Exception {
        QueryRewritingAStar rewriter = createRewriter(config -> {});
        Field mode = QueryRewritingAStar.class.getDeclaredField("whyMode");
        mode.setAccessible(true);
        mode.set(rewriter, WhyMode.WHY_MANY);
        for (String name : new String[]{"minTarget", "maxTarget"}) {
            Field field = QueryRewritingAStar.class.getDeclaredField(name);
            field.setAccessible(true);
            field.setLong(rewriter, name.equals("minTarget") ? 0L : 5L);
        }
        Method goal = QueryRewritingAStar.class.getDeclaredMethod("meetsActualGoal", long.class);
        goal.setAccessible(true);
        assertFalse((boolean)goal.invoke(rewriter, 0L));
        assertTrue((boolean)goal.invoke(rewriter, 1L));
        assertTrue((boolean)goal.invoke(rewriter, 5L));
        assertFalse((boolean)goal.invoke(rewriter, 6L));
        assertFalse((boolean)goal.invoke(rewriter, -1L));
    }

    private void injectSchemaGraph(QueryRewritingAStar rewriter, String sourceLabel, String relType,
                                    String targetLabel, long edgeCount) throws Exception {
        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        Map<String, Long> labelCounts = new HashMap<>();
        triples.put(
            new SchemaGraph.SchemaTriple(sourceLabel, relType, targetLabel),
            new SchemaGraph.TripleStats(edgeCount, 1.0, 1.0, edgeCount, edgeCount, 0.0, 0.0)
        );
        labelCounts.put(sourceLabel, edgeCount);
        labelCounts.put(targetLabel, edgeCount);
        SchemaGraph schemaGraph = new SchemaGraph(triples, labelCounts);

        Field field = QueryRewritingAStar.class.getDeclaredField("schemaGraph");
        field.setAccessible(true);
        field.set(rewriter, schemaGraph);
    }

    private QueryAlternative candidate(String query, int modificationCount, long estimatedRows, double fScore) {
        ModificationOperation op = new ModificationOperation(
            ModificationOperation.Type.ADD_PREDICATE,
            "n",
            "L",
            "p",
            new Object[]{"v"}
        );
        List<ModificationStep> steps = new ArrayList<>();
        for (int i = 0; i < modificationCount; i++) {
            steps.add(new ModificationStep(op, Collections.singletonList("c" + i)));
        }
        return new QueryAlternative(
            query,
            steps,
            estimatedRows,
            1.0,
            modificationCount,
            fScore,
            1,
            "test",
            1L,
            estimatedRows,
            0.1,
            modificationCount
        );
    }

    private QueryRewritingAStar createRewriter(java.util.function.Consumer<RewritingConfig> configCustomizer) {
        System.setProperty("why.schema.snapshot.only", "false");
        Transaction tx = Neo4jTestSupport.transaction(query -> Neo4jTestSupport.emptyResult());
        GraphDatabaseService db = Neo4jTestSupport.databaseService(() -> tx);
        RewritingConfig config = new RewritingConfig();
        configCustomizer.accept(config);
        Neo4jStatistics stats = new Neo4jStatistics(db, false, false);
        return new QueryRewritingAStar(db, stats, config);
    }

    private Object invokePrivate(Object target, String methodName, Class<?>[] paramTypes, Object[] args) throws Exception {
        Method method = target.getClass().getDeclaredMethod(methodName, paramTypes);
        method.setAccessible(true);
        return method.invoke(target, args);
    }

    private boolean booleanField(Object target, String fieldName) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getBoolean(target);
    }

    private Object getField(Object target, String fieldName) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(target);
    }

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private double doubleField(Object target, String fieldName) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getDouble(target);
    }

    @SuppressWarnings("unchecked")
    private List<ModificationOperation> getApplicableOperations(QueryRewritingAStar rewriter, CypherAST ast) throws Exception {
        return (List<ModificationOperation>) invokePrivate(
            rewriter,
            "getApplicableOperations",
            new Class[]{CypherAST.class},
            new Object[]{ast}
        );
    }
}
