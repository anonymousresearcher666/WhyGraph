package com.whyquery.neo4j.ast;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CypherASTBuilderInlinePropertyTest {

    @Test
    void parsesInlineNodeProperties() {
        String query = "MATCH (p:Person {name: 'NonExistent Actor'})-[:ACTED_IN]->(m:Movie {released: 2099}) RETURN p, m";
        CypherAST ast = CypherASTBuilder.parseQuery(query);

        List<ASTNode> nodes = ast.getNodesByType(NodeType.NODE);
        assertEquals(2, nodes.size(), "Expected two pattern nodes");

        boolean personSeen = false;
        boolean movieSeen = false;

        for (ASTNode node : nodes) {
            String variable = node.getAttribute("variable", String.class);
            Map<String, Object> props = node.getAttribute("properties", Map.class);
            if ("p".equals(variable)) {
                personSeen = true;
                assertNotNull(props);
                assertEquals("NonExistent Actor", props.get("name"));
            } else if ("m".equals(variable)) {
                movieSeen = true;
                assertNotNull(props);
                assertEquals(2099L, props.get("released"));
            }
        }

        assertTrue(personSeen, "Person node missing");
        assertTrue(movieSeen, "Movie node missing");
    }

    @Test
    void parsesBooleanWhereFalseAsPredicate() {
        String query = "MATCH (p:Person)-[:KNOWS]->(q:Person) WHERE false RETURN p, q";
        CypherAST ast = CypherASTBuilder.parseQuery(query);

        List<ASTNode> predicates = ast.getNodesByType(NodeType.PREDICATE);

        assertEquals(1, predicates.size());
        assertEquals("false", predicates.get(0).getAttribute("expression", String.class));
        assertTrue(ast.generateCypher().contains("WHERE false"));
    }

    @Test
    void escapesApostrophesInGeneratedStringLiterals() {
        CypherAST ast = CypherASTBuilder.parseQuery("MATCH (p:Person) WHERE p.name = 'placeholder' RETURN p");
        List<ASTNode> whereNodes = ast.getNodesByType(NodeType.WHERE);
        assertEquals(1, whereNodes.size());
        for (ASTNode child : ast.getChildren(whereNodes.get(0).getId())) {
            ast.removeNode(child.getId());
        }

        String equalsId = ast.addNode(NodeType.EQUALS, Map.of());
        String propertyId = ast.addNode(NodeType.PROPERTY, Map.of("variable", "p", "name", "name"));
        String literalId = ast.addNode(NodeType.LITERAL, Map.of("value", "Abd_Allah_ibn_'Amr_ibn_al-'As"));
        ast.addEdge(equalsId, propertyId);
        ast.addEdge(equalsId, literalId);
        ast.addEdge(whereNodes.get(0).getId(), equalsId);

        String cypher = ast.generateCypher();

        assertTrue(cypher.contains("p.name = 'Abd_Allah_ibn_\\'Amr_ibn_al-\\'As'"));
        assertFalse(cypher.contains("''Amr"));
    }
}
