package com.whyquery.neo4j.schema;

import com.whyquery.neo4j.QueryGraph;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Direct tests for {@link SchemaGraph#estimateSafeLowerBound}, the
 * implementation of the paper's Proposition 2 (safe lower bound,
 * predicate-free tree core). Soundness-critical code gets its own tests
 * independent of the live-database integration path.
 */
class SchemaGraphSafeLowerBoundTest {

    private static SchemaGraph.TripleStats stats(long edgeCount, double minOut, double minIn) {
        return new SchemaGraph.TripleStats(edgeCount, 1.0, 1.0, edgeCount, edgeCount, minOut, minIn);
    }

    @Test
    void singleHopForward_usesMinOutDegree() {
        // (p:Person)-[:WORKS_AT]->(c:Company); every Person has >=2 WORKS_AT edges.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "p", List.of("Person"), Map.of());
        qg.addVertex(1, "c", List.of("Company"), Map.of());
        qg.addEdge(0, 1, "WORKS_AT", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("Person", "WORKS_AT", "Company"), stats(1000, 2.0, 5.0));
        Map<String, Long> labelCounts = Map.of("Person", 100L, "Company", 30L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        long bound = graph.estimateSafeLowerBound(pattern, 0, "Person");
        assertEquals(200L, bound); // 100 people * 2 guaranteed WORKS_AT edges each
    }

    @Test
    void singleHopBackward_rootIsTarget_usesMinInDegree() {
        // Root the same pattern at the Company side instead: every Company
        // has >=1 incoming WORKS_AT edge from some Person, so the bound must
        // use min IN-degree here, not min out-degree.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "p", List.of("Person"), Map.of());
        qg.addVertex(1, "c", List.of("Company"), Map.of());
        qg.addEdge(0, 1, "WORKS_AT", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("Person", "WORKS_AT", "Company"), stats(1000, 2.0, 5.0));
        Map<String, Long> labelCounts = Map.of("Person", 100L, "Company", 30L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        long bound = graph.estimateSafeLowerBound(pattern, 1, "Company");
        assertEquals(150L, bound); // 30 companies * 5 guaranteed incoming edges each
    }

    @Test
    void zeroMinDegree_yieldsUninformativeZero_notUnsoundPositive() {
        // Some Person has 0 WORKS_AT edges -- the true minimum is 0, so no
        // positive existence certificate is available, and the method must
        // say so (return 0) rather than silently use a stale/looser number.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "p", List.of("Person"), Map.of());
        qg.addVertex(1, "c", List.of("Company"), Map.of());
        qg.addEdge(0, 1, "WORKS_AT", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("Person", "WORKS_AT", "Company"), stats(1000, 0.0, 5.0));
        Map<String, Long> labelCounts = Map.of("Person", 100L, "Company", 30L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        assertEquals(0L, graph.estimateSafeLowerBound(pattern, 0, "Person"));
    }

    @Test
    void twoHopChain_multipliesAlongTheTree() {
        // (p:Person)-[:WORKS_AT]->(c:Company)-[:LOCATED_IN]->(ct:City)
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "p", List.of("Person"), Map.of());
        qg.addVertex(1, "c", List.of("Company"), Map.of());
        qg.addVertex(2, "ct", List.of("City"), Map.of());
        qg.addEdge(0, 1, "WORKS_AT", Map.of());
        qg.addEdge(1, 2, "LOCATED_IN", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("Person", "WORKS_AT", "Company"), stats(1000, 2.0, 5.0));
        triples.put(new SchemaGraph.SchemaTriple("Company", "LOCATED_IN", "City"), stats(500, 1.0, 10.0));
        Map<String, Long> labelCounts = Map.of("Person", 100L, "Company", 30L, "City", 10L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        long bound = graph.estimateSafeLowerBound(pattern, 0, "Person");
        assertEquals(200L, bound); // 100 * min(2) * min(1); LOCATED_IN's min-out is the binding constraint
    }

    @Test
    void nonTreePattern_withParallelEdge_returnsZero() {
        // (a)-[:R1]->(b), (a)-[:R2]->(b): two edges between the same pair,
        // not a tree -- the method must refuse rather than guess.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "a", List.of("A"), Map.of());
        qg.addVertex(1, "b", List.of("B"), Map.of());
        qg.addEdge(0, 1, "R1", Map.of());
        qg.addEdge(0, 1, "R2", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("A", "R1", "B"), stats(10, 1.0, 1.0));
        triples.put(new SchemaGraph.SchemaTriple("A", "R2", "B"), stats(10, 1.0, 1.0));
        Map<String, Long> labelCounts = Map.of("A", 10L, "B", 10L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        assertEquals(0L, graph.estimateSafeLowerBound(pattern, 0, "A"));
    }

    @Test
    void convergingStar_sharedRelationshipInstance_reviewerCounterexample() {
        // Reviewer counterexample: (x:A)-[:R]->(y:B)<-[:R]-(z:A) over a graph
        // with exactly one A node, one B node, and one R edge between them.
        // Cypher's default relationship-uniqueness (DIFFERENT RELATIONSHIPS)
        // semantics forbid x and z from both binding to that same single R
        // instance, so the query returns 0 rows -- confirmed live against
        // Neo4j. The tree-counting proof, as stated, ignores this and would
        // claim n(B)=1, L(e)=1 for both edges, product=1: an unsound
        // positive. This test is expected to currently FAIL (return 1, not
        // 0) until the method is restricted to reject trees where two edges
        // share a node via the same (relationship type, direction) pair.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "y", List.of("B"), Map.of());
        qg.addVertex(1, "x", List.of("A"), Map.of());
        qg.addVertex(2, "z", List.of("A"), Map.of());
        qg.addEdge(1, 0, "R", Map.of());
        qg.addEdge(2, 0, "R", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("A", "R", "B"), stats(1, 1.0, 1.0));
        Map<String, Long> labelCounts = Map.of("A", 1L, "B", 1L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        assertEquals(0L, graph.estimateSafeLowerBound(pattern, 0, "B"),
            "two tree edges converging on the same node via the same schema triple "
            + "can be forced to share one physical relationship instance under Cypher's "
            + "default DIFFERENT RELATIONSHIPS semantics -- the certificate must refuse, not guess 1");
    }

    @Test
    void nonAdjacentTypeCollision_deeperReviewerCounterexample() {
        // (r)-[:T1]->(a), (r)-[:T3]->(c), (a)-[:T2]->(b), (c)-[:T2]->(d).
        // No single query node has two same-typed edges (T1/T3 differ at r;
        // T1/T2 differ at a; T3/T2 differ at c), so a purely node-local
        // type-disjointness check accepts this tree. But nothing stops
        // query variables a and c -- bound independently via different
        // types T1/T3 -- from resolving to the SAME graph node if r's
        // minimum-degree witness for both types happens to be that one
        // node; once a and c coincide as graph nodes, their downstream T2
        // children compete for the same relationship set, and if that node
        // has only one outgoing T2 edge, b and d are forced onto the same
        // physical relationship. Confirmed live: 0 real rows for this exact
        // shape (one R node, one M node reachable via both T1 and T3, one
        // N node reachable via T2), so any positive bound here is unsound.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "r", List.of("R"), Map.of());
        qg.addVertex(1, "a", List.of("M"), Map.of());
        qg.addVertex(2, "c", List.of("M"), Map.of());
        qg.addVertex(3, "b", List.of("N"), Map.of());
        qg.addVertex(4, "d", List.of("N"), Map.of());
        qg.addEdge(0, 1, "T1", Map.of());
        qg.addEdge(0, 2, "T3", Map.of());
        qg.addEdge(1, 3, "T2", Map.of());
        qg.addEdge(2, 4, "T2", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("R", "T1", "M"), stats(1, 1.0, 1.0));
        triples.put(new SchemaGraph.SchemaTriple("R", "T3", "M"), stats(1, 1.0, 1.0));
        triples.put(new SchemaGraph.SchemaTriple("M", "T2", "N"), stats(1, 1.0, 1.0));
        Map<String, Long> labelCounts = Map.of("R", 1L, "M", 1L, "N", 1L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        assertEquals(0L, graph.estimateSafeLowerBound(pattern, 0, "R"),
            "repeated relationship type T2 appearing twice anywhere in the tree, even at "
            + "non-adjacent nodes reached via different types, can still force a shared "
            + "relationship instance once the intermediate nodes coincide -- must refuse");
    }

    @Test
    void uncollectedMinDegree_returnsZero_notUnsoundGuess() {
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "p", List.of("Person"), Map.of());
        qg.addVertex(1, "c", List.of("Company"), Map.of());
        qg.addEdge(0, 1, "WORKS_AT", Map.of());
        SchemaPattern pattern = SchemaPattern.from(qg);

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        // Old-style TripleStats without min-degree collection (-1.0 sentinel).
        triples.put(new SchemaGraph.SchemaTriple("Person", "WORKS_AT", "Company"),
            new SchemaGraph.TripleStats(1000, 10.0, 3.0, 50.0, 20.0));
        Map<String, Long> labelCounts = Map.of("Person", 100L, "Company", 30L);
        SchemaGraph graph = new SchemaGraph(triples, labelCounts);

        assertEquals(0L, graph.estimateSafeLowerBound(pattern, 0, "Person"));
    }

    @Test
    void conjunctiveLabelOnNonRoot_isRejected() {
        // Separate minima for (A,R,B) and (A,R,C) say nothing about the
        // conjunctive B:C population.  In particular, the two populations
        // may be disjoint and the real query may have no row.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "x", List.of("A"), Map.of());
        qg.addVertex(1, "y", List.of("B", "C"), Map.of());
        qg.addEdge(0, 1, "R", Map.of());

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("A", "R", "B"), stats(10, 1.0, 1.0));
        triples.put(new SchemaGraph.SchemaTriple("A", "R", "C"), stats(10, 1.0, 1.0));
        SchemaGraph graph = new SchemaGraph(triples, Map.of("A", 10L, "B", 10L, "C", 10L));

        assertEquals(0L, graph.estimateSafeLowerBound(SchemaPattern.from(qg), 0, "A"));
    }

    @Test
    void unlabeledNonRoot_isRejected() {
        // A wildcard neighbor cannot inherit the minimum of each known label:
        // it ranges over their union and over nodes with no label at all.
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "x", List.of("A"), Map.of());
        qg.addVertex(1, "y", List.of(), Map.of());
        qg.addEdge(0, 1, "R", Map.of());

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("A", "R", "B"), stats(10, 1.0, 1.0));
        SchemaGraph graph = new SchemaGraph(triples, Map.of("A", 10L, "B", 10L));

        assertEquals(0L, graph.estimateSafeLowerBound(SchemaPattern.from(qg), 0, "A"));
    }

    @Test
    void untypedRelationship_isRejected() {
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "x", List.of("A"), Map.of());
        qg.addVertex(1, "y", List.of("B"), Map.of());
        qg.addEdge(0, 1, null, Map.of());

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("A", "R", "B"), stats(10, 1.0, 1.0));
        SchemaGraph graph = new SchemaGraph(triples, Map.of("A", 10L, "B", 10L));

        assertEquals(0L, graph.estimateSafeLowerBound(SchemaPattern.from(qg), 0, "A"));
    }

    @Test
    void mismatchedRootLabel_isRejected() {
        QueryGraph qg = new QueryGraph();
        qg.addVertex(0, "x", List.of("A"), Map.of());
        qg.addVertex(1, "y", List.of("B"), Map.of());
        qg.addEdge(0, 1, "R", Map.of());

        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = new HashMap<>();
        triples.put(new SchemaGraph.SchemaTriple("A", "R", "B"), stats(10, 1.0, 1.0));
        SchemaGraph graph = new SchemaGraph(triples, Map.of("A", 10L, "Wrong", 999L, "B", 10L));

        assertEquals(0L, graph.estimateSafeLowerBound(SchemaPattern.from(qg), 0, "Wrong"));
    }
}
