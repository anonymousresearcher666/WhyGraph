package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.ast.ASTModificationOperations;
import com.whyquery.neo4j.ast.ASTNode;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.ast.NodeType;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class VasilyevaTopologyAstTest {

    @Test
    void connectedPrefixDeletionKeepsStableAstIdsAndProjection() {
        CypherAST original = CypherASTBuilder.parseQuery(
            "MATCH (v0)-[:ERisConnectedTo]->(v1) "
                + "MATCH (v1)-[:ERowns]->(v2) RETURN v0, v1, v2"
        );
        List<ASTNode> relationships = original.getNodesByType(NodeType.RELATIONSHIP);
        assertEquals(2, relationships.size());
        assertEquals(2, relationships.stream().map(ASTNode::getId).distinct().count());
        for (ASTNode relationship : relationships) {
            assertTrue(original.getNodesByType(NodeType.PATTERN).stream()
                .map(pattern -> original.getChildren(pattern.getId()))
                .anyMatch(children -> children.stream()
                    .anyMatch(child -> relationship.getId().equals(child.getId()))));
        }
        String keptRelationshipId = relationships.get(0).getId();
        String removedRelationshipId = relationships.get(1).getId();
        List<ASTNode> elements = original.getNodesByType(NodeType.PATTERN).stream()
            .map(pattern -> original.getChildren(pattern.getId()))
            .filter(children -> children.stream().anyMatch(child -> keptRelationshipId.equals(child.getId())))
            .findFirst()
            .orElseThrow();
        int keptIndex = -1;
        for (int i = 0; i < elements.size(); i++) {
            if (keptRelationshipId.equals(elements.get(i).getId())) {
                keptIndex = i;
                break;
            }
        }
        assertTrue(keptIndex > 0 && keptIndex < elements.size() - 1);
        Set<String> keptNodeIds = Set.of(elements.get(keptIndex - 1).getId(), elements.get(keptIndex + 1).getId());
        Set<String> keptVariables = Set.of("v0", "v1");

        CypherAST candidate = original.deepCopy();
        assertEquals(
            relationships.stream().map(ASTNode::getId).collect(java.util.stream.Collectors.toSet()),
            candidate.getNodesByType(NodeType.RELATIONSHIP).stream()
                .map(ASTNode::getId).collect(java.util.stream.Collectors.toSet()));
        assertTrue(candidate.getNode(keptRelationshipId) != null);
        ASTModificationOperations.ModificationResult relDeletion =
            ASTModificationOperations.deleteRelationship(candidate, removedRelationshipId);
        assertTrue(relDeletion.isSuccessful());
        candidate = relDeletion.getModifiedAST();

        for (ASTNode node : candidate.getNodesByType(NodeType.NODE)) {
            String variable = node.getAttribute("variable", String.class);
            if (!keptNodeIds.contains(node.getId()) && !keptVariables.contains(variable)) {
                ASTModificationOperations.ModificationResult nodeDeletion =
                    ASTModificationOperations.deleteNode(candidate, node.getId());
                assertTrue(nodeDeletion.isSuccessful());
                candidate = nodeDeletion.getModifiedAST();
            }
        }

        String cypher = candidate.generateCypher();
        assertTrue(cypher.contains("ERisConnectedTo"));
        assertFalse(cypher.contains("ERowns"));
        assertFalse(cypher.contains("v2"));
    }
}
