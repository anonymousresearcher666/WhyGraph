package org.neo4j.whygraph;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.procedure.*;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;

import com.whyquery.neo4j.ast.*;
import com.whyquery.neo4j.rewriting.*;
import com.whyquery.neo4j.rewriting.WhyMode;
import com.whyquery.neo4j.statistics.Neo4jStatistics;

import java.util.*;
import java.util.stream.Stream;

/**
 * WhyGraph Neo4j Plugin - Main Procedures
 * Implements the unified algorithmic framework for why-query explanations
 */
public class WhyGraphProcedures {
    
    @Context
    public GraphDatabaseService db;
    
    @Context
    public Transaction tx;
    
    @Context
    public Log log;
    
    private static Neo4jStatistics statistics;
    private static QueryRewritingAStar rewriter;
    
    /**
     * Initialize the WhyGraph components
     */
    private void initializeIfNeeded() {
        if (statistics == null) {
            statistics = new Neo4jStatistics(db);
            RewritingConfig config = new RewritingConfig();
            rewriter = new QueryRewritingAStar(db, statistics, config);
            log.info("WhyGraph plugin initialized successfully");
        }
    }
    
    /**
     * Main why-query procedure - automatically detects why_empty, why_few, why_many
     * 
     * @param query The Cypher query to analyze
     * @param wantedCardinality Desired number of results (default: auto-detect based on type)
     * @param maxModifications Maximum number of modifications to apply
     * @return Stream of explanation results
     */
    @Procedure(name = "whygraph.explain", mode = Mode.READ)
    @Description("Explain why a query returned unexpected results and suggest modifications to achieve wanted cardinality")
    public Stream<ExplanationResult> explainQuery(
            @Name("query") String query,
            @Name(value = "wantedCardinality", defaultValue = "-1") Long wantedCardinality,
            @Name(value = "maxModifications", defaultValue = "100") Long maxModifications) {
        
        initializeIfNeeded();
        
        try {
            log.info("WhyGraph explaining query: " + query);
            
            // Step 1: Execute the original query to get actual cardinality
            long actualCardinality = getActualCardinality(query);
            log.info("Actual cardinality: " + actualCardinality);
            
            // Step 2: Determine the explanation type and target cardinality
            WhyType whyType;
            long targetCardinality;
            
            if (wantedCardinality > 0) {
                // User specified wanted cardinality - determine type based on comparison
                targetCardinality = wantedCardinality;
                if (actualCardinality == 0 && wantedCardinality > 0) {
                    whyType = WhyType.WHY_EMPTY;
                } else if (actualCardinality < wantedCardinality) {
                    whyType = WhyType.WHY_FEW;
                } else if (actualCardinality > wantedCardinality) {
                    whyType = WhyType.WHY_MANY;
                } else {
                    // actualCardinality == wantedCardinality
                    whyType = WhyType.WHY_SATISFIED;
                }
            } else {
                // Auto-detect based on actual cardinality with smart defaults
                if (actualCardinality == 0) {
                    whyType = WhyType.WHY_EMPTY;
                    targetCardinality = 1; // Default: want at least 1 result
                } else if (actualCardinality < 10) { // Configurable threshold
                    whyType = WhyType.WHY_FEW;
                    targetCardinality = Math.max(actualCardinality * 5, 20); // Default: 5x more or 20
                } else {
                    whyType = WhyType.WHY_MANY;
                    targetCardinality = Math.max(actualCardinality / 5, 1); // Default: 5x less or 1
                }
            }
            
            log.info("Detected type: " + whyType + ", target: " + targetCardinality);
            
            // Step 3: Apply appropriate rewriting strategy
            RewritingResult result = performWhyAnalysis(query, actualCardinality, targetCardinality, whyType, maxModifications);
            
            // Step 4: Get final cardinality (already calculated by A* algorithm)
            long finalCardinality = result.getFinalCardinality();
            // Don't recalculate - the A* algorithm already computed the correct actual cardinality
            
            // Create explanation result
            ExplanationResult explanation = new ExplanationResult();
            explanation.originalQuery = query;
            explanation.actualCardinality = actualCardinality;
            explanation.wantedCardinality = (wantedCardinality > 0) ? wantedCardinality : targetCardinality;
            explanation.targetCardinality = targetCardinality;
            explanation.whyType = whyType.toString();
            explanation.success = result.isSuccess();
            explanation.rewrittenQuery = result.getRewrittenQuery();
            explanation.finalCardinality = finalCardinality; // Use actual final cardinality
            explanation.modifications = (long) result.getModificationSteps().size();
            explanation.iterations = (long) result.getIterations();
            explanation.explanation = result.getExplanation();
            
            if (!result.getErrors().isEmpty()) {
                explanation.errors = String.join("; ", result.getErrors());
            }
            
            if (!result.getWarnings().isEmpty()) {
                explanation.warnings = String.join("; ", result.getWarnings());
            }
            
            // Add modification details
            StringBuilder modDetails = new StringBuilder();
            for (ModificationStep step : result.getModificationSteps()) {
                modDetails.append(step.getDescription()).append(": ");
                modDetails.append(String.join(", ", step.getChanges())).append("\n");
            }
            explanation.modificationDetails = modDetails.toString();
            
            // Add multi-alternative information
            if (!result.getAlternatives().isEmpty()) {
                explanation.alternativeCount = (long) result.getAlternatives().size();
                
                // Rank alternatives by cost
                result.rankAlternatives();
                QueryAlternative bestAlt = result.getBestAlternative();
                if (bestAlt != null) {
                    explanation.bestAlternative = bestAlt.getRewrittenQuery();
                    explanation.bestAlternativeCost = bestAlt.getOverallScore();
                }
                
                // Create summary of all alternatives
                StringBuilder allAlts = new StringBuilder("[");
                for (int i = 0; i < result.getAlternatives().size(); i++) {
                    QueryAlternative alt = result.getAlternatives().get(i);
                    if (i > 0) allAlts.append(", ");
                    allAlts.append("{")
                        .append("\"query\":\"").append(alt.getRewrittenQuery().replace("\"", "\\\"")).append("\", ")
                        .append("\"cardinality\":").append(alt.getActualCardinality()).append(", ")
                        .append("\"cost\":").append(String.format("%.2f", alt.getOverallScore())).append(", ")
                        .append("\"modifications\":\"").append(alt.getModificationSummary().replace("\"", "\\\"")).append("\"")
                        .append("}");
                }
                allAlts.append("]");
                explanation.allAlternatives = allAlts.toString();
            } else {
                explanation.alternativeCount = 0L;
                explanation.allAlternatives = "[]";
            }
            
            log.info("WhyGraph explanation completed: success=" + result.isSuccess() + 
                    ", modifications=" + result.getModificationSteps().size() + 
                    ", alternatives=" + (explanation.alternativeCount != null ? explanation.alternativeCount : 0));
            
            return Stream.of(explanation);
            
        } catch (Exception e) {
            log.error("WhyGraph explanation failed", e);
            
            ExplanationResult errorResult = new ExplanationResult();
            errorResult.originalQuery = query;
            errorResult.success = false;
            errorResult.errors = "WhyGraph error: " + e.getMessage();
            errorResult.explanation = "Failed to generate explanation due to: " + e.getMessage();
            
            return Stream.of(errorResult);
        }
    }
    
    /**
     * Analyze query statistics without rewriting
     */
    @Procedure(name = "whygraph.analyze", mode = Mode.READ)
    @Description("Analyze query statistics and complexity")
    public Stream<AnalysisResult> analyzeQuery(@Name("cypherQuery") String cypherQuery) {
        
        initializeIfNeeded();
        
        try {
            log.info("WhyGraph analyzing query: " + cypherQuery);
            
            // Get query plan statistics
            Neo4jStatistics.QueryPlanStatistics planStats = statistics.getQueryPlanStatistics(cypherQuery);
            
            // Parse query to AST for analysis
            CypherAST ast = CypherASTBuilder.parseQuery(cypherQuery);
            
            AnalysisResult analysis = new AnalysisResult();
            analysis.originalQuery = cypherQuery;
            analysis.estimatedRows = planStats.getEstimatedRows();
            analysis.dbHits = planStats.getDbHits();
            analysis.plannerTime = planStats.getPlannerTime();
            
            // AST analysis
            analysis.nodeCount = (long) ast.getNodesByType(NodeType.NODE).size();
            analysis.relationshipCount = (long) ast.getNodesByType(NodeType.RELATIONSHIP).size();
            analysis.predicateCount = (long) (
                ast.getNodesByType(NodeType.EQUALS).size() +
                ast.getNodesByType(NodeType.GREATER_THAN).size() +
                ast.getNodesByType(NodeType.LESS_THAN).size()
            );
            
            // Variables analysis
            Set<String> variables = ast.getVariables();
            Set<String> boundVars = ast.getBoundVariables();
            Set<String> returnVars = ast.getReturnVariables();
            
            analysis.variableCount = (long) variables.size();
            analysis.boundVariables = String.join(", ", boundVars);
            analysis.returnVariables = String.join(", ", returnVars);
            
            // Validation
            CypherAST.ValidationResult validation = ast.validateAST();
            analysis.isValid = validation.isValid();
            if (!validation.isValid()) {
                analysis.validationErrors = String.join("; ", validation.getErrors());
            }
            
            log.info("WhyGraph analysis completed for query with " + analysis.nodeCount + " nodes");
            
            return Stream.of(analysis);
            
        } catch (Exception e) {
            log.error("WhyGraph analysis failed", e);
            
            AnalysisResult errorResult = new AnalysisResult();
            errorResult.originalQuery = cypherQuery;
            errorResult.isValid = false;
            errorResult.validationErrors = "Analysis error: " + e.getMessage();
            
            return Stream.of(errorResult);
        }
    }
    
    /**
     * Get WhyGraph statistics and cache information
     */
    @Procedure(name = "whygraph.stats", mode = Mode.READ)
    @Description("Get WhyGraph statistics and cache information")
    public Stream<StatisticsResult> getStatistics() {
        
        initializeIfNeeded();
        
        try {
            Neo4jStatistics.CacheStatistics cacheStats = statistics.getCacheStatistics();
            
            StatisticsResult stats = new StatisticsResult();
            stats.cacheSize = cacheStats.getTotalEntries();
            stats.cacheHits = cacheStats.getValidEntries();
            stats.cacheMisses = cacheStats.getExpiredEntries();
            stats.hitRate = cacheStats.getHitRate();
            
            // Get some sample statistics
            stats.totalNodes = statistics.getNodeCount(null);
            stats.totalRelationships = statistics.getRelationshipCount(null);
            
            return Stream.of(stats);
            
        } catch (Exception e) {
            log.error("WhyGraph statistics failed", e);
            
            StatisticsResult errorResult = new StatisticsResult();
            errorResult.error = "Statistics error: " + e.getMessage();
            
            return Stream.of(errorResult);
        }
    }
    
    /**
     * Clear WhyGraph caches
     */
    @Procedure(name = "whygraph.clearCache", mode = Mode.WRITE)
    @Description("Clear WhyGraph statistics cache")
    public Stream<ClearCacheResult> clearCache() {
        
        initializeIfNeeded();
        
        try {
            statistics.clearCache();
            log.info("WhyGraph cache cleared");
            
            ClearCacheResult result = new ClearCacheResult();
            result.success = true;
            result.message = "Cache cleared successfully";
            
            return Stream.of(result);
            
        } catch (Exception e) {
            log.error("WhyGraph cache clear failed", e);
            
            ClearCacheResult errorResult = new ClearCacheResult();
            errorResult.success = false;
            errorResult.error = "Cache clear error: " + e.getMessage();
            
            return Stream.of(errorResult);
        }
    }
    
    /**
     * Get cardinality using both statistics and actual verification for edge cases
     * Uses Neo4j schema and statistics APIs dynamically for ANY query
     */
    private long getActualCardinality(String query) {
        try {
            log.info("Getting cardinality using DB statistics for: " + query);
            
            // First get the basic query plan statistics
            Neo4jStatistics.QueryPlanStatistics planStats = statistics.getQueryPlanStatistics(query);
            
            if (planStats != null) {
                long estimatedRows = planStats.getEstimatedRows();
                log.info("DB statistics estimated rows: " + estimatedRows);
                
                // For better accuracy with equality predicates, analyze using schema statistics
                long refinedCardinality = refineCardinalityUsingSchemaStats(query, estimatedRows);
                
                // IMPORTANT: If statistics suggest > 0 but our refined analysis suggests 0, 
                // trust the refined analysis (it's based on actual schema checking)
                if (estimatedRows > 0 && refinedCardinality == 0) {
                    log.info("Statistics vs refined cardinality mismatch - using refined analysis (more accurate)");
                    return refinedCardinality;
                }
                
                log.info("Refined cardinality: " + refinedCardinality);
                return refinedCardinality;
            }
            
            log.warn("Could not get query plan statistics, returning 0");
            return 0;
            
        } catch (Exception e) {
            log.error("Database statistics failed: " + e.getMessage(), e);
            return 0;
        }
    }
    
    
    /**
     * Refine cardinality using AST analysis with Neo4j schema and statistics
     * Check each AST node and edge against actual database schema
     */
    private long refineCardinalityUsingSchemaStats(String query, long baseEstimate) {
        try {
            // Parse query to AST
            CypherAST ast = CypherASTBuilder.parseQuery(query);
            
            // Calculate actual cardinality by analyzing each AST component
            return calculateCardinalityFromAST(ast, baseEstimate);
            
        } catch (Exception e) {
            log.debug("Could not refine cardinality using AST analysis", e);
            return baseEstimate;
        }
    }
    
    /**
     * Calculate cardinality by analyzing AST nodes against database statistics
     */
    private long calculateCardinalityFromAST(CypherAST ast, long baseEstimate) {
        try {
            double totalSelectivity = 1.0;
            
            // Analyze all nodes in the AST
            for (ASTNode node : ast.getAllNodes()) {
                switch (node.getType()) {
                    case NODE:
                        double nodeSelectivity = calculateNodeSelectivity(node);
                        totalSelectivity *= nodeSelectivity;
                        break;
                        
                    case EQUALS:
                    case GREATER_THAN:
                    case LESS_THAN:
                        double predicateSelectivity = calculatePredicateSelectivity(node, ast);
                        totalSelectivity *= predicateSelectivity;
                        break;
                        
                    case RELATIONSHIP:
                        double relSelectivity = calculateRelationshipSelectivity(node);
                        totalSelectivity *= relSelectivity;
                        break;
                }
                
                // If any component has zero selectivity, the whole query returns 0
                if (totalSelectivity == 0.0) {
                    log.info("Zero selectivity detected in AST analysis");
                    return 0;
                }
            }
            
            // Apply total selectivity to base estimate
            long refinedEstimate = Math.round(baseEstimate * totalSelectivity);
            log.info("AST-based selectivity: " + totalSelectivity + ", refined estimate: " + refinedEstimate);
            
            return refinedEstimate;
            
        } catch (Exception e) {
            log.debug("Error in AST cardinality calculation", e);
            return baseEstimate;
        }
    }
    
    /**
     * Calculate selectivity for a node using database statistics
     */
    private double calculateNodeSelectivity(ASTNode node) {
        try {
            // Get labels from node
            List<String> labels = node.getAttribute("labels", List.class);
            if (labels == null || labels.isEmpty()) {
                return 1.0; // No label constraint
            }
            
            // Check if labels exist in database schema
            double selectivity = 1.0;
            for (String label : labels) {
                long labelCount = statistics.getNodeCount(label);
                long totalNodes = statistics.getNodeCount(null); // Total nodes
                
                if (labelCount == 0) {
                    log.info("Label '" + label + "' has zero nodes in database");
                    return 0.0; // Label doesn't exist
                }
                
                // Calculate label selectivity
                double labelSelectivity = totalNodes > 0 ? (double) labelCount / totalNodes : 0.0;
                selectivity *= labelSelectivity;
                
                log.info("Label '" + label + "' selectivity: " + labelSelectivity + " (" + labelCount + "/" + totalNodes + ")");
            }
            
            return selectivity;
            
        } catch (Exception e) {
            log.debug("Error calculating node selectivity", e);
            return 1.0;
        }
    }
    
    /**
     * Calculate selectivity for a predicate using property statistics
     */
    private double calculatePredicateSelectivity(ASTNode predicate, CypherAST ast) {
        try {
            // Find the property and value nodes connected to this predicate
            List<String> children = ast.getEdges().get(predicate.getId());
            if (children == null || children.size() < 2) {
                return 1.0;
            }
            
            // Analyze left and right sides of predicate
            ASTNode leftNode = ast.getNode(children.get(0));
            ASTNode rightNode = ast.getNode(children.get(1));
            
            if (leftNode != null && leftNode.getType() == NodeType.PROPERTY &&
                rightNode != null && rightNode.getType() == NodeType.LITERAL) {
                
                // Extract property info
                String variable = leftNode.getAttribute("variable", String.class);
                String propertyName = leftNode.getAttribute("name", String.class);
                Object value = rightNode.getAttribute("value", Object.class);
                
                if (variable != null && propertyName != null && value != null) {
                    // Find the label(s) for this variable by traversing AST
                    Set<String> variableLabels = findLabelsForVariable(ast, variable);
                    
                    if (!variableLabels.isEmpty()) {
                        return calculatePropertyValueSelectivity(variableLabels, propertyName, value);
                    }
                }
            }
            
            return 1.0; // Default if can't analyze
            
        } catch (Exception e) {
            log.debug("Error calculating predicate selectivity", e);
            return 1.0;
        }
    }
    
    /**
     * Calculate selectivity for relationship using database statistics
     */
    private double calculateRelationshipSelectivity(ASTNode relationship) {
        try {
            String relType = relationship.getAttribute("type", String.class);
            if (relType == null) {
                return 1.0; // No type constraint
            }
            
            // Check relationship type statistics
            long relCount = statistics.getRelationshipCount(relType);
            if (relCount == 0) {
                log.info("Relationship type '" + relType + "' has zero instances in database");
                return 0.0;
            }
            
            // Calculate relationship selectivity (simplified)
            return 1.0; // For now, assume relationship exists if type exists
            
        } catch (Exception e) {
            log.debug("Error calculating relationship selectivity", e);
            return 1.0;
        }
    }
    
    /**
     * Find labels associated with a variable in the AST
     */
    private Set<String> findLabelsForVariable(CypherAST ast, String variable) {
        Set<String> labels = new HashSet<>();
        
        for (ASTNode node : ast.getAllNodes()) {
            if (node.getType() == NodeType.NODE) {
                String nodeVariable = node.getAttribute("variable", String.class);
                if (variable.equals(nodeVariable)) {
                    List<String> nodeLabels = node.getAttribute("labels", List.class);
                    if (nodeLabels != null) {
                        labels.addAll(nodeLabels);
                    }
                }
            }
        }
        
        return labels;
    }
    
    /**
     * Calculate selectivity for a specific property value using database statistics
     */
    private double calculatePropertyValueSelectivity(Set<String> labels, String propertyName, Object value) {
        try {
            double minSelectivity = 1.0;
            
            for (String label : labels) {
                // Get property selectivity from database statistics
                double propertySelectivity = statistics.getPropertySelectivity(label, propertyName);
                
                log.info("Property selectivity for " + label + "." + propertyName + ": " + propertySelectivity);
                
                // If property selectivity is 0, this property doesn't exist for this label
                if (propertySelectivity == 0.0) {
                    log.info("Property '" + propertyName + "' doesn't exist for label '" + label + "'");
                    return 0.0;
                }
                
                // Use Neo4j statistics API to get specific value selectivity  
                if (value != null) {
                    // Get value-specific selectivity using Neo4j statistics API
                    double valueSelectivity = statistics.getValueSelectivity(label, propertyName, value);
                    log.info("Value selectivity for " + value + " in " + label + "." + propertyName + ": " + valueSelectivity);
                    
                    // Apply value selectivity to property selectivity
                    propertySelectivity *= valueSelectivity;
                    
                    // If value selectivity is 0, this means the value likely doesn't exist
                    if (valueSelectivity == 0.0) {
                        log.info("Value '" + value + "' likely doesn't exist for " + label + "." + propertyName);
                        return 0.0;
                    }
                }
                
                minSelectivity = Math.min(minSelectivity, propertySelectivity);
            }
            
            return minSelectivity;
            
        } catch (Exception e) {
            log.debug("Error calculating property value selectivity", e);
            return 1.0;
        }
    }
    
    
    /**
     * Perform why analysis based on the detected type
     */
    private RewritingResult performWhyAnalysis(String query, long actualCardinality, long targetCardinality, WhyType whyType, Long maxModifications) {
        // Create user preferences based on why type
        UserPreferences userPrefs;
        RewritingConfig config = new RewritingConfig();
        config.setMaxIterations(maxModifications.intValue());
        config.setMaxAlternatives(5); // Enable multi-alternative collection
        
        switch (whyType) {
            case WHY_EMPTY:
                // For empty results, prefer relaxing constraints - BE AGGRESSIVE!
                userPrefs = UserPreferences.createMinimalChanges(); 
                config.setModificationThreshold(1000.0); // VERY aggressive - allow lots of changes
                config.setMaxIterations(Math.max(maxModifications.intValue(), 50)); // Ensure enough iterations
                config.setOperationStrategy("RELAX_ONLY"); // Only relaxation operations
                break;
                
            case WHY_FEW:
                // For few results, moderate relaxation
                userPrefs = UserPreferences.createMinimalChanges();
                config.setModificationThreshold(75.0);
                config.setOperationStrategy("RELAX_ONLY"); // Only relaxation operations
                break;
                
            case WHY_MANY:
                // For many results, prefer adding constraints
                userPrefs = UserPreferences.createMinimalChanges();
                config.setModificationThreshold(50.0);
                config.setOperationStrategy("RESTRICT_ONLY"); // Only restriction operations
                break;
                
            case WHY_SATISFIED:
                // Query already returns wanted cardinality - no modifications needed
                return createSatisfiedResult(query, actualCardinality, targetCardinality);
                
            default:
                userPrefs = UserPreferences.createMinimalChanges();
                config.setModificationThreshold(50.0);
                config.setOperationStrategy("AUTO"); // Both types
        }
        
        // Create rewriter with appropriate config
        QueryRewritingAStar rewriter = new QueryRewritingAStar(db, statistics, config);
        
        // Perform query rewriting
        WhyMode mode = mapWhyMode(whyType);
        long minRange = mode == WhyMode.WHY_FEW ? Math.max(1, targetCardinality) : 0;
        long maxRange = mode == WhyMode.WHY_FEW ? Math.max(minRange, targetCardinality) : targetCardinality;

        return rewriter.rewriteQuery(
            query,
            targetCardinality,
            userPrefs,
            config.getModificationThreshold(),
            mode,
            minRange,
            maxRange
        );
    }
    
    /**
     * Create result for satisfied queries (no modifications needed)
     */
    private RewritingResult createSatisfiedResult(String query, long actualCardinality, long targetCardinality) {
        // Create a successful result with no modifications
        RewritingResult result = new RewritingResult();
        result.setSuccess(true);
        result.setRewrittenQuery(query); // Same query
        result.setFinalCardinality(actualCardinality);
        result.setIterations(0);
        result.setExplanation("Query already returns the desired cardinality. No modifications needed.");
        return result;
    }
    
    /**
     * Why-query types enum
     */
    public enum WhyType {
        WHY_EMPTY,      // Query returns no results
        WHY_FEW,        // Query returns too few results  
        WHY_MANY,       // Query returns too many results
        WHY_SATISFIED   // Query returns exactly the wanted cardinality
    }

    private WhyMode mapWhyMode(WhyType type) {
        switch (type) {
            case WHY_FEW:
                return WhyMode.WHY_FEW;
            case WHY_MANY:
                return WhyMode.WHY_MANY;
            default:
                return WhyMode.WHY_EMPTY;
        }
    }
    
    /**
     * Why Empty Enhanced: Explain why a query returns no results and provide alternatives
     */
    @Procedure(name = "whygraph.why_empty", mode = Mode.READ)
    @Description("Explain why a query returns empty results with multiple alternatives")
    public Stream<ExplanationResult> whyEmptyEnhanced(
            @Name("query") String query,
            @Name(value = "targetCardinality", defaultValue = "10") Long targetCardinality) {
        
        return explainQuery(query, targetCardinality, 100L);
    }
    
    /**
     * Why So Few Enhanced: Explain why a query returns fewer results than expected
     */
    @Procedure(name = "whygraph.why_so_few", mode = Mode.READ)
    @Description("Explain why a query returns so few results with multiple alternatives")
    public Stream<ExplanationResult> whySoFewEnhanced(
            @Name("query") String query,
            @Name("expectedCardinality") Long expectedCardinality) {
        
        return explainQuery(query, expectedCardinality, 100L);
    }
    
    /**
     * Why So Many Enhanced: Explain why a query returns more results than expected
     */
    @Procedure(name = "whygraph.why_so_many", mode = Mode.READ)
    @Description("Explain why a query returns so many results with multiple alternatives")
    public Stream<ExplanationResult> whySoManyEnhanced(
            @Name("query") String query,
            @Name("expectedCardinality") Long expectedCardinality) {
        
        return explainQuery(query, expectedCardinality, 100L);
    }

    /**
     * Get multiple query rewriting alternatives with cost ranking
     */
    @Procedure(name = "whygraph.get_query_alternatives", mode = Mode.READ)
    @Description("Get multiple query rewriting alternatives with cost ranking")
    public Stream<QueryAlternativeResult> getQueryAlternatives(
            @Name("query") String cypherQuery,
            @Name(value = "maxAlternatives", defaultValue = "5") Long maxAlternatives) {
        
        initializeIfNeeded();
        
        try {
            log.info("Getting query alternatives for: " + cypherQuery);
            
            // Configure rewriting with multiple alternatives
            RewritingConfig config = new RewritingConfig();
            config.setMaxAlternatives(maxAlternatives.intValue());
            
            // Create query rewriter
            QueryRewritingAStar rewriter = new QueryRewritingAStar(db, statistics, config);
            
            // Run rewriting to get alternatives
            RewritingResult result = rewriter.rewriteQuery(
                cypherQuery,
                10,
                null,
                1000.0,
                WhyMode.WHY_EMPTY,
                0,
                0
            );
            
            if (result.isSuccess() && !result.getAlternatives().isEmpty()) {
                // Rank alternatives by cost
                result.rankAlternatives();
                
                return result.getAlternatives().stream().map(alt -> {
                    QueryAlternativeResult qar = new QueryAlternativeResult();
                    qar.rewrittenQuery = alt.getRewrittenQuery();
                    qar.actualCardinality = alt.getActualCardinality();
                    qar.performanceCost = alt.getPerformanceCost();
                    qar.semanticDistance = alt.getSemanticDistance();
                    qar.dbHits = alt.getDbHits();
                    qar.executionTimeEstimate = alt.getExecutionTimeEstimate();
                    qar.modificationComplexity = alt.getModificationComplexity();
                    qar.overallScore = alt.getOverallScore();
                    qar.modifications = alt.getModificationSummary();
                    qar.costSummary = alt.getCostSummary();
                    return qar;
                });
            } else {
                QueryAlternativeResult errorResult = new QueryAlternativeResult();
                errorResult.rewrittenQuery = "No alternatives found";
                errorResult.modifications = "Query rewriting failed";
                errorResult.costSummary = result.getErrors().toString();
                return Stream.of(errorResult);
            }
            
        } catch (Exception e) {
            log.error("Failed to get query alternatives", e);
            QueryAlternativeResult errorResult = new QueryAlternativeResult();
            errorResult.rewrittenQuery = "Error occurred";
            errorResult.modifications = "Exception: " + e.getMessage();
            errorResult.costSummary = e.toString();
            return Stream.of(errorResult);
        }
    }

    /**
     * Result classes for procedures
     */
    public static class ExplanationResult {
        public String originalQuery;
        public Long actualCardinality;
        public Long wantedCardinality;
        public Long targetCardinality;
        public String whyType;
        public Boolean success;
        public String rewrittenQuery;
        public Long finalCardinality;
        public Long modifications;
        public Long iterations;
        public String explanation;
        public String modificationDetails;
        public String errors;
        public String warnings;
        
        // Multi-alternative support
        public Long alternativeCount;
        public String bestAlternative;
        public Double bestAlternativeCost;
        public String allAlternatives; // JSON-like string with all alternatives
    }
    
    public static class AnalysisResult {
        public String originalQuery;
        public Long estimatedRows;
        public Long dbHits;
        public Long plannerTime;
        public Long nodeCount;
        public Long relationshipCount;
        public Long predicateCount;
        public Long variableCount;
        public String boundVariables;
        public String returnVariables;
        public Boolean isValid;
        public String validationErrors;
    }
    
    public static class StatisticsResult {
        public Long cacheSize;
        public Long cacheHits;
        public Long cacheMisses;
        public Double hitRate;
        public Long totalNodes;
        public Long totalRelationships;
        public String error;
    }
    
    public static class ClearCacheResult {
        public Boolean success;
        public String message;
        public String error;
    }
    
    public static class QueryAlternativeResult {
        public String rewrittenQuery;
        public Long actualCardinality;
        public Double performanceCost;
        public Double semanticDistance;
        public Long dbHits;
        public Double executionTimeEstimate;
        public Double modificationComplexity;
        public Double overallScore;
        public String modifications;
        public String costSummary;
    }
}
