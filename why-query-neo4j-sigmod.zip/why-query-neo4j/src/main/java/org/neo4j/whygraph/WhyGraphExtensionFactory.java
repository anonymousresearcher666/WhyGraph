package org.neo4j.whygraph;

import org.neo4j.annotations.service.ServiceProvider;
import org.neo4j.kernel.extension.ExtensionFactory;
import org.neo4j.kernel.extension.ExtensionType;
import org.neo4j.kernel.extension.context.ExtensionContext;
import org.neo4j.kernel.lifecycle.Lifecycle;
import org.neo4j.kernel.lifecycle.LifecycleAdapter;
import org.neo4j.logging.Log;
import org.neo4j.logging.internal.LogService;

/**
 * WhyGraph Extension Factory for Neo4j plugin registration
 */
@ServiceProvider
public class WhyGraphExtensionFactory extends ExtensionFactory<WhyGraphExtensionFactory.Dependencies> {
    
    public interface Dependencies {
        LogService logService();
    }
    
    public WhyGraphExtensionFactory() {
        super(ExtensionType.GLOBAL, "whygraph");
    }
    
    @Override
    public Lifecycle newInstance(ExtensionContext context, Dependencies dependencies) {
        return new LifecycleAdapter() {
            private Log log;
            
            @Override
            public void init() {
                log = dependencies.logService().getInternalLog(WhyGraphExtensionFactory.class);
                log.info("WhyGraph extension initializing...");
            }
            
            @Override
            public void start() {
                log.info("WhyGraph plugin loaded successfully - procedures should be available");
            }

            @Override
            public void stop() {
                if (log != null) {
                    log.info("WhyGraph plugin stopped");
                }
            }
        };
    }
}