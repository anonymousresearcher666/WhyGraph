package com.whyquery.v2;

import com.whyquery.neo4j.CypherASTQueryGraphParser;
import com.whyquery.neo4j.QueryGraph;
import com.whyquery.neo4j.ast.ASTNode;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.ast.NodeType;
import com.whyquery.neo4j.rewriting.QueryRewritingAStar;
import com.whyquery.neo4j.rewriting.RewritingConfig;
import com.whyquery.neo4j.rewriting.RewritingResult;
import com.whyquery.neo4j.rewriting.UserPreferences;
import com.whyquery.neo4j.rewriting.WhyMode;
import com.whyquery.neo4j.rewriting.ModificationOperation;
import com.whyquery.neo4j.rewriting.ModificationStep;
import com.whyquery.neo4j.rewriting.EstimatorConfidenceModel;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.neo4j.graphdb.ExecutionPlanDescription;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.logging.Log;
import org.neo4j.procedure.Context;
import org.neo4j.procedure.Description;
import org.neo4j.procedure.Mode;
import org.neo4j.procedure.Name;
import org.neo4j.procedure.Procedure;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * WhyGraph v2 procedures.
 *
 * This class introduces a clean API namespace (`why2.*`) while reusing validated
 * lower-level components (schema cache, statistics cache, A* rewriting engine).
 * It does not replace v1 procedures and can run in parallel.
 */
public class Why2Procedures {

    @Context
    public GraphDatabaseService db;

    @Context
    public Transaction tx;

    @Context
    public Log log;

    private static final AtomicReference<DatabaseSchemaCache> SCHEMA_CACHE = new AtomicReference<>();
    private static final AtomicReference<Neo4jStatistics> STATS = new AtomicReference<>();
    private static final EstimatorConfidenceModel CI_MODEL = EstimatorConfidenceModel.loadFromConfiguredPath();

    @Procedure(value = "why2.not", mode = Mode.READ)
    @Description("Why-Not v2: query + witness/witnesses + schema-aware A* rewriting with trace.")
    public Stream<Why2Result> why2Not(
        @Name("query") String query,
        @Name("target") Map<String, Object> target,
        @Name(value = "options", defaultValue = "{}") Map<String, Object> options
    ) {
        return Stream.of(runWhy(WhyMode.WHY_NOT, query, target, options));
    }

    @Procedure(value = "why2.empty", mode = Mode.READ)
    @Description("Why-Empty v2: schema-aware A* rewriting for empty result explanations.")
    public Stream<Why2Result> why2Empty(
        @Name("query") String query,
        @Name(value = "options", defaultValue = "{}") Map<String, Object> options
    ) {
        return Stream.of(runWhy(WhyMode.WHY_EMPTY, query, Collections.emptyMap(), options));
    }

    @Procedure(value = "why2.few", mode = Mode.READ)
    @Description("Why-Few v2: schema-aware A* rewriting targeting a lower cardinality bound.")
    public Stream<Why2Result> why2Few(
        @Name("query") String query,
        @Name("target") Map<String, Object> target,
        @Name(value = "options", defaultValue = "{}") Map<String, Object> options
    ) {
        return Stream.of(runWhy(WhyMode.WHY_FEW, query, target, options));
    }

    @Procedure(value = "why2.many", mode = Mode.READ)
    @Description("Why-Many v2: schema-aware A* rewriting targeting an upper cardinality bound.")
    public Stream<Why2Result> why2Many(
        @Name("query") String query,
        @Name("target") Map<String, Object> target,
        @Name(value = "options", defaultValue = "{}") Map<String, Object> options
    ) {
        return Stream.of(runWhy(WhyMode.WHY_MANY, query, target, options));
    }

    @Procedure(value = "why2.operators", mode = Mode.READ)
    @Description("List exact rewrite operators implemented in WhyGraph and their intended mode usage.")
    public Stream<OperatorRow> why2Operators() {
        List<OperatorRow> rows = new ArrayList<>();
        for (ModificationOperation.Type t : ModificationOperation.Type.values()) {
            if (isCoreRewriteOperator(t)) {
                rows.add(new OperatorRow(
                    t.name(),
                    operatorFamily(t),
                    operatorEffect(t),
                    operatorModes(t),
                    isCoreRewriteOperator(t)
                ));
            }
        }
        rows.sort((a, b) -> a.operator.compareToIgnoreCase(b.operator));
        return rows.stream();
    }

    @Procedure(value = "why2.statistics", mode = Mode.READ)
    @Description("Return statistics profile used by why2 including snapshot path and S_path availability.")
    public Stream<StatisticsProfileRow> why2Statistics() {
        return Stream.of(new StatisticsProfileRow(buildStatisticsProfile(getStatistics())));
    }

    @Procedure(value = "why2.refreshStatistics", mode = Mode.READ)
    @Description("Prime statistics snapshot including bounded-path S_path entries derived from schema triples.")
    public Stream<StatisticsProfileRow> why2RefreshStatistics(
        @Name(value = "options", defaultValue = "{}") Map<String, Object> options
    ) {
        Neo4jStatistics stats = getStatistics();
        DatabaseSchemaCache schema = getSchemaCache();
        int minLen = (int) Math.max(1L, optLong(options, "path_min_len", 1L));
        int maxLen = (int) Math.max(minLen, optLong(options, "path_max_len", 3L));
        Set<String> relTypes = new LinkedHashSet<>();
        schema.getSchemaTripleStats().keySet().forEach(t -> {
            if (t != null && t.getRelationshipType() != null && !t.getRelationshipType().isBlank()) {
                relTypes.add(t.getRelationshipType());
            }
        });
        for (String relType : relTypes) {
            stats.getPathSafeUpperBound(relType, minLen, maxLen);
            stats.getPathEstimate(relType, minLen, maxLen);
        }
        return Stream.of(new StatisticsProfileRow(buildStatisticsProfile(stats)));
    }

    private Why2Result runWhy(WhyMode mode, String query, Map<String, Object> target, Map<String, Object> options) {
        long t0 = System.currentTimeMillis();
        Map<String, Object> diagnostics = new LinkedHashMap<>();
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("api_version", "2.0");
        payload.put("mode", mode.name());
        payload.put("query", query);

        if (query == null || query.isBlank()) {
            return Why2Result.error("Query is required", payload, diagnostics, t0);
        }

        boolean strictCore = optBool(options, "strict_core", true);
        CoreComplianceReport compliance = checkCoreCompliance(query);
        payload.put("core_compliance", compliance.toMap());
        if (strictCore && !compliance.valid) {
            return Why2Result.error("Query is outside core fragment", payload, diagnostics, t0);
        }

        WitnessInput witnessInput = parseWitnessInput(target);
        payload.put("witness_mode", witnessInput.witnesses.size() > 1 ? "MULTI_WITNESS" : "SINGLE_WITNESS");
        payload.put("witness_count", witnessInput.witnesses.size());
        if (mode == WhyMode.WHY_NOT && witnessInput.witnesses.isEmpty()) {
            return Why2Result.error("WHY_NOT requires `witness` or `witnesses` input", payload, diagnostics, t0);
        }
        if (mode == WhyMode.WHY_NOT) {
            List<String> unknownVars = findUnknownWitnessVariables(query, witnessInput);
            if (!unknownVars.isEmpty()) {
                diagnostics.put("unknown_witness_variables", unknownVars);
                return Why2Result.error("Witness variables not found in query: " + unknownVars, payload, diagnostics, t0);
            }
        }

        long minTarget = computeMinTarget(mode, target, witnessInput);
        long maxTarget = computeMaxTarget(mode, target, minTarget);
        payload.put("target_min_rows", minTarget);
        payload.put("target_max_rows", maxTarget);
        payload.put("search_invariant_no_data_execution", true);
        payload.put("search_invariant_no_add_limit", true);

        try {
            QueryRewritingAStar astar = buildAStar(mode, options);
            if (mode == WhyMode.WHY_NOT) {
                Map<String, WitnessSpec> first = witnessInput.witnesses.get(0);
                astar.setWhyNotBindings(toPropertyBindings(first), toIdBindings(first));
            }

            RewritingConfig cfg = buildRewritingConfig(mode, options);
            UserPreferences prefs = buildUserPreferences(options);
            double threshold = cfg.getModificationThreshold();
            long targetCardinality = mode == WhyMode.WHY_NOT
                ? Math.max(1L, witnessInput.witnesses.size())
                : minTarget;

            RewritingResult rr = astar.rewriteQuery(
                query,
                targetCardinality,
                prefs,
                threshold,
                mode,
                minTarget,
                maxTarget
            );
            if (!rr.isSuccess()) {
                RewritingResult rescued = tryRescueRewrite(mode, query, targetCardinality, minTarget, maxTarget, witnessInput, options);
                if (rescued != null && rescued.isSuccess()) {
                    rr = rescued;
                }
            }

            payload.put("rewriting_summary", rr.getSummary());
            payload.put("trace", toTrace(rr));
            payload.put("root_cause_summary", normalizeRootCauseSummary(rr.getRootCauseSummary(), rr, mode, minTarget, maxTarget));
            payload.put("goal_estimate", buildGoalEstimate(rr, mode, minTarget, maxTarget, witnessInput));
            payload.put("statistics_profile", buildStatisticsProfile(getStatistics()));
            payload.put("explain_overhead", buildExplainOverhead(rr));
            List<String> rewrites = sanitizeRewriteQueries(collectRewrites(rr));
            if (rewrites.isEmpty() && rr.getRewrittenQuery() != null && !rr.getRewrittenQuery().isBlank()) {
                rewrites.add(rr.getRewrittenQuery().trim());
            }
            if (rewrites.isEmpty()) {
                @SuppressWarnings("unchecked")
                Map<String, Object> summaryMap = payload.get("rewriting_summary") instanceof Map
                    ? (Map<String, Object>) payload.get("rewriting_summary")
                    : rr.getSummary();
                Object rq = summaryMap != null ? summaryMap.get("rewrittenQuery") : null;
                if (rq instanceof String && !((String) rq).isBlank()) {
                    rewrites.add(((String) rq).trim());
                }
            }
            if (rewrites.isEmpty()) {
                @SuppressWarnings("unchecked")
                Map<String, Object> summaryMap = payload.get("rewriting_summary") instanceof Map
                    ? (Map<String, Object>) payload.get("rewriting_summary")
                    : rr.getSummary();
                Object oq = summaryMap != null ? summaryMap.get("originalQuery") : null;
                if (oq instanceof String && !((String) oq).isBlank()) {
                    rewrites.add(((String) oq).trim());
                }
            }
            payload.put("suggested_rewrite_queries", rewrites);
            String primaryRewrite = !rewrites.isEmpty() ? rewrites.get(0) : null;
            if (primaryRewrite == null || primaryRewrite.isBlank()) {
                primaryRewrite = sanitizeRewriteQuery(rr.getRewrittenQuery());
            }
            Map<String, Object> appliedOps = buildAppliedOperations(rr);
            payload.put("rewritten_query", primaryRewrite);
            payload.put("rewrittenQuery", primaryRewrite);
            payload.put("no_rewrite_needed", rr.isSuccess() && rr.getModificationSteps() != null && rr.getModificationSteps().isEmpty());
            payload.put("applied_operations", appliedOps.get("operations"));
            payload.put("applied_operation_types", appliedOps.get("operation_types"));
            payload.put("applied_operation_count", appliedOps.get("operation_count"));

            if (mode == WhyMode.WHY_NOT) {
                Map<String, Object> recovery = buildWitnessRecovery(primaryRewrite, witnessInput, options);
                payload.put("witness_recovery", recovery);
                payload.put("answer_closeness", buildCloseness(mode, rr, minTarget, maxTarget, recovery));
            } else {
                payload.put("answer_closeness", buildCloseness(mode, rr, minTarget, maxTarget, null));
            }

            diagnostics.put("rewriting_status", rr.isSuccess() ? "SUCCESS" : "FAILED");
            diagnostics.put("errors", rr.getErrors());
            diagnostics.put("warnings", rr.getWarnings());
            diagnostics.put("elapsed_ms", System.currentTimeMillis() - t0);
            diagnostics.put("why2_build_tag", "why2-2026-04-28-r9");
            diagnostics.put("rewrites_count", rewrites.size());
            diagnostics.put("applied_operations", appliedOps.get("operations"));
            diagnostics.put("applied_operation_types", appliedOps.get("operation_types"));
            diagnostics.put("applied_operation_count", appliedOps.get("operation_count"));
            log.info("why2 mode=%s status=%s op_count=%s op_types=%s",
                mode.name(),
                rr.isSuccess() ? "SUCCESS" : "FAILED",
                String.valueOf(appliedOps.get("operation_count")),
                String.valueOf(appliedOps.get("operation_types")));
            if (!rr.isSuccess()) {
                if (mode == WhyMode.WHY_NOT) {
                    Map<String, Object> witnessFallback = tryWitnessGuidedWhyNotFallback(query, witnessInput, options);
                    if (Boolean.TRUE.equals(witnessFallback.get("success"))) {
                        @SuppressWarnings("unchecked")
                        List<String> wfRewrites = (List<String>) witnessFallback.getOrDefault("rewrites", Collections.emptyList());
                        @SuppressWarnings("unchecked")
                        List<Map<String, Object>> wfOps = (List<Map<String, Object>>) witnessFallback.getOrDefault("operations", Collections.emptyList());
                        payload.put("suggested_rewrite_queries", wfRewrites);
                        payload.put("rewritten_query", witnessFallback.get("rewritten_query"));
                        payload.put("rewrittenQuery", witnessFallback.get("rewritten_query"));
                        payload.put("applied_operations", wfOps);
                        payload.put("applied_operation_types", witnessFallback.getOrDefault("operation_types", List.of("WITNESS_PREDICATE_REPAIR")));
                        payload.put("applied_operation_count", wfOps.size());
                        payload.put("witness_recovery", witnessFallback.getOrDefault("witness_recovery", payload.get("witness_recovery")));
                        payload.put("answer_closeness", witnessFallback.getOrDefault("answer_closeness", payload.get("answer_closeness")));
                        diagnostics.put("rewriting_status", "SUCCESS");
                        diagnostics.put("warnings", List.of("Returned witness-guided fallback rewrite."));
                        diagnostics.put("errors", Collections.emptyList());
                        diagnostics.put("rewriting_failure_code", null);
                        diagnostics.put("applied_operations", wfOps);
                        diagnostics.put("applied_operation_types", witnessFallback.getOrDefault("operation_types", List.of("WITNESS_PREDICATE_REPAIR")));
                        diagnostics.put("applied_operation_count", wfOps.size());
                        diagnostics.put("rewrites_count", wfRewrites.size());
                        return Why2Result.success(payload, diagnostics);
                    }
                }
                String failureCode = classifyFailure(rr);
                diagnostics.put("rewriting_failure_code", failureCode);
                String msg = (rr.getErrors() != null && !rr.getErrors().isEmpty())
                    ? rr.getErrors().get(0)
                    : "Rewrite search failed";
                return Why2Result.failed(payload, diagnostics, msg);
            }
            return Why2Result.success(payload, diagnostics);
        } catch (Exception e) {
            diagnostics.put("elapsed_ms", System.currentTimeMillis() - t0);
            diagnostics.put("exception_type", e.getClass().getName());
            return Why2Result.error(e.getMessage(), payload, diagnostics, t0);
        }
    }

    private QueryRewritingAStar buildAStar(WhyMode mode, Map<String, Object> options) {
        RewritingConfig cfg = buildRewritingConfig(mode, options);
        return new QueryRewritingAStar(db, getStatistics(), cfg, getSchemaCache());
    }

    private RewritingResult tryRescueRewrite(WhyMode mode,
                                             String query,
                                             long targetCardinality,
                                             long minTarget,
                                             long maxTarget,
                                             WitnessInput witnessInput,
                                             Map<String, Object> options) {
        try {
            Map<String, Object> rescueOptions = new LinkedHashMap<>(options == null ? Collections.emptyMap() : options);
            rescueOptions.putIfAbsent("modification_threshold", 1000.0);
            rescueOptions.putIfAbsent("max_iterations", 2000.0);
            rescueOptions.putIfAbsent("allow_unbounded_ops", true);
            rescueOptions.putIfAbsent("use_admissible_heuristic", false);
            rescueOptions.putIfAbsent("use_planner_stats", true);
            QueryRewritingAStar rescueAstar = buildAStar(mode, rescueOptions);
            if (mode == WhyMode.WHY_NOT && witnessInput != null && !witnessInput.witnesses.isEmpty()) {
                Map<String, WitnessSpec> first = witnessInput.witnesses.get(0);
                rescueAstar.setWhyNotBindings(toPropertyBindings(first), toIdBindings(first));
            }
            UserPreferences prefs = buildUserPreferences(rescueOptions);
            double threshold = buildRewritingConfig(mode, rescueOptions).getModificationThreshold();
            return rescueAstar.rewriteQuery(query, targetCardinality, prefs, threshold, mode, minTarget, maxTarget);
        } catch (Exception ignored) {
            return null;
        }
    }

    private RewritingConfig buildRewritingConfig(WhyMode mode, Map<String, Object> options) {
        RewritingConfig cfg = RewritingConfig.createPerformanceOptimized();
        boolean strictTheoremMode = optBool(options, "strict_theorem_mode", false);
        cfg.setStrictTheoremMode(strictTheoremMode);
        cfg.setUseSchema(optBool(options, "use_schema", true));
        // Fast defaults: avoid expensive EXPLAIN-per-state unless explicitly requested.
        cfg.setUsePlannerStats(optBool(options, "use_planner_stats", false));
        cfg.setUseFormalBounds(optBool(options, "use_formal_bounds", true));
        cfg.setCardinalityEstimator(optString(options, "cardinality_estimator", "schema_bounds"));
        cfg.setUseSoftUpperBounds(optBool(options, "use_soft_upper_bounds", false));
        cfg.setUseCalibratedBounds(optBool(options, "use_calibrated_bounds", false));
        cfg.setAllowUnboundedOps(optBool(options, "allow_unbounded_ops", false));
        cfg.setAllowRelationshipRepairs(optBool(options, "allow_relationship_repairs", true));
        cfg.setAllowRelationshipDeletionRelaxation(optBool(options, "allow_relationship_deletion_relaxation", false));
        // Hard invariant for why2 search loop: never execute candidate rewrites.
        cfg.setAllowDataQueries(false);
        cfg.setStrictEstimateOnly(true);
        cfg.setUseAdmissibleHeuristic(optBool(options, "use_admissible_heuristic", true));
        cfg.setUseUniformCost(optBool(options, "use_uniform_cost", false));
        cfg.setParetoFrontierEnabled(optBool(options, "pareto_frontier", false));
        cfg.setForceAStarRewrite(optBool(options, "force_astar", true));
        cfg.setUnboundedPenalty(optDouble(options, "unbounded_penalty", 5.0));
        cfg.setCostEpsilon(optDouble(options, "cost_epsilon", 0.01));
        cfg.setHeuristicRho(optDouble(options, "heuristic_rho", 2.0));
        cfg.setWeightedAStarWeight(optDouble(options, "weighted_astar_weight", 1.0));
        cfg.setModificationThreshold(optDouble(options, "modification_threshold", 200.0));
        cfg.setMaxIterations((int) Math.round(optDouble(options, "max_iterations", 1000.0)));
        cfg.setAllowedOperations(coreAllowedOperations(mode));
        if (strictTheoremMode) {
            cfg.setUseAdmissibleHeuristic(true);
            cfg.setAllowUnboundedOps(false);
            cfg.setUncertaintyAwareSearch(false);
            cfg.setLearningGuidanceEnabled(false);
            cfg.setWeightedAStarWeight(1.0);
            cfg.setUseFormalBounds(true);
            cfg.setUseSoftUpperBounds(false);
            cfg.setUseCalibratedBounds(false);
            cfg.setParetoFrontierEnabled(false);
        }
        return cfg;
    }

    private Set<ModificationOperation.Type> coreAllowedOperations(WhyMode mode) {
        LinkedHashSet<ModificationOperation.Type> ops = new LinkedHashSet<>();
        if (mode == WhyMode.WHY_MANY) {
            ops.add(ModificationOperation.Type.ADD_PREDICATE);
            ops.add(ModificationOperation.Type.STRENGTHEN_PREDICATE);
            ops.add(ModificationOperation.Type.ADD_LABEL);
            ops.add(ModificationOperation.Type.ADD_EDGE);
            ops.add(ModificationOperation.Type.ADD_RELATIONSHIP);
            return ops;
        }
        // WHY_EMPTY / WHY_FEW / WHY_NOT: core relaxations + repairs only.
        ops.add(ModificationOperation.Type.DELETE_PREDICATE);
        ops.add(ModificationOperation.Type.RELAX_ENDPOINT_PREDICATE);
        ops.add(ModificationOperation.Type.RELAX_LABEL);
        ops.add(ModificationOperation.Type.WEAKEN_PREDICATE);
        ops.add(ModificationOperation.Type.RELAX_PROPERTY);
        ops.add(ModificationOperation.Type.RELAX_NODE_PROPERTY);
        ops.add(ModificationOperation.Type.DELETE_NODE);
        ops.add(ModificationOperation.Type.DELETE_RELATIONSHIP);
        ops.add(ModificationOperation.Type.DEL_EDGE);
        ops.add(ModificationOperation.Type.FLIP_RELATIONSHIP_DIRECTION);
        ops.add(ModificationOperation.Type.REPLACE_RELATIONSHIP_TYPE);
        ops.add(ModificationOperation.Type.REPAIR_END_LABEL);
        return ops;
    }

    private UserPreferences buildUserPreferences(Map<String, Object> options) {
        String preset = String.valueOf(options.getOrDefault("preference_preset", "minimal")).toLowerCase(Locale.ROOT);
        UserPreferences prefs;
        if ("completeness".equals(preset)) {
            prefs = UserPreferences.createResultCompleteness();
        } else {
            prefs = UserPreferences.createMinimalChanges();
        }
        return prefs;
    }

    private DatabaseSchemaCache getSchemaCache() {
        DatabaseSchemaCache cache = SCHEMA_CACHE.get();
        if (cache != null) {
            return cache;
        }
        DatabaseSchemaCache created = DatabaseSchemaCache.getShared(db);
        if (SCHEMA_CACHE.compareAndSet(null, created)) {
            return created;
        }
        return SCHEMA_CACHE.get();
    }

    private Neo4jStatistics getStatistics() {
        Neo4jStatistics stats = STATS.get();
        if (stats != null) {
            return stats;
        }
        Neo4jStatistics created = new Neo4jStatistics(db, false, true);
        if (STATS.compareAndSet(null, created)) {
            return created;
        }
        return STATS.get();
    }

    private CoreComplianceReport checkCoreCompliance(String query) {
        CoreComplianceReport report = new CoreComplianceReport();
        try {
            CypherAST ast = CypherASTBuilder.parseQuery(query);
            int matchCount = ast.getNodesByType(NodeType.MATCH).size();
            int optionalMatchCount = ast.getNodesByType(NodeType.OPTIONAL_MATCH).size();
            int whereCount = ast.getNodesByType(NodeType.WHERE).size();
            int returnCount = ast.getNodesByType(NodeType.RETURN).size();

            if (matchCount != 1) {
                report.add("MATCH_BLOCK", "Core requires a single MATCH block");
            }
            if (optionalMatchCount > 0) {
                report.add("OPTIONAL_MATCH", "OPTIONAL MATCH is out of core");
            }
            if (returnCount != 1) {
                report.add("RETURN_BLOCK", "Core requires exactly one RETURN block");
            }
            if (whereCount > 1) {
                report.add("WHERE_BLOCK", "Core allows at most one WHERE block");
            }
            if (!ast.getNodesByType(NodeType.UNION).isEmpty() || !ast.getNodesByType(NodeType.UNION_ALL).isEmpty()) {
                report.add("UNION", "UNION is out of core");
            }
            if (!ast.getNodesByType(NodeType.CALL).isEmpty() || !ast.getNodesByType(NodeType.SUBQUERY).isEmpty()) {
                report.add("SUBQUERY", "Subqueries/procedure calls are out of core");
            }
            if (!ast.getNodesByType(NodeType.SHORTEST_PATH).isEmpty() ||
                !ast.getNodesByType(NodeType.ALL_SHORTEST_PATHS).isEmpty()) {
                report.add("SHORTEST_PATH", "Shortest-path operators are out of core");
            }
            if (!ast.getNodesByType(NodeType.OR).isEmpty() || !ast.getNodesByType(NodeType.NOT).isEmpty()) {
                report.add("DISJUNCTION_NEGATION", "OR/NOT are out of strict conjunctive core");
            }

            QueryGraph graph = CypherASTQueryGraphParser.parse(query);
            if (!isConnected(graph)) {
                report.add("DISCONNECTED_PATTERN", "MATCH pattern is disconnected");
            }

            if (hasVariableLengthPattern(query)) {
                report.add("VAR_LENGTH_PATTERN", "Variable-length paths are extension atoms (not fixed-length core)");
            }
        } catch (Exception e) {
            report.add("PARSE_ERROR", "Failed to parse query for core compliance: " + e.getMessage());
        }
        return report;
    }

    private boolean hasVariableLengthPattern(String query) {
        if (query == null) {
            return false;
        }
        // Detect [:R*], [:R*1..3], [*1..3], etc.
        Pattern p = Pattern.compile("\\[[^\\]]*\\*[^\\]]*\\]");
        return p.matcher(query).find();
    }

    private boolean isConnected(QueryGraph graph) {
        Collection<QueryGraph.Vertex> nodes = graph.getNodes();
        List<QueryGraph.Edge> edges = graph.getEdges();
        if (nodes.size() <= 1) {
            return true;
        }
        if (edges.isEmpty()) {
            return false;
        }
        Map<Integer, Set<Integer>> adj = new HashMap<>();
        for (QueryGraph.Vertex v : nodes) {
            adj.put(v.id, new HashSet<>());
        }
        for (QueryGraph.Edge e : edges) {
            adj.computeIfAbsent(e.source, k -> new HashSet<>()).add(e.target);
            adj.computeIfAbsent(e.target, k -> new HashSet<>()).add(e.source);
        }
        Integer start = nodes.iterator().next().id;
        Set<Integer> visited = new HashSet<>();
        ArrayDeque<Integer> q = new ArrayDeque<>();
        q.add(start);
        visited.add(start);
        while (!q.isEmpty()) {
            int u = q.removeFirst();
            for (Integer v : adj.getOrDefault(u, Collections.emptySet())) {
                if (visited.add(v)) {
                    q.addLast(v);
                }
            }
        }
        return visited.size() == nodes.size();
    }

    private long computeMinTarget(WhyMode mode, Map<String, Object> target, WitnessInput witnesses) {
        switch (mode) {
            case WHY_EMPTY:
                return 1L;
            case WHY_FEW:
                return Math.max(1L, optLong(target, "min", optLong(target, "target_min_rows", 1L)));
            case WHY_MANY:
                return 0L;
            case WHY_NOT:
                return Math.max(1L, optLong(target, "target_min_rows", Math.max(1L, witnesses.witnesses.size())));
            default:
                return 1L;
        }
    }

    private long computeMaxTarget(WhyMode mode, Map<String, Object> target, long minTarget) {
        switch (mode) {
            case WHY_EMPTY:
                return Math.max(minTarget, Long.MAX_VALUE / 4);
            case WHY_FEW:
                return Math.max(minTarget, optLong(target, "max", optLong(target, "target_max_rows", Long.MAX_VALUE / 4)));
            case WHY_MANY:
                return Math.max(1L, optLong(target, "max", optLong(target, "target_max_rows", 1000L)));
            case WHY_NOT:
                return Math.max(minTarget, optLong(target, "target_max_rows", 5000L));
            default:
                return Math.max(minTarget, 1L);
        }
    }

    private Map<String, Object> toTrace(RewritingResult rr) {
        Map<String, Object> trace = new LinkedHashMap<>();
        if (rr == null || rr.getTrace() == null || rr.getTrace().getSteps() == null) {
            trace.put("steps", Collections.emptyList());
            return trace;
        }
        List<Map<String, Object>> steps = new ArrayList<>();
        for (RewritingResult.AStarTrace.Step s : rr.getTrace().getSteps()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("operation", s.operation);
            m.put("operation_type", s.operationType);
            m.put("g", s.gScore);
            m.put("h", s.hScore);
            m.put("f", s.fScore);
            m.put("estimated_rows", s.estimatedRows);
            m.put("bound_lb", s.boundLower);
            m.put("bound_ub", s.boundUpper);
            m.put("goal", s.goal);
            steps.add(m);
        }
        trace.put("steps", steps);
        trace.put("step_count", steps.size());
        return trace;
    }

    private Map<String, Object> buildAppliedOperations(RewritingResult rr) {
        Map<String, Object> out = new LinkedHashMap<>();
        List<Map<String, Object>> operations = new ArrayList<>();
        LinkedHashSet<String> operationTypes = new LinkedHashSet<>();
        if (rr != null && rr.getModificationSteps() != null) {
            int idx = 0;
            for (ModificationStep step : rr.getModificationSteps()) {
                if (step == null || step.getOperation() == null) {
                    continue;
                }
                idx++;
                ModificationOperation op = step.getOperation();
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("index", idx);
                row.put("type", op.getType() != null ? op.getType().name() : "UNKNOWN");
                row.put("target_id", op.getTargetId());
                row.put("target_label", op.getTargetLabel());
                row.put("target_property", op.getTargetProperty());
                row.put("target_variable", op.getTargetVariable());
                row.put("range", op.getRange() != null ? Arrays.asList(op.getRange()) : Collections.emptyList());
                row.put("description", step.getDescription());
                row.put("changes", step.getChanges() != null ? step.getChanges() : Collections.emptyList());
                row.put("timestamp", step.getTimestamp());
                operations.add(row);
                if (op.getType() != null) {
                    operationTypes.add(op.getType().name());
                }
            }
        }
        out.put("operations", operations);
        out.put("operation_types", new ArrayList<>(operationTypes));
        out.put("operation_count", operations.size());
        return out;
    }

    private Map<String, Object> buildExplainOverhead(RewritingResult rr) {
        Map<String, Object> out = new LinkedHashMap<>();
        int explainCalls = 0;
        if (rr != null && rr.getTrace() != null && rr.getTrace().getSteps() != null) {
            for (RewritingResult.AStarTrace.Step s : rr.getTrace().getSteps()) {
                if (s != null && s.rootOperator != null && !s.rootOperator.isBlank()) {
                    explainCalls++;
                }
            }
        }
        out.put("explain_calls", explainCalls);
        out.put("planner_only", true);
        out.put("bounded_overhead_note", "EXPLAIN latency is included in procedure_time; no candidate query is executed.");
        return out;
    }

    private Map<String, Object> buildGoalEstimate(RewritingResult rr,
                                                  WhyMode mode,
                                                  long minTarget,
                                                  long maxTarget,
                                                  WitnessInput witnesses) {
        Map<String, Object> out = new LinkedHashMap<>();
        long lbSafe = bestBound(rr, true);
        long ubSafe = bestBound(rr, false);
        long cEst = rr != null ? rr.getEstimatedRows() : -1L;
        String opFamily = dominantOperationFamily(rr);
        EstimatorConfidenceModel.Interval ci = CI_MODEL.interval(cEst, mode, opFamily);
        out.put("bound_lb_safe", lbSafe);
        out.put("bound_ub_safe", ubSafe);
        out.put("bound_lb", lbSafe);
        out.put("bound_ub", ubSafe);
        out.put("c_est", cEst);
        out.put("estimated_rows", cEst);
        out.put("estimated_rows_ci_lower", ci.lower);
        out.put("estimated_rows_ci_upper", ci.upper);
        out.put("estimated_rows_confidence_level", ci.confidenceLevel);
        out.put("estimated_rows_ci_factor", ci.factor);
        out.put("estimated_rows_ci_method", ci.factor < 0 ? "calibrated_log_residual" : "multiplicative_factor");
        out.put("estimated_rows_ci_operation_family", opFamily);
        out.put("estimated_goal_reached", estimateGoal(mode, rr, lbSafe, ubSafe, cEst, minTarget, maxTarget, witnesses));
        return out;
    }

    private String dominantOperationFamily(RewritingResult rr) {
        if (rr == null || rr.getModificationSteps() == null || rr.getModificationSteps().isEmpty()) {
            return "NONE";
        }
        ModificationStep first = rr.getModificationSteps().get(0);
        if (first == null || first.getOperation() == null || first.getOperation().getType() == null) {
            return "NONE";
        }
        return operatorFamily(first.getOperation().getType());
    }

    private boolean estimateGoal(WhyMode mode,
                                 RewritingResult rr,
                                 long lb,
                                 long ub,
                                 long estimatedRows,
                                 long minTarget,
                                 long maxTarget,
                                 WitnessInput witnesses) {
        long finalCard = rr != null ? rr.getFinalCardinality() : -1L;
        switch (mode) {
            case WHY_EMPTY:
                if (lb >= 0) {
                    return lb > 0;
                }
                if (estimatedRows >= 0) {
                    return estimatedRows >= 1;
                }
                return finalCard > 0;
            case WHY_FEW:
                if (lb >= 0 && ub >= 0) {
                    return lb >= minTarget && ub <= maxTarget;
                }
                return finalCard >= minTarget && finalCard <= maxTarget;
            case WHY_MANY:
                if (ub >= 0) {
                    return ub <= maxTarget;
                }
                return finalCard >= 0 && finalCard <= maxTarget;
            case WHY_NOT:
                if (ub >= 0) {
                    return ub >= Math.max(1, witnesses.witnesses.size());
                }
                return rr != null && rr.isSuccess();
            default:
                return false;
        }
    }

    private long bestBound(RewritingResult rr, boolean lower) {
        if (rr == null || rr.getTrace() == null || rr.getTrace().getSteps() == null || rr.getTrace().getSteps().isEmpty()) {
            return -1L;
        }
        List<RewritingResult.AStarTrace.Step> steps = rr.getTrace().getSteps();
        for (int i = steps.size() - 1; i >= 0; i--) {
            RewritingResult.AStarTrace.Step s = steps.get(i);
            long v = lower ? s.boundLower : s.boundUpper;
            if (v >= 0) {
                return v;
            }
        }
        return -1L;
    }

    private Map<String, Object> buildCloseness(WhyMode mode,
                                               RewritingResult rr,
                                               long minTarget,
                                               long maxTarget,
                                               Map<String, Object> witnessRecovery) {
        Map<String, Object> out = new LinkedHashMap<>();
        switch (mode) {
            case WHY_NOT:
                out.put("metric", "cl_wit");
                out.put("proxy_metric", "cl_wit_sigma");
                out.put("value", witnessRecovery != null ? asDouble(witnessRecovery.get("recovery_rate"), 0.0) : 0.0);
                break;
            case WHY_EMPTY:
                out.put("metric", "cl_card");
                out.put("target_min", 1L);
                out.put("value", computeCardinalityCloseness(mode, rr, 1L, maxTarget));
                break;
            case WHY_FEW:
                out.put("metric", "cl_card");
                out.put("target_min", minTarget);
                out.put("value", computeCardinalityCloseness(mode, rr, minTarget, maxTarget));
                break;
            case WHY_MANY:
                out.put("metric", "cl_many");
                out.put("target_max", maxTarget);
                out.put("value", computeCardinalityCloseness(mode, rr, minTarget, maxTarget));
                break;
            default:
                out.put("metric", "unknown");
                out.put("value", 0.0);
        }
        out.put("estimated_only", true);
        return out;
    }

    private Map<String, Object> normalizeRootCauseSummary(Map<String, Object> raw,
                                                          RewritingResult rr,
                                                          WhyMode mode,
                                                          long minTarget,
                                                          long maxTarget) {
        Map<String, Object> out = new LinkedHashMap<>();
        Map<String, Object> source = raw == null ? Collections.emptyMap() : raw;
        out.put("blocking_predicates", source.getOrDefault("blocking_predicates", Collections.emptyList()));
        out.put("schema_conflicts", source.getOrDefault("schema_conflicts", Collections.emptyList()));
        Map<String, Object> card = new LinkedHashMap<>();
        card.put("target_min", minTarget);
        card.put("target_max", maxTarget);
        card.put("estimated_rows", rr != null ? rr.getEstimatedRows() : -1L);
        card.put("estimated_lb", rr != null ? rr.getEstimatedRowsCILower() : -1L);
        card.put("estimated_ub", rr != null ? rr.getEstimatedRowsCIUpper() : -1L);
        card.put("mode", mode.name());
        out.put("cardinality_gap", source.getOrDefault("cardinality_gap", card));
        out.put("pruned_operator_classes", source.getOrDefault("pruned_operator_classes", Collections.emptyList()));
        out.put("suggested_budget_increase", source.getOrDefault("suggested_budget_increase", Collections.emptyMap()));
        return out;
    }

    private List<String> collectRewrites(RewritingResult rr) {
        LinkedHashSet<String> rewrites = new LinkedHashSet<>();
        if (rr == null) {
            return new ArrayList<>();
        }
        if (rr.getRewrittenQuery() != null && !rr.getRewrittenQuery().isBlank()) {
            rewrites.add(rr.getRewrittenQuery().trim());
        }
        Map<String, Object> summary = rr.getSummary();
        Object summaryRewrite = summary.get("rewrittenQuery");
        if (summaryRewrite instanceof String && !((String) summaryRewrite).isBlank()) {
            rewrites.add(((String) summaryRewrite).trim());
        }
        if (rr.getBestAlternative() != null &&
            rr.getBestAlternative().getRewrittenQuery() != null &&
            !rr.getBestAlternative().getRewrittenQuery().isBlank()) {
            rewrites.add(rr.getBestAlternative().getRewrittenQuery().trim());
        }
        if (rewrites.isEmpty()) {
            Object original = summary.get("originalQuery");
            if (Boolean.TRUE.equals(summary.get("success")) && original instanceof String && !((String) original).isBlank()) {
                // Explicit fallback to avoid ambiguous empty array on successful no-op cases.
                rewrites.add(((String) original).trim());
            }
        }
        return new ArrayList<>(rewrites);
    }

    private List<String> sanitizeRewriteQueries(List<String> rewrites) {
        if (rewrites == null || rewrites.isEmpty()) {
            return Collections.emptyList();
        }
        List<String> out = new ArrayList<>();
        for (String q : rewrites) {
            String s = sanitizeRewriteQuery(q);
            if (s != null && !s.isBlank() && !out.contains(s)) {
                out.add(s);
            }
        }
        return out;
    }

    private String sanitizeRewriteQuery(String query) {
        if (query == null || query.isBlank()) {
            return query;
        }
        // Remove wildcard label markers produced by downstream relaxers (e.g., (:*:Label)).
        return query.replaceAll(":\\*", "");
    }

    private String classifyFailure(RewritingResult rr) {
        if (rr == null || rr.getErrors() == null || rr.getErrors().isEmpty()) {
            return "FAILED_UNKNOWN";
        }
        String e = String.valueOf(rr.getErrors().get(0)).toLowerCase(Locale.ROOT);
        if (e.contains("no valid alternatives")) {
            return "FAILED_NO_ALTERNATIVE";
        }
        if (e.contains("threshold") || e.contains("iteration limit") || e.contains("max iterations")) {
            return "FAILED_BUDGET_EXHAUSTED";
        }
        if (e.contains("schema")) {
            return "FAILED_SCHEMA_BLOCKED";
        }
        return "FAILED_UNKNOWN";
    }

    private Map<String, Object> buildStatisticsProfile(Neo4jStatistics stats) {
        Map<String, Object> out = new LinkedHashMap<>();
        Path snapshot = stats != null ? stats.getSnapshotPath() : null;
        out.put("statistics_snapshot_path", snapshot != null ? snapshot.toString() : null);
        out.put("snapshot_exists", snapshot != null && Files.exists(snapshot));
        out.put("s_card", true);
        out.put("s_sel", true);
        out.put("s_idx", true);
        out.put("s_edge", true);
        out.put("s_null", false);
        out.put("s_dist", false);
        boolean hasPath = stats != null && stats.hasPathStatistics();
        out.put("s_path_est", hasPath);
        out.put("s_path_safe", hasPath);
        out.put("s_path_safe_entries", stats != null ? stats.getPathSafeEntryCount() : 0);
        out.put("s_path_est_entries", stats != null ? stats.getPathEstimateEntryCount() : 0);
        out.put("s_path_note", hasPath
            ? "S_path snapshot available (estimate + conservative layers)."
            : "S_path snapshot empty; path guarantees remain outside fixed-length core until bounded path atoms are enabled.");
        if (snapshot != null && Files.exists(snapshot)) {
            try {
                String json = Files.readString(snapshot);
                out.put("snapshot_bytes", json.length());
                out.put("snapshot_node_count_entries", countJsonObjectEntries(json, "nodeCounts"));
                out.put("snapshot_relationship_count_entries", countJsonObjectEntries(json, "relationshipCounts"));
                out.put("snapshot_selectivity_entries", countJsonObjectEntries(json, "propertySelectivities"));
                out.put("snapshot_path_safe_entries", countJsonObjectEntries(json, "pathSafeUpperBounds"));
                out.put("snapshot_path_est_entries", countJsonObjectEntries(json, "pathEstimates"));
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    private int countJsonObjectEntries(String json, String objectName) {
        if (json == null || objectName == null) {
            return 0;
        }
        Pattern p = Pattern.compile("\"" + Pattern.quote(objectName) + "\"\\s*:\\s*\\{([^}]*)\\}");
        Matcher m = p.matcher(json);
        if (!m.find()) {
            return 0;
        }
        String body = m.group(1).trim();
        if (body.isEmpty()) {
            return 0;
        }
        int count = 1;
        for (int i = 0; i < body.length(); i++) {
            if (body.charAt(i) == ',') {
                count++;
            }
        }
        return count;
    }

    private Map<String, Object> buildWitnessRecovery(String rewrittenQuery, WitnessInput witnessInput, Map<String, Object> options) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (rewrittenQuery == null || rewrittenQuery.isBlank() || witnessInput.witnesses.isEmpty()) {
            out.put("witness_count", witnessInput.witnesses.size());
            out.put("recovered_witnesses", 0);
            out.put("recovery_rate", 0.0);
            out.put("checks", Collections.emptyList());
            return out;
        }
        boolean useExplain = optBool(options, "use_planner_stats", true);
        List<Map<String, Object>> checks = new ArrayList<>();
        int recovered = 0;
        int idx = 0;
        for (Map<String, WitnessSpec> witness : witnessInput.witnesses) {
            idx++;
            String boundQuery = addWitnessBindings(rewrittenQuery, witness);
            Map<String, Object> est = useExplain
                ? estimateByExplain(boundQuery)
                : estimateByExplain(boundQuery);
            double rows = asDouble(est.get("estimated_rows"), -1.0);
            boolean ok = rows > 0.0;
            if (ok) {
                recovered++;
            }
            Map<String, Object> c = new LinkedHashMap<>();
            c.put("witness_index", idx);
            c.put("query", boundQuery);
            c.put("estimated_rows", rows);
            c.put("estimate_status", est.get("status"));
            c.put("recovered", ok);
            checks.add(c);
        }
        int total = witnessInput.witnesses.size();
        out.put("witness_count", total);
        out.put("recovered_witnesses", recovered);
        out.put("recovery_rate", total == 0 ? 0.0 : ((double) recovered) / total);
        out.put("likely_recovers_missing_item", recovered > 0);
        out.put("likely_recovers_all_witnesses", total > 0 && recovered == total);
        out.put("checks", checks);
        return out;
    }

    private Map<String, Object> tryWitnessGuidedWhyNotFallback(String query,
                                                                WitnessInput witnessInput,
                                                                Map<String, Object> options) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("success", false);
        if (query == null || query.isBlank() || witnessInput == null || witnessInput.witnesses.isEmpty()) {
            return out;
        }

        List<String> candidates = new ArrayList<>();
        List<Map<String, Object>> opTrace = new ArrayList<>();
        for (Map<String, WitnessSpec> witness : witnessInput.witnesses) {
            for (Map.Entry<String, WitnessSpec> w : witness.entrySet()) {
                String var = w.getKey();
                WitnessSpec spec = w.getValue();
                if (spec == null || spec.properties == null || spec.properties.isEmpty()) {
                    continue;
                }
                for (Map.Entry<String, Object> p : spec.properties.entrySet()) {
                    String prop = p.getKey();
                    Object value = p.getValue();
                    if (prop == null || prop.isBlank() || value == null) {
                        continue;
                    }
                    String replacement = var + "." + prop + " = " + formatCypherLiteral(value);
                    Pattern eqPat = Pattern.compile("(?i)\\b" + Pattern.quote(var) + "\\s*\\.\\s*" + Pattern.quote(prop) + "\\s*=\\s*('([^']|'')*'|\\\"([^\\\"]|\\\"\\\")*\\\"|-?\\d+(?:\\.\\d+)?|true|false)");
                    Matcher m = eqPat.matcher(query);
                    if (m.find()) {
                        String rewritten = m.replaceFirst(replacement);
                        if (!rewritten.equals(query)) {
                            candidates.add(rewritten);
                            Map<String, Object> op = new LinkedHashMap<>();
                            op.put("index", opTrace.size() + 1);
                            op.put("type", "WITNESS_PREDICATE_REPAIR");
                            op.put("description", "Rewrote predicate to witness value: " + replacement);
                            op.put("target_variable", var);
                            op.put("target_property", prop);
                            op.put("changes", List.of("Replaced conflicting equality with witness value"));
                            opTrace.add(op);
                        }
                    } else {
                        String bound = addWitnessBindings(query, Map.of(var, spec));
                        if (!bound.equals(query)) {
                            candidates.add(bound);
                            Map<String, Object> op = new LinkedHashMap<>();
                            op.put("index", opTrace.size() + 1);
                            op.put("type", "WITNESS_PREDICATE_BIND");
                            op.put("description", "Injected witness binding predicate: " + replacement);
                            op.put("target_variable", var);
                            op.put("target_property", prop);
                            op.put("changes", List.of("Added witness property binding"));
                            opTrace.add(op);
                        }
                    }
                }
            }
        }
        if (candidates.isEmpty()) {
            return out;
        }

        String best = null;
        Map<String, Object> bestRecovery = null;
        double bestRate = -1.0;
        for (String candidate : candidates) {
            Map<String, Object> recovery = buildWitnessRecovery(candidate, witnessInput, options);
            double rate = asDouble(recovery.get("recovery_rate"), 0.0);
            if (rate > bestRate) {
                bestRate = rate;
                best = candidate;
                bestRecovery = recovery;
            }
        }
        if (best == null || best.isBlank()) {
            return out;
        }

        long estimatedRows = -1L;
        try {
            estimatedRows = Math.round(asDouble(estimateByExplain(best).get("estimated_rows"), -1.0));
        } catch (Exception ignored) {
        }
        if (bestRate <= 0.0 && estimatedRows <= 0) {
            return out;
        }

        LinkedHashSet<String> opTypes = new LinkedHashSet<>();
        for (Map<String, Object> op : opTrace) {
            opTypes.add(String.valueOf(op.get("type")));
        }
        out.put("success", true);
        out.put("rewritten_query", best);
        out.put("rewrites", List.of(best));
        out.put("operation_types", new ArrayList<>(opTypes));
        out.put("operations", opTrace);
        out.put("witness_recovery", bestRecovery != null ? bestRecovery : Collections.emptyMap());
        Map<String, Object> closeness = new LinkedHashMap<>();
        closeness.put("metric", "cl_wit");
        closeness.put("proxy_metric", "cl_wit_sigma");
        closeness.put("estimated_only", true);
        closeness.put("value", Math.max(0.0, bestRate));
        out.put("answer_closeness", closeness);
        return out;
    }

    private String formatCypherLiteral(Object value) {
        if (value == null) {
            return "null";
        }
        if (value instanceof Number || value instanceof Boolean) {
            return value.toString();
        }
        String s = String.valueOf(value).replace("'", "''");
        return "'" + s + "'";
    }

    private List<String> findUnknownWitnessVariables(String query, WitnessInput witnessInput) {
        Set<String> queryVars = new LinkedHashSet<>();
        try {
            QueryGraph graph = CypherASTQueryGraphParser.parse(query);
            for (QueryGraph.Vertex v : graph.getNodes()) {
                if (v != null && v.identifier != null && !v.identifier.isBlank()) {
                    queryVars.add(v.identifier);
                }
            }
        } catch (Exception ignored) {
        }
        List<String> unknown = new ArrayList<>();
        for (Map<String, WitnessSpec> witness : witnessInput.witnesses) {
            for (String var : witness.keySet()) {
                if (!queryVars.contains(var)) {
                    unknown.add(var);
                }
            }
        }
        return unknown;
    }

    private Map<String, Object> estimateByExplain(String query) {
        Map<String, Object> m = new LinkedHashMap<>();
        if (query == null || query.isBlank()) {
            m.put("status", "EMPTY_QUERY");
            m.put("estimated_rows", -1.0);
            return m;
        }
        try (Result res = tx.execute("EXPLAIN " + query)) {
            ExecutionPlanDescription plan = res.getExecutionPlanDescription();
            double rows = extractEstimatedRows(plan);
            m.put("status", "OK");
            m.put("estimated_rows", rows);
            return m;
        } catch (Exception e) {
            m.put("status", "ERROR");
            m.put("error", e.getMessage());
            m.put("estimated_rows", -1.0);
            return m;
        }
    }

    private double extractEstimatedRows(ExecutionPlanDescription plan) {
        if (plan == null) {
            return -1.0;
        }
        Object v = plan.getArguments().get("EstimatedRows");
        if (v instanceof Number) {
            return ((Number) v).doubleValue();
        }
        try {
            if (v != null) {
                return Double.parseDouble(v.toString());
            }
        } catch (NumberFormatException ignored) {
        }
        for (ExecutionPlanDescription child : plan.getChildren()) {
            double c = extractEstimatedRows(child);
            if (c >= 0.0) {
                return c;
            }
        }
        return -1.0;
    }

    private double computeCardinalityCloseness(WhyMode mode, RewritingResult rr, long minTarget, long maxTarget) {
        if (rr == null) {
            return 0.0;
        }
        double finalCard = Math.max(0.0, rr.getFinalCardinality());
        switch (mode) {
            case WHY_EMPTY:
                return finalCard > 0.0 ? 1.0 : 0.0;
            case WHY_FEW:
                return Math.min(1.0, finalCard / Math.max(1.0, minTarget));
            case WHY_MANY:
                return finalCard <= maxTarget ? 1.0 : Math.max(0.0, maxTarget / Math.max(1.0, finalCard));
            default:
                return 0.0;
        }
    }

    private Map<String, Map<String, Object>> toPropertyBindings(Map<String, WitnessSpec> witness) {
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        if (witness == null) {
            return out;
        }
        for (Map.Entry<String, WitnessSpec> e : witness.entrySet()) {
            if (!e.getValue().properties.isEmpty()) {
                out.put(e.getKey(), new LinkedHashMap<>(e.getValue().properties));
            }
        }
        return out;
    }

    private Map<String, List<Long>> toIdBindings(Map<String, WitnessSpec> witness) {
        Map<String, List<Long>> out = new LinkedHashMap<>();
        if (witness == null) {
            return out;
        }
        for (Map.Entry<String, WitnessSpec> e : witness.entrySet()) {
            if (!e.getValue().ids.isEmpty()) {
                out.put(e.getKey(), new ArrayList<>(e.getValue().ids));
            }
        }
        return out;
    }

    private WitnessInput parseWitnessInput(Map<String, Object> target) {
        if (target == null || target.isEmpty()) {
            return new WitnessInput(Collections.emptyList());
        }
        Object witnessesObj = target.get("witnesses");
        if (witnessesObj instanceof Iterable<?>) {
            List<Map<String, WitnessSpec>> witnessList = new ArrayList<>();
            for (Object item : (Iterable<?>) witnessesObj) {
                if (item instanceof Map<?, ?>) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> raw = (Map<String, Object>) item;
                    Map<String, WitnessSpec> parsed = parseSingleWitness(raw);
                    if (!parsed.isEmpty()) {
                        witnessList.add(parsed);
                    }
                }
            }
            return new WitnessInput(witnessList);
        }
        Object witnessObj = target.get("witness");
        if (witnessObj instanceof Map<?, ?>) {
            @SuppressWarnings("unchecked")
            Map<String, Object> raw = (Map<String, Object>) witnessObj;
            return new WitnessInput(Collections.singletonList(parseSingleWitness(raw)));
        }
        // Backward compatibility with legacy shape: {p:{...}, c:{...}}
        return new WitnessInput(Collections.singletonList(parseSingleWitness(target)));
    }

    private Map<String, WitnessSpec> parseSingleWitness(Map<String, Object> raw) {
        Map<String, WitnessSpec> out = new LinkedHashMap<>();
        if (raw == null) {
            return out;
        }
        for (Map.Entry<String, Object> e : raw.entrySet()) {
            if (!(e.getValue() instanceof Map<?, ?>)) {
                continue;
            }
            String var = e.getKey();
            if (var == null || var.isBlank()) {
                continue;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> m = (Map<String, Object>) e.getValue();
            WitnessSpec spec = new WitnessSpec();
            Object labelsObj = m.get("labels");
            if (labelsObj instanceof Iterable<?>) {
                for (Object item : (Iterable<?>) labelsObj) {
                    if (item != null) {
                        spec.labels.add(item.toString());
                    }
                }
            } else if (labelsObj instanceof String) {
                spec.labels.add((String) labelsObj);
            }
            Object propsObj = m.get("properties");
            if (propsObj instanceof Map<?, ?>) {
                for (Map.Entry<?, ?> p : ((Map<?, ?>) propsObj).entrySet()) {
                    if (p.getKey() != null) {
                        spec.properties.put(p.getKey().toString(), p.getValue());
                    }
                }
            }
            Object idsObj = m.get("ids");
            if (idsObj instanceof Iterable<?>) {
                for (Object id : (Iterable<?>) idsObj) {
                    if (id instanceof Number) {
                        spec.ids.add(((Number) id).longValue());
                    }
                }
            } else if (idsObj instanceof Number) {
                spec.ids.add(((Number) idsObj).longValue());
            }
            if (!spec.labels.isEmpty() || !spec.properties.isEmpty() || !spec.ids.isEmpty()) {
                out.put(var, spec);
            }
        }
        return out;
    }

    private String addWitnessBindings(String query, Map<String, WitnessSpec> witness) {
        if (query == null || witness == null || witness.isEmpty()) {
            return query;
        }
        List<String> predicates = new ArrayList<>();
        for (Map.Entry<String, WitnessSpec> e : witness.entrySet()) {
            String var = e.getKey();
            WitnessSpec spec = e.getValue();
            for (Long id : spec.ids) {
                predicates.add("id(" + var + ") = " + id);
            }
            for (Map.Entry<String, Object> p : spec.properties.entrySet()) {
                predicates.add(var + "." + p.getKey() + " = " + formatLiteral(p.getValue()));
            }
        }
        if (predicates.isEmpty()) {
            return query;
        }
        Matcher ret = Pattern.compile("(?i)\\bRETURN\\b").matcher(query);
        if (!ret.find()) {
            return query;
        }
        int pos = ret.start();
        String before = query.substring(0, pos).trim();
        String after = query.substring(pos);
        String clause = String.join(" AND ", predicates);
        if (Pattern.compile("(?i)\\bWHERE\\b").matcher(before).find()) {
            return before + " AND " + clause + " " + after;
        }
        return before + " WHERE " + clause + " " + after;
    }

    private String formatLiteral(Object value) {
        if (value == null) {
            return "null";
        }
        if (value instanceof Number || value instanceof Boolean) {
            return String.valueOf(value);
        }
        String escaped = String.valueOf(value).replace("'", "''");
        return "'" + escaped + "'";
    }

    private boolean optBool(Map<String, Object> options, String key, boolean defaultValue) {
        if (options == null || !options.containsKey(key)) {
            return defaultValue;
        }
        Object v = options.get(key);
        if (v instanceof Boolean) {
            return (Boolean) v;
        }
        if (v == null) {
            return defaultValue;
        }
        return Boolean.parseBoolean(String.valueOf(v));
    }

    private double optDouble(Map<String, Object> options, String key, double defaultValue) {
        if (options == null || !options.containsKey(key)) {
            return defaultValue;
        }
        return asDouble(options.get(key), defaultValue);
    }

    private String optString(Map<String, Object> options, String key, String defaultValue) {
        if (options == null || !options.containsKey(key)) {
            return defaultValue;
        }
        Object value = options.get(key);
        if (value == null) {
            return defaultValue;
        }
        String text = String.valueOf(value).trim();
        return text.isEmpty() ? defaultValue : text;
    }

    private long optLong(Map<String, Object> options, String key, long defaultValue) {
        if (options == null || !options.containsKey(key)) {
            return defaultValue;
        }
        Object v = options.get(key);
        if (v instanceof Number) {
            return ((Number) v).longValue();
        }
        try {
            return Long.parseLong(String.valueOf(v));
        } catch (Exception ignored) {
            return defaultValue;
        }
    }

    private double asDouble(Object v, double defaultValue) {
        if (v instanceof Number) {
            return ((Number) v).doubleValue();
        }
        try {
            if (v != null) {
                return Double.parseDouble(String.valueOf(v));
            }
        } catch (Exception ignored) {
        }
        return defaultValue;
    }

    public static class Why2Result {
        public String status;
        public Map<String, Object> payload;
        public Map<String, Object> diagnostics;
        public String errorMessage;

        public Why2Result(String status,
                          Map<String, Object> payload,
                          Map<String, Object> diagnostics,
                          String errorMessage) {
            this.status = status;
            this.payload = payload;
            this.diagnostics = diagnostics;
            this.errorMessage = errorMessage;
        }

        static Why2Result success(Map<String, Object> payload, Map<String, Object> diagnostics) {
            return new Why2Result("SUCCESS", payload, diagnostics, null);
        }

        static Why2Result failed(Map<String, Object> payload,
                                 Map<String, Object> diagnostics,
                                 String message) {
            return new Why2Result("FAILED", payload, diagnostics, message);
        }

        static Why2Result error(String message,
                                Map<String, Object> payload,
                                Map<String, Object> diagnostics,
                                long startMs) {
            diagnostics.putIfAbsent("elapsed_ms", System.currentTimeMillis() - startMs);
            return new Why2Result("ERROR", payload, diagnostics, message);
        }
    }

    public static class OperatorRow {
        public String operator;
        public String family;
        public String effect;
        public String modes;
        public boolean coreOperator;

        public OperatorRow(String operator, String family, String effect, String modes, boolean coreOperator) {
            this.operator = operator;
            this.family = family;
            this.effect = effect;
            this.modes = modes;
            this.coreOperator = coreOperator;
        }
    }

    public static class StatisticsProfileRow {
        public Map<String, Object> profile;

        public StatisticsProfileRow(Map<String, Object> profile) {
            this.profile = profile;
        }
    }

    private static class WitnessInput {
        final List<Map<String, WitnessSpec>> witnesses;

        WitnessInput(List<Map<String, WitnessSpec>> witnesses) {
            List<Map<String, WitnessSpec>> normalized = new ArrayList<>();
            if (witnesses != null) {
                for (Map<String, WitnessSpec> w : witnesses) {
                    if (w != null && !w.isEmpty()) {
                        normalized.add(w);
                    }
                }
            }
            this.witnesses = normalized;
        }
    }

    private static class WitnessSpec {
        final List<String> labels = new ArrayList<>();
        final Map<String, Object> properties = new LinkedHashMap<>();
        final List<Long> ids = new ArrayList<>();
    }

    private static class CoreComplianceReport {
        boolean valid = true;
        final List<Map<String, String>> violations = new ArrayList<>();

        void add(String code, String message) {
            valid = false;
            Map<String, String> entry = new LinkedHashMap<>();
            entry.put("code", code);
            entry.put("message", message);
            violations.add(entry);
        }

        Map<String, Object> toMap() {
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("valid", valid);
            out.put("violations", violations);
            return out;
        }
    }

    private boolean isCoreRewriteOperator(ModificationOperation.Type t) {
        switch (t) {
            case DELETE_PREDICATE:
            case RELAX_ENDPOINT_PREDICATE:
            case RELAX_LABEL:
            case WEAKEN_PREDICATE:
            case DELETE_NODE:
            case DELETE_RELATIONSHIP:
            case DEL_EDGE:
            case REPLACE_RELATIONSHIP_TYPE:
            case FLIP_RELATIONSHIP_DIRECTION:
            case REPAIR_END_LABEL:
            case ADD_PREDICATE:
            case STRENGTHEN_PREDICATE:
            case ADD_LABEL:
            case ADD_EDGE:
            case ADD_RELATIONSHIP:
                return true;
            default:
                return false;
        }
    }

    private String operatorFamily(ModificationOperation.Type t) {
        switch (t) {
            case DELETE_PREDICATE:
            case RELAX_ENDPOINT_PREDICATE:
            case RELAX_LABEL:
            case WEAKEN_PREDICATE:
            case DELETE_NODE:
            case DELETE_RELATIONSHIP:
            case DEL_EDGE:
            case MAKE_OPTIONAL:
                return "RELAX";
            case REPLACE_RELATIONSHIP_TYPE:
            case FLIP_RELATIONSHIP_DIRECTION:
            case REPAIR_END_LABEL:
                return "REPAIR";
            case ADD_PREDICATE:
            case STRENGTHEN_PREDICATE:
            case ADD_LABEL:
            case ADD_EDGE:
            case ADD_RELATIONSHIP:
                return "RESTRICT";
            default:
                return "OTHER";
        }
    }

    private String operatorEffect(ModificationOperation.Type t) {
        switch (t) {
            case DELETE_PREDICATE:
            case RELAX_ENDPOINT_PREDICATE:
            case RELAX_LABEL:
            case WEAKEN_PREDICATE:
            case DELETE_NODE:
            case DELETE_RELATIONSHIP:
            case DEL_EDGE:
            case MAKE_OPTIONAL:
                return "UP";
            case ADD_PREDICATE:
            case STRENGTHEN_PREDICATE:
            case ADD_LABEL:
            case ADD_EDGE:
            case ADD_RELATIONSHIP:
                return "DOWN";
            case REPLACE_RELATIONSHIP_TYPE:
            case FLIP_RELATIONSHIP_DIRECTION:
            case REPAIR_END_LABEL:
                return "NEUTRAL_OR_UP";
            default:
                return "UNSPECIFIED";
        }
    }

    private String operatorModes(ModificationOperation.Type t) {
        switch (t) {
            case ADD_PREDICATE:
            case STRENGTHEN_PREDICATE:
            case ADD_LABEL:
            case ADD_EDGE:
            case ADD_RELATIONSHIP:
                return "M,N";
            case DELETE_PREDICATE:
            case RELAX_ENDPOINT_PREDICATE:
            case RELAX_LABEL:
            case WEAKEN_PREDICATE:
            case DELETE_NODE:
            case DELETE_RELATIONSHIP:
            case DEL_EDGE:
            case MAKE_OPTIONAL:
            case REPLACE_RELATIONSHIP_TYPE:
            case FLIP_RELATIONSHIP_DIRECTION:
            case REPAIR_END_LABEL:
                return "E,F,N";
            default:
                return "";
        }
    }
}
