package com.whyquery.neo4j.paths;

import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Generates alternative path algorithms and query modifications to improve
 * path finding or address path-related issues.
 */
public class PathAlternativeGenerator {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    private final Neo4jStatistics statistics;
    
    public PathAlternativeGenerator(GraphDatabaseService db, Transaction tx, Neo4jStatistics statistics) {
        this.db = db;
        this.tx = tx;
        this.statistics = statistics;
    }
    
    /**
     * Generate path alternatives based on analysis
     */
    public List<PathAlternative> generateAlternatives(PathAnalysis analysis) {
        List<PathAlternative> alternatives = new ArrayList<>();
        
        // Generate algorithm alternatives
        alternatives.addAll(generateAlgorithmAlternatives(analysis));
        
        // Generate constraint modifications
        alternatives.addAll(generateConstraintAlternatives(analysis));
        
        // Generate optimization alternatives
        alternatives.addAll(generateOptimizationAlternatives(analysis));
        
        // Generate relationship type alternatives
        alternatives.addAll(generateRelationshipTypeAlternatives(analysis));
        
        // Sort by estimated effectiveness
        alternatives.sort((a, b) -> Double.compare(b.getEffectivenessScore(), a.getEffectivenessScore()));
        
        return alternatives;
    }
    
    /**
     * Generate alternatives with different path algorithms
     */
    private List<PathAlternative> generateAlgorithmAlternatives(PathAnalysis analysis) {
        List<PathAlternative> alternatives = new ArrayList<>();
        String originalQuery = analysis.getOriginalQuery();
        PathAlgorithmType currentAlgorithm = analysis.getAlgorithmType();
        
        // Suggest shortest path if not already using it
        if (currentAlgorithm != PathAlgorithmType.SHORTEST_PATH && 
            currentAlgorithm != PathAlgorithmType.ALL_SHORTEST_PATHS) {
            
            PathAlternative shortestPathAlt = new PathAlternative();
            shortestPathAlt.setType(PathAlternativeType.ALGORITHM_CHANGE);
            shortestPathAlt.setTitle("Use Shortest Path Algorithm");
            shortestPathAlt.setDescription("Replace current path finding with shortestPath() for optimal hop count");
            shortestPathAlt.setModifiedQuery(convertToShortestPath(originalQuery));
            shortestPathAlt.setEffectivenessScore(0.8);
            shortestPathAlt.addBenefit("Guaranteed minimal hop count");
            shortestPathAlt.addBenefit("Better performance for simple connectivity queries");
            alternatives.add(shortestPathAlt);
        }
        
        // Suggest all shortest paths for finding multiple optimal paths
        if (currentAlgorithm == PathAlgorithmType.SHORTEST_PATH) {
            PathAlternative allShortestAlt = new PathAlternative();
            allShortestAlt.setType(PathAlternativeType.ALGORITHM_CHANGE);
            allShortestAlt.setTitle("Find All Shortest Paths");
            allShortestAlt.setDescription("Use allShortestPaths() to find all optimal routes");
            allShortestAlt.setModifiedQuery(convertToAllShortestPaths(originalQuery));
            allShortestAlt.setEffectivenessScore(0.7);
            allShortestAlt.addBenefit("Discover multiple optimal paths");
            allShortestAlt.addBenefit("Better for redundancy analysis");
            allShortestAlt.addTradeoff("Higher memory usage");
            alternatives.add(allShortestAlt);
        }
        
        // Suggest weighted shortest path if weights are available
        if (hasWeightableRelationships(analysis)) {
            PathAlternative weightedAlt = new PathAlternative();
            weightedAlt.setType(PathAlternativeType.ALGORITHM_CHANGE);
            weightedAlt.setTitle("Use Weighted Shortest Path");
            weightedAlt.setDescription("Optimize for total cost rather than hop count");
            weightedAlt.setModifiedQuery(convertToWeightedShortestPath(originalQuery));
            weightedAlt.setEffectivenessScore(0.9);
            weightedAlt.addBenefit("Considers relationship costs/weights");
            weightedAlt.addBenefit("More realistic path optimization");
            alternatives.add(weightedAlt);
        }
        
        // Suggest variable-length traversal for flexibility
        if (currentAlgorithm == PathAlgorithmType.FIXED_LENGTH) {
            PathAlternative variableLengthAlt = new PathAlternative();
            variableLengthAlt.setType(PathAlternativeType.ALGORITHM_CHANGE);
            variableLengthAlt.setTitle("Use Variable-Length Traversal");
            variableLengthAlt.setDescription("Allow flexible path lengths with [*min..max] syntax");
            variableLengthAlt.setModifiedQuery(convertToVariableLength(originalQuery));
            variableLengthAlt.setEffectivenessScore(0.6);
            variableLengthAlt.addBenefit("More flexible path discovery");
            variableLengthAlt.addBenefit("Can find paths of varying lengths");
            variableLengthAlt.addTradeoff("Potentially higher complexity");
            alternatives.add(variableLengthAlt);
        }
        
        return alternatives;
    }
    
    /**
     * Generate alternatives with modified constraints
     */
    private List<PathAlternative> generateConstraintAlternatives(PathAnalysis analysis) {
        List<PathAlternative> alternatives = new ArrayList<>();
        String originalQuery = analysis.getOriginalQuery();
        PathConstraints constraints = analysis.getConstraints();
        
        if (constraints == null) return alternatives;
        
        // Relax length constraints
        if (constraints.hasLengthConstraints()) {
            PathAlternative relaxLengthAlt = new PathAlternative();
            relaxLengthAlt.setType(PathAlternativeType.CONSTRAINT_RELAXATION);
            relaxLengthAlt.setTitle("Relax Length Constraints");
            relaxLengthAlt.setDescription("Increase maximum path length to find more paths");
            relaxLengthAlt.setModifiedQuery(relaxLengthConstraints(originalQuery, constraints));
            relaxLengthAlt.setEffectivenessScore(0.5);
            relaxLengthAlt.addBenefit("May discover previously excluded paths");
            relaxLengthAlt.addTradeoff("Potentially longer, less optimal paths");
            alternatives.add(relaxLengthAlt);
        }
        
        // Tighten length constraints
        if (constraints.getMaxLength() > 3) {
            PathAlternative tightenLengthAlt = new PathAlternative();
            tightenLengthAlt.setType(PathAlternativeType.CONSTRAINT_TIGHTENING);
            tightenLengthAlt.setTitle("Tighten Length Constraints");
            tightenLengthAlt.setDescription("Reduce maximum path length for faster, more direct paths");
            tightenLengthAlt.setModifiedQuery(tightenLengthConstraints(originalQuery, constraints));
            tightenLengthAlt.setEffectivenessScore(0.6);
            tightenLengthAlt.addBenefit("Faster query execution");
            tightenLengthAlt.addBenefit("More direct paths");
            tightenLengthAlt.addTradeoff("May miss some valid paths");
            alternatives.add(tightenLengthAlt);
        }
        
        // Add relationship direction constraints
        if ("BOTH".equals(constraints.getDirection())) {
            PathAlternative directionAlt = new PathAlternative();
            directionAlt.setType(PathAlternativeType.CONSTRAINT_ADDITION);
            directionAlt.setTitle("Constrain Relationship Direction");
            directionAlt.setDescription("Use directed relationships for more predictable paths");
            directionAlt.setModifiedQuery(addDirectionConstraints(originalQuery));
            directionAlt.setEffectivenessScore(0.4);
            directionAlt.addBenefit("More predictable path semantics");
            directionAlt.addBenefit("Often better performance");
            alternatives.add(directionAlt);
        }
        
        return alternatives;
    }
    
    /**
     * Generate optimization alternatives
     */
    private List<PathAlternative> generateOptimizationAlternatives(PathAnalysis analysis) {
        List<PathAlternative> alternatives = new ArrayList<>();
        String originalQuery = analysis.getOriginalQuery();
        
        // Add LIMIT for performance
        if (!originalQuery.toUpperCase().contains("LIMIT")) {
            PathAlternative limitAlt = new PathAlternative();
            limitAlt.setType(PathAlternativeType.PERFORMANCE_OPTIMIZATION);
            limitAlt.setTitle("Add Result Limit");
            limitAlt.setDescription("Limit results to improve query performance");
            limitAlt.setModifiedQuery(addLimit(originalQuery, 100));
            limitAlt.setEffectivenessScore(0.7);
            limitAlt.addBenefit("Improved query performance");
            limitAlt.addBenefit("Reduced memory usage");
            limitAlt.addTradeoff("May not return all valid paths");
            alternatives.add(limitAlt);
        }
        
        // Add path uniqueness constraints
        PathAlternative uniqueAlt = new PathAlternative();
        uniqueAlt.setType(PathAlternativeType.CONSTRAINT_ADDITION);
        uniqueAlt.setTitle("Ensure Path Uniqueness");
        uniqueAlt.setDescription("Add constraints to prevent duplicate or cyclic paths");
        uniqueAlt.setModifiedQuery(addUniquenessConstraints(originalQuery));
        uniqueAlt.setEffectivenessScore(0.5);
        uniqueAlt.addBenefit("Eliminates redundant paths");
        uniqueAlt.addBenefit("Cleaner result set");
        alternatives.add(uniqueAlt);
        
        // Add node filtering
        PathAlternative nodeFilterAlt = new PathAlternative();
        nodeFilterAlt.setType(PathAlternativeType.CONSTRAINT_ADDITION);
        nodeFilterAlt.setTitle("Add Node Filtering");
        nodeFilterAlt.setDescription("Filter intermediate nodes by properties or labels");
        nodeFilterAlt.setModifiedQuery(addNodeFiltering(originalQuery));
        nodeFilterAlt.setEffectivenessScore(0.6);
        nodeFilterAlt.addBenefit("More relevant intermediate nodes");
        nodeFilterAlt.addBenefit("Better semantic meaning");
        alternatives.add(nodeFilterAlt);
        
        return alternatives;
    }
    
    /**
     * Generate relationship type alternatives
     */
    private List<PathAlternative> generateRelationshipTypeAlternatives(PathAnalysis analysis) {
        List<PathAlternative> alternatives = new ArrayList<>();
        String originalQuery = analysis.getOriginalQuery();
        PathConstraints constraints = analysis.getConstraints();
        
        // Suggest specific relationship types if currently using all types
        if (constraints == null || constraints.getAllowedRelationshipTypes().isEmpty()) {
            PathAlternative specificTypesAlt = new PathAlternative();
            specificTypesAlt.setType(PathAlternativeType.RELATIONSHIP_TYPE_CONSTRAINT);
            specificTypesAlt.setTitle("Constrain Relationship Types");
            specificTypesAlt.setDescription("Specify relationship types for more meaningful paths");
            specificTypesAlt.setModifiedQuery(addRelationshipTypeConstraints(originalQuery));
            specificTypesAlt.setEffectivenessScore(0.8);
            specificTypesAlt.addBenefit("More semantically meaningful paths");
            specificTypesAlt.addBenefit("Better performance through selectivity");
            alternatives.add(specificTypesAlt);
        }
        
        // Suggest excluding certain relationship types
        if (constraints != null && !constraints.getAllowedRelationshipTypes().isEmpty()) {
            PathAlternative excludeTypesAlt = new PathAlternative();
            excludeTypesAlt.setType(PathAlternativeType.RELATIONSHIP_TYPE_CONSTRAINT);
            excludeTypesAlt.setTitle("Exclude Noisy Relationship Types");
            excludeTypesAlt.setDescription("Remove relationship types that create irrelevant paths");
            excludeTypesAlt.setModifiedQuery(addRelationshipTypeExclusions(originalQuery));
            excludeTypesAlt.setEffectivenessScore(0.6);
            excludeTypesAlt.addBenefit("Cleaner, more focused paths");
            excludeTypesAlt.addBenefit("Reduced noise in results");
            alternatives.add(excludeTypesAlt);
        }
        
        return alternatives;
    }
    
    /**
     * Convert query to use shortest path
     */
    private String convertToShortestPath(String originalQuery) {
        // Look for path patterns and wrap them in shortestPath()
        String pattern = "\\(([^)]+)\\)\\s*-\\[[^\\]]*\\]->?\\s*\\(([^)]+)\\)";
        Pattern pathPattern = Pattern.compile(pattern);
        Matcher matcher = pathPattern.matcher(originalQuery);
        
        if (matcher.find()) {
            String pathExpression = matcher.group(0);
            String shortestPathExpression = "shortestPath(" + pathExpression + ")";
            return originalQuery.replace(pathExpression, shortestPathExpression);
        }
        
        return originalQuery + " /* Consider wrapping path in shortestPath() */";
    }
    
    /**
     * Convert query to use all shortest paths
     */
    private String convertToAllShortestPaths(String originalQuery) {
        return originalQuery.replaceAll("(?i)shortestPath\\s*\\(", "allShortestPaths(");
    }
    
    /**
     * Convert query to use weighted shortest path
     */
    private String convertToWeightedShortestPath(String originalQuery) {
        // Add weight property to relationships
        String modifiedQuery = originalQuery.replaceAll(
            "\\[([^\\]]*)\\]", 
            "[$1 {weight: r.cost}]"
        );
        
        if (modifiedQuery.equals(originalQuery)) {
            modifiedQuery = originalQuery + " /* Add {weight: r.propertyName} to relationships */";
        }
        
        return modifiedQuery;
    }
    
    /**
     * Convert fixed-length to variable-length
     */
    private String convertToVariableLength(String originalQuery) {
        // Convert single relationships to variable-length
        return originalQuery.replaceAll("\\[([^\\]]*[^*])\\]", "[$1*1..3]");
    }
    
    /**
     * Relax length constraints
     */
    private String relaxLengthConstraints(String originalQuery, PathConstraints constraints) {
        int newMaxLength = Math.min(constraints.getMaxLength() * 2, 10);
        String currentPattern = "\\*" + constraints.getMinLength() + "\\.\\." + constraints.getMaxLength();
        String newPattern = "*" + constraints.getMinLength() + ".." + newMaxLength;
        
        return originalQuery.replaceAll(currentPattern, newPattern);
    }
    
    /**
     * Tighten length constraints
     */
    private String tightenLengthConstraints(String originalQuery, PathConstraints constraints) {
        int newMaxLength = Math.max(constraints.getMaxLength() / 2, constraints.getMinLength());
        String currentPattern = "\\*" + constraints.getMinLength() + "\\.\\." + constraints.getMaxLength();
        String newPattern = "*" + constraints.getMinLength() + ".." + newMaxLength;
        
        return originalQuery.replaceAll(currentPattern, newPattern);
    }
    
    /**
     * Add direction constraints
     */
    private String addDirectionConstraints(String originalQuery) {
        // Convert undirected to directed relationships
        return originalQuery.replaceAll("-\\[([^\\]]*)\\]-", "-[$1]->")
                          .replaceAll("<-\\[([^\\]]*)\\]-", "<-[$1]-");
    }
    
    /**
     * Add LIMIT clause
     */
    private String addLimit(String originalQuery, int limit) {
        if (originalQuery.toUpperCase().contains("LIMIT")) {
            return originalQuery;
        }
        
        return originalQuery + " LIMIT " + limit;
    }
    
    /**
     * Add uniqueness constraints
     */
    private String addUniquenessConstraints(String originalQuery) {
        // This is a simplified approach - in practice would need more sophisticated AST manipulation
        return originalQuery + " /* Add WHERE none(n IN nodes(path)[1..-1] WHERE n = nodes(path)[0]) to prevent cycles */";
    }
    
    /**
     * Add node filtering
     */
    private String addNodeFiltering(String originalQuery) {
        return originalQuery + " /* Add WHERE clauses to filter intermediate nodes by label or properties */";
    }
    
    /**
     * Add relationship type constraints
     */
    private String addRelationshipTypeConstraints(String originalQuery) {
        // Replace generic relationships with type-specific ones
        return originalQuery.replaceAll("\\[\\s*\\]", "[:SPECIFIC_TYPE]")
                          .replaceAll("\\[\\s*\\*", "[:SPECIFIC_TYPE*");
    }
    
    /**
     * Add relationship type exclusions
     */
    private String addRelationshipTypeExclusions(String originalQuery) {
        return originalQuery + " /* Consider excluding noisy relationship types like [:!NOISE_TYPE] */";
    }
    
    /**
     * Check if relationships can be weighted
     */
    private boolean hasWeightableRelationships(PathAnalysis analysis) {
        String query = analysis.getOriginalQuery().toLowerCase();
        return query.contains("cost") || query.contains("weight") || 
               query.contains("distance") || query.contains("length") ||
               query.contains("duration") || query.contains("price");
    }
}