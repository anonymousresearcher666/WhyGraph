package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.schema.SchemaGraph;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lightweight A-LHD-style cardinality estimator.
 *
 * It propagates label/type probabilities over the query pattern using the
 * snapshot statistics already maintained by WhyGraph. This is an estimator
 * backend for comparison; it is not used as a formal bound.
 */
final class LabelProbabilityCardinalityEstimator {
    private static final Pattern MATCH_BODY = Pattern.compile(
        "(?is)\\bMATCH\\s+(.*?)(?:\\bWHERE\\b|\\bRETURN\\b|\\bORDER\\s+BY\\b|\\bLIMIT\\b|$)"
    );
    private static final Pattern NODE = Pattern.compile(
        "\\(([A-Za-z_][A-Za-z0-9_]*|)([^)]*)\\)"
    );
    private static final Pattern REL = Pattern.compile(
        "\\(([A-Za-z_][A-Za-z0-9_]*|)([^)]*)\\)\\s*(<-|-)" +
        "\\s*(?:\\[[^]:]*:([A-Za-z_][A-Za-z0-9_]*)[^]]*\\])?\\s*" +
        "(->|-)" +
        "\\s*\\(([A-Za-z_][A-Za-z0-9_]*|)([^)]*)\\)"
    );
    private static final Pattern LABEL = Pattern.compile(":([A-Za-z_][A-Za-z0-9_]*)");

    private final DatabaseSchemaCache schemaCache;

    LabelProbabilityCardinalityEstimator(DatabaseSchemaCache schemaCache) {
        this.schemaCache = schemaCache;
    }

    long estimate(CypherAST ast, String query) {
        String cypher = query != null && !query.isBlank()
            ? query
            : ast != null ? ast.generateCypher() : "";
        PatternSnapshot pattern = parse(cypher);
        if (pattern.nodes.isEmpty() && pattern.edges.isEmpty()) {
            return -1L;
        }
        double estimate = estimatePattern(pattern);
        if (!Double.isFinite(estimate) || estimate < 0.0) {
            return -1L;
        }
        if (estimate >= Long.MAX_VALUE) {
            return Long.MAX_VALUE;
        }
        return Math.round(estimate);
    }

    private double estimatePattern(PatternSnapshot pattern) {
        Map<String, Long> labelCounts = schemaCache.getLabelCountsSnapshot();
        long totalNodes = labelCounts.values().stream().mapToLong(Long::longValue).sum();
        if (totalNodes <= 0) {
            return -1.0;
        }
        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = schemaCache.getSchemaTripleStats();
        if (pattern.edges.isEmpty()) {
            double product = 1.0;
            for (NodePattern node : pattern.nodes.values()) {
                product *= nodeSpace(node, labelCounts, totalNodes);
            }
            return product;
        }

        List<EdgePattern> ordered = orderEdges(pattern);
        Set<String> bound = new HashSet<>();
        double cardinality = -1.0;
        for (EdgePattern edge : ordered) {
            double edgeCount = edgeCount(edge, pattern, triples);
            if (edgeCount <= 0.0) {
                return 0.0;
            }
            if (cardinality < 0.0) {
                cardinality = edgeCount;
                bound.add(edge.source);
                bound.add(edge.target);
                continue;
            }
            boolean sourceBound = bound.contains(edge.source);
            boolean targetBound = bound.contains(edge.target);
            if (sourceBound && !targetBound) {
                cardinality *= averageOutDegree(edge, pattern, triples, labelCounts, totalNodes);
                bound.add(edge.target);
            } else if (!sourceBound && targetBound) {
                cardinality *= averageInDegree(edge, pattern, triples, labelCounts, totalNodes);
                bound.add(edge.source);
            } else if (sourceBound && targetBound) {
                double sourceSpace = nodeSpace(pattern.node(edge.source), labelCounts, totalNodes);
                double targetSpace = nodeSpace(pattern.node(edge.target), labelCounts, totalNodes);
                cardinality *= Math.min(1.0, edgeCount / Math.max(1.0, sourceSpace * targetSpace));
            } else {
                cardinality *= edgeCount;
                bound.add(edge.source);
                bound.add(edge.target);
            }
        }
        return Math.max(0.0, cardinality);
    }

    private List<EdgePattern> orderEdges(PatternSnapshot pattern) {
        List<EdgePattern> remaining = new ArrayList<>(pattern.edges);
        remaining.sort(Comparator.comparingDouble(edge -> edgeNodeLabelCount(edge, pattern)));
        List<EdgePattern> ordered = new ArrayList<>();
        Set<String> bound = new HashSet<>();
        while (!remaining.isEmpty()) {
            int best = 0;
            for (int i = 0; i < remaining.size(); i++) {
                EdgePattern edge = remaining.get(i);
                if (bound.contains(edge.source) || bound.contains(edge.target)) {
                    best = i;
                    break;
                }
            }
            EdgePattern edge = remaining.remove(best);
            ordered.add(edge);
            bound.add(edge.source);
            bound.add(edge.target);
        }
        return ordered;
    }

    private int edgeNodeLabelCount(EdgePattern edge, PatternSnapshot pattern) {
        return pattern.node(edge.source).labels.size() + pattern.node(edge.target).labels.size();
    }

    private double averageOutDegree(EdgePattern edge,
                                    PatternSnapshot pattern,
                                    Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples,
                                    Map<String, Long> labelCounts,
                                    long totalNodes) {
        double count = edgeCount(edge, pattern, triples);
        double sourceSpace = nodeSpace(pattern.node(edge.source), labelCounts, totalNodes);
        return count / Math.max(1.0, sourceSpace);
    }

    private double averageInDegree(EdgePattern edge,
                                   PatternSnapshot pattern,
                                   Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples,
                                   Map<String, Long> labelCounts,
                                   long totalNodes) {
        double count = edgeCount(edge, pattern, triples);
        double targetSpace = nodeSpace(pattern.node(edge.target), labelCounts, totalNodes);
        return count / Math.max(1.0, targetSpace);
    }

    private double edgeCount(EdgePattern edge,
                             PatternSnapshot pattern,
                             Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples) {
        Set<String> sourceLabels = expandLabels(pattern.node(edge.source).labels);
        Set<String> targetLabels = expandLabels(pattern.node(edge.target).labels);
        double count = 0.0;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry : triples.entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (edge.type != null && !edge.type.equals(triple.getRelationshipType())) {
                continue;
            }
            boolean forward = sourceLabels.contains(triple.getSourceLabel())
                && targetLabels.contains(triple.getTargetLabel());
            boolean backward = !edge.directed
                && sourceLabels.contains(triple.getTargetLabel())
                && targetLabels.contains(triple.getSourceLabel());
            if (forward || backward) {
                count += Math.max(0L, entry.getValue().getEdgeCount());
            }
        }
        return count;
    }

    private Set<String> expandLabels(Set<String> labels) {
        if (labels == null || labels.isEmpty()) {
            return schemaCache.getAllLabels();
        }
        return labels;
    }

    private double nodeSpace(NodePattern node, Map<String, Long> labelCounts, long totalNodes) {
        if (node == null || node.labels.isEmpty()) {
            return totalNodes;
        }
        long best = Long.MAX_VALUE;
        for (String label : node.labels) {
            long count = labelCounts.getOrDefault(label, 0L);
            if (count <= 0) {
                return 0.0;
            }
            best = Math.min(best, count);
        }
        return best == Long.MAX_VALUE ? totalNodes : best;
    }

    private PatternSnapshot parse(String cypher) {
        String body = extractMatchBody(cypher);
        PatternSnapshot snapshot = new PatternSnapshot();
        if (body.isBlank()) {
            return snapshot;
        }
        Matcher nodeMatcher = NODE.matcher(body);
        while (nodeMatcher.find()) {
            String variable = nodeMatcher.group(1);
            if (variable == null || variable.isBlank()) {
                variable = "_n" + snapshot.nodes.size();
            }
            snapshot.nodes.putIfAbsent(variable, new NodePattern(variable, labels(nodeMatcher.group(2))));
        }
        Matcher relMatcher = REL.matcher(body);
        while (relMatcher.find()) {
            String source = relMatcher.group(1);
            String target = relMatcher.group(6);
            if (source == null || source.isBlank() || target == null || target.isBlank()) {
                continue;
            }
            String leftArrow = relMatcher.group(3);
            String type = relMatcher.group(4);
            String rightArrow = relMatcher.group(5);
            boolean incoming = "<-".equals(leftArrow);
            boolean outgoing = "->".equals(rightArrow);
            String normalizedSource = incoming ? target : source;
            String normalizedTarget = incoming ? source : target;
            boolean directed = incoming || outgoing;
            snapshot.edges.add(new EdgePattern(normalizedSource, normalizedTarget, type, directed));
        }
        return snapshot;
    }

    private String extractMatchBody(String cypher) {
        Matcher matcher = MATCH_BODY.matcher(cypher == null ? "" : cypher);
        if (!matcher.find()) {
            return "";
        }
        return stripInlineProperties(matcher.group(1));
    }

    private String stripInlineProperties(String text) {
        return text.replaceAll("\\{[^}]*}", "");
    }

    private Set<String> labels(String text) {
        LinkedHashSet<String> labels = new LinkedHashSet<>();
        Matcher matcher = LABEL.matcher(text == null ? "" : text);
        while (matcher.find()) {
            labels.add(matcher.group(1));
        }
        return labels;
    }

    private static final class PatternSnapshot {
        private final Map<String, NodePattern> nodes = new LinkedHashMap<>();
        private final List<EdgePattern> edges = new ArrayList<>();

        private NodePattern node(String variable) {
            return nodes.computeIfAbsent(variable, v -> new NodePattern(v, Set.of()));
        }
    }

    private static final class NodePattern {
        private final String variable;
        private final Set<String> labels;

        private NodePattern(String variable, Set<String> labels) {
            this.variable = variable;
            this.labels = labels == null ? Set.of() : labels;
        }
    }

    private static final class EdgePattern {
        private final String source;
        private final String target;
        private final String type;
        private final boolean directed;

        private EdgePattern(String source, String target, String type, boolean directed) {
            this.source = source;
            this.target = target;
            this.type = type;
            this.directed = directed;
        }
    }
}
