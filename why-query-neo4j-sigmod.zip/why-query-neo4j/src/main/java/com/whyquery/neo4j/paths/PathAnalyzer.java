package com.whyquery.neo4j.paths;

import com.whyquery.neo4j.ast.*;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Analyzes path patterns in Cypher queries to explain path selection decisions
 * and identify alternative path-finding approaches.
 */
public class PathAnalyzer {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    private final Neo4jStatistics statistics;
    
    public PathAnalyzer(GraphDatabaseService db, Transaction tx, Neo4jStatistics statistics) {
        this.db = db;
        this.tx = tx;
        this.statistics = statistics;
    }
    
    /**
     * Analyze path patterns in a Cypher query
     */
    public PathAnalysis analyzePaths(CypherAST ast, String originalQuery) {
        PathAnalysis analysis = new PathAnalysis();
        analysis.setOriginalQuery(originalQuery);
        
        // Extract path patterns from AST
        List<PathPattern> patterns = extractPathPatterns(ast, originalQuery);
        analysis.setPathPatterns(patterns);
        
        // Determine path algorithm being used
        PathAlgorithmType algorithmType = detectPathAlgorithm(originalQuery, patterns);
        analysis.setAlgorithmType(algorithmType);
        
        // Extract path constraints
        PathConstraints constraints = extractPathConstraints(originalQuery, patterns);
        analysis.setConstraints(constraints);
        
        // Analyze actual paths found
        List<PathInstance> actualPaths = findActualPaths(originalQuery, patterns);
        analysis.setActualPaths(actualPaths);
        
        return analysis;
    }
    
    /**
     * Extract path patterns from the AST
     */
    private List<PathPattern> extractPathPatterns(CypherAST ast, String originalQuery) {
        List<PathPattern> patterns = new ArrayList<>();
        
        // Look for shortest path functions
        if (originalQuery.toLowerCase().contains("shortestpath")) {
            patterns.addAll(extractShortestPathPatterns(originalQuery));
        }
        
        // Look for variable-length relationships
        patterns.addAll(extractVariableLengthPatterns(ast, originalQuery));
        
        // Look for regular path patterns
        patterns.addAll(extractRegularPathPatterns(ast));
        
        return patterns;
    }
    
    /**
     * Extract shortest path patterns
     */
    private List<PathPattern> extractShortestPathPatterns(String query) {
        List<PathPattern> patterns = new ArrayList<>();
        
        // Pattern for shortestPath((start)-[relationships*]-(end))
        Pattern shortestPathPattern = Pattern.compile(
            "shortestPath\\s*\\(\\s*\\((\\w+)\\)\\s*-\\[(.*?)\\]-\\s*\\((\\w+)\\)\\s*\\)",
            Pattern.CASE_INSENSITIVE);
        
        Matcher matcher = shortestPathPattern.matcher(query);
        while (matcher.find()) {
            PathPattern pattern = new PathPattern();
            pattern.setType(PathPatternType.SHORTEST_PATH);
            pattern.setStartVariable(matcher.group(1));
            pattern.setEndVariable(matcher.group(3));
            pattern.setRelationshipPattern(matcher.group(2));
            pattern.setMinLength(1);
            pattern.setMaxLength(Integer.MAX_VALUE);
            patterns.add(pattern);
        }
        
        return patterns;
    }
    
    /**
     * Extract variable-length relationship patterns
     */
    private List<PathPattern> extractVariableLengthPatterns(CypherAST ast, String query) {
        List<PathPattern> patterns = new ArrayList<>();
        
        // Pattern for variable-length relationships: [*min..max] or [*] or [*n]
        Pattern varLengthPattern = Pattern.compile(
            "\\[([^\\]]*?)\\*(\\d+)?(?:\\.\\.(\\d+|\\*))?([^\\]]*)\\]",
            Pattern.CASE_INSENSITIVE);
        
        Matcher matcher = varLengthPattern.matcher(query);
        while (matcher.find()) {
            PathPattern pattern = new PathPattern();
            pattern.setType(PathPatternType.VARIABLE_LENGTH);
            
            String beforeStar = matcher.group(1);
            String minStr = matcher.group(2);
            String maxStr = matcher.group(3);
            String afterStar = matcher.group(4);
            
            // Extract relationship types from before and after
            pattern.setRelationshipTypes(extractRelationshipTypes(beforeStar + afterStar));
            
            // Parse length constraints
            if (minStr != null) {
                pattern.setMinLength(Integer.parseInt(minStr));
                if (maxStr != null) {
                    if ("*".equals(maxStr)) {
                        pattern.setMaxLength(Integer.MAX_VALUE);
                    } else {
                        pattern.setMaxLength(Integer.parseInt(maxStr));
                    }
                } else {
                    pattern.setMaxLength(Integer.parseInt(minStr));
                }
            } else {
                pattern.setMinLength(1);
                pattern.setMaxLength(Integer.MAX_VALUE);
            }
            
            patterns.add(pattern);
        }
        
        return patterns;
    }
    
    /**
     * Extract regular path patterns (fixed-length)
     */
    private List<PathPattern> extractRegularPathPatterns(CypherAST ast) {
        List<PathPattern> patterns = new ArrayList<>();
        
        List<ASTNode> relationshipNodes = ast.getNodesByType(NodeType.RELATIONSHIP);
        for (ASTNode relNode : relationshipNodes) {
            String type = relNode.getAttribute("type", String.class);
            String direction = relNode.getAttribute("direction", String.class);
            
            if (type != null && !type.contains("*")) {
                PathPattern pattern = new PathPattern();
                pattern.setType(PathPatternType.FIXED_LENGTH);
                pattern.setRelationshipTypes(Arrays.asList(type));
                pattern.setDirection(direction);
                pattern.setMinLength(1);
                pattern.setMaxLength(1);
                patterns.add(pattern);
            }
        }
        
        return patterns;
    }
    
    /**
     * Extract relationship types from a pattern string
     */
    private List<String> extractRelationshipTypes(String pattern) {
        List<String> types = new ArrayList<>();
        
        if (pattern == null || pattern.trim().isEmpty()) {
            return types;
        }
        
        // Remove colons and split by pipe
        String cleaned = pattern.replaceAll(":", "").trim();
        if (!cleaned.isEmpty()) {
            String[] parts = cleaned.split("\\|");
            for (String part : parts) {
                String trimmed = part.trim();
                if (!trimmed.isEmpty()) {
                    types.add(trimmed);
                }
            }
        }
        
        return types;
    }
    
    /**
     * Detect the path algorithm being used
     */
    private PathAlgorithmType detectPathAlgorithm(String query, List<PathPattern> patterns) {
        String lowerQuery = query.toLowerCase();
        
        if (lowerQuery.contains("shortestpath(")) {
            return PathAlgorithmType.SHORTEST_PATH;
        } else if (lowerQuery.contains("allshortestpaths(")) {
            return PathAlgorithmType.ALL_SHORTEST_PATHS;
        } else if (hasVariableLengthPatterns(patterns)) {
            return PathAlgorithmType.VARIABLE_LENGTH;
        } else if (hasFixedLengthPaths(patterns)) {
            return PathAlgorithmType.FIXED_LENGTH;
        } else {
            return PathAlgorithmType.SIMPLE_TRAVERSAL;
        }
    }
    
    /**
     * Check if patterns contain variable-length relationships
     */
    private boolean hasVariableLengthPatterns(List<PathPattern> patterns) {
        return patterns.stream().anyMatch(p -> p.getType() == PathPatternType.VARIABLE_LENGTH);
    }
    
    /**
     * Check if patterns contain fixed-length paths
     */
    private boolean hasFixedLengthPaths(List<PathPattern> patterns) {
        return patterns.stream().anyMatch(p -> p.getType() == PathPatternType.FIXED_LENGTH);
    }
    
    /**
     * Extract path constraints from the query
     */
    private PathConstraints extractPathConstraints(String query, List<PathPattern> patterns) {
        PathConstraints constraints = new PathConstraints();
        
        // Extract length constraints
        for (PathPattern pattern : patterns) {
            constraints.setMinLength(Math.min(constraints.getMinLength(), pattern.getMinLength()));
            constraints.setMaxLength(Math.max(constraints.getMaxLength(), pattern.getMaxLength()));
        }
        
        // Extract relationship type constraints
        Set<String> allowedTypes = new HashSet<>();
        for (PathPattern pattern : patterns) {
            allowedTypes.addAll(pattern.getRelationshipTypes());
        }
        constraints.setAllowedRelationshipTypes(new ArrayList<>(allowedTypes));
        
        // Extract direction constraints
        String direction = extractDirectionConstraint(query);
        constraints.setDirection(direction);
        
        // Extract weight property if present
        String weightProperty = extractWeightProperty(query);
        constraints.setWeightProperty(weightProperty);
        
        return constraints;
    }
    
    /**
     * Extract direction constraint from query
     */
    private String extractDirectionConstraint(String query) {
        if (query.contains("<-")) {
            return "IN";
        } else if (query.contains("->")) {
            return "OUT";
        } else if (query.contains("-") && !query.contains("<-") && !query.contains("->")) {
            return "BOTH";
        } else {
            return "OUT"; // Default
        }
    }
    
    /**
     * Extract weight property from query (for weighted shortest path)
     */
    private String extractWeightProperty(String query) {
        // Look for patterns like {weight: r.cost} or {distance: r.length}
        Pattern weightPattern = Pattern.compile("\\{\\s*(weight|cost|distance|length)\\s*:\\s*\\w+\\.(\\w+)\\s*\\}");
        Matcher matcher = weightPattern.matcher(query);
        
        if (matcher.find()) {
            return matcher.group(2);
        }
        
        return null;
    }
    
    /**
     * Find actual paths returned by the query
     */
    private List<PathInstance> findActualPaths(String query, List<PathPattern> patterns) {
        List<PathInstance> paths = new ArrayList<>();
        
        try {
            // Check if query is safe to execute for analysis
            if (!isSafeForPathAnalysis(query)) {
                System.err.println("Skipping path analysis for potentially problematic query");
                return paths;
            }
            
            // Modify query to return path information
            String pathQuery = buildPathAnalysisQuery(query);
            
            try (Result result = tx.execute(pathQuery)) {
                int count = 0;
                while (result.hasNext() && count < 20) { // Limit to 20 samples
                    Map<String, Object> row = result.next();
                    PathInstance path = createPathInstanceFromResult(row);
                    if (path != null) {
                        paths.add(path);
                    }
                    count++;
                }
            }
        } catch (Exception e) {
            System.err.println("Error analyzing actual paths: " + e.getMessage());
        }
        
        return paths;
    }
    
    /**
     * Check if query is safe to execute for path analysis
     */
    private boolean isSafeForPathAnalysis(String query) {
        String lowerQuery = query.toLowerCase();
        
        // Skip analysis for shortestPath without proper WHERE clauses
        if (lowerQuery.contains("shortestpath")) {
            // Check if it has proper start/end node constraints
            if (!lowerQuery.contains("where") || 
                (!lowerQuery.contains("name =") && !lowerQuery.contains("id("))) {
                return false;
            }
        }
        
        // Skip analysis for unlimited variable length paths without constraints
        if (lowerQuery.contains("-[*]-") && !lowerQuery.contains("where")) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Build a query to analyze paths
     */
    private String buildPathAnalysisQuery(String originalQuery) {
        // This is a simplified approach - in practice, this would need more sophisticated parsing
        if (originalQuery.toLowerCase().contains("shortestpath")) {
            // For shortest path, return the path itself
            return originalQuery.replaceAll("(?i)return\\s+.*", "RETURN path, length(path) as pathLength");
        } else {
            // For other patterns, try to extract path information
            return originalQuery + " LIMIT 20";
        }
    }
    
    /**
     * Create a PathInstance from query result
     */
    private PathInstance createPathInstanceFromResult(Map<String, Object> row) {
        PathInstance instance = new PathInstance();
        
        // Extract path information from result row
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            
            if ("pathLength".equals(key) && value instanceof Number) {
                instance.setLength(((Number) value).intValue());
            } else if ("path".equals(key)) {
                // Path object - would need to extract nodes and relationships
                instance.setPath(value.toString());
            } else if (key.contains("cost") || key.contains("weight")) {
                if (value instanceof Number) {
                    instance.setCost(((Number) value).doubleValue());
                }
            }
        }
        
        return instance;
    }
    
    /**
     * Check if query uses path functions
     */
    public boolean hasPathPatterns(String query) {
        String lowerQuery = query.toLowerCase();
        return lowerQuery.contains("shortestpath") ||
               lowerQuery.contains("allshortestpaths") ||
               query.contains("[*") ||
               lowerQuery.contains("path");
    }
    
    /**
     * Get path complexity score
     */
    public double calculatePathComplexity(PathAnalysis analysis) {
        double complexity = 0.0;
        
        // Base complexity from algorithm type
        switch (analysis.getAlgorithmType()) {
            case SIMPLE_TRAVERSAL:
                complexity += 1.0;
                break;
            case FIXED_LENGTH:
                complexity += 2.0;
                break;
            case VARIABLE_LENGTH:
                complexity += 4.0;
                break;
            case SHORTEST_PATH:
                complexity += 6.0;
                break;
            case ALL_SHORTEST_PATHS:
                complexity += 8.0;
                break;
        }
        
        // Add complexity from constraints
        PathConstraints constraints = analysis.getConstraints();
        if (constraints != null) {
            if (constraints.getMaxLength() > 10) {
                complexity += 2.0;
            }
            if (constraints.getAllowedRelationshipTypes().size() > 3) {
                complexity += 1.0;
            }
            if (constraints.getWeightProperty() != null) {
                complexity += 1.0;
            }
        }
        
        return complexity;
    }
}