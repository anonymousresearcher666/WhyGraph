package com.whyquery.neo4j.ranking;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.util.*;

/**
 * Decomposes ranking into individual contributing factors and calculates their impact
 * on the relative ordering of entities.
 */
public class RankingFactorDecomposition {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    
    public RankingFactorDecomposition(GraphDatabaseService db, Transaction tx) {
        this.db = db;
        this.tx = tx;
    }
    
    /**
     * Decompose the ranking difference between two entities
     */
    public RankingComparison compareEntities(String entityA, String entityB, 
                                           RankingAnalysis analysis) {
        RankingComparison comparison = new RankingComparison(entityA, entityB);
        
        // Calculate factor values for both entities
        Map<String, Object> valuesA = getEntityFactorValues(entityA, analysis);
        Map<String, Object> valuesB = getEntityFactorValues(entityB, analysis);
        
        // Decompose each ranking factor
        for (RankingFactor factor : analysis.getRankingFactors()) {
            FactorContribution contribution = calculateFactorContribution(
                factor, valuesA, valuesB);
            comparison.addFactorContribution(contribution);
        }
        
        // Calculate overall ranking difference
        comparison.calculateOverallDifference();
        
        return comparison;
    }
    
    /**
     * Get factor values for a specific entity
     */
    private Map<String, Object> getEntityFactorValues(String entityId, RankingAnalysis analysis) {
        Map<String, Object> values = new HashMap<>();
        
        for (RankingFactor factor : analysis.getRankingFactors()) {
            Object value = getFactorValueForEntity(entityId, factor, analysis);
            values.put(factor.getExpression(), value);
        }
        
        return values;
    }
    
    /**
     * Get a specific factor value for an entity
     */
    private Object getFactorValueForEntity(String entityId, RankingFactor factor, 
                                         RankingAnalysis analysis) {
        try {
            String query = buildFactorValueQuery(entityId, factor, analysis);
            
            try (Result result = tx.execute(query)) {
                if (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    return row.get("factor_value");
                }
            }
        } catch (Exception e) {
            System.err.println("Error getting factor value for entity " + entityId + 
                             " and factor " + factor.getExpression() + ": " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Build a query to get factor value for a specific entity
     */
    private String buildFactorValueQuery(String entityId, RankingFactor factor, 
                                       RankingAnalysis analysis) {
        StringBuilder query = new StringBuilder();
        
        // Extract the base pattern from the original query
        String basePattern = extractBasePattern(analysis.getOriginalQuery());
        
        // Start with the base pattern
        query.append(basePattern);
        
        // Add entity filter
        if (factor.getVariable() != null) {
            if (analysis.getOriginalQuery().toUpperCase().contains("WHERE")) {
                query.append(" AND ");
            } else {
                query.append(" WHERE ");
            }
            query.append("id(").append(factor.getVariable()).append(") = ").append(entityId);
        }
        
        // Add factor expression to return
        query.append(" RETURN ").append(factor.getExpression()).append(" as factor_value");
        
        return query.toString();
    }
    
    /**
     * Extract base pattern from the original query (MATCH clause)
     */
    private String extractBasePattern(String originalQuery) {
        // Find MATCH clause
        int matchIndex = originalQuery.toUpperCase().indexOf("MATCH");
        if (matchIndex == -1) return "MATCH (n)";
        
        // Find where MATCH clause ends
        int whereIndex = originalQuery.toUpperCase().indexOf("WHERE", matchIndex);
        int returnIndex = originalQuery.toUpperCase().indexOf("RETURN", matchIndex);
        int orderIndex = originalQuery.toUpperCase().indexOf("ORDER", matchIndex);
        
        int endIndex = originalQuery.length();
        if (whereIndex != -1) endIndex = Math.min(endIndex, whereIndex);
        if (returnIndex != -1) endIndex = Math.min(endIndex, returnIndex);
        if (orderIndex != -1) endIndex = Math.min(endIndex, orderIndex);
        
        return originalQuery.substring(matchIndex, endIndex).trim();
    }
    
    /**
     * Calculate the contribution of a factor to the ranking difference
     */
    private FactorContribution calculateFactorContribution(RankingFactor factor,
                                                         Map<String, Object> valuesA,
                                                         Map<String, Object> valuesB) {
        String factorKey = factor.getExpression();
        Object valueA = valuesA.get(factorKey);
        Object valueB = valuesB.get(factorKey);
        
        FactorContribution contribution = new FactorContribution(factor);
        contribution.setValueA(valueA);
        contribution.setValueB(valueB);
        
        if (valueA != null && valueB != null) {
            double numericA = factor.calculateContribution(valueA);
            double numericB = factor.calculateContribution(valueB);
            
            double difference = numericA - numericB;
            contribution.setContributionDifference(difference);
            
            // Determine which entity this factor favors
            if (difference > 0) {
                contribution.setFavorsEntity("A");
            } else if (difference < 0) {
                contribution.setFavorsEntity("B");
            } else {
                contribution.setFavorsEntity("NEUTRAL");
            }
        }
        
        return contribution;
    }
    
    /**
     * Generate alternative ranking compositions
     */
    public List<RankingComposition> generateAlternativeCompositions(RankingAnalysis analysis) {
        List<RankingComposition> alternatives = new ArrayList<>();
        
        // Original composition
        RankingComposition original = new RankingComposition("Original");
        for (RankingFactor factor : analysis.getRankingFactors()) {
            original.addFactor(factor);
        }
        alternatives.add(original);
        
        // Generate weight variations
        alternatives.addAll(generateWeightVariations(analysis));
        
        // Generate factor additions
        alternatives.addAll(generateFactorAdditions(analysis));
        
        // Generate direction changes
        alternatives.addAll(generateDirectionChanges(analysis));
        
        return alternatives;
    }
    
    /**
     * Generate ranking compositions with different weights
     */
    private List<RankingComposition> generateWeightVariations(RankingAnalysis analysis) {
        List<RankingComposition> variations = new ArrayList<>();
        
        for (int i = 0; i < analysis.getRankingFactors().size(); i++) {
            RankingComposition variation = new RankingComposition("Emphasize Factor " + (i + 1));
            
            for (int j = 0; j < analysis.getRankingFactors().size(); j++) {
                RankingFactor originalFactor = analysis.getRankingFactors().get(j);
                RankingFactor modifiedFactor = copyFactor(originalFactor);
                
                if (i == j) {
                    // Increase weight of this factor
                    modifiedFactor.setWeight(originalFactor.getWeight() * 2.0);
                } else {
                    // Decrease weight of other factors
                    modifiedFactor.setWeight(originalFactor.getWeight() * 0.5);
                }
                
                variation.addFactor(modifiedFactor);
            }
            
            variations.add(variation);
        }
        
        return variations;
    }
    
    /**
     * Generate ranking compositions with additional factors
     */
    private List<RankingComposition> generateFactorAdditions(RankingAnalysis analysis) {
        List<RankingComposition> additions = new ArrayList<>();
        
        // Add common ranking factors if not present
        Map<String, String> commonFactors = getCommonRankingFactors(analysis);
        
        for (Map.Entry<String, String> entry : commonFactors.entrySet()) {
            RankingComposition addition = new RankingComposition("Add " + entry.getKey());
            
            // Copy existing factors
            for (RankingFactor factor : analysis.getRankingFactors()) {
                addition.addFactor(copyFactor(factor));
            }
            
            // Add new factor
            RankingFactor newFactor = new RankingFactor();
            newFactor.setType(RankingFactorType.EXPRESSION);
            newFactor.setExpression(entry.getValue());
            newFactor.setDirection("DESC");
            newFactor.setWeight(1.0);
            addition.addFactor(newFactor);
            
            additions.add(addition);
        }
        
        return additions;
    }
    
    /**
     * Generate ranking compositions with direction changes
     */
    private List<RankingComposition> generateDirectionChanges(RankingAnalysis analysis) {
        List<RankingComposition> changes = new ArrayList<>();
        
        for (int i = 0; i < analysis.getRankingFactors().size(); i++) {
            RankingComposition change = new RankingComposition("Reverse Factor " + (i + 1));
            
            for (int j = 0; j < analysis.getRankingFactors().size(); j++) {
                RankingFactor originalFactor = analysis.getRankingFactors().get(j);
                RankingFactor modifiedFactor = copyFactor(originalFactor);
                
                if (i == j) {
                    // Reverse direction of this factor
                    String newDirection = "ASC".equals(originalFactor.getDirection()) ? "DESC" : "ASC";
                    modifiedFactor.setDirection(newDirection);
                }
                
                change.addFactor(modifiedFactor);
            }
            
            changes.add(change);
        }
        
        return changes;
    }
    
    /**
     * Get common ranking factors that could be added to the query
     */
    private Map<String, String> getCommonRankingFactors(RankingAnalysis analysis) {
        Map<String, String> factors = new HashMap<>();
        
        // Extract variables from the query
        Set<String> variables = extractVariables(analysis.getOriginalQuery());
        
        for (String variable : variables) {
            factors.put("Degree of " + variable, "size(("+variable+")-[]-())");
            factors.put("Creation time of " + variable, variable + ".created");
            factors.put("ID of " + variable, "id(" + variable + ")");
        }
        
        return factors;
    }
    
    /**
     * Extract variables from the original query
     */
    private Set<String> extractVariables(String query) {
        Set<String> variables = new HashSet<>();
        
        // Simple regex to find variables in patterns like (variable)
        String[] parts = query.split("[\\(\\)\\[\\]]");
        for (String part : parts) {
            String trimmed = part.trim();
            if (trimmed.matches("[a-zA-Z][a-zA-Z0-9_]*") && 
                !isKeyword(trimmed.toUpperCase())) {
                variables.add(trimmed);
            }
        }
        
        return variables;
    }
    
    /**
     * Check if a word is a Cypher keyword
     */
    private boolean isKeyword(String word) {
        Set<String> keywords = new HashSet<>(Arrays.asList(
            "MATCH", "WHERE", "RETURN", "ORDER", "BY", "LIMIT", "SKIP", "WITH",
            "CREATE", "MERGE", "DELETE", "SET", "REMOVE", "AND", "OR", "NOT",
            "ASC", "DESC", "COUNT", "SUM", "AVG", "MIN", "MAX", "DISTINCT"
        ));
        return keywords.contains(word);
    }
    
    /**
     * Create a copy of a ranking factor
     */
    private RankingFactor copyFactor(RankingFactor original) {
        RankingFactor copy = new RankingFactor();
        copy.setType(original.getType());
        copy.setVariable(original.getVariable());
        copy.setProperty(original.getProperty());
        copy.setExpression(original.getExpression());
        copy.setDirection(original.getDirection());
        copy.setWeight(original.getWeight());
        copy.setMetadata(new HashMap<>(original.getMetadata()));
        return copy;
    }
}