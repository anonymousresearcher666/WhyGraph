package com.whyquery.neo4j.schema;

import com.whyquery.neo4j.QueryGraph;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Lightweight representation of a query pattern used for schema reasoning.
 */
public class SchemaPattern {
    public static final String ANY_LABEL = "*";

    public SchemaPattern() {
    }

    public static final class EdgePattern {
        private final Set<String> sourceLabels;
        private final String relationshipType;
        private final Set<String> targetLabels;
        private final String description;
        private final int sourceId;
        private final int targetId;

        EdgePattern(Set<String> sourceLabels, String relationshipType, Set<String> targetLabels,
                    String description, int sourceId, int targetId) {
            this.sourceLabels = sourceLabels;
            this.relationshipType = relationshipType;
            this.targetLabels = targetLabels;
            this.description = description;
            this.sourceId = sourceId;
            this.targetId = targetId;
        }

        public Set<String> getSourceLabels() {
            return sourceLabels;
        }

        public String getRelationshipType() {
            return relationshipType;
        }

        public Set<String> getTargetLabels() {
            return targetLabels;
        }

        public String getDescription() {
            return description;
        }

        public int getSourceId() {
            return sourceId;
        }

        public int getTargetId() {
            return targetId;
        }
    }

    private final List<EdgePattern> edges = new ArrayList<>();

    public List<EdgePattern> getEdges() {
        return edges;
    }

    public boolean isEmpty() {
        return edges.isEmpty();
    }

    public static SchemaPattern from(QueryGraph queryGraph) {
        SchemaPattern pattern = new SchemaPattern();
        if (queryGraph == null) {
            return pattern;
        }

        // Map node id -> labels
        List<QueryGraph.Vertex> vertices = new ArrayList<>(queryGraph.getNodes());
        java.util.Map<Integer, List<String>> labelMap = new java.util.HashMap<>();
        for (QueryGraph.Vertex vertex : vertices) {
            List<String> labels = vertex.getLabels();
            if (labels == null || labels.isEmpty()) {
                labels = List.of(ANY_LABEL);
            }
            labelMap.put(vertex.id, labels);
        }

        for (QueryGraph.Edge edge : queryGraph.getEdges()) {
            List<String> src = labelMap.getOrDefault(edge.source, List.of(ANY_LABEL));
            List<String> dst = labelMap.getOrDefault(edge.target, List.of(ANY_LABEL));

            pattern.edges.add(new EdgePattern(new HashSet<>(src),
                edge.getType(), new HashSet<>(dst),
                describeEdge(src, edge.getType(), dst),
                edge.source, edge.target));
        }

        return pattern;
    }

    private static String describeEdge(List<String> src, String rel, List<String> dst) {
        String srcLabel = src.isEmpty() ? ANY_LABEL : src.get(0);
        String dstLabel = dst.isEmpty() ? ANY_LABEL : dst.get(0);
        return "(" + srcLabel + ")-[:" + rel + "]->(" + dstLabel + ")";
    }
}
