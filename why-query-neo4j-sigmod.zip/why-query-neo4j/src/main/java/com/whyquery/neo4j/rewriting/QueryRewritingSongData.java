package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.CypherASTQueryGraphParser;
import com.whyquery.neo4j.QueryGraph;
import com.whyquery.neo4j.ast.ASTModificationOperations;
import com.whyquery.neo4j.ast.ASTNode;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.ast.NodeType;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.schema.SchemaGraph;
import com.whyquery.neo4j.schema.SchemaPattern;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.Comparator;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Song et al. TKDE 2020 baseline (data-driven):
 * greedy responsibility-based relaxation/restriction with actual query counts.
 */
public class QueryRewritingSongData {
    private static final double BIG_SCORE = 1e12;

    private final GraphDatabaseService db;
    private final RewritingConfig config;
    private final DatabaseSchemaCache schemaCache;
    private final SchemaGraph schemaGraph;
    private final boolean useSchema;
    private final boolean enforceConnectedPatterns;
    private final Set<ModificationOperation.Type> allowedOperations;
    private final Map<String, Long> countCache = new HashMap<>();
    private final int queryTimeoutSeconds;
    private long rewriteDeadlineNanos = Long.MAX_VALUE;
    private static final ExecutorService COUNT_EXECUTOR = Executors.newCachedThreadPool();

    private WhyMode whyMode = WhyMode.WHY_EMPTY;
    private long minTarget = 0;
    private long maxTarget = 0;

    private static final class CandidateOperation {
        private final ModificationOperation op;
        private final double score;

        private CandidateOperation(ModificationOperation op, double score) {
            this.op = op;
            this.score = score;
        }
    }

    private static final class CandidateEvaluation {
        private final ModificationOperation op;
        private final CypherAST ast;
        private final List<String> changes;
        private final long count;
        private final double score;
        private final String hash;

        private CandidateEvaluation(ModificationOperation op, CypherAST ast, List<String> changes,
                                    long count, double score, String hash) {
            this.op = op;
            this.ast = ast;
            this.changes = changes;
            this.count = count;
            this.score = score;
            this.hash = hash;
        }
    }

    public QueryRewritingSongData(GraphDatabaseService db, RewritingConfig config) {
        this(db, config, DatabaseSchemaCache.getShared(db));
    }

    public QueryRewritingSongData(GraphDatabaseService db, RewritingConfig config, DatabaseSchemaCache schemaCache) {
        this.db = db;
        this.config = config != null ? config : new RewritingConfig();
        this.useSchema = this.config.isUseSchema();
        this.enforceConnectedPatterns = this.config.isEnforceConnectedPatterns();
        this.allowedOperations = this.config.getAllowedOperations();
        this.schemaCache = schemaCache != null ? schemaCache : DatabaseSchemaCache.getShared(db);
        this.schemaGraph = this.schemaCache.buildSchemaGraph();
        this.queryTimeoutSeconds = this.config.getDataDrivenTimeoutSeconds();
    }

    public RewritingResult rewriteQuery(String failedQuery, long targetCardinality,
                                        UserPreferences userPreferences, double modificationThreshold,
                                        WhyMode mode, long minTarget, long maxTarget) {
        long start = System.currentTimeMillis();
        rewriteDeadlineNanos = queryTimeoutSeconds > 0
            ? System.nanoTime() + TimeUnit.SECONDS.toNanos(queryTimeoutSeconds)
            : Long.MAX_VALUE;
        RewritingResult result = new RewritingResult();
        result.setOriginalQuery(failedQuery);
        result.setTargetCardinality(targetCardinality);

        this.whyMode = mode != null ? mode : WhyMode.WHY_EMPTY;
        switch (this.whyMode) {
            case WHY_EMPTY:
                this.minTarget = 1;
                this.maxTarget = Math.max(1, maxTarget > 0 ? maxTarget : targetCardinality);
                break;
            case WHY_FEW:
                this.minTarget = Math.max(1, minTarget);
                this.maxTarget = Math.max(this.minTarget, maxTarget > 0 ? maxTarget : Long.MAX_VALUE);
                break;
            case WHY_MANY:
                this.minTarget = 0;
                this.maxTarget = Math.max(1, maxTarget > 0 ? maxTarget : targetCardinality);
                break;
            default:
                this.minTarget = 1;
                this.maxTarget = Math.max(1, targetCardinality);
        }

        CypherAST originalAST = parseQuery(failedQuery);
        if (originalAST == null) {
            result.addError("Failed to parse query: " + failedQuery);
            result.setExecutionTimeMs(System.currentTimeMillis() - start);
            return result;
        }

        SchemaPattern initialPattern = buildSchemaPattern(originalAST);
        SchemaGraph.SchemaCompatibility initialCompat = schemaGraph.analyzeCompatibility(initialPattern);
        if (useSchema && initialCompat != null && !initialCompat.isConsistent()
            && !config.isForceRewriteAfterPrecheck() && !config.isForceAStarRewrite()) {
            result.addError("Query is schema-unsatisfiable; no compatible schema triples for one or more pattern edges.");
            result.setExecutionTimeMs(System.currentTimeMillis() - start);
            return result;
        }

        if (whyMode == WhyMode.WHY_MANY) {
            return rewriteRestriction(originalAST, start);
        }
        return rewriteRelaxation(originalAST, start);
    }

    private RewritingResult rewriteRelaxation(CypherAST originalAST, long start) {
        CypherAST current = originalAST;
        List<ModificationStep> steps = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        visited.add(computeASTHash(current));

        long currentCount = countQuery(current.generateCypher());
        if (currentCount < 0) {
            return buildErrorResult(originalAST, "Failed to execute count for original query.", steps, 0, start);
        }

        int iterations = 0;
        int maxIterations = config.getMaxIterations();
        while (iterations < maxIterations && !deadlineExceeded()) {
            iterations++;
            if (!steps.isEmpty() && isGoal(currentCount)) {
                return buildSuccessResult(originalAST, current, steps, currentCount, iterations, start);
            }

            List<CandidateOperation> candidates = buildRelaxCandidates(current);
            if (candidates.isEmpty()) {
                break;
            }
            candidates.sort(Comparator.comparingDouble((CandidateOperation c) -> c.score).reversed());

            CandidateEvaluation best = null;
            double bestScore = Double.NEGATIVE_INFINITY;
            int limit = Math.max(1, config.getMaxAlternatives());
            for (int idx = 0; idx < candidates.size() && idx < limit && !deadlineExceeded(); idx++) {
                CandidateOperation candidate = candidates.get(idx);
                ASTModificationOperations.ModificationResult mod = applyOperation(current, candidate.op);
                if (!mod.isSuccessful()) {
                    continue;
                }
                CypherAST nextAst = mod.getModifiedAST();
                if (nextAst == null) {
                    continue;
                }
                if (enforceConnectedPatterns && hasCartesianProduct(nextAst)) {
                    continue;
                }
                SchemaPattern nextPattern = buildSchemaPattern(nextAst);
                SchemaGraph.SchemaCompatibility compat = schemaGraph.analyzeCompatibility(nextPattern);
                if (useSchema && compat != null && !compat.isConsistent()) {
                    continue;
                }
                String hash = computeASTHash(nextAst);
                if (visited.contains(hash)) {
                    continue;
                }
                long nextCount = countQuery(nextAst.generateCypher());
                if (nextCount < 0) {
                    continue;
                }
                double score = scoreCandidate(currentCount, nextCount);
                if (score > bestScore) {
                    bestScore = score;
                    best = new CandidateEvaluation(candidate.op, nextAst, mod.getChanges(), nextCount, score, hash);
                }
            }
            if (best == null) {
                break;
            }

            visited.add(best.hash);
            steps.add(new ModificationStep(best.op, best.changes));
            current = best.ast;
            currentCount = best.count;

            if (isGoal(currentCount)) {
                return buildSuccessResult(originalAST, current, steps, currentCount, iterations, start);
            }
        }

        return buildErrorResult(originalAST, "No rewrite found within iteration limit.", steps, iterations, start);
    }

    private RewritingResult rewriteRestriction(CypherAST originalAST, long start) {
        CypherAST current = originalAST;
        List<ModificationStep> steps = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        visited.add(computeASTHash(current));

        long currentCount = countQuery(current.generateCypher());
        if (currentCount < 0) {
            return buildErrorResult(originalAST, "Failed to execute count for original query.", steps, 0, start);
        }

        int iterations = 0;
        int maxIterations = config.getMaxIterations();
        while (iterations < maxIterations && !deadlineExceeded()) {
            iterations++;
            if (!steps.isEmpty() && isGoal(currentCount)) {
                return buildSuccessResult(originalAST, current, steps, currentCount, iterations, start);
            }

            List<CandidateOperation> candidates = buildRestrictionCandidates(current);
            if (candidates.isEmpty()) {
                break;
            }
            candidates.sort(Comparator.comparingDouble((CandidateOperation c) -> c.score).reversed());

            CandidateEvaluation best = null;
            double bestScore = Double.NEGATIVE_INFINITY;
            int limit = Math.max(1, config.getMaxAlternatives());
            for (int idx = 0; idx < candidates.size() && idx < limit && !deadlineExceeded(); idx++) {
                CandidateOperation candidate = candidates.get(idx);
                ASTModificationOperations.ModificationResult mod = applyOperation(current, candidate.op);
                if (!mod.isSuccessful()) {
                    continue;
                }
                CypherAST nextAst = mod.getModifiedAST();
                if (nextAst == null) {
                    continue;
                }
                if (enforceConnectedPatterns && hasCartesianProduct(nextAst)) {
                    continue;
                }
                SchemaPattern nextPattern = buildSchemaPattern(nextAst);
                SchemaGraph.SchemaCompatibility compat = schemaGraph.analyzeCompatibility(nextPattern);
                if (useSchema && compat != null && !compat.isConsistent()) {
                    continue;
                }
                String hash = computeASTHash(nextAst);
                if (visited.contains(hash)) {
                    continue;
                }
                long nextCount = countQuery(nextAst.generateCypher());
                if (nextCount < 0) {
                    continue;
                }
                double score = scoreCandidate(currentCount, nextCount);
                if (score > bestScore) {
                    bestScore = score;
                    best = new CandidateEvaluation(candidate.op, nextAst, mod.getChanges(), nextCount, score, hash);
                }
            }
            if (best == null) {
                break;
            }

            visited.add(best.hash);
            steps.add(new ModificationStep(best.op, best.changes));
            current = best.ast;
            currentCount = best.count;

            if (isGoal(currentCount)) {
                return buildSuccessResult(originalAST, current, steps, currentCount, iterations, start);
            }
        }

        return buildErrorResult(originalAST, "No rewrite found within iteration limit.", steps, iterations, start);
    }

    private RewritingResult buildSuccessResult(CypherAST originalAST, CypherAST current,
                                               List<ModificationStep> steps, long actualCount,
                                               int iterations, long start) {
        RewritingResult result = new RewritingResult();
        result.setOriginalQuery(originalAST.generateCypher());
        result.setTargetCardinality(maxTarget);
        result.setSuccess(true);
        result.setRewrittenQuery(current.generateCypher());
        result.setRewrittenAST(current);
        result.setFinalCardinality(actualCount);
        result.setEstimatedRows(actualCount);
        result.setModificationSteps(steps);
        result.setIterations(iterations);
        result.setStatesExplored(iterations);
        result.setQueueMaxSize(1);
        result.setExecutionTimeMs(System.currentTimeMillis() - start);
        return result;
    }

    private RewritingResult buildErrorResult(CypherAST originalAST, String message,
                                             List<ModificationStep> steps, int iterations, long start) {
        RewritingResult result = new RewritingResult();
        result.setOriginalQuery(originalAST.generateCypher());
        result.setTargetCardinality(maxTarget);
        result.setSuccess(false);
        result.setModificationSteps(steps);
        result.addError(message);
        result.setIterations(iterations);
        result.setStatesExplored(iterations);
        result.setQueueMaxSize(1);
        result.setExecutionTimeMs(System.currentTimeMillis() - start);
        return result;
    }

    private boolean isGoal(long count) {
        switch (whyMode) {
            case WHY_EMPTY:
                return count > 0;
            case WHY_FEW:
                return count >= minTarget && count <= maxTarget;
            case WHY_MANY:
                return count <= maxTarget;
            default:
                return false;
        }
    }

    private double scoreCandidate(long currentCount, long candidateCount) {
        if (candidateCount < 0) {
            return Double.NEGATIVE_INFINITY;
        }
        switch (whyMode) {
            case WHY_EMPTY:
                return candidateCount;
            case WHY_FEW:
                if (candidateCount >= minTarget && candidateCount <= maxTarget) {
                    return BIG_SCORE + (maxTarget - candidateCount);
                }
                if (candidateCount < minTarget) {
                    return candidateCount - currentCount;
                }
                return (maxTarget - candidateCount);
            case WHY_MANY:
                if (candidateCount <= maxTarget) {
                    return BIG_SCORE + (maxTarget - candidateCount);
                }
                return currentCount - candidateCount;
            default:
                return candidateCount;
        }
    }

    private List<CandidateOperation> buildRelaxCandidates(CypherAST ast) {
        List<CandidateOperation> candidates = new ArrayList<>();
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        double maxEdgeCount = Math.max(1.0, getTotalEdgeCount());
        double maxNodeCount = Math.max(1.0, schemaGraph.getTotalNodeCount());

        addHistogramThresholdRelaxations(ast, varLabelMap, candidates);

        if (isOpAllowed(ModificationOperation.Type.DELETE_PREDICATE)) {
            for (ASTNode pred : ast.getAllNodes()) {
                if (pred == null || !isPredicateNode(pred)) {
                    continue;
                }
                double sel = predicateSelectivity(ast, pred, varLabelMap);
                double score = -Math.log10(Math.max(1e-6, sel));
                candidates.add(new CandidateOperation(
                    new ModificationOperation(ModificationOperation.Type.DELETE_PREDICATE, pred.getId(), null, null, null),
                    score
                ));
            }
        }

        if (isOpAllowed(ModificationOperation.Type.DELETE_RELATIONSHIP)) {
            for (ASTNode rel : ast.getNodesByType(NodeType.RELATIONSHIP)) {
                long support = estimateRelationshipSupport(ast, rel);
                double score = Math.log10((maxEdgeCount + 1.0) / Math.max(1.0, support));
                candidates.add(new CandidateOperation(
                    new ModificationOperation(ModificationOperation.Type.DELETE_RELATIONSHIP, rel.getId(), null, null, null),
                    score
                ));
            }
        }

        if (isOpAllowed(ModificationOperation.Type.DELETE_NODE)) {
            for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
                List<String> labels = node.getAttribute("labels", List.class);
                long count = estimateLabelCount(labels);
                double score = Math.log10((maxNodeCount + 1.0) / Math.max(1.0, count));
                candidates.add(new CandidateOperation(
                    new ModificationOperation(ModificationOperation.Type.DELETE_NODE, node.getId(), null, null, null),
                    score
                ));
            }
        }

        return candidates;
    }

    private void addHistogramThresholdRelaxations(CypherAST ast,
                                                   Map<String, String> varLabelMap,
                                                   List<CandidateOperation> candidates) {
        if (!isOpAllowed(ModificationOperation.Type.WEAKEN_PREDICATE)) return;
        for (ASTNode predicate : ast.getAllNodes()) {
            NodeType type = predicate.getType();
            boolean greater = type == NodeType.GREATER_THAN || type == NodeType.GREATER_THAN_OR_EQUAL;
            boolean less = type == NodeType.LESS_THAN || type == NodeType.LESS_THAN_OR_EQUAL;
            if (!greater && !less) continue;
            ASTNode propertyNode = null, literalNode = null;
            for (ASTNode child : ast.getChildren(predicate.getId())) {
                if (child.getType() == NodeType.PROPERTY) propertyNode = child;
                if (child.getType() == NodeType.LITERAL) literalNode = child;
            }
            if (propertyNode == null || literalNode == null || !(literalNode.getAttribute("value") instanceof Number)) continue;
            String variable = propertyNode.getAttribute("variable", String.class);
            String property = propertyNode.getAttribute("name", String.class);
            String label = varLabelMap.get(variable);
            double current = ((Number) literalNode.getAttribute("value")).doubleValue();
            List<Double> eligible = new ArrayList<>();
            for (Double boundary : schemaCache.getHistogramBoundaries(label, property)) {
                if (boundary != null && (greater ? boundary < current : boundary > current)) eligible.add(boundary);
            }
            eligible.sort(Comparator.comparingDouble(v -> Math.abs(v - current)));
            int cap = Math.min(config.getMaxThresholdCandidatesPerPredicate(), eligible.size());
            for (int i = 0; i < cap; i++) {
                candidates.add(new CandidateOperation(new ModificationOperation(
                    ModificationOperation.Type.WEAKEN_PREDICATE, predicate.getId(), label,
                    property, new Object[]{eligible.get(i)}, variable), i + 1.0));
            }
        }
    }

    private List<CandidateOperation> buildRestrictionCandidates(CypherAST ast) {
        List<CandidateOperation> candidates = new ArrayList<>();
        double maxNodeCount = Math.max(1.0, schemaGraph.getTotalNodeCount());

        if (config.isAllowAddLimit() && isOpAllowed(ModificationOperation.Type.ADD_LIMIT)
            && ast.getNodesByType(NodeType.LIMIT).isEmpty()) {
            if (maxTarget <= Integer.MAX_VALUE) {
                candidates.add(new CandidateOperation(
                    new ModificationOperation(ModificationOperation.Type.ADD_LIMIT, "limit", null, null, new Object[]{(int) maxTarget}),
                    BIG_SCORE
                ));
            }
        }

        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String nodeId = node.getId();
            List<String> labels = node.getAttribute("labels", List.class);
            String label = labels != null && !labels.isEmpty() ? labels.get(0) : null;

            if (label != null && isOpAllowed(ModificationOperation.Type.ADD_PREDICATE)) {
                DatabaseSchemaCache.PropertyInfo best = null;
                String bestProp = null;
                for (Map.Entry<String, DatabaseSchemaCache.PropertyInfo> entry :
                    schemaCache.getPropertyDetailsForLabel(label).entrySet()) {
                    DatabaseSchemaCache.PropertyInfo info = entry.getValue();
                    if (info == null) {
                        continue;
                    }
                    double sel = info.getSelectivity();
                    if (best == null || sel < best.getSelectivity()) {
                        best = info;
                        bestProp = entry.getKey();
                    }
                }
                if (best != null && bestProp != null) {
                    Object value = null;
                    List<Object> common = best.getCommonValues();
                    if (common != null && !common.isEmpty()) {
                        value = common.get(0);
                    }
                    if (value == null) {
                        value = best.getAlternativeValue(null);
                    }
                    if (value != null) {
                        double sel = Math.max(1e-6, best.getSelectivity());
                        double score = -Math.log10(sel);
                        candidates.add(new CandidateOperation(
                            new ModificationOperation(
                                ModificationOperation.Type.ADD_PREDICATE,
                                nodeId,
                                label,
                                bestProp,
                                new Object[]{"EQUALS", value}
                            ),
                            score
                        ));
                    }
                }
            }

            if (isOpAllowed(ModificationOperation.Type.ADD_LABEL)) {
                String nextLabel = pickAdditionalLabel(labels);
                if (nextLabel != null) {
                    long count = schemaGraph.getLabelCount(nextLabel);
                    double score = Math.log10((maxNodeCount + 1.0) / Math.max(1.0, count));
                    candidates.add(new CandidateOperation(
                        new ModificationOperation(ModificationOperation.Type.ADD_LABEL, nodeId, nextLabel, null, null),
                        score
                    ));
                }
            }
        }

        return candidates;
    }

    private boolean isOpAllowed(ModificationOperation.Type type) {
        return allowedOperations == null || allowedOperations.contains(type);
    }

    private ASTModificationOperations.ModificationResult applyOperation(CypherAST ast, ModificationOperation operation) {
        switch (operation.getType()) {
            case DELETE_NODE:
                return ASTModificationOperations.deleteNode(ast, operation.getTargetId());
            case DELETE_RELATIONSHIP:
                return ASTModificationOperations.deleteRelationship(ast, operation.getTargetId());
            case DELETE_PREDICATE:
                return ASTModificationOperations.deletePredicate(ast, operation.getTargetId());
            case WEAKEN_PREDICATE:
                return ASTModificationOperations.replacePredicateThreshold(
                    ast, operation.getTargetId(), operation.getRange()[0]);
            case ADD_PREDICATE:
                return ASTModificationOperations.addPredicate(ast, operation.getTargetId(),
                    operation.getTargetProperty(), operation.getRange());
            case ADD_LABEL:
                return ASTModificationOperations.addLabel(ast, operation.getTargetId(), operation.getTargetLabel());
            case ADD_RELATIONSHIP:
                return ASTModificationOperations.addRelationship(ast, operation.getTargetId(), operation.getTargetLabel());
            case RESTRICT_PROPERTY:
                return ASTModificationOperations.restrictProperty(ast, operation.getTargetId(),
                    operation.getTargetProperty(), operation.getRange());
            case ADD_LIMIT:
                return ASTModificationOperations.addLimit(ast, operation.getRange());
            default:
                ASTModificationOperations.ModificationResult result = new ASTModificationOperations.ModificationResult();
                result.addError("Unsupported operation: " + operation.getType());
                return result;
        }
    }

    private long countQuery(String query) {
        if (query == null || deadlineExceeded()) {
            return -1L;
        }
        Long cached = countCache.get(query);
        if (cached != null) {
            return cached;
        }
        long cap = countCap();
        String countQuery;
        if (cap > 0) {
            countQuery = "CALL () { " + query + " } WITH * LIMIT " + cap + " RETURN count(*) AS cnt";
        } else {
            countQuery = "CALL () { " + query + " } RETURN count(*) AS cnt";
        }
        if (queryTimeoutSeconds <= 0) {
            try (Transaction tx = db.beginTx()) {
                Result result = tx.execute(countQuery);
                long cnt = 0L;
                if (result.hasNext()) {
                    Object val = result.next().get("cnt");
                    if (val instanceof Number) {
                        cnt = ((Number) val).longValue();
                    } else if (val != null) {
                        cnt = Long.parseLong(val.toString());
                    }
                }
                tx.commit();
                countCache.put(query, cnt);
                return cnt;
            } catch (Exception e) {
                countCache.put(query, -1L);
                return -1L;
            }
        }

        AtomicReference<Transaction> txRef = new AtomicReference<>();
        Callable<Long> task = () -> {
            try (Transaction tx = db.beginTx()) {
                txRef.set(tx);
                Result result = tx.execute(countQuery);
                long cnt = 0L;
                if (result.hasNext()) {
                    Object val = result.next().get("cnt");
                    if (val instanceof Number) {
                        cnt = ((Number) val).longValue();
                    } else if (val != null) {
                        cnt = Long.parseLong(val.toString());
                    }
                }
                tx.commit();
                return cnt;
            }
        };

        Future<Long> future = COUNT_EXECUTOR.submit(task);
        try {
            long remainingNanos = Math.max(1L, rewriteDeadlineNanos - System.nanoTime());
            long remainingSeconds = Math.max(1L, TimeUnit.NANOSECONDS.toSeconds(remainingNanos) + 1L);
            long cnt = future.get(Math.min(queryTimeoutSeconds, remainingSeconds), TimeUnit.SECONDS);
            countCache.put(query, cnt);
            return cnt;
        } catch (TimeoutException e) {
            Transaction tx = txRef.get();
            if (tx != null) {
                tx.terminate();
            }
            future.cancel(true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            // Fall through to failure
        }

        countCache.put(query, -1L);
        return -1L;
    }

    private boolean deadlineExceeded() {
        return System.nanoTime() >= rewriteDeadlineNanos;
    }

    private long countCap() {
        switch (whyMode) {
            case WHY_EMPTY:
                return 1L;
            case WHY_FEW:
                return maxTarget >= Long.MAX_VALUE / 2 ? -1L : Math.max(1L, maxTarget);
            case WHY_MANY:
                return maxTarget >= Long.MAX_VALUE - 1 ? -1L : Math.max(1L, maxTarget + 1);
            default:
                return -1L;
        }
    }

    private Map<String, String> buildVariableLabelMap(CypherAST ast) {
        Map<String, String> map = new HashMap<>();
        if (ast == null) {
            return map;
        }
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String var = node.getAttribute("variable", String.class);
            List<String> labels = node.getAttribute("labels", List.class);
            if (var != null && labels != null && !labels.isEmpty()) {
                map.put(var, labels.get(0));
            }
        }
        return map;
    }

    private boolean isPredicateNode(ASTNode node) {
        if (node == null) {
            return false;
        }
        switch (node.getType()) {
            case EQUALS:
            case NOT_EQUALS:
            case GREATER_THAN:
            case GREATER_THAN_OR_EQUAL:
            case LESS_THAN:
            case LESS_THAN_OR_EQUAL:
            case CONTAINS:
            case STARTS_WITH:
                return true;
            default:
                return false;
        }
    }

    private boolean hasCartesianProduct(CypherAST ast) {
        if (ast == null) {
            return false;
        }
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }
            int nodeCount = 0;
            int relCount = 0;
            NodeType prev = null;
            for (ASTNode element : elements) {
                if (element == null) {
                    continue;
                }
                NodeType type = element.getType();
                if (type == NodeType.NODE) {
                    nodeCount++;
                    if (prev == NodeType.NODE) {
                        return true;
                    }
                    prev = NodeType.NODE;
                } else if (type == NodeType.RELATIONSHIP) {
                    relCount++;
                    if (prev == NodeType.RELATIONSHIP) {
                        return true;
                    }
                    prev = NodeType.RELATIONSHIP;
                }
            }
            if (nodeCount > 1 && relCount == 0) {
                return true;
            }
        }
        return false;
    }

    private long estimateRelationshipSupport(CypherAST ast, ASTNode rel) {
        if (ast == null || rel == null) {
            return 0L;
        }
        String relType = rel.getAttribute("type", String.class);
        if (relType == null || relType.isBlank()) {
            return 0L;
        }
        RelationshipEndpoints endpoints = extractRelationshipEndpoints(ast, rel.getId());
        if (endpoints == null) {
            return 0L;
        }
        String direction = rel.getAttribute("direction", String.class);
        Set<String> srcLabels = endpoints.leftLabels;
        Set<String> dstLabels = endpoints.rightLabels;
        if ("IN".equalsIgnoreCase(direction)) {
            srcLabels = endpoints.rightLabels;
            dstLabels = endpoints.leftLabels;
        }
        long support = minPositiveEdgeCount(srcLabels, relType, dstLabels);
        if (support <= 0) {
            support = maxEdgeCount(srcLabels, relType, dstLabels);
        }
        return support;
    }

    private RelationshipEndpoints extractRelationshipEndpoints(CypherAST ast, String relationshipId) {
        if (ast == null || relationshipId == null) {
            return null;
        }
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }
            for (int i = 0; i < elements.size(); i++) {
                ASTNode element = elements.get(i);
                if (element == null || element.getType() != NodeType.RELATIONSHIP) {
                    continue;
                }
                if (!relationshipId.equals(element.getId())) {
                    continue;
                }
                Set<String> leftLabels = labelSetForNode(i > 0 ? elements.get(i - 1) : null);
                Set<String> rightLabels = labelSetForNode(i < elements.size() - 1 ? elements.get(i + 1) : null);
                return new RelationshipEndpoints(leftLabels, rightLabels);
            }
        }
        return null;
    }

    private Set<String> labelSetForNode(ASTNode node) {
        if (node == null || node.getType() != NodeType.NODE) {
            return Set.of(SchemaPattern.ANY_LABEL);
        }
        List<String> labels = node.getAttribute("labels", List.class);
        if (labels == null || labels.isEmpty()) {
            return Set.of(SchemaPattern.ANY_LABEL);
        }
        return new HashSet<>(labels);
    }

    private long maxEdgeCount(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (schemaGraph == null || relType == null || relType.isBlank()) {
            return 0L;
        }
        long max = 0L;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry :
            schemaGraph.getSchemaTriples().entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (!relType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (!labelSetMatches(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!labelSetMatches(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            SchemaGraph.TripleStats stats = entry.getValue();
            if (stats == null) {
                continue;
            }
            long count = stats.getEdgeCount();
            if (count > max) {
                max = count;
            }
        }
        return max;
    }

    private long minPositiveEdgeCount(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (schemaGraph == null || relType == null || relType.isBlank()) {
            return 0L;
        }
        long min = Long.MAX_VALUE;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry :
            schemaGraph.getSchemaTriples().entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (!relType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (!labelSetMatches(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!labelSetMatches(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            SchemaGraph.TripleStats stats = entry.getValue();
            if (stats == null) {
                continue;
            }
            long count = stats.getEdgeCount();
            if (count > 0 && count < min) {
                min = count;
            }
        }
        return min == Long.MAX_VALUE ? 0L : min;
    }

    private boolean labelSetMatches(Set<String> labels, String schemaLabel) {
        if (labels == null || labels.isEmpty()) {
            return true;
        }
        if (labels.contains(SchemaPattern.ANY_LABEL)) {
            return true;
        }
        return labels.contains(schemaLabel);
    }

    private long estimateLabelCount(List<String> labels) {
        if (labels == null || labels.isEmpty()) {
            return Math.max(1L, schemaGraph.getTotalNodeCount());
        }
        long min = Long.MAX_VALUE;
        for (String label : labels) {
            long count = schemaGraph.getLabelCount(label);
            if (count > 0 && count < min) {
                min = count;
            }
        }
        if (min == Long.MAX_VALUE) {
            return Math.max(1L, schemaGraph.getTotalNodeCount());
        }
        return Math.max(1L, min);
    }

    private String pickAdditionalLabel(List<String> existing) {
        String best = null;
        long bestCount = Long.MAX_VALUE;
        Set<String> current = existing == null ? Set.of() : new HashSet<>(existing);
        for (String label : schemaCache.getAllLabels()) {
            if (current.contains(label)) {
                continue;
            }
            long count = schemaGraph.getLabelCount(label);
            if (count > 0 && count < bestCount) {
                bestCount = count;
                best = label;
            }
        }
        return best;
    }

    private double predicateSelectivity(CypherAST ast, ASTNode predicate, Map<String, String> varLabelMap) {
        if (ast == null || predicate == null) {
            return 1.0;
        }
        List<ASTNode> children = ast.getChildren(predicate.getId());
        if (children == null || children.isEmpty()) {
            return 1.0;
        }
        ASTNode prop = null;
        ASTNode lit = null;
        for (ASTNode child : children) {
            if (child == null) {
                continue;
            }
            if (prop == null && child.getType() == NodeType.PROPERTY) {
                prop = child;
            } else if (lit == null && child.getType() == NodeType.LITERAL) {
                lit = child;
            }
        }
        if (prop == null) {
            return 1.0;
        }
        String variable = prop.getAttribute("variable", String.class);
        String property = prop.getAttribute("name", String.class);
        String label = variable != null ? varLabelMap.get(variable) : null;
        double base = (label != null && property != null)
            ? schemaCache.getPropertySelectivity(label, property)
            : 0.5;
        base = Math.max(0.0, Math.min(1.0, base));

        Object value = lit != null && lit.getType() == NodeType.LITERAL ? lit.getAttribute("value", Object.class) : null;
        if (looksImpossibleLiteral(value)) {
            return 0.0;
        }

        switch (predicate.getType()) {
            case NOT_EQUALS:
                return Math.max(0.0, Math.min(1.0, 1.0 - base));
            case GREATER_THAN:
            case GREATER_THAN_OR_EQUAL:
            case LESS_THAN:
            case LESS_THAN_OR_EQUAL:
                return 0.5;
            case CONTAINS:
            case STARTS_WITH:
                return 0.2;
            case EQUALS:
            default:
                return base;
        }
    }

    private boolean looksImpossibleLiteral(Object value) {
        if (!(value instanceof String)) {
            return false;
        }
        String s = ((String) value).trim();
        if (s.isEmpty()) {
            return false;
        }
        return s.contains("XX_NON_EXISTING") || s.contains("XX-NON-EXISTING");
    }

    private long getTotalEdgeCount() {
        if (schemaGraph == null) {
            return 0L;
        }
        long total = 0L;
        for (SchemaGraph.TripleStats stats : schemaGraph.getSchemaTriples().values()) {
            if (stats != null) {
                total += stats.getEdgeCount();
            }
        }
        return total;
    }

    private CypherAST parseQuery(String cypherQuery) {
        try {
            return CypherASTBuilder.parseQuery(cypherQuery);
        } catch (Exception e) {
            return null;
        }
    }

    private SchemaPattern buildSchemaPattern(CypherAST ast) {
        try {
            if (ast == null) {
                return null;
            }
            QueryGraph queryGraph = CypherASTQueryGraphParser.fromAst(ast, ast.generateCypher());
            return SchemaPattern.from(queryGraph);
        } catch (Exception e) {
            return null;
        }
    }

    private String computeASTHash(CypherAST ast) {
        return Integer.toString(ast.generateCypher().hashCode());
    }

    private static final class RelationshipEndpoints {
        private final Set<String> leftLabels;
        private final Set<String> rightLabels;

        private RelationshipEndpoints(Set<String> leftLabels, Set<String> rightLabels) {
            this.leftLabels = leftLabels;
            this.rightLabels = rightLabels;
        }
    }
}
