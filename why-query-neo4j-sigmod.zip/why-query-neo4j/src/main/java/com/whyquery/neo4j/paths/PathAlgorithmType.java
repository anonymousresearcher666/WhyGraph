package com.whyquery.neo4j.paths;

/**
 * Types of path algorithms used in Cypher queries
 */
public enum PathAlgorithmType {
    
    /**
     * Simple graph traversal without special path algorithms
     */
    SIMPLE_TRAVERSAL,
    
    /**
     * Fixed-length path traversal
     */
    FIXED_LENGTH,
    
    /**
     * Variable-length path traversal
     */
    VARIABLE_LENGTH,
    
    /**
     * Shortest path algorithm
     */
    SHORTEST_PATH,
    
    /**
     * All shortest paths algorithm
     */
    ALL_SHORTEST_PATHS,
    
    /**
     * Weighted shortest path (Dijkstra's algorithm)
     */
    WEIGHTED_SHORTEST_PATH,
    
    /**
     * A* pathfinding algorithm
     */
    A_STAR,
    
    /**
     * Custom or complex path algorithm
     */
    CUSTOM
}