package com.whyquery.neo4j.rewriting;

/**
 * Modes describing the intention of the why-analysis.
 */
public enum WhyMode {
    WHY_EMPTY,
    WHY_FEW,
    WHY_MANY,
    WHY_NOT
}
