package com.whyquery.neo4j.rewriting;

import java.util.Set;

/**
 * Configuration parameters for the query rewriting algorithm
 */
public class RewritingConfig {
    
    // Default values following the unified framework
    private int maxIterations = 1000;
    private double alpha = 1.0;   // User penalty weight (Definition 5)
    private double beta = 0.001;  // Row estimation weight in planner cost
    private double gamma = 2.0;   // Schema penalty weight
    private double heuristicRho = 2.0; // Multiplicative effect bound for heuristics
    private double weightedAStarWeight = 1.0; // w >= 1.0 for Weighted A*
    private double costEpsilon = 0.01; // Minimum positive operation cost
    private boolean allowUnboundedOps = true;
    private double unboundedPenalty = 5.0;
    // Hard policy: LIMIT-based rewrites are disabled.
    private boolean allowAddLimit = false;
    private boolean useAdmissibleHeuristic = false;
    private double modificationThreshold = 1000.0;
    private boolean enableStatisticsCache = true;
    private long statisticsCacheTTL = 3600000; // 1 hour
    private int maxAlternatives = 5; // Maximum number of alternatives to return
    private String operationStrategy = "AUTO"; // AUTO, RELAX_ONLY, RESTRICT_ONLY
    private boolean useSchema = true;
    private boolean usePlannerStats = true;
    private boolean useFormalBounds = false;
    private String cardinalityEstimator = "schema_bounds";
    private boolean useSoftUpperBounds = false;
    private boolean useCalibratedBounds = false;
    private boolean forceRewriteAfterPrecheck = false;
    private boolean forceAStarRewrite = false;
    private boolean useUniformCost = false;
    private String frontierOrder = "astar";
    private Set<ModificationOperation.Type> allowedOperations = null;
    private boolean enforceConnectedPatterns = true;
    private boolean allowRelationshipRepairs = true;
    private boolean allowRelationshipDeletionRelaxation = true;
    private int dataDrivenTimeoutSeconds = 0;
    private boolean allowDataQueries = false;
    private boolean strictEstimateOnly = true;
    /** Maximum uncached candidate COUNT queries per rewrite; 0 keeps the legacy unlimited budget. */
    private int maxCandidateCountCalls = 0;
    private boolean candidateCountUpperBoundGate = false;
    // Innovation toggles: uncertainty-aware scoring, learning-guided expansion, Pareto frontier output
    private boolean uncertaintyAwareSearch = true;
    private double uncertaintyPenaltyWeight = 0.1;
    private boolean learningGuidanceEnabled = true;
    private double learningGuidanceStrength = 0.15;
    private int learningMinSupport = 5;
    private boolean paretoFrontierEnabled = true;
    private boolean strictTheoremMode = false;
    private int maxThresholdCandidatesPerPredicate = 4;
    
    public RewritingConfig() {
        // Use defaults
    }
    
    public RewritingConfig(int maxIterations, double alpha, double beta, double modificationThreshold) {
        this.maxIterations = maxIterations;
        this.alpha = alpha;
        this.beta = beta;
        this.modificationThreshold = modificationThreshold;
    }
    
    // Getters and setters
    public int getMaxIterations() { return maxIterations; }
    public void setMaxIterations(int maxIterations) { this.maxIterations = maxIterations; }
    
    public double getAlpha() { return alpha; }
    public void setAlpha(double alpha) { this.alpha = alpha; }
    
    public double getBeta() { return beta; }
    public void setBeta(double beta) { this.beta = beta; }

    public double getGamma() { return gamma; }
    public void setGamma(double gamma) { this.gamma = gamma; }

    public double getHeuristicRho() { return heuristicRho; }
    public void setHeuristicRho(double heuristicRho) { this.heuristicRho = heuristicRho; }

    public double getWeightedAStarWeight() { return weightedAStarWeight; }
    public void setWeightedAStarWeight(double weightedAStarWeight) {
        this.weightedAStarWeight = weightedAStarWeight <= 1.0 ? 1.0 : weightedAStarWeight;
    }

    public double getCostEpsilon() { return costEpsilon; }
    public void setCostEpsilon(double costEpsilon) { this.costEpsilon = Math.max(0.0, costEpsilon); }

    public boolean isAllowUnboundedOps() { return allowUnboundedOps; }
    public void setAllowUnboundedOps(boolean allowUnboundedOps) { this.allowUnboundedOps = allowUnboundedOps; }

    public double getUnboundedPenalty() { return unboundedPenalty; }
    public void setUnboundedPenalty(double unboundedPenalty) { this.unboundedPenalty = Math.max(0.0, unboundedPenalty); }

    public boolean isAllowAddLimit() { return false; }
    public void setAllowAddLimit(boolean allowAddLimit) { this.allowAddLimit = false; }

    public boolean isUseAdmissibleHeuristic() { return useAdmissibleHeuristic; }
    public void setUseAdmissibleHeuristic(boolean useAdmissibleHeuristic) { this.useAdmissibleHeuristic = useAdmissibleHeuristic; }
    
    public double getModificationThreshold() { return modificationThreshold; }
    public void setModificationThreshold(double modificationThreshold) { 
        this.modificationThreshold = modificationThreshold; 
    }
    
    public boolean isEnableStatisticsCache() { return enableStatisticsCache; }
    public void setEnableStatisticsCache(boolean enableStatisticsCache) { 
        this.enableStatisticsCache = enableStatisticsCache; 
    }

    public boolean isUseSchema() {
        return useSchema;
    }

    public void setUseSchema(boolean useSchema) {
        this.useSchema = useSchema;
    }

    public boolean isUsePlannerStats() {
        return usePlannerStats;
    }

    public void setUsePlannerStats(boolean usePlannerStats) {
        this.usePlannerStats = usePlannerStats;
    }

    public int getDataDrivenTimeoutSeconds() {
        return dataDrivenTimeoutSeconds;
    }

    public void setDataDrivenTimeoutSeconds(int dataDrivenTimeoutSeconds) {
        this.dataDrivenTimeoutSeconds = Math.max(0, dataDrivenTimeoutSeconds);
    }

    public boolean isAllowDataQueries() {
        return allowDataQueries;
    }

    public void setAllowDataQueries(boolean allowDataQueries) {
        this.allowDataQueries = allowDataQueries;
    }

    public boolean isStrictEstimateOnly() {
        return strictEstimateOnly;
    }

    public void setStrictEstimateOnly(boolean strictEstimateOnly) {
        this.strictEstimateOnly = strictEstimateOnly;
    }

    public int getMaxCandidateCountCalls() { return maxCandidateCountCalls; }
    public void setMaxCandidateCountCalls(int maxCandidateCountCalls) {
        this.maxCandidateCountCalls = Math.max(0, maxCandidateCountCalls);
    }
    public boolean isCandidateCountUpperBoundGate() { return candidateCountUpperBoundGate; }
    public void setCandidateCountUpperBoundGate(boolean enabled) {
        this.candidateCountUpperBoundGate = enabled;
    }

    public boolean isUncertaintyAwareSearch() {
        return uncertaintyAwareSearch;
    }

    public void setUncertaintyAwareSearch(boolean uncertaintyAwareSearch) {
        this.uncertaintyAwareSearch = uncertaintyAwareSearch;
    }

    public double getUncertaintyPenaltyWeight() {
        return uncertaintyPenaltyWeight;
    }

    public void setUncertaintyPenaltyWeight(double uncertaintyPenaltyWeight) {
        this.uncertaintyPenaltyWeight = Math.max(0.0, uncertaintyPenaltyWeight);
    }

    public boolean isLearningGuidanceEnabled() {
        return learningGuidanceEnabled;
    }

    public void setLearningGuidanceEnabled(boolean learningGuidanceEnabled) {
        this.learningGuidanceEnabled = learningGuidanceEnabled;
    }

    public double getLearningGuidanceStrength() {
        return learningGuidanceStrength;
    }

    public void setLearningGuidanceStrength(double learningGuidanceStrength) {
        this.learningGuidanceStrength = Math.max(0.0, learningGuidanceStrength);
    }

    public int getLearningMinSupport() {
        return learningMinSupport;
    }

    public void setLearningMinSupport(int learningMinSupport) {
        this.learningMinSupport = Math.max(1, learningMinSupport);
    }

    public boolean isParetoFrontierEnabled() {
        return paretoFrontierEnabled;
    }

    public void setParetoFrontierEnabled(boolean paretoFrontierEnabled) {
        this.paretoFrontierEnabled = paretoFrontierEnabled;
    }

    public boolean isStrictTheoremMode() {
        return strictTheoremMode;
    }

    public void setStrictTheoremMode(boolean strictTheoremMode) {
        this.strictTheoremMode = strictTheoremMode;
    }

    public int getMaxThresholdCandidatesPerPredicate() {
        return maxThresholdCandidatesPerPredicate;
    }

    public void setMaxThresholdCandidatesPerPredicate(int value) {
        this.maxThresholdCandidatesPerPredicate = Math.max(1, value);
    }

    public boolean isUseFormalBounds() {
        return useFormalBounds;
    }

    public void setUseFormalBounds(boolean useFormalBounds) {
        this.useFormalBounds = useFormalBounds;
    }

    public String getCardinalityEstimator() {
        return cardinalityEstimator;
    }

    public void setCardinalityEstimator(String cardinalityEstimator) {
        if (cardinalityEstimator == null || cardinalityEstimator.isBlank()) {
            this.cardinalityEstimator = "schema_bounds";
            return;
        }
        this.cardinalityEstimator = cardinalityEstimator.trim().toLowerCase().replace('-', '_');
    }

    public boolean isUseSoftUpperBounds() {
        return useSoftUpperBounds;
    }

    public void setUseSoftUpperBounds(boolean useSoftUpperBounds) {
        this.useSoftUpperBounds = useSoftUpperBounds;
    }

    public boolean isUseCalibratedBounds() {
        return useCalibratedBounds;
    }

    public void setUseCalibratedBounds(boolean useCalibratedBounds) {
        this.useCalibratedBounds = useCalibratedBounds;
    }

    public boolean isForceRewriteAfterPrecheck() {
        return forceRewriteAfterPrecheck;
    }

    public void setForceRewriteAfterPrecheck(boolean forceRewriteAfterPrecheck) {
        this.forceRewriteAfterPrecheck = forceRewriteAfterPrecheck;
    }

    public boolean isForceAStarRewrite() {
        return forceAStarRewrite;
    }

    public void setForceAStarRewrite(boolean forceAStarRewrite) {
        this.forceAStarRewrite = forceAStarRewrite;
    }

    /** Queue-order intervention; does not change edits, edge costs or goal tests. */
    public String getFrontierOrder() { return frontierOrder; }
    public void setFrontierOrder(String order) {
        if (!Set.of("astar", "uniform", "greedy").contains(order)) {
            throw new IllegalArgumentException("frontier_order must be astar, uniform or greedy");
        }
        frontierOrder = order;
    }

    public boolean isUseUniformCost() {
        return useUniformCost;
    }

    public void setUseUniformCost(boolean useUniformCost) {
        this.useUniformCost = useUniformCost;
    }

    public Set<ModificationOperation.Type> getAllowedOperations() {
        return allowedOperations;
    }

    public void setAllowedOperations(Set<ModificationOperation.Type> allowedOperations) {
        this.allowedOperations = allowedOperations;
    }

    public boolean isEnforceConnectedPatterns() {
        return enforceConnectedPatterns;
    }

    public void setEnforceConnectedPatterns(boolean enforceConnectedPatterns) {
        this.enforceConnectedPatterns = enforceConnectedPatterns;
    }

    public boolean isAllowRelationshipRepairs() {
        return allowRelationshipRepairs;
    }

    public void setAllowRelationshipRepairs(boolean allowRelationshipRepairs) {
        this.allowRelationshipRepairs = allowRelationshipRepairs;
    }

    public boolean isAllowRelationshipDeletionRelaxation() {
        return allowRelationshipDeletionRelaxation;
    }

    public void setAllowRelationshipDeletionRelaxation(boolean allowRelationshipDeletionRelaxation) {
        this.allowRelationshipDeletionRelaxation = allowRelationshipDeletionRelaxation;
    }
    
    public long getStatisticsCacheTTL() { return statisticsCacheTTL; }
    public void setStatisticsCacheTTL(long statisticsCacheTTL) { 
        this.statisticsCacheTTL = statisticsCacheTTL; 
    }
    
    public int getMaxAlternatives() { return maxAlternatives; }
    public void setMaxAlternatives(int maxAlternatives) { this.maxAlternatives = maxAlternatives; }
    
    public String getOperationStrategy() { return operationStrategy; }
    public void setOperationStrategy(String operationStrategy) { this.operationStrategy = operationStrategy; }
    
    /**
     * Create a configuration optimized for performance
     */
    public static RewritingConfig createPerformanceOptimized() {
        RewritingConfig config = new RewritingConfig();
        config.setMaxIterations(500);
        config.setAlpha(0.5);
        config.setBeta(0.0005);
        config.setUseFormalBounds(true);
        config.setModificationThreshold(50.0);
        return config;
    }
    
    /**
    * Create a configuration optimized for thoroughness
    */
    public static RewritingConfig createThoroughness() {
        RewritingConfig config = new RewritingConfig();
        config.setMaxIterations(2000);
        config.setAlpha(2.0);
        config.setBeta(0.01);
        config.setUseFormalBounds(true);
        config.setModificationThreshold(200.0);
        return config;
    }
    
    @Override
    public String toString() {
        return String.format(
            "RewritingConfig{maxIterations=%d, alpha=%.3f, beta=%.3f, gamma=%.3f, rho=%.2f, w=%.2f, threshold=%.1f, epsilon=%.3f, estimator=%s, uniformCost=%s, relDeleteRelax=%s, uncertainty=%s, learning=%s, pareto=%s, strictTheorem=%s}",
            maxIterations, alpha, beta, gamma, heuristicRho, weightedAStarWeight, modificationThreshold, costEpsilon,
            cardinalityEstimator, useUniformCost, allowRelationshipDeletionRelaxation, uncertaintyAwareSearch, learningGuidanceEnabled, paretoFrontierEnabled, strictTheoremMode);
    }
}
