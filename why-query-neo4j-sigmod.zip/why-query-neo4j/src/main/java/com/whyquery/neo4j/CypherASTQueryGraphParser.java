package com.whyquery.neo4j;

import com.whyquery.neo4j.ast.ASTNode;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.ast.NodeType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * AST-only Cypher -> QueryGraph conversion (no Neo4j planner calls).
 *
 * This intentionally supports the subset of Cypher used in the evaluation workloads:
 * - MATCH / OPTIONAL MATCH with simple linear patterns
 * - Inline node/relationship labels and properties
 * - WHERE is parsed separately by other utilities; we only build the pattern graph here
 */
public final class CypherASTQueryGraphParser {

    private CypherASTQueryGraphParser() {
    }

    public static QueryGraph parse(String cypherQuery) {
        CypherAST ast = CypherASTBuilder.parseQuery(cypherQuery);
        return fromAst(ast, cypherQuery);
    }

    @SuppressWarnings("unchecked")
    public static QueryGraph fromAst(CypherAST ast, String originalCypherQuery) {
        QueryGraph queryGraph = new QueryGraph();
        queryGraph.setOriginalCypherQuery(originalCypherQuery);
        if (ast == null) {
            return queryGraph;
        }

        Map<String, Integer> idByVar = new LinkedHashMap<>();
        Map<Integer, String> varById = new HashMap<>();
        Map<Integer, Set<String>> labelsById = new HashMap<>();
        Map<Integer, Map<String, Object>> propsById = new HashMap<>();
        final int[] nextId = new int[]{1};
        final int[] anonCounter = new int[]{0};

        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            Integer lastNodeId = null;
            ASTNode pendingRel = null;

            for (ASTNode element : elements) {
                if (element == null) {
                    continue;
                }
                if (element.getType() == NodeType.NODE) {
                    String var = element.getAttribute("variable", String.class);
                    if (var == null || var.isBlank()) {
                        var = "__anon" + (++anonCounter[0]);
                    }
                    int nodeId = idByVar.computeIfAbsent(var, v -> {
                        int assigned = nextId[0]++;
                        varById.put(assigned, v);
                        labelsById.put(assigned, new HashSet<>());
                        propsById.put(assigned, new HashMap<>());
                        return assigned;
                    });

                    Object lblObj = element.getAttribute("labels", Object.class);
                    if (lblObj instanceof List<?>) {
                        for (Object o : (List<?>) lblObj) {
                            if (o != null && !o.toString().isBlank()) {
                                labelsById.get(nodeId).add(o.toString());
                            }
                        }
                    }
                    Object propsObj = element.getAttribute("properties", Object.class);
                    if (propsObj instanceof Map<?, ?>) {
                        for (Map.Entry<?, ?> entry : ((Map<?, ?>) propsObj).entrySet()) {
                            if (entry.getKey() != null) {
                                propsById.get(nodeId).put(entry.getKey().toString(), entry.getValue());
                            }
                        }
                    }
                    upsertVertex(queryGraph, nodeId, varById.get(nodeId), labelsById.get(nodeId), propsById.get(nodeId));

                    if (pendingRel != null && lastNodeId != null) {
                        String relType = pendingRel.getAttribute("type", String.class);
                        if (relType == null) {
                            relType = "";
                        }
                        String direction = pendingRel.getAttribute("direction", String.class);
                        Map<String, Object> relProps = new HashMap<>();
                        Object relPropsObj = pendingRel.getAttribute("properties", Object.class);
                        if (relPropsObj instanceof Map<?, ?>) {
                            for (Map.Entry<?, ?> entry : ((Map<?, ?>) relPropsObj).entrySet()) {
                                if (entry.getKey() != null) {
                                    relProps.put(entry.getKey().toString(), entry.getValue());
                                }
                            }
                        }

                        int source = lastNodeId;
                        int target = nodeId;
                        if ("IN".equalsIgnoreCase(direction)) {
                            source = nodeId;
                            target = lastNodeId;
                        }

                        queryGraph.addEdge(source, target, relType, relProps);
                        pendingRel = null;
                    }
                    lastNodeId = nodeId;
                } else if (element.getType() == NodeType.RELATIONSHIP) {
                    pendingRel = element;
                }
            }
        }

        // Ensure there is at least one vertex for downstream logic.
        if (queryGraph.numVertices() == 0 && originalCypherQuery != null) {
            queryGraph.addVertex(1, "query_root", List.of("Query"), Map.of("text", originalCypherQuery));
        }
        return queryGraph;
    }

    private static void upsertVertex(QueryGraph queryGraph,
                                     int id,
                                     String variable,
                                     Set<String> labels,
                                     Map<String, Object> properties) {
        if (queryGraph == null || variable == null || variable.isBlank()) {
            return;
        }
        Set<String> lbls = labels != null ? labels : Set.of();
        Map<String, Object> props = properties != null ? properties : Map.of();
        queryGraph.addVertex(id, variable, List.copyOf(lbls), new HashMap<>(props));
    }
}
