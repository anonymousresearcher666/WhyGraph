package com.whyquery.neo4j.ranking;

import java.util.*;
import java.text.DecimalFormat;

/**
 * Generates natural language explanations for ranking decisions and comparisons.
 */
public class RankingExplanationGenerator {
    
    private final DecimalFormat decimalFormat = new DecimalFormat("#.##");
    
    /**
     * Generate explanation for why one entity ranks higher than another
     */
    public String explainRankingComparison(RankingComparison comparison) {
        StringBuilder explanation = new StringBuilder();
        
        String entityA = comparison.getEntityA();
        String entityB = comparison.getEntityB();
        String favored = comparison.getFavoredEntity();
        double difference = Math.abs(comparison.getOverallDifference());
        
        // Overall summary
        if ("NEUTRAL".equals(favored)) {
            explanation.append(String.format("Entities %s and %s have equal ranking scores.", 
                                            entityA, entityB));
        } else {
            String favoredEntity = "A".equals(favored) ? entityA : entityB;
            String otherEntity = "A".equals(favored) ? entityB : entityA;
            
            explanation.append(String.format("Entity %s ranks higher than Entity %s " +
                                            "by an overall difference of %s points. ",
                                            favoredEntity, otherEntity, decimalFormat.format(difference)));
        }
        
        // Factor-by-factor breakdown
        List<FactorContribution> significantFactors = comparison.getMostInfluentialFactors(5);
        if (!significantFactors.isEmpty()) {
            explanation.append("Here's the breakdown by factor:\n\n");
            
            for (int i = 0; i < significantFactors.size(); i++) {
                FactorContribution factor = significantFactors.get(i);
                explanation.append(String.format("%d. %s\n", 
                                                i + 1, explainFactorContribution(factor, entityA, entityB)));
            }
        }
        
        // Summary of factor counts
        int factorsForA = comparison.getFactorsFavoringA().size();
        int factorsForB = comparison.getFactorsFavoringB().size();
        int neutralFactors = comparison.getNeutralFactors().size();
        
        if (factorsForA + factorsForB + neutralFactors > 0) {
            explanation.append(String.format("\nSummary: %d factors favor %s, %d factors favor %s, " +
                                            "and %d factors are neutral.",
                                            factorsForA, entityA, factorsForB, entityB, neutralFactors));
        }
        
        return explanation.toString();
    }
    
    /**
     * Explain a single factor's contribution to the ranking difference
     */
    private String explainFactorContribution(FactorContribution contribution, 
                                           String entityA, String entityB) {
        RankingFactor factor = contribution.getFactor();
        Object valueA = contribution.getValueA();
        Object valueB = contribution.getValueB();
        double diff = contribution.getContributionDifference();
        String favors = contribution.getFavorsEntity();
        
        StringBuilder explanation = new StringBuilder();
        
        // Factor name and values
        String factorName = getFactorFriendlyName(factor);
        explanation.append(String.format("%s: ", factorName));
        
        if (valueA != null && valueB != null) {
            explanation.append(String.format("%s has %s vs %s's %s", 
                                            entityA, formatValue(valueA), entityB, formatValue(valueB)));
        } else if (valueA != null) {
            explanation.append(String.format("%s has %s while %s has no value", 
                                            entityA, formatValue(valueA), entityB));
        } else if (valueB != null) {
            explanation.append(String.format("%s has no value while %s has %s", 
                                            entityA, entityB, formatValue(valueB)));
        } else {
            explanation.append("Both entities have no value");
        }
        
        // Impact explanation
        if (!"NEUTRAL".equals(favors)) {
            String favoredEntity = "A".equals(favors) ? entityA : entityB;
            explanation.append(String.format(" (contributes %s points in favor of %s)",
                                           decimalFormat.format(Math.abs(diff)), favoredEntity));
        } else {
            explanation.append(" (no ranking impact)");
        }
        
        return explanation.toString();
    }
    
    /**
     * Generate explanation for a ranking analysis
     */
    public String explainRankingAnalysis(RankingAnalysis analysis) {
        StringBuilder explanation = new StringBuilder();
        
        explanation.append("🎯 REAL Ranking Analysis (not just echoing what you wrote):\n\n");
        
        String query = analysis.getOriginalQuery().toLowerCase();
        RankingType type = analysis.getRankingType();
        
        // PERFORMANCE & CORRECTNESS ANALYSIS
        explanation.append("⚡ PERFORMANCE & CORRECTNESS ISSUES:\n");
        
        if (type == RankingType.IMPLICIT_LIMIT) {
            explanation.append("🚨 CRITICAL ISSUE: LIMIT without ORDER BY!\n");
            explanation.append("   Your query returns RANDOM results that change every time you run it!\n");
            explanation.append("💡 URGENT FIX: Add ORDER BY clause before LIMIT\n");
            explanation.append("   Example: ORDER BY m.title ASC LIMIT 5\n");
        }
        
        if (query.contains("order by") && query.contains("null")) {
            explanation.append("❌ NULL VALUES IN RANKING: Some entities have null ranking values!\n");
            explanation.append("💡 FIX: Use 'WHERE property IS NOT NULL' or 'ORDER BY coalesce(property, 0)'\n");
        }
        
        if (query.contains("order by") && !query.contains("limit")) {
            explanation.append("⚠️  NO LIMIT: You're sorting the entire dataset without limiting results\n");
            explanation.append("💡 OPTIMIZATION: Add LIMIT if you only need top N results\n");
        }
        
        // RANKING LOGIC ANALYSIS  
        explanation.append("\n🧠 RANKING LOGIC ANALYSIS:\n");
        
        if (type == RankingType.EXPLICIT_ORDER_BY) {
            // Extract ORDER BY property
            if (query.contains("order by")) {
                String orderPart = extractOrderByClause(query);
                explanation.append(String.format("You're ranking by: %s\n", orderPart));
                
                // Check for common issues
                if (orderPart.contains("desc")) {
                    explanation.append("✅ Good: Using DESC for highest-first ranking\n");
                } else if (orderPart.contains("asc")) {
                    explanation.append("✅ Good: Using ASC for lowest-first ranking\n");
                }
                
                // Check for multiple ranking factors
                if (orderPart.contains(",")) {
                    explanation.append("🔍 MULTI-FACTOR RANKING: Using multiple ranking criteria\n");
                    explanation.append("   Order matters! First criterion is primary, others are tie-breakers\n");
                }
            }
        } else if (type == RankingType.NO_RANKING) {
            explanation.append("⚠️  NO RANKING DETECTED: Results are in arbitrary order\n");
            explanation.append("💡 SUGGESTIONS:\n");
            explanation.append("1. Alphabetical: ORDER BY m.title ASC\n");
            explanation.append("2. Temporal: ORDER BY m.released DESC\n");
            explanation.append("3. Popularity: ORDER BY size((m)-[]-()) DESC\n");
        }
        
        // DATA QUALITY ANALYSIS
        explanation.append("\n📊 DATA QUALITY INSIGHTS:\n");
        
        // Check if we have factors with sample values
        List<RankingFactor> factors = analysis.getRankingFactors();
        if (!factors.isEmpty()) {
            for (RankingFactor factor : factors) {
                List<Map<String, Object>> samples = factor.getSampleValues();
                if (!samples.isEmpty()) {
                    long nullCount = samples.stream()
                        .mapToLong(s -> s.get("factor_value") == null ? 1 : 0)
                        .sum();
                    
                    if (nullCount > 0) {
                        explanation.append(String.format("⚠️  %s has %d null values out of %d samples\n", 
                            factor.getExpression(), nullCount, samples.size()));
                        explanation.append("💡 Consider filtering: WHERE " + factor.getExpression() + " IS NOT NULL\n");
                    }
                }
            }
        }
        
        // ACTIONABLE IMPROVEMENTS
        explanation.append("\n🎯 ACTIONABLE IMPROVEMENTS:\n");
        
        if (query.contains("limit") && !query.contains("order by")) {
            explanation.append("1. 🚨 URGENT: Add ORDER BY before LIMIT\n");
        }
        
        if (query.contains("order by") && !query.contains("desc") && !query.contains("asc")) {
            explanation.append("2. Specify direction: ORDER BY property DESC (or ASC)\n");
        }
        
        if (!query.contains("limit") && query.contains("order by")) {
            explanation.append("3. Consider adding selective predicates before ranking for better performance\n");
        }
        
        if (query.contains("return") && !query.contains("order by") && !query.contains("limit")) {
            explanation.append("4. Add ranking for predictable results: ORDER BY m.title\n");
        }
        
        return explanation.toString();
    }
    
    private String extractOrderByClause(String query) {
        String[] parts = query.split("order by");
        if (parts.length > 1) {
            String orderPart = parts[1].split("limit")[0].trim();
            return orderPart.length() > 50 ? orderPart.substring(0, 50) + "..." : orderPart;
        }
        return "unknown";
    }
    
    /**
     * Explain a single ranking factor
     */
    private String explainRankingFactor(RankingFactor factor) {
        StringBuilder explanation = new StringBuilder();
        
        String factorName = getFactorFriendlyName(factor);
        explanation.append(factorName);
        
        // Direction
        String direction = factor.getDirection();
        if ("DESC".equalsIgnoreCase(direction)) {
            explanation.append(" (higher values rank first)");
        } else {
            explanation.append(" (lower values rank first)");
        }
        
        // Weight
        if (Math.abs(factor.getWeight() - 1.0) > 0.001) {
            explanation.append(String.format(" with weight %s", decimalFormat.format(factor.getWeight())));
        }
        
        // Value range if available
        if (!factor.getSampleValues().isEmpty()) {
            RankingFactor.ValueRange range = factor.getValueRange();
            explanation.append(String.format(" [range: %s to %s]", 
                                            decimalFormat.format(range.getMin()),
                                            decimalFormat.format(range.getMax())));
        }
        
        return explanation.toString();
    }
    
    /**
     * Generate suggestions for ranking improvements
     */
    public String generateRankingSuggestions(RankingComparison comparison, 
                                           List<RankingComposition> alternatives) {
        StringBuilder suggestions = new StringBuilder();
        
        suggestions.append("Ranking Improvement Suggestions:\n\n");
        
        // Analyze problematic factors
        List<FactorContribution> problematic = findProblematicFactors(comparison);
        if (!problematic.isEmpty()) {
            suggestions.append("Potential Issues Identified:\n");
            for (FactorContribution factor : problematic) {
                suggestions.append(String.format("- %s may be causing unexpected ranking\n",
                                                getFactorFriendlyName(factor.getFactor())));
            }
            suggestions.append("\n");
        }
        
        // Alternative compositions
        if (!alternatives.isEmpty()) {
            suggestions.append("Alternative Ranking Approaches:\n");
            for (int i = 0; i < Math.min(3, alternatives.size()); i++) {
                RankingComposition alt = alternatives.get(i);
                suggestions.append(String.format("%d. %s\n", i + 1, explainComposition(alt)));
            }
        }
        
        return suggestions.toString();
    }
    
    /**
     * Explain a ranking composition
     */
    private String explainComposition(RankingComposition composition) {
        StringBuilder explanation = new StringBuilder();
        
        explanation.append(composition.getName()).append(": ");
        
        List<RankingFactor> factors = composition.getFactorsByImportance();
        if (factors.isEmpty()) {
            explanation.append("No factors");
        } else if (factors.size() == 1) {
            explanation.append("Ranks by ").append(getFactorFriendlyName(factors.get(0)));
        } else {
            explanation.append("Prioritizes ").append(getFactorFriendlyName(factors.get(0)));
            if (factors.size() > 1) {
                explanation.append(", then ").append(getFactorFriendlyName(factors.get(1)));
            }
            if (factors.size() > 2) {
                explanation.append(String.format(", and %d other factors", factors.size() - 2));
            }
        }
        
        // Add diversity info
        if (composition.isBalanced()) {
            explanation.append(" (balanced approach)");
        } else {
            explanation.append(" (focused approach)");
        }
        
        return explanation.toString();
    }
    
    /**
     * Find factors that might be causing unexpected ranking
     */
    private List<FactorContribution> findProblematicFactors(RankingComparison comparison) {
        List<FactorContribution> problematic = new ArrayList<>();
        
        for (FactorContribution contribution : comparison.getFactorContributions()) {
            RankingFactor factor = contribution.getFactor();
            
            // Check if factor is likely problematic
            if (factor.isLikelyProblem()) {
                problematic.add(contribution);
            }
            
            // Check for unexpected null values
            if ((contribution.getValueA() == null) != (contribution.getValueB() == null)) {
                problematic.add(contribution);
            }
        }
        
        return problematic;
    }
    
    /**
     * Get a user-friendly name for a ranking factor
     */
    private String getFactorFriendlyName(RankingFactor factor) {
        String expression = factor.getExpression();
        
        // Handle common patterns
        if (expression.matches("\\w+\\.\\w+")) {
            return expression; // property access like "movie.rating"
        } else if (expression.startsWith("count(")) {
            return "Count of items";
        } else if (expression.startsWith("size(")) {
            return "Size/length";
        } else if (expression.startsWith("degree(")) {
            return "Node degree/connectivity";
        } else if (expression.startsWith("id(")) {
            return "Internal ID";
        } else if (expression.contains("created")) {
            return "Creation time";
        } else if (expression.contains("updated") || expression.contains("modified")) {
            return "Modification time";
        } else {
            return expression;
        }
    }
    
    /**
     * Get description for ranking type
     */
    private String getRankingTypeDescription(RankingType type) {
        switch (type) {
            case NO_RANKING:
                return "No explicit ranking (arbitrary order)";
            case EXPLICIT_ORDER_BY:
                return "Explicit ranking with ORDER BY clause";
            case IMPLICIT_LIMIT:
                return "Implicit ranking due to LIMIT without ORDER BY";
            case IMPLICIT_DEGREE:
                return "Implicit ranking based on node connectivity";
            case IMPLICIT_AGGREGATION:
                return "Implicit ranking based on aggregation functions";
            case IMPLICIT_PROPERTY:
                return "Implicit ranking based on property values";
            case IMPLICIT_PATH:
                return "Implicit ranking based on path metrics";
            case CUSTOM:
                return "Custom ranking logic";
            case IMPLICIT_GENERIC:
                return "Generic ranking strategy applied";
            default:
                return "Unknown ranking type";
        }
    }
    
    /**
     * Format a value for display
     */
    private String formatValue(Object value) {
        if (value == null) {
            return "null";
        } else if (value instanceof Number) {
            return decimalFormat.format(((Number) value).doubleValue());
        } else if (value instanceof String) {
            String str = (String) value;
            if (str.length() > 20) {
                return "\"" + str.substring(0, 17) + "...\"";
            } else {
                return "\"" + str + "\"";
            }
        } else {
            return value.toString();
        }
    }
}
