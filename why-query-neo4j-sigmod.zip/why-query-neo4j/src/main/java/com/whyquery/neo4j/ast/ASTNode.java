package com.whyquery.neo4j.ast;

import java.util.*;

/**
 * Individual AST node implementation following the formal definition.
 * Each node has:
 * - Unique ID
 * - Node type (from NodeType enum)
 * - Attributes map (σ function)
 */
public class ASTNode {
    
    private final String id;
    private final NodeType type;
    private final Map<String, Object> attributes;
    
    public ASTNode(String id, NodeType type, Map<String, Object> attributes) {
        this.id = id;
        this.type = type;
        this.attributes = attributes != null ? new HashMap<>(attributes) : new HashMap<>();
    }
    
    public String getId() {
        return id;
    }
    
    public NodeType getType() {
        return type;
    }
    
    public Map<String, Object> getAttributes() {
        return new HashMap<>(attributes);
    }
    
    public void setAttribute(String key, Object value) {
        attributes.put(key, value);
    }
    
    public Object getAttribute(String key) {
        return attributes.get(key);
    }
    
    @SuppressWarnings("unchecked")
    public <T> T getAttribute(String key, Class<T> type) {
        Object value = attributes.get(key);
        if (value != null && type.isAssignableFrom(value.getClass())) {
            return (T) value;
        }
        return null;
    }
    
    public boolean hasAttribute(String key) {
        return attributes.containsKey(key);
    }
    
    public void removeAttribute(String key) {
        attributes.remove(key);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        ASTNode astNode = (ASTNode) obj;
        return Objects.equals(id, astNode.id) &&
               type == astNode.type &&
               Objects.equals(attributes, astNode.attributes);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, type, attributes);
    }
    
    @Override
    public String toString() {
        return String.format("ASTNode{id='%s', type=%s, attributes=%s}", 
                           id, type, attributes);
    }
    
    /**
     * Create a copy of this node with a new ID
     */
    public ASTNode copyWithNewId(String newId) {
        return new ASTNode(newId, this.type, new HashMap<>(this.attributes));
    }
    
    /**
     * Create a copy of this node with modified attributes
     */
    public ASTNode copyWithAttributes(Map<String, Object> newAttributes) {
        Map<String, Object> combined = new HashMap<>(this.attributes);
        combined.putAll(newAttributes);
        return new ASTNode(this.id, this.type, combined);
    }
}