package com.whyquery.neo4j;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Builds binary graph representation for zero-copy C++ communication
 * Layout: [Header] [Label Table] [Property Table] [Node Array] [Edge Array]
 */
public class BinaryGraphBuilder {
    
    private static final int MAGIC_NUMBER = 0x47524146; // "GRAF"
    private static final int VERSION = 1;
    private static final int HEADER_SIZE = 64; // Fixed header size
    
    // Data collections
    private final List<NodeData> nodes = new ArrayList<>();
    private final List<EdgeData> edges = new ArrayList<>();
    private final Map<String, Integer> labelMap = new HashMap<>();
    private final Map<String, Integer> propertyMap = new HashMap<>();
    private final List<String> labels = new ArrayList<>();
    private final List<PropertyInfo> properties = new ArrayList<>();
    
    // Data structures
    public static class NodeData {
        public long nodeId;
        public List<String> labels;
        public Map<String, Object> properties;
        
        public NodeData(long id, List<String> lbls, Map<String, Object> props) {
            this.nodeId = id;
            this.labels = lbls != null ? lbls : new ArrayList<>();
            this.properties = props != null ? props : new HashMap<>();
        }
    }
    
    public static class EdgeData {
        public long edgeId;
        public long sourceId;
        public long targetId;
        public String edgeType;
        public Map<String, Object> properties;
        
        public EdgeData(long id, long src, long tgt, String type, Map<String, Object> props) {
            this.edgeId = id;
            this.sourceId = src;
            this.targetId = tgt;
            this.edgeType = type != null ? type : "";
            this.properties = props != null ? props : new HashMap<>();
        }
    }
    
    private static class PropertyInfo {
        public String name;
        public byte type; // 0=string, 1=int, 2=double, 3=bool
        
        public PropertyInfo(String name, byte type) {
            this.name = name;
            this.type = type;
        }
    }
    
    public void addNode(long nodeId, List<String> labels, Map<String, Object> properties) {
        nodes.add(new NodeData(nodeId, labels, properties));
        
        // Register labels
        if (labels != null) {
            for (String label : labels) {
                registerLabel(label);
            }
        }
        
        // Register properties
        if (properties != null) {
            for (Map.Entry<String, Object> entry : properties.entrySet()) {
                registerProperty(entry.getKey(), entry.getValue());
            }
        }
    }
    
    public void addEdge(long edgeId, long sourceId, long targetId, String edgeType, Map<String, Object> properties) {
        edges.add(new EdgeData(edgeId, sourceId, targetId, edgeType, properties));
        
        // Register edge type as label
        if (edgeType != null && !edgeType.isEmpty()) {
            registerLabel(edgeType);
        }
        
        // Register properties
        if (properties != null) {
            for (Map.Entry<String, Object> entry : properties.entrySet()) {
                registerProperty(entry.getKey(), entry.getValue());
            }
        }
    }
    
    private void registerLabel(String label) {
        if (!labelMap.containsKey(label)) {
            labelMap.put(label, labels.size());
            labels.add(label);
        }
    }
    
    private void registerProperty(String propName, Object value) {
        if (!propertyMap.containsKey(propName)) {
            byte type = getValueType(value);
            propertyMap.put(propName, properties.size());
            properties.add(new PropertyInfo(propName, type));
        }
    }
    
    private byte getValueType(Object value) {
        if (value instanceof String) return 0;
        if (value instanceof Integer || value instanceof Long) return 1;
        if (value instanceof Double || value instanceof Float) return 2;
        if (value instanceof Boolean) return 3;
        return 0; // Default to string
    }
    
    public ByteBuffer build() {
        // Calculate total size needed
        int totalSize = calculateTotalSize();
        
        // Allocate direct buffer (off-heap)
        ByteBuffer buffer = ByteBuffer.allocateDirect(totalSize);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        
        // Calculate offsets
        int labelTableOffset = HEADER_SIZE;
        int propertyTableOffset = labelTableOffset + calculateLabelTableSize();
        int nodeArrayOffset = propertyTableOffset + calculatePropertyTableSize();
        int edgeArrayOffset = nodeArrayOffset + calculateNodeArraySize();
        
        // Write header
        writeHeader(buffer, labelTableOffset, propertyTableOffset, 
                   nodeArrayOffset, edgeArrayOffset, totalSize);
        
        // Write data sections
        writeLabelTable(buffer, labelTableOffset);
        writePropertyTable(buffer, propertyTableOffset);
        writeNodeArray(buffer, nodeArrayOffset);
        writeEdgeArray(buffer, edgeArrayOffset);
        
        buffer.flip();
        return buffer;
    }
    
    private int calculateTotalSize() {
        return HEADER_SIZE + 
               calculateLabelTableSize() + 
               calculatePropertyTableSize() + 
               calculateNodeArraySize() + 
               calculateEdgeArraySize();
    }
    
    private int calculateLabelTableSize() {
        int size = 0;
        for (String label : labels) {
            size += 4; // LabelEntry header
            size += label.getBytes(StandardCharsets.UTF_8).length;
        }
        return size;
    }
    
    private int calculatePropertyTableSize() {
        int size = 0;
        for (PropertyInfo prop : properties) {
            size += 8; // PropertyEntry header
            size += prop.name.getBytes(StandardCharsets.UTF_8).length;
        }
        return size;
    }
    
    private int calculateNodeArraySize() {
        int size = 0;
        for (NodeData node : nodes) {
            size += 24; // NodeEntry header
            size += node.labels.size() * 2; // Label IDs
            size += calculatePropertyValues(node.properties);
        }
        return size;
    }
    
    private int calculateEdgeArraySize() {
        int size = 0;
        for (EdgeData edge : edges) {
            size += 32; // EdgeEntry header
            size += calculatePropertyValues(edge.properties);
        }
        return size;
    }
    
    private int calculatePropertyValues(Map<String, Object> properties) {
        int size = 0;
        for (Map.Entry<String, Object> entry : properties.entrySet()) {
            size += 8; // PropertyValue header
            Object value = entry.getValue();
            if (value instanceof String) {
                size += ((String) value).getBytes(StandardCharsets.UTF_8).length;
            } else if (value instanceof Integer || value instanceof Long) {
                size += 8;
            } else if (value instanceof Double || value instanceof Float) {
                size += 8;
            } else if (value instanceof Boolean) {
                size += 1;
            } else {
                size += value.toString().getBytes(StandardCharsets.UTF_8).length;
            }
        }
        return size;
    }
    
    private void writeHeader(ByteBuffer buffer, int labelOffset, int propOffset, 
                           int nodeOffset, int edgeOffset, int totalSize) {
        buffer.putInt(MAGIC_NUMBER);
        buffer.putInt(VERSION);
        buffer.putInt(nodes.size());
        buffer.putInt(edges.size());
        buffer.putInt(labels.size());
        buffer.putInt(properties.size());
        buffer.putInt(labelOffset);
        buffer.putInt(propOffset);
        buffer.putInt(nodeOffset);
        buffer.putInt(edgeOffset);
        buffer.putInt(totalSize);
        
        // Reserved space
        for (int i = 0; i < 5; i++) {
            buffer.putInt(0);
        }
    }
    
    private void writeLabelTable(ByteBuffer buffer, int offset) {
        buffer.position(offset);
        for (int i = 0; i < labels.size(); i++) {
            String label = labels.get(i);
            byte[] labelBytes = label.getBytes(StandardCharsets.UTF_8);
            
            buffer.putShort((short) i); // label_id
            buffer.putShort((short) labelBytes.length); // label_length
            buffer.put(labelBytes); // label_name
        }
    }
    
    private void writePropertyTable(ByteBuffer buffer, int offset) {
        buffer.position(offset);
        for (int i = 0; i < properties.size(); i++) {
            PropertyInfo prop = properties.get(i);
            byte[] propBytes = prop.name.getBytes(StandardCharsets.UTF_8);
            
            buffer.putShort((short) i); // property_id
            buffer.putShort((short) propBytes.length); // property_length
            buffer.put(prop.type); // property_type
            buffer.put((byte) 0); // reserved
            buffer.put((byte) 0); // reserved
            buffer.put((byte) 0); // reserved
            buffer.put(propBytes); // property_name
        }
    }
    
    private void writeNodeArray(ByteBuffer buffer, int offset) {
        buffer.position(offset);
        
        for (NodeData node : nodes) {
            int nodeStart = buffer.position();
            
            // Write NodeEntry header (reserve space)
            buffer.putLong(node.nodeId);
            buffer.putShort((short) node.labels.size());
            buffer.putShort((short) node.properties.size());
            int labelOffsetPos = buffer.position();
            buffer.putInt(0); // label_offset (fill later)
            int propOffsetPos = buffer.position();
            buffer.putInt(0); // property_offset (fill later)
            
            // Write label IDs
            int labelArrayStart = buffer.position();
            buffer.putInt(labelOffsetPos - 4, labelArrayStart - nodeStart); // Update label_offset
            
            for (String label : node.labels) {
                Integer labelId = labelMap.get(label);
                buffer.putShort(labelId != null ? labelId.shortValue() : 0);
            }
            
            // Write property values
            int propArrayStart = buffer.position();
            buffer.putInt(propOffsetPos - 4, propArrayStart - nodeStart); // Update property_offset
            
            writePropertyValues(buffer, node.properties);
        }
    }
    
    private void writeEdgeArray(ByteBuffer buffer, int offset) {
        buffer.position(offset);
        
        for (EdgeData edge : edges) {
            int edgeStart = buffer.position();
            
            // Write EdgeEntry header
            buffer.putLong(edge.edgeId);
            buffer.putLong(edge.sourceId);
            buffer.putLong(edge.targetId);
            
            Integer edgeTypeId = labelMap.get(edge.edgeType);
            buffer.putShort(edgeTypeId != null ? edgeTypeId.shortValue() : 0);
            buffer.putShort((short) edge.properties.size());
            
            int propOffsetPos = buffer.position();
            buffer.putInt(0); // property_offset (fill later)
            
            // Write property values
            int propArrayStart = buffer.position();
            buffer.putInt(propOffsetPos - 4, propArrayStart - edgeStart); // Update property_offset
            
            writePropertyValues(buffer, edge.properties);
        }
    }
    
    private void writePropertyValues(ByteBuffer buffer, Map<String, Object> properties) {
        for (Map.Entry<String, Object> entry : properties.entrySet()) {
            Integer propId = propertyMap.get(entry.getKey());
            Object value = entry.getValue();
            
            buffer.putShort(propId != null ? propId.shortValue() : 0); // property_id
            buffer.put(getValueType(value)); // value_type
            buffer.put((byte) 0); // reserved
            
            // Write value data
            byte[] valueBytes = null;
            if (value instanceof String) {
                valueBytes = ((String) value).getBytes(StandardCharsets.UTF_8);
                buffer.putInt(valueBytes.length);
                buffer.put(valueBytes);
            } else if (value instanceof Integer) {
                buffer.putInt(4);
                buffer.putInt((Integer) value);
            } else if (value instanceof Long) {
                buffer.putInt(8);
                buffer.putLong((Long) value);
            } else if (value instanceof Double) {
                buffer.putInt(8);
                buffer.putDouble((Double) value);
            } else if (value instanceof Float) {
                buffer.putInt(4);
                buffer.putFloat((Float) value);
            } else if (value instanceof Boolean) {
                buffer.putInt(1);
                buffer.put((byte) (((Boolean) value) ? 1 : 0));
            } else {
                // Fallback: convert to string
                valueBytes = value.toString().getBytes(StandardCharsets.UTF_8);
                buffer.putInt(valueBytes.length);
                buffer.put(valueBytes);
            }
        }
    }
    
    // Factory method for DataGraph - legacy placeholder removed
    // Use DataGraph.toBinaryBuffer() instead which uses REAL data
}
