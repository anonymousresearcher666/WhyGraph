package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Represents an actual path instance found by a query
 */
public class PathInstance {
    
    private String path;
    private int length;
    private double cost;
    private List<String> nodeIds;
    private List<String> relationshipIds;
    private List<String> relationshipTypes;
    private Map<String, Object> properties;
    private Map<String, Object> metadata;
    
    public PathInstance() {
        this.nodeIds = new ArrayList<>();
        this.relationshipIds = new ArrayList<>();
        this.relationshipTypes = new ArrayList<>();
        this.properties = new HashMap<>();
        this.metadata = new HashMap<>();
        this.cost = 0.0;
    }
    
    public String getPath() {
        return path;
    }
    
    public void setPath(String path) {
        this.path = path;
    }
    
    public int getLength() {
        return length;
    }
    
    public void setLength(int length) {
        this.length = length;
    }
    
    public double getCost() {
        return cost;
    }
    
    public void setCost(double cost) {
        this.cost = cost;
    }
    
    public List<String> getNodeIds() {
        return nodeIds;
    }
    
    public void setNodeIds(List<String> nodeIds) {
        this.nodeIds = nodeIds;
    }
    
    public void addNodeId(String nodeId) {
        this.nodeIds.add(nodeId);
    }
    
    public List<String> getRelationshipIds() {
        return relationshipIds;
    }
    
    public void setRelationshipIds(List<String> relationshipIds) {
        this.relationshipIds = relationshipIds;
    }
    
    public void addRelationshipId(String relationshipId) {
        this.relationshipIds.add(relationshipId);
    }
    
    public List<String> getRelationshipTypes() {
        return relationshipTypes;
    }
    
    public void setRelationshipTypes(List<String> relationshipTypes) {
        this.relationshipTypes = relationshipTypes;
    }
    
    public void addRelationshipType(String type) {
        this.relationshipTypes.add(type);
    }
    
    public Map<String, Object> getProperties() {
        return properties;
    }
    
    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }
    
    public void addProperty(String key, Object value) {
        this.properties.put(key, value);
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    /**
     * Get the start node ID
     */
    public String getStartNodeId() {
        return nodeIds.isEmpty() ? null : nodeIds.get(0);
    }
    
    /**
     * Get the end node ID
     */
    public String getEndNodeId() {
        return nodeIds.isEmpty() ? null : nodeIds.get(nodeIds.size() - 1);
    }
    
    /**
     * Get the average cost per hop
     */
    public double getAverageCostPerHop() {
        return length > 0 ? cost / length : 0.0;
    }
    
    /**
     * Check if this path contains a specific relationship type
     */
    public boolean containsRelationshipType(String type) {
        return relationshipTypes.contains(type);
    }
    
    /**
     * Get unique relationship types in this path
     */
    public Set<String> getUniqueRelationshipTypes() {
        return new HashSet<>(relationshipTypes);
    }
    
    /**
     * Check if this path has cycles (repeated nodes)
     */
    public boolean hasCycles() {
        Set<String> uniqueNodes = new HashSet<>(nodeIds);
        return uniqueNodes.size() < nodeIds.size();
    }
    
    /**
     * Get the efficiency score (lower cost per hop is better)
     */
    public double getEfficiencyScore() {
        if (length == 0) return 0.0;
        return 1.0 / getAverageCostPerHop();
    }
    
    /**
     * Generate a human-readable path description
     */
    public String getDescription() {
        StringBuilder desc = new StringBuilder();
        
        desc.append("Path of length ").append(length);
        
        if (cost > 0) {
            desc.append(" with cost ").append(String.format("%.2f", cost));
        }
        
        if (!relationshipTypes.isEmpty()) {
            Set<String> uniqueTypes = getUniqueRelationshipTypes();
            if (uniqueTypes.size() == 1) {
                desc.append(" using ").append(uniqueTypes.iterator().next()).append(" relationships");
            } else {
                desc.append(" using ").append(uniqueTypes.size()).append(" relationship types");
            }
        }
        
        if (hasCycles()) {
            desc.append(" (contains cycles)");
        }
        
        return desc.toString();
    }
    
    /**
     * Compare this path with another by length
     */
    public int compareByLength(PathInstance other) {
        return Integer.compare(this.length, other.length);
    }
    
    /**
     * Compare this path with another by cost
     */
    public int compareByCost(PathInstance other) {
        return Double.compare(this.cost, other.cost);
    }
    
    /**
     * Compare this path with another by efficiency
     */
    public int compareByEfficiency(PathInstance other) {
        return Double.compare(other.getEfficiencyScore(), this.getEfficiencyScore());
    }
    
    /**
     * Check if this path is equivalent to another (same nodes and relationships)
     */
    public boolean isEquivalentTo(PathInstance other) {
        return Objects.equals(this.nodeIds, other.nodeIds) &&
               Objects.equals(this.relationshipIds, other.relationshipIds);
    }
    
    @Override
    public String toString() {
        return "PathInstance{" +
               "length=" + length +
               ", cost=" + String.format("%.2f", cost) +
               ", types=" + getUniqueRelationshipTypes().size() +
               ", cycles=" + hasCycles() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        PathInstance that = (PathInstance) o;
        
        return length == that.length &&
               Double.compare(that.cost, cost) == 0 &&
               Objects.equals(nodeIds, that.nodeIds) &&
               Objects.equals(relationshipIds, that.relationshipIds);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(length, cost, nodeIds, relationshipIds);
    }
}