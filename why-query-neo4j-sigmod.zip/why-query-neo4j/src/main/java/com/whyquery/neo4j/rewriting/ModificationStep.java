package com.whyquery.neo4j.rewriting;

import java.util.List;

/**
 * Represents a single step in the query modification process
 */
public class ModificationStep {
    
    private final ModificationOperation operation;
    private final List<String> changes;
    private final long timestamp;
    
    public ModificationStep(ModificationOperation operation, List<String> changes) {
        this.operation = operation;
        this.changes = changes;
        this.timestamp = System.currentTimeMillis();
    }
    
    public ModificationOperation getOperation() { return operation; }
    public List<String> getChanges() { return changes; }
    public long getTimestamp() { return timestamp; }
    
    public String getDescription() {
        StringBuilder desc = new StringBuilder();
        desc.append(operation.getType());
        
        if (operation.getTargetId() != null) {
            desc.append(" on ").append(operation.getTargetId());
        }
        
        if (operation.getTargetLabel() != null) {
            desc.append(" (label: ").append(operation.getTargetLabel()).append(")");
        }
        
        if (operation.getTargetProperty() != null) {
            desc.append(" (property: ").append(operation.getTargetProperty()).append(")");
        }
        
        if (operation.getRange() != null && operation.getRange().length > 0) {
            desc.append(" (values: ");
            for (int i = 0; i < operation.getRange().length; i++) {
                if (i > 0) desc.append(", ");
                desc.append(operation.getRange()[i]);
            }
            desc.append(")");
        }
        
        return desc.toString();
    }
    
    @Override
    public String toString() {
        return String.format("ModificationStep{operation=%s, changes=%d, timestamp=%d}", 
                           operation.getType(), changes.size(), timestamp);
    }
}