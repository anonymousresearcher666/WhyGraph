package com.whyquery.neo4j.statistics;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.schema.SchemaGraph;
import com.whyquery.neo4j.util.DatabaseIdentityUtil;
import org.neo4j.graphdb.ExecutionPlanDescription;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Neo4j Statistics Integration following Definition 2 from the unified framework.
 * Leverages Neo4j's comprehensive statistics system to estimate modification costs
 * without expensive graph traversal.
 */
public class Neo4jStatistics {
    
    private final GraphDatabaseService db;
    private final StatisticsCache cache;
    private final DatabaseSchemaCache schemaCache;
    private final Set<String> statsWarningMessages = ConcurrentHashMap.newKeySet();
    private final Path statsSnapshotPath;
    private final boolean allowDataQueries;
    private final boolean strictPlanOnly;
    private StatisticsSnapshot persistedStats;
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    
    // Cache expiration times (in milliseconds)
    private static final long NODE_COUNT_CACHE_TTL = 3600000; // 1 hour
    private static final long SELECTIVITY_CACHE_TTL = 86400000; // 24 hours
    private static final long PLAN_CACHE_TTL = 1800000; // 30 minutes
    private static final long PATH_STATS_CACHE_TTL = 86400000; // 24 hours
    
    public Neo4jStatistics(GraphDatabaseService db) {
        this(db, resolveDefaultAllowDataQueries(), resolveStrictPlanOnly());
    }

    public Neo4jStatistics(GraphDatabaseService db, boolean allowDataQueries) {
        this(db, allowDataQueries, resolveStrictPlanOnly());
    }

    public Neo4jStatistics(GraphDatabaseService db, boolean allowDataQueries, boolean strictPlanOnly) {
        this.db = db;
        this.cache = new StatisticsCache();
        this.schemaCache = DatabaseSchemaCache.getShared(db);
        this.allowDataQueries = allowDataQueries;
        this.strictPlanOnly = strictPlanOnly;
        this.statsSnapshotPath = resolveStatsSnapshotPath();
        this.persistedStats = loadSnapshotFromDisk();
    }

    private static boolean resolveDefaultAllowDataQueries() {
        String prop = System.getProperty("why.allow_data_queries");
        if (prop == null || prop.isBlank()) {
            prop = System.getenv("WHY_ALLOW_DATA_QUERIES");
        }
        if (prop == null || prop.isBlank()) {
            return false;
        }
        return Boolean.parseBoolean(prop);
    }

    private static boolean resolveStrictPlanOnly() {
        String prop = System.getProperty("why.strict_plan_only");
        if (prop == null || prop.isBlank()) {
            prop = System.getenv("WHY_STRICT_PLAN_ONLY");
        }
        if (prop == null || prop.isBlank()) {
            return true;
        }
        return Boolean.parseBoolean(prop);
    }

    private void assertPlanOnlyQuery(String query) {
        if (!strictPlanOnly || query == null) {
            return;
        }
        String trimmed = query.stripLeading();
        if (!trimmed.regionMatches(true, 0, "EXPLAIN", 0, "EXPLAIN".length())) {
            throw new IllegalStateException("Strict plan-only mode forbids non-EXPLAIN query execution in statistics layer");
        }
    }

    private Result executeGuarded(Transaction tx, String query) {
        assertPlanOnlyQuery(query);
        return tx.execute(query);
    }

    private Result executeGuarded(Transaction tx, String query, Map<String, Object> params) {
        assertPlanOnlyQuery(query);
        return tx.execute(query, params);
    }

    public Path getSnapshotPath() {
        return statsSnapshotPath;
    }

    /**
     * Returns whether path statistics (S_path layers) are available in the current snapshot.
     */
    public boolean hasPathStatistics() {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        return !persistedStats.pathSafeUpperBounds.isEmpty() || !persistedStats.pathEstimates.isEmpty();
    }

    public int getPathSafeEntryCount() {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        return persistedStats.pathSafeUpperBounds.size();
    }

    public int getPathEstimateEntryCount() {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        return persistedStats.pathEstimates.size();
    }

    /**
     * Conservative S_path layer (safe upper bound) for bounded path atom [:R*min..max].
     * This does not execute data queries and is derived from schema triple max-out statistics.
     */
    public long getPathSafeUpperBound(String relationshipType, int minLen, int maxLen) {
        int min = Math.max(1, minLen);
        int max = Math.max(min, maxLen);
        String cacheKey = "path_safe_" + relationshipType + "_" + min + "_" + max;
        return cache.computeIfAbsent(cacheKey, PATH_STATS_CACHE_TTL, () -> {
            if (persistedStats == null) {
                persistedStats = new StatisticsSnapshot();
            }
            String key = pathKey(relationshipType, min, max);
            Long snap = persistedStats.pathSafeUpperBounds.get(key);
            if (snap != null && snap >= 0) {
                return snap;
            }
            long computed = computePathSafeUpperBound(relationshipType, min, max);
            persistedStats.pathSafeUpperBounds.put(key, computed);
            persistedStats.pathRefreshedAt = System.currentTimeMillis();
            saveSnapshotToDisk();
            return computed;
        });
    }

    /**
     * Estimate S_path layer for bounded path atom [:R*min..max] used for ranking.
     * Derived from schema triple average out-degree (non-sound, estimate only).
     */
    public double getPathEstimate(String relationshipType, int minLen, int maxLen) {
        int min = Math.max(1, minLen);
        int max = Math.max(min, maxLen);
        String cacheKey = "path_est_" + relationshipType + "_" + min + "_" + max;
        return cache.computeIfAbsent(cacheKey, PATH_STATS_CACHE_TTL, () -> {
            if (persistedStats == null) {
                persistedStats = new StatisticsSnapshot();
            }
            String key = pathKey(relationshipType, min, max);
            Double snap = persistedStats.pathEstimates.get(key);
            if (snap != null && !Double.isNaN(snap) && snap >= 0.0) {
                return snap;
            }
            double computed = computePathEstimate(relationshipType, min, max);
            persistedStats.pathEstimates.put(key, computed);
            persistedStats.pathRefreshedAt = System.currentTimeMillis();
            saveSnapshotToDisk();
            return computed;
        });
    }

    public synchronized void forceReloadSnapshot() {
        this.persistedStats = loadSnapshotFromDisk();
        clearCache();
    }
    
    /**
     * Get all labels in the database
     */
    public Set<String> getAllLabels() {
        return schemaCache.getAllLabels();
    }
    
    
    /**
     * Get node count for a specific label
     * NodeCount(l) = APOC meta.stats or db.stats.nodeCount(label=l)
     * Uses APOC and Neo4j's built-in statistics API - NO QUERY EXECUTION
     */
    public long getNodeCount(String label) {
        String cacheKey = "node_count_" + (label != null ? label : "ALL");
        
        return cache.computeIfAbsent(cacheKey, NODE_COUNT_CACHE_TTL, () -> {
            Long snapshotValue = getSnapshotNodeCount(label);
            if (snapshotValue != null) {
                return snapshotValue;
            }
            if (label != null) {
                long count = schemaCache.getLabelCount(label);
                if (count > 0) {
                    updateSnapshotNodeCount(label, count);
                    saveSnapshotToDisk();
                    return count;
                }

            } else {
                long total = schemaCache.getLabelCountsSnapshot()
                    .values()
                    .stream()
                    .mapToLong(Long::longValue)
                    .sum();
                updateSnapshotNodeCount(null, total);
                saveSnapshotToDisk();
                return total;
            }
            return 0L;
        });
    }
    
    /**
     * Get property selectivity for a label-property combination
     * PropertySelectivity(l, p) = APOC meta.schema + db.stats.uniqueValueSelectivity(label=l, property=p)
     * Uses APOC and Neo4j's built-in statistics API - NO QUERY EXECUTION
     */
    public double getPropertySelectivity(String label, String property) {
        String cacheKey = "selectivity_" + label + "_" + property;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            Double snapshotValue = getSnapshotPropertySelectivity(label, property);
            if (snapshotValue != null) {
                return snapshotValue;
            }
            double selectivity = schemaCache.getPropertySelectivity(label, property);
            if (selectivity > 0) {
                updateSnapshotPropertySelectivity(label, property, selectivity);
                saveSnapshotToDisk();
                return selectivity;
            }
            double calculated = calculateSelectivityFromSchema(label, property);
            if (!Double.isNaN(calculated) && calculated >= 0.0) {
                updateSnapshotPropertySelectivity(label, property, calculated);
                saveSnapshotToDisk();
            }
            return calculated;
        });
    }
    
    private double calculateSelectivityFromSchema(String label, String property) {
        if (!allowDataQueries) {
            return Double.NaN;
        }
        // Calculate actual selectivity from database schema and data
        try (Transaction tx = db.beginTx()) {
            // Get distinct value count and total count for this property
            String distinctQuery = "MATCH (n:" + label + ") WHERE n." + property + " IS NOT NULL " +
                                 "RETURN count(DISTINCT n." + property + ") as distinctCount, count(n) as totalCount";
            
            Result result = executeGuarded(tx, distinctQuery);
            if (result.hasNext()) {
                Map<String, Object> row = result.next();
                Number distinctCount = (Number) row.get("distinctCount");
                Number totalCount = (Number) row.get("totalCount");
                
                if (totalCount != null && totalCount.longValue() > 0) {
                    double selectivity = distinctCount.doubleValue() / totalCount.doubleValue();
                    System.out.println("STATS: Calculated selectivity for " + label + "." + property + 
                        ": " + selectivity + " (" + distinctCount + "/" + totalCount + ")");
                    return selectivity;
                }
            }
            
            System.out.println("STATS: No data found for " + label + "." + property + ", selectivity unavailable");
            return Double.NaN;
            
        } catch (Exception e) {
            System.err.println("ERROR: Failed to calculate selectivity from schema for " + label + "." + property + ": " + e.getMessage());
            return Double.NaN;
        }
    }
    
    /**
     * Check if an index exists for a label-property combination
     * IndexExists(l, p) = db.stats.indexExists(label=l, property=p)
     */
    public boolean indexExists(String label, String property) {
        String cacheKey = "index_" + label + "_" + property;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            try (Transaction tx = db.beginTx()) {
                String query = "SHOW INDEXES YIELD labelsOrTypes, properties " +
                              "WHERE $label IN labelsOrTypes AND $property IN properties " +
                              "RETURN count(*) > 0 as exists";
                              
                Result result = executeGuarded(tx, query, Map.of("label", label, "property", property));
                if (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    return (Boolean) row.get("exists");
                }
                return false;
            } catch (Exception e) {
                // Fallback for older Neo4j versions
                return checkIndexExistsFallback(label, property);
            }
        });
    }
    
    /**
     * Get relationship count for a specific type
     * RelCount(t) = APOC meta.stats + db.stats.relationshipCount(type=t)
     * Uses APOC and Neo4j's built-in statistics API - NO QUERY EXECUTION
     */
    public long getRelationshipCount(String type) {
        String cacheKey = "rel_count_" + (type != null ? type : "ALL");
        
        return cache.computeIfAbsent(cacheKey, NODE_COUNT_CACHE_TTL, () -> {
            Long snapshotValue = getSnapshotRelationshipCount(type);
            if (snapshotValue != null) {
                return snapshotValue;
            }
            long count = schemaCache.getRelationshipCount(type);
            updateSnapshotRelationshipCount(type, count);
            saveSnapshotToDisk();
            return count;
        });
    }
    
    /**
     * Get average degree for nodes with specific label and relationship type
     * AvgDegree(l, t) = db.stats.averageDegree(label=l, type=t)
     */
    public double getAverageDegree(String label, String relationshipType) {
        String cacheKey = "avg_degree_" + label + "_" + relationshipType;
        
        return cache.computeIfAbsent(cacheKey, NODE_COUNT_CACHE_TTL, () -> {
            if (!allowDataQueries) {
                return Double.NaN;
            }
            try (Transaction tx = db.beginTx()) {
                String query = String.format(
                    "MATCH (n:%s)-[r:%s]-() " +
                    "WITH n, count(r) as degree " +
                    "RETURN avg(degree) as avg_degree",
                    label, relationshipType
                );
                
                Result result = executeGuarded(tx, query);
                if (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    Object avgDegree = row.get("avg_degree");
                    return avgDegree != null ? ((Number) avgDegree).doubleValue() : Double.NaN;
                }
                return Double.NaN;
            } catch (Exception e) {
                System.err.println("ERROR: Failed to compute average degree for " + label + "-" + relationshipType + ": " + e.getMessage());
                return Double.NaN;
            }
        });
    }
    
    /**
     * Get relationship property selectivity
     * RelSelectivity(t, p) = db.stats.relationshipPropertySelectivity(type=t, property=p)
     */
    public double getRelationshipPropertySelectivity(String type, String property) {
        String cacheKey = "rel_selectivity_" + type + "_" + property;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            if (!allowDataQueries) {
                return Double.NaN;
            }
            try (Transaction tx = db.beginTx()) {
                String query = String.format(
                    "MATCH ()-[r:%s]-() WHERE r.%s IS NOT NULL " +
                    "WITH count(DISTINCT r.%s) as distinct_values, count(r) as total_rels " +
                    "RETURN CASE WHEN total_rels > 0 THEN distinct_values * 1.0 / total_rels ELSE 0.0 END as selectivity",
                    type, property, property
                );
                
                Result result = executeGuarded(tx, query);
                if (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    return ((Number) row.get("selectivity")).doubleValue();
                }
                return Double.NaN;
            } catch (Exception e) {
                System.err.println("ERROR: Failed to compute relationship property selectivity for " + type + "." + property + ": " + e.getMessage());
                return Double.NaN;
            }
        });
    }
    
    /**
     * Get query plan statistics using EXPLAIN
     * EstimatedRows(Q) = EXPLAIN root estimated rows.
     * EstCost(Q) = sum of per-operator estimated rows, with pessimistic
     * ancestor-row imputation when Neo4j omits an operator estimate.
     * PlannerTime(Q) = EXPLAIN Q.time
     */
    public QueryPlanStatistics getQueryPlanStatistics(String cypherQuery) {
        String cacheKey = "plan_" + cypherQuery.hashCode();
        
        return cache.computeIfAbsent(cacheKey, PLAN_CACHE_TTL, () -> {
            try (Transaction tx = db.beginTx()) {
                String explainQuery = "EXPLAIN " + cypherQuery;
                Result result = executeGuarded(tx, explainQuery);
                
                ExecutionPlanDescription plan = result.getExecutionPlanDescription();
                return extractPlanStatistics(plan);
                
            } catch (Exception e) {
                // Keep callers in estimate-only mode; surface the diagnostic.
                return QueryPlanStatistics.unavailable(e.getMessage());
            }
        });
    }
    
    /**
     * Calculate syntactic distance using Neo4j planner cost estimates
     * d_syn(Q, Q') = Σ w_op * |{op applied}| * PlannerCost(op)
     */
    public double calculateSyntacticDistance(String originalQuery, String modifiedQuery) {
        QueryPlanStatistics originalStats = getQueryPlanStatistics(originalQuery);
        QueryPlanStatistics modifiedStats = getQueryPlanStatistics(modifiedQuery);
        
        // Simple distance metric based on plan cost differences
        double costDifference = Math.abs(modifiedStats.getEstCost() - originalStats.getEstCost());
        double rowsDifference = Math.abs(modifiedStats.getEstimatedRows() - originalStats.getEstimatedRows());
        
        return costDifference + (rowsDifference * 0.1);
    }
    
    /**
     * Calculate semantic distance using Neo4j statistics
     * d_sem(Q, Q') = Σ Δ^stats functions for nodes, relationships, and predicates
     */
    public double calculateSemanticDistance(String originalQuery, String modifiedQuery, 
                                          List<String> modifiedLabels, List<String> modifiedRelTypes) {
        double distance = 0.0;
        
        // Node label modifications
        for (String label : modifiedLabels) {
            long totalNodes = getNodeCount(null);
            long labelNodes = getNodeCount(label);
            if (labelNodes > 0 && totalNodes > 0) {
                distance += Math.log((double) totalNodes / labelNodes);
            }
        }
        
        // Relationship type modifications
        for (String relType : modifiedRelTypes) {
            long totalRels = getRelationshipCount(null);
            long typeRels = getRelationshipCount(relType);
            if (typeRels > 0 && totalRels > 0) {
                distance += Math.log((double) totalRels / typeRels);
            }
        }
        
        return distance;
    }
    
    /**
     * Calculate cardinality impact using query planner estimates
     * Impact(O) = EstimatedRows(Q') / EstimatedRows(Q)
     */
    public double calculateCardinalityImpact(String originalQuery, String modifiedQuery) {
        QueryPlanStatistics originalStats = getQueryPlanStatistics(originalQuery);
        QueryPlanStatistics modifiedStats = getQueryPlanStatistics(modifiedQuery);
        
        if (originalStats.getEstimatedRows() == 0) {
            return modifiedStats.getEstimatedRows() > 0 ? Double.POSITIVE_INFINITY : 1.0;
        }
        
        return (double) modifiedStats.getEstimatedRows() / originalStats.getEstimatedRows();
    }
    
    /**
     * Load comprehensive Neo4j statistics into cache using APOC
     */
    public void loadStatistics() {
        try (Transaction tx = db.beginTx()) {
            // Use APOC meta.stats to load all statistics at once
            String apocStatsQuery = "CALL apoc.meta.stats() YIELD labels, relTypes, nodeCount, relCount";
            Result apocResult = executeGuarded(tx, apocStatsQuery);
            
            if (apocResult.hasNext()) {
                Map<String, Object> statsRow = apocResult.next();
                
                // Cache node counts from APOC stats
                @SuppressWarnings("unchecked")
                Map<String, Object> labels = (Map<String, Object>) statsRow.get("labels");
                if (labels != null) {
                    for (Map.Entry<String, Object> entry : labels.entrySet()) {
                        String label = entry.getKey();
                        Long count = ((Number) entry.getValue()).longValue();
                        String cacheKey = "node_count_" + label;
                        cache.putDirect(cacheKey, count, System.currentTimeMillis() + NODE_COUNT_CACHE_TTL);
                        System.out.println("APOC STATS: Cached node count for " + label + ": " + count);
                        updateSnapshotNodeCount(label, count);
                    }
                }
                
                // Cache relationship counts from APOC stats
                @SuppressWarnings("unchecked")
                Map<String, Object> relTypes = (Map<String, Object>) statsRow.get("relTypes");
                if (relTypes != null) {
                    for (Map.Entry<String, Object> entry : relTypes.entrySet()) {
                        String type = entry.getKey();
                        Long count = ((Number) entry.getValue()).longValue();
                        String cacheKey = "rel_count_" + type;
                        cache.putDirect(cacheKey, count, System.currentTimeMillis() + NODE_COUNT_CACHE_TTL);
                        System.out.println("APOC STATS: Cached relationship count for " + type + ": " + count);
                        updateSnapshotRelationshipCount(type, count);
                    }
                }
                
                // Cache total counts
                Object totalNodes = statsRow.get("nodeCount");
                if (totalNodes instanceof Number) {
                    String cacheKey = "node_count_ALL";
                    Long count = ((Number) totalNodes).longValue();
                    cache.cache.put(cacheKey, new StatisticsCache.CacheEntry<>(count, System.currentTimeMillis() + NODE_COUNT_CACHE_TTL));
                    System.out.println("APOC STATS: Cached total node count: " + count);
                    updateSnapshotNodeCount(null, count);
                }
                
                Object totalRels = statsRow.get("relCount");
                if (totalRels instanceof Number) {
                    String cacheKey = "rel_count_ALL";
                    Long count = ((Number) totalRels).longValue();
                    cache.cache.put(cacheKey, new StatisticsCache.CacheEntry<>(count, System.currentTimeMillis() + NODE_COUNT_CACHE_TTL));
                    System.out.println("APOC STATS: Cached total relationship count: " + count);
                    updateSnapshotRelationshipCount(null, count);
                }
            }
            
            // Load additional schema statistics using APOC meta.schema
            loadApocSchemaStatistics(tx);
            
            // Fallback: Load using standard Neo4j procedures if APOC fails
            loadStandardStatistics(tx);
            
        } catch (Exception e) {
            System.err.println("Failed to load APOC statistics, falling back to standard procedures: " + e.getMessage());
            // Fallback to standard Neo4j procedures
            loadStandardStatistics(null);
        }
        saveSnapshotToDisk();
    }
    
    private void loadApocSchemaStatistics(Transaction tx) {
        try {
            // Use APOC meta.schema for detailed property statistics
            String schemaQuery = "CALL apoc.meta.schema() YIELD value";
            Result schemaResult = executeGuarded(tx, schemaQuery);
            
            if (schemaResult.hasNext()) {
                Map<String, Object> schemaRow = schemaResult.next();
                @SuppressWarnings("unchecked")
                Map<String, Object> schema = (Map<String, Object>) schemaRow.get("value");
                
                if (schema != null) {
                    for (Map.Entry<String, Object> labelEntry : schema.entrySet()) {
                        String label = labelEntry.getKey();
                        @SuppressWarnings("unchecked")
                        Map<String, Object> labelInfo = (Map<String, Object>) labelEntry.getValue();
                        
                        if (labelInfo != null && labelInfo.containsKey("properties")) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> properties = (Map<String, Object>) labelInfo.get("properties");
                            
                            for (String property : properties.keySet()) {
                                // Pre-load property selectivity
                                getPropertySelectivity(label, property);
                                indexExists(label, property);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to load APOC schema statistics: " + e.getMessage());
        }
    }
    
    private void loadStandardStatistics(Transaction tx) {
        try {
            if (tx == null) {
                tx = db.beginTx();
            }
            
            // Load node labels
            Result labelResult = executeGuarded(tx, "CALL db.labels()");
            while (labelResult.hasNext()) {
                Map<String, Object> row = labelResult.next();
                String label = (String) row.get("label");
                getNodeCount(label); // This will cache the count
            }
            
            // Load relationship types
            Result typeResult = executeGuarded(tx, "CALL db.relationshipTypes()");
            while (typeResult.hasNext()) {
                Map<String, Object> row = typeResult.next();
                String type = (String) row.get("relationshipType");
                getRelationshipCount(type); // This will cache the count
            }
            
            // Load property keys and calculate selectivities
            loadPropertyStatistics(tx);
            
        } catch (Exception e) {
            System.err.println("Failed to load standard statistics: " + e.getMessage());
        }
    }
    
    private void loadPropertyStatistics(Transaction tx) {
        try {
            // Get all property keys
            Result propResult = executeGuarded(tx, "CALL db.propertyKeys()");
            Set<String> properties = new HashSet<>();
            while (propResult.hasNext()) {
                Map<String, Object> row = propResult.next();
                properties.add((String) row.get("propertyKey"));
            }
            
            // Get all labels
            Result labelResult = executeGuarded(tx, "CALL db.labels()");
            while (labelResult.hasNext()) {
                Map<String, Object> row = labelResult.next();
                String label = (String) row.get("label");
                
                // Calculate selectivity for each property on this label
                for (String property : properties) {
                    getPropertySelectivity(label, property);
                    indexExists(label, property);
                }
            }
        } catch (Exception e) {
            // Fallback - properties will be loaded on demand
        }
    }
    
    private boolean checkIndexExistsFallback(String label, String property) {
        try (Transaction tx = db.beginTx()) {
            // Try to execute a query that would use the index
            String query = String.format("MATCH (n:%s) WHERE n.%s = $value RETURN count(n)", label, property);
            Result result = executeGuarded(tx, "EXPLAIN " + query, Map.of("value", "dummy"));
            
            ExecutionPlanDescription plan = result.getExecutionPlanDescription();
            return containsIndexOperation(plan);
        } catch (Exception e) {
            return false;
        }
    }
    
    private boolean containsIndexOperation(ExecutionPlanDescription plan) {
        String operatorType = plan.getName().toLowerCase();
        if (operatorType.contains("index") || operatorType.contains("seek")) {
            return true;
        }
        
        for (ExecutionPlanDescription child : plan.getChildren()) {
            if (containsIndexOperation(child)) {
                return true;
            }
        }
        
        return false;
    }
    
    private QueryPlanStatistics extractPlanStatistics(ExecutionPlanDescription plan) {
        long estimatedRows = extractEstimatedRows(plan);
        long dbHits = extractDbHits(plan);
        long estCost = extractEstimatedCost(plan, -1L);
        long plannerTime = 0L; // Neo4j doesn't expose planner time directly

        PlanFeatures features = analyzePlanFeatures(plan, -1L);
        return new QueryPlanStatistics(
            estimatedRows,
            dbHits,
            plannerTime,
            estCost,
            true,
            null,
            plan.getName(),
            safeString(plan.getArguments().get("Details")),
            features.hasIndexAccess,
            features.hasFullScan,
            features.bottleneckOperator,
            features.bottleneckDetails,
            features.bottleneckEstimatedRows,
            features.bottleneckCollapseRatio,
            features.anchorVariable,
            features.anchorProperty,
            features.anchorRelationshipType
        );
    }

    private static final class PlanFeatures {
        private boolean hasIndexAccess;
        private boolean hasFullScan;
        private String bottleneckOperator;
        private String bottleneckDetails;
        private long bottleneckEstimatedRows = Long.MAX_VALUE;
        private double bottleneckCollapseRatio = 1.0;
        private String anchorVariable;
        private String anchorProperty;
        private String anchorRelationshipType;
    }

    private PlanFeatures analyzePlanFeatures(ExecutionPlanDescription plan, long parentRows) {
        PlanFeatures features = new PlanFeatures();
        if (plan == null) {
            features.bottleneckEstimatedRows = -1L;
            return features;
        }

        String operator = plan.getName();
        String details = safeString(plan.getArguments().get("Details"));
        long rows = extractLocalEstimatedRows(plan);
        String lowered = operator != null ? operator.toLowerCase(Locale.ROOT) : "";
        if (lowered.contains("index") || lowered.contains("seek")) {
            features.hasIndexAccess = true;
        }
        if (lowered.contains("allnodesscan") || lowered.contains("nodebylabelscan") || lowered.contains("scan")) {
            features.hasFullScan = true;
        }

        if (rows >= 0) {
            double collapseRatio = parentRows > 0 ? ((double) rows) / Math.max(1.0, (double) parentRows) : 1.0;
            boolean betterBottleneck = rows < features.bottleneckEstimatedRows
                || (rows == features.bottleneckEstimatedRows && collapseRatio < features.bottleneckCollapseRatio);
            if (betterBottleneck) {
                features.bottleneckEstimatedRows = rows;
                features.bottleneckCollapseRatio = collapseRatio;
                features.bottleneckOperator = operator;
                features.bottleneckDetails = details;
                String[] anchor = inferAnchorFromDetails(details);
                features.anchorVariable = anchor[0];
                features.anchorProperty = anchor[1];
                features.anchorRelationshipType = anchor[2];
            }
        }

        for (ExecutionPlanDescription child : plan.getChildren()) {
            PlanFeatures childFeatures = analyzePlanFeatures(child, rows >= 0 ? rows : parentRows);
            features.hasIndexAccess |= childFeatures.hasIndexAccess;
            features.hasFullScan |= childFeatures.hasFullScan;
            boolean betterChild = childFeatures.bottleneckEstimatedRows >= 0
                && (features.bottleneckEstimatedRows == Long.MAX_VALUE
                    || childFeatures.bottleneckEstimatedRows < features.bottleneckEstimatedRows
                    || (childFeatures.bottleneckEstimatedRows == features.bottleneckEstimatedRows
                        && childFeatures.bottleneckCollapseRatio < features.bottleneckCollapseRatio));
            if (betterChild) {
                features.bottleneckEstimatedRows = childFeatures.bottleneckEstimatedRows;
                features.bottleneckCollapseRatio = childFeatures.bottleneckCollapseRatio;
                features.bottleneckOperator = childFeatures.bottleneckOperator;
                features.bottleneckDetails = childFeatures.bottleneckDetails;
                features.anchorVariable = childFeatures.anchorVariable;
                features.anchorProperty = childFeatures.anchorProperty;
                features.anchorRelationshipType = childFeatures.anchorRelationshipType;
            }
        }

        if (features.bottleneckEstimatedRows == Long.MAX_VALUE) {
            features.bottleneckEstimatedRows = -1L;
        }
        return features;
    }

    private long extractLocalEstimatedRows(ExecutionPlanDescription plan) {
        Object rows = plan.getArguments().get("EstimatedRows");
        if (rows instanceof Number) {
            return ((Number) rows).longValue();
        }
        return -1L;
    }

    private String safeString(Object value) {
        return value != null ? String.valueOf(value) : null;
    }

    private String[] inferAnchorFromDetails(String details) {
        String[] anchor = new String[]{null, null, null};
        if (details == null || details.isBlank()) {
            return anchor;
        }
        java.util.regex.Matcher propertyMatcher =
            java.util.regex.Pattern.compile("([A-Za-z_][A-Za-z0-9_]*)\\.([A-Za-z_][A-Za-z0-9_]*)")
                .matcher(details);
        if (propertyMatcher.find()) {
            anchor[0] = propertyMatcher.group(1);
            anchor[1] = propertyMatcher.group(2);
        }
        java.util.regex.Matcher relMatcher =
            java.util.regex.Pattern.compile(":([A-Za-z_][A-Za-z0-9_]*)").matcher(details);
        if (relMatcher.find()) {
            anchor[2] = relMatcher.group(1);
        }
        return anchor;
    }
    
    private long extractEstimatedRows(ExecutionPlanDescription plan) {
        Object rows = plan.getArguments().get("EstimatedRows");
        if (rows instanceof Number) {
            return ((Number) rows).longValue();
        }
        
        // Recursively check children
        long totalRows = 0L;
        for (ExecutionPlanDescription child : plan.getChildren()) {
            totalRows += extractEstimatedRows(child);
        }
        
        return Math.max(totalRows, 1L);
    }

    private long extractEstimatedCost(ExecutionPlanDescription plan, long ancestorRows) {
        if (plan == null) {
            return Math.max(ancestorRows, 0L);
        }
        long localRows = extractLocalEstimatedRows(plan);
        long imputedRows = localRows >= 0 ? localRows : Math.max(ancestorRows, 0L);
        long total = Math.max(imputedRows, 0L);
        long childAncestor = Math.max(imputedRows, ancestorRows);
        for (ExecutionPlanDescription child : plan.getChildren()) {
            total = saturatedAdd(total, extractEstimatedCost(child, childAncestor));
        }
        return Math.max(total, 1L);
    }

    private long saturatedAdd(long a, long b) {
        if (a > Long.MAX_VALUE - b) {
            return Long.MAX_VALUE;
        }
        return a + b;
    }
    
    private long extractDbHits(ExecutionPlanDescription plan) {
        Object hits = plan.getArguments().get("DbHits");
        if (hits instanceof Number) {
            return ((Number) hits).longValue();
        }
        
        // Recursively sum children
        long totalHits = 0L;
        for (ExecutionPlanDescription child : plan.getChildren()) {
            totalHits += extractDbHits(child);
        }
        
        return totalHits;
    }
    
    /**
     * Clear the statistics cache
     */
    public void clearCache() {
        cache.clear();
    }
    
    /**
     * Get cache statistics
     */
    public CacheStatistics getCacheStatistics() {
        return cache.getStatistics();
    }

    /**
     * Build a schema-indexed statistics snapshot aligned with the formal tuple:
     * (S_card, S_sel, S_dist, S_null, S_idx, S_edge, S_plan).
     * This is metadata-only and does not execute candidate rewrites.
     */
    public Map<String, Object> buildSchemaIndexedSnapshot() {
        Map<String, Object> out = new LinkedHashMap<>();

        Map<String, Object> sCard = new LinkedHashMap<>();
        for (Map.Entry<String, Long> e : schemaCache.getLabelCountsSnapshot().entrySet()) {
            sCard.put(e.getKey(), e.getValue());
        }
        out.put("S_card", sCard);

        Map<String, Object> sSel = new LinkedHashMap<>();
        Map<String, Object> sDist = new LinkedHashMap<>();
        Map<String, Object> sNull = new LinkedHashMap<>();
        Map<String, Object> sIdx = new LinkedHashMap<>();

        for (String label : schemaCache.getAllLabels()) {
            for (String property : schemaCache.getPropertiesForLabel(label)) {
                String key = label + "." + property;
                DatabaseSchemaCache.PropertyInfo info = schemaCache.getPropertyInfo(label, property);
                if (info == null) {
                    continue;
                }
                double nullFrac = info.getTotalCount() > 0
                    ? Math.min(1.0, Math.max(0.0, (double) info.getNullCount() / (double) info.getTotalCount()))
                    : 0.0;
                sNull.put(key, nullFrac);

                Map<String, Object> dist = new LinkedHashMap<>();
                dist.put("type", info.getType());
                dist.put("min", info.getMinValue());
                dist.put("max", info.getMaxValue());
                dist.put("common_values", info.getCommonValues());
                sDist.put(key, dist);

                Map<String, Object> sel = new LinkedHashMap<>();
                sel.put("eq_generic", clamp01(info.getSelectivity()));
                sel.put("is_not_null", clamp01(1.0 - nullFrac));
                sel.put("gt_midpoint", getPredicateSelectivity(label, property, ">", estimateMidpoint(info)));
                sel.put("lt_midpoint", getPredicateSelectivity(label, property, "<", estimateMidpoint(info)));
                sSel.put(key, sel);

                // In strict plan-only mode index catalog calls are intentionally avoided.
                if (strictPlanOnly) {
                    sIdx.put(key, null);
                } else {
                    sIdx.put(key, indexExists(label, property) ? 1 : 0);
                }
            }
        }
        out.put("S_sel", sSel);
        out.put("S_dist", sDist);
        out.put("S_null", sNull);
        out.put("S_idx", sIdx);

        Map<String, Object> sEdge = new LinkedHashMap<>();
        schemaCache.getSchemaTripleStats().forEach((triple, stats) -> {
            String k = "(" + triple.getSourceLabel() + ")-[:" + triple.getRelationshipType() + "]->(" + triple.getTargetLabel() + ")";
            Map<String, Object> v = new LinkedHashMap<>();
            v.put("N_t", stats.getEdgeCount());
            v.put("d_avg_out", stats.getAvgOutDegree());
            v.put("d_max_out", stats.getMaxOutDegree());
            v.put("d_avg_in", stats.getAvgInDegree());
            v.put("d_max_in", stats.getMaxInDegree());
            sEdge.put(k, v);
        });
        out.put("S_edge", sEdge);

        Map<String, Object> sPlan = new LinkedHashMap<>();
        CacheStatistics cacheStats = getCacheStatistics();
        sPlan.put("plan_cache_entries", cache.cache.entrySet().stream()
            .filter(e -> e.getKey() != null && e.getKey().startsWith("plan_"))
            .count());
        sPlan.put("cache_hit_rate", cacheStats.getHitRate());
        out.put("S_plan", sPlan);

        return out;
    }

    /**
     * Approximate predicate selectivity S_sel(label, property, predicate) in [0,1].
     */
    public double getPredicateSelectivity(String label, String property, String operator, Object value) {
        DatabaseSchemaCache.PropertyInfo info = schemaCache.getPropertyInfo(label, property);
        if (info == null || operator == null) {
            return Double.NaN;
        }
        String op = operator.trim().toUpperCase(Locale.ROOT);
        double eq = clamp01(info.getSelectivity());
        double nullFrac = info.getTotalCount() > 0
            ? Math.min(1.0, Math.max(0.0, (double) info.getNullCount() / (double) info.getTotalCount()))
            : 0.0;
        double nonNull = clamp01(1.0 - nullFrac);

        switch (op) {
            case "=":
            case "EQ":
                return eq;
            case "IS NOT NULL":
            case "NOT_NULL":
                return nonNull;
            case "IN":
                if (value instanceof Collection<?>) {
                    int n = ((Collection<?>) value).size();
                    return clamp01(nonNull * Math.min(1.0, n * eq));
                }
                return clamp01(nonNull * eq);
            case ">":
            case ">=":
            case "<":
            case "<=":
                // Range predicates use available min/max when numeric; fallback to 0.5*nonNull.
                Double v = asDouble(value);
                Double min = asDouble(info.getMinValue());
                Double max = asDouble(info.getMaxValue());
                if (v == null || min == null || max == null || max <= min) {
                    return clamp01(nonNull * 0.5);
                }
                double p = (v - min) / (max - min);
                p = clamp01(p);
                if (op.startsWith(">")) {
                    return clamp01(nonNull * (1.0 - p));
                }
                return clamp01(nonNull * p);
            default:
                return Double.NaN;
        }
    }

    private static Double asDouble(Object value) {
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        if (value instanceof String) {
            try {
                return Double.parseDouble(((String) value).trim());
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        return null;
    }

    private static Object estimateMidpoint(DatabaseSchemaCache.PropertyInfo info) {
        Double min = asDouble(info.getMinValue());
        Double max = asDouble(info.getMaxValue());
        if (min == null || max == null) {
            return null;
        }
        return (min + max) / 2.0;
    }

    private static double clamp01(double v) {
        if (Double.isNaN(v)) {
            return Double.NaN;
        }
        if (v < 0.0) return 0.0;
        if (v > 1.0) return 1.0;
        return v;
    }
    
    /**
     * Query plan statistics container
     */
    public static class QueryPlanStatistics {
        private final long estimatedRows;
        private final long dbHits;
        private final long plannerTime;
        private final long estCost;
        private final boolean planAvailable;
        private final String plannerDiagnostic;
        private final String rootOperator;
        private final String rootDetails;
        private final boolean hasIndexAccess;
        private final boolean hasFullScan;
        private final String bottleneckOperator;
        private final String bottleneckDetails;
        private final long bottleneckEstimatedRows;
        private final double bottleneckCollapseRatio;
        private final String anchorVariable;
        private final String anchorProperty;
        private final String anchorRelationshipType;
        
        public QueryPlanStatistics(long estimatedRows, long dbHits, long plannerTime) {
            this(estimatedRows, dbHits, plannerTime, Math.max(estimatedRows, 0L), estimatedRows >= 0, null,
                 null, null, false, false, null, null, -1L, 1.0, null, null, null);
        }

        public QueryPlanStatistics(long estimatedRows, long dbHits, long plannerTime,
                                   String rootOperator, String rootDetails,
                                   boolean hasIndexAccess, boolean hasFullScan,
                                   String bottleneckOperator, String bottleneckDetails,
                                   long bottleneckEstimatedRows, double bottleneckCollapseRatio,
                                   String anchorVariable, String anchorProperty,
                                   String anchorRelationshipType) {
            this(estimatedRows, dbHits, plannerTime, Math.max(estimatedRows, 0L), estimatedRows >= 0, null,
                 rootOperator, rootDetails, hasIndexAccess, hasFullScan, bottleneckOperator, bottleneckDetails,
                 bottleneckEstimatedRows, bottleneckCollapseRatio, anchorVariable, anchorProperty, anchorRelationshipType);
        }

        public QueryPlanStatistics(long estimatedRows, long dbHits, long plannerTime,
                                   long estCost, boolean planAvailable, String plannerDiagnostic,
                                   String rootOperator, String rootDetails,
                                   boolean hasIndexAccess, boolean hasFullScan,
                                   String bottleneckOperator, String bottleneckDetails,
                                   long bottleneckEstimatedRows, double bottleneckCollapseRatio,
                                   String anchorVariable, String anchorProperty,
                                   String anchorRelationshipType) {
            this.estimatedRows = estimatedRows;
            this.dbHits = dbHits;
            this.plannerTime = plannerTime;
            this.estCost = estCost;
            this.planAvailable = planAvailable;
            this.plannerDiagnostic = plannerDiagnostic;
            this.rootOperator = rootOperator;
            this.rootDetails = rootDetails;
            this.hasIndexAccess = hasIndexAccess;
            this.hasFullScan = hasFullScan;
            this.bottleneckOperator = bottleneckOperator;
            this.bottleneckDetails = bottleneckDetails;
            this.bottleneckEstimatedRows = bottleneckEstimatedRows;
            this.bottleneckCollapseRatio = bottleneckCollapseRatio;
            this.anchorVariable = anchorVariable;
            this.anchorProperty = anchorProperty;
            this.anchorRelationshipType = anchorRelationshipType;
        }

        public static QueryPlanStatistics unavailable(String diagnostic) {
            return new QueryPlanStatistics(
                -1L, 0L, 0L, 0L, false, diagnostic,
                null, null, false, false, null, null, -1L, 1.0, null, null, null
            );
        }
        
        public long getEstimatedRows() { return estimatedRows; }
        public long getDbHits() { return dbHits; }
        public long getPlannerTime() { return plannerTime; }
        public long getEstCost() { return estCost; }
        public boolean isPlanAvailable() { return planAvailable; }
        public String getPlannerDiagnostic() { return plannerDiagnostic; }
        public String getRootOperator() { return rootOperator; }
        public String getRootDetails() { return rootDetails; }
        public boolean hasIndexAccess() { return hasIndexAccess; }
        public boolean hasFullScan() { return hasFullScan; }
        public String getBottleneckOperator() { return bottleneckOperator; }
        public String getBottleneckDetails() { return bottleneckDetails; }
        public long getBottleneckEstimatedRows() { return bottleneckEstimatedRows; }
        public double getBottleneckCollapseRatio() { return bottleneckCollapseRatio; }
        public String getAnchorVariable() { return anchorVariable; }
        public String getAnchorProperty() { return anchorProperty; }
        public String getAnchorRelationshipType() { return anchorRelationshipType; }
    }
    
    /**
     * Multi-level statistics cache implementation
     */
    private static class StatisticsCache {
        private final Map<String, CacheEntry<?>> cache = new ConcurrentHashMap<>();
        
        @SuppressWarnings("unchecked")
        public <T> T computeIfAbsent(String key, long ttl, java.util.function.Supplier<T> supplier) {
            CacheEntry<T> entry = (CacheEntry<T>) cache.get(key);
            
            if (entry != null && !entry.isExpired()) {
                return entry.getValue();
            }
            
            T value = supplier.get();
            cache.put(key, new CacheEntry<>(value, System.currentTimeMillis() + ttl));
            return value;
        }
        
        public <T> void putDirect(String key, T value, long expirationTime) {
            cache.put(key, new CacheEntry<>(value, expirationTime));
        }
        
        public void clear() {
            cache.clear();
        }
        
        public CacheStatistics getStatistics() {
            long totalEntries = cache.size();
            long expiredEntries = cache.values().stream()
                .mapToLong(entry -> entry.isExpired() ? 1 : 0)
                .sum();
            
            return new CacheStatistics(totalEntries, totalEntries - expiredEntries, expiredEntries);
        }
        
        private static class CacheEntry<T> {
            private final T value;
            private final long expirationTime;
            
            public CacheEntry(T value, long expirationTime) {
                this.value = value;
                this.expirationTime = expirationTime;
            }
            
            public T getValue() { return value; }
            public boolean isExpired() { return System.currentTimeMillis() > expirationTime; }
        }
    }
    
    /**
     * Cache statistics container
     */
    public static class CacheStatistics {
        private final long totalEntries;
        private final long validEntries;
        private final long expiredEntries;
        
        public CacheStatistics(long totalEntries, long validEntries, long expiredEntries) {
            this.totalEntries = totalEntries;
            this.validEntries = validEntries;
            this.expiredEntries = expiredEntries;
        }
        
        public long getTotalEntries() { return totalEntries; }
        public long getValidEntries() { return validEntries; }
        public long getExpiredEntries() { return expiredEntries; }
        public double getHitRate() { 
            return totalEntries > 0 ? (double) validEntries / totalEntries : 0.0; 
        }
    }
    
    /**
     * Get all property selectivities for a label
     * Uses Neo4j's schema API to get properties - NO QUERY EXECUTION
     */
    public Map<String, Double> getAllPropertySelectivities(String label) {
        String cacheKey = "all_selectivities_" + label;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            Map<String, Double> selectivities = new HashMap<>();
            
            try (Transaction tx = db.beginTx()) {
                // Use Neo4j's schema API to get all property keys that exist for this label
                // This would ideally use: tx.schema().getPropertyKeysForLabel(label)
                
                // For now, get property keys from indexes and constraints (actual schema data)
                tx.schema().getIndexes().forEach(indexDefinition -> {
                    if (indexDefinition.getLabels().iterator().hasNext()) {
                        String indexLabel = indexDefinition.getLabels().iterator().next().name();
                        if (label.equals(indexLabel)) {
                            indexDefinition.getPropertyKeys().forEach(propertyKey -> {
                                String property = propertyKey; // propertyKey is already a String in Neo4j 5.x
                                double selectivity = getPropertySelectivity(label, property);
                                selectivities.put(property, selectivity);
                                System.out.println("STATS: Found indexed property " + property + " for " + label + " (selectivity: " + selectivity + ")");
                            });
                        }
                    }
                });
                
                // Also check constraints for additional properties
                tx.schema().getConstraints().forEach(constraintDefinition -> {
                    // Get label from constraint (API varies by Neo4j version)
                    try {
                        constraintDefinition.getLabel(); // Try single label API first
                        String constraintLabel = constraintDefinition.getLabel().name();
                        if (label.equals(constraintLabel)) {
                            constraintDefinition.getPropertyKeys().forEach(propertyKey -> {
                                String property = propertyKey; // propertyKey is already a String
                                if (!selectivities.containsKey(property)) {
                                    double selectivity = getPropertySelectivity(label, property);
                                    selectivities.put(property, selectivity);
                                    System.out.println("STATS: Found constraint property " + property + " for " + label + " (selectivity: " + selectivity + ")");
                                }
                            });
                        }
                    } catch (Exception e) {
                        // Fallback for different Neo4j API versions
                        System.out.println("STATS: Could not access constraint labels (Neo4j API version difference)");
                    }
                });
                
                if (selectivities.isEmpty()) {
                    for (String property : schemaCache.getPropertiesForLabel(label)) {
                        double selectivity = getPropertySelectivity(label, property);
                        if (!Double.isNaN(selectivity)) {
                            selectivities.put(property, selectivity);
                        }
                    }
                }

                // If no properties found from schema, this label might not have indexes/constraints
                if (selectivities.isEmpty()) {
                    System.out.println("STATS: No schema properties found for label " + label + " - may need to scan data");
                }
                
            } catch (Exception e) {
                System.err.println("Failed to load property selectivities for " + label + ": " + e.getMessage());
            }
            
            return selectivities;
        });
    }
    
    /**
     * Get property value range from ACTUAL database data
     */
    public Object[] getPropertyValueRange(String label, String property) {
        String cacheKey = "value_range_" + label + "_" + property;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            if (!allowDataQueries) {
                DatabaseSchemaCache.PropertyInfo info = schemaCache.getPropertyInfo(label, property);
                if (info != null && info.getMinValue() != null && info.getMaxValue() != null) {
                    return new Object[]{info.getMinValue(), info.getMaxValue()};
                }
                return null;
            }
            try (Transaction tx = db.beginTx()) {
                // Get ACTUAL min/max values from the database for numeric properties
                String minMaxQuery = "MATCH (n:" + label + ") WHERE n." + property + " IS NOT NULL " +
                                   "AND apoc.meta.cypher.type(n." + property + ") IN ['INTEGER', 'LONG', 'FLOAT', 'DOUBLE'] " +
                                   "RETURN min(n." + property + ") as minVal, max(n." + property + ") as maxVal";
                
                Result result = executeGuarded(tx, minMaxQuery);
                if (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    Object minVal = row.get("minVal");
                    Object maxVal = row.get("maxVal");
                    
                    if (minVal != null && maxVal != null) {
                        System.out.println("STATS: Actual range for " + label + "." + property + 
                                         ": " + minVal + " to " + maxVal);
                        return new Object[]{minVal, maxVal};
                    }
                }
                
                // If no numeric data found, return null (not a numeric property)
                return null;
                
            } catch (Exception e) {
                System.err.println("ERROR: Failed to get actual value range for " + label + "." + property + ": " + e.getMessage());
                return null;
            }
        });
    }
    
    
    /**
     * Get ACTUAL null percentage for a property from database data
     */
    public double getPropertyNullPercentage(String label, String property) {
        String cacheKey = "null_percentage_" + label + "_" + property;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            if (!allowDataQueries) {
                DatabaseSchemaCache.PropertyInfo info = schemaCache.getPropertyInfo(label, property);
                if (info != null && info.getTotalCount() > 0) {
                    return (double) info.getNullCount() / (double) info.getTotalCount();
                }
                return Double.NaN;
            }
            try (Transaction tx = db.beginTx()) {
                // Calculate ACTUAL null percentage from database
                String nullQuery = "MATCH (n:" + label + ") " +
                                 "RETURN count(*) as totalCount, " +
                                 "count(n." + property + ") as nonNullCount, " +
                                 "(count(*) - count(n." + property + ")) as nullCount";
                
                Result result = executeGuarded(tx, nullQuery);
                if (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    long totalCount = ((Number) row.get("totalCount")).longValue();
                    long nullCount = ((Number) row.get("nullCount")).longValue();
                    
                    if (totalCount > 0) {
                        double nullPercentage = (double) nullCount / totalCount;
                        System.out.println("STATS: Actual null percentage for " + label + "." + property + 
                                         ": " + String.format("%.2f%%", nullPercentage * 100) + 
                                         " (" + nullCount + "/" + totalCount + ")");
                        return nullPercentage;
                    }
                }
                
                return Double.NaN;
                
            } catch (Exception e) {
                System.err.println("ERROR: Failed to get actual null percentage for " + label + "." + property + ": " + e.getMessage());
                return Double.NaN;
            }
        });
    }
    
    private boolean hasNotNullConstraint(Transaction tx, String label, String property) {
        if (tx == null) {
            return false;
        }
        try {
            for (org.neo4j.graphdb.schema.ConstraintDefinition constraint : tx.schema().getConstraints()) {
                try {
                    Label constraintLabel = constraint.getLabel();
                    if (constraintLabel != null && constraintLabel.name().equals(label)) {
                        for (String propKey : constraint.getPropertyKeys()) {
                            if (propKey.equals(property)) {
                                org.neo4j.graphdb.schema.ConstraintType type = constraint.getConstraintType();
                                if (type == org.neo4j.graphdb.schema.ConstraintType.NODE_KEY ||
                                    type == org.neo4j.graphdb.schema.ConstraintType.UNIQUENESS ||
                                    type == org.neo4j.graphdb.schema.ConstraintType.NODE_PROPERTY_EXISTENCE) {
                                    return true;
                                }
                            }
                        }
                    }
                } catch (UnsupportedOperationException ignored) {
                    // Older Neo4j versions may not expose constraint details uniformly
                }
            }
        } catch (Exception e) {
            System.err.println("ERROR: Could not check NOT NULL constraint for " + label + "." + property + ": " + e.getMessage());
            return false;
        }
        return false;
    }

    private Path resolveStatsSnapshotPath() {
        String override = System.getProperty("why.statistics.snapshot.path");
        if (override == null || override.isBlank()) {
            override = System.getenv("WHY_STATISTICS_SNAPSHOT_PATH");
        }
        if (override != null && !override.isBlank()) {
            return Paths.get(override);
        }

        File pluginDir = resolvePluginDirectory();
        String dbKey = DatabaseIdentityUtil.resolveDatabaseKey(db);
        if (pluginDir != null) {
            return pluginDir.toPath().resolve("whygraph-statistics." + dbKey + ".json");
        }
        return Paths.get(System.getProperty("java.io.tmpdir"), "whygraph-statistics." + dbKey + ".json");
    }

    private Path resolveLegacyStatsSnapshotPath() {
        File pluginDir = resolvePluginDirectory();
        if (pluginDir != null) {
            return pluginDir.toPath().resolve("whygraph-statistics.json");
        }
        return Paths.get(System.getProperty("java.io.tmpdir"), "whygraph-statistics.json");
    }
    
    private File resolvePluginDirectory() {
        try {
            File jar = new File(Neo4jStatistics.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI());
            File parent = jar.getParentFile();
            if (parent != null && parent.isDirectory()) {
                return parent;
            }
        } catch (Exception ignored) {
        }
        return null;
    }
    
    private StatisticsSnapshot loadSnapshotFromDisk() {
        try {
            Path pathToLoad = statsSnapshotPath;
            if (pathToLoad == null || !Files.exists(pathToLoad)) {
                Path legacyPath = resolveLegacyStatsSnapshotPath();
                if (legacyPath != null && !legacyPath.equals(statsSnapshotPath) && Files.exists(legacyPath)) {
                    pathToLoad = legacyPath;
                    System.out.println("STATISTICS: Falling back to legacy snapshot path: " + legacyPath);
                } else {
                    return new StatisticsSnapshot();
                }
            }
            StatisticsSnapshot snapshot = OBJECT_MAPPER.readValue(pathToLoad.toFile(), StatisticsSnapshot.class);
            if (!pathToLoad.equals(statsSnapshotPath)) {
                this.persistedStats = snapshot;
                saveSnapshotToDisk();
            }
            return snapshot;
        } catch (IOException e) {
            System.err.println("Failed to load statistics snapshot: " + e.getMessage());
        }
        return new StatisticsSnapshot();
    }
    
    private void saveSnapshotToDisk() {
        if (statsSnapshotPath == null || persistedStats == null) {
            return;
        }
        try {
            Path parent = statsSnapshotPath.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            persistedStats.refreshedAt = System.currentTimeMillis();
            OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValue(statsSnapshotPath.toFile(), persistedStats);
        } catch (IOException e) {
            System.err.println("Failed to save statistics snapshot: " + e.getMessage());
        }
    }
    
    private Long getSnapshotNodeCount(String label) {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        if (label == null) {
            return persistedStats.nodeCounts.get("_ALL");
        }
        return persistedStats.nodeCounts.get(label);
    }
    
    private void updateSnapshotNodeCount(String label, long count) {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        if (label == null) {
            persistedStats.nodeCounts.put("_ALL", count);
        } else {
            persistedStats.nodeCounts.put(label, count);
        }
    }
    
    private Long getSnapshotRelationshipCount(String type) {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        if (type == null) {
            return persistedStats.relationshipCounts.get("_ALL");
        }
        return persistedStats.relationshipCounts.get(type);
    }
    
    private void updateSnapshotRelationshipCount(String type, long count) {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        if (type == null) {
            persistedStats.relationshipCounts.put("_ALL", count);
        } else {
            persistedStats.relationshipCounts.put(type, count);
        }
    }
    
    private Double getSnapshotPropertySelectivity(String label, String property) {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        return persistedStats.propertySelectivities.get(propertyKey(label, property));
    }
    
    private void updateSnapshotPropertySelectivity(String label, String property, double selectivity) {
        if (persistedStats == null) {
            persistedStats = new StatisticsSnapshot();
        }
        persistedStats.propertySelectivities.put(propertyKey(label, property), selectivity);
    }
    
    private String propertyKey(String label, String property) {
        String safeLabel = label != null ? label : "_";
        String safeProperty = property != null ? property : "_";
        return safeLabel + "." + safeProperty;
    }

    private String pathKey(String relationshipType, int minLen, int maxLen) {
        String rel = relationshipType != null ? relationshipType : "_ANY_REL_";
        return rel + "|" + minLen + "|" + maxLen;
    }

    private long computePathSafeUpperBound(String relationshipType, int minLen, int maxLen) {
        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = schemaCache.getSchemaTripleStats();
        if (triples == null || triples.isEmpty()) {
            return 0L;
        }

        double maxOut = 0.0;
        long sourceNodes = 0L;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> e : triples.entrySet()) {
            SchemaGraph.SchemaTriple t = e.getKey();
            if (relationshipType != null && t.getRelationshipType() != null &&
                !relationshipType.equals(t.getRelationshipType())) {
                continue;
            }
            SchemaGraph.TripleStats s = e.getValue();
            double candidate = s != null ? Math.max(0.0, s.getMaxOutDegree()) : 0.0;
            if (candidate <= 0.0 && s != null) {
                candidate = Math.max(0.0, s.getAvgOutDegree());
            }
            maxOut = Math.max(maxOut, candidate);
            sourceNodes += Math.max(0L, schemaCache.getLabelCount(t.getSourceLabel()));
        }
        if (sourceNodes <= 0L || maxOut <= 0.0) {
            return 0L;
        }

        double total = 0.0;
        for (int k = minLen; k <= maxLen; k++) {
            total += sourceNodes * Math.pow(maxOut, k);
            if (total > Long.MAX_VALUE / 4.0) {
                return Long.MAX_VALUE / 4;
            }
        }
        return Math.max(0L, (long) Math.ceil(total));
    }

    private double computePathEstimate(String relationshipType, int minLen, int maxLen) {
        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples = schemaCache.getSchemaTripleStats();
        if (triples == null || triples.isEmpty()) {
            return 0.0;
        }

        double avgOutSum = 0.0;
        int tripleCount = 0;
        long sourceNodes = 0L;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> e : triples.entrySet()) {
            SchemaGraph.SchemaTriple t = e.getKey();
            if (relationshipType != null && t.getRelationshipType() != null &&
                !relationshipType.equals(t.getRelationshipType())) {
                continue;
            }
            SchemaGraph.TripleStats s = e.getValue();
            if (s != null && s.getAvgOutDegree() > 0.0) {
                avgOutSum += s.getAvgOutDegree();
                tripleCount++;
                sourceNodes += Math.max(0L, schemaCache.getLabelCount(t.getSourceLabel()));
            }
        }
        if (tripleCount == 0 || sourceNodes <= 0L) {
            return 0.0;
        }
        double avgOut = avgOutSum / tripleCount;
        double estimate = 0.0;
        for (int k = minLen; k <= maxLen; k++) {
            estimate += sourceNodes * Math.pow(avgOut, k);
        }
        return Math.max(0.0, estimate);
    }

    private static class StatisticsSnapshot {
        public Map<String, Long> nodeCounts = new HashMap<>();
        public Map<String, Long> relationshipCounts = new HashMap<>();
        public Map<String, Double> propertySelectivities = new HashMap<>();
        // S_path estimate/safe layers for bounded variable-length path summaries.
        public Map<String, Double> pathEstimates = new HashMap<>();
        public Map<String, Long> pathSafeUpperBounds = new HashMap<>();
        public long pathRefreshedAt = 0L;
        public long refreshedAt = 0L;
    }
    
    /**
     * Get most common values for a property from ACTUAL database data
     */
    public List<Object> getMostCommonValues(String label, String property, int limit) {
        String cacheKey = "common_values_" + label + "_" + property + "_" + limit;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            List<Object> commonValues = new ArrayList<>();
            if (!allowDataQueries) {
                List<Object> snapshotValues = schemaCache.getCommonValuesForProperty(label, property);
                return snapshotValues.subList(0, Math.min(limit, snapshotValues.size()));
            }
            
            try (Transaction tx = db.beginTx()) {
                // Get ACTUAL most common values from the database
                String valuesQuery = "MATCH (n:" + label + ") WHERE n." + property + " IS NOT NULL " +
                                   "RETURN n." + property + " as value, count(*) as frequency " +
                                   "ORDER BY frequency DESC LIMIT " + limit;
                
                Result result = executeGuarded(tx, valuesQuery);
                while (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    Object value = row.get("value");
                    Long frequency = ((Number) row.get("frequency")).longValue();
                    
                    if (value != null) {
                        commonValues.add(value);
                        System.out.println("STATS: Found common value for " + label + "." + property + 
                                         ": " + value + " (freq: " + frequency + ")");
                    }
                }
                
                if (commonValues.isEmpty()) {
                    System.out.println("STATS: No values found for " + label + "." + property);
                }
                
                // Limit to requested size
                return commonValues.subList(0, Math.min(limit, commonValues.size()));
            } catch (Exception e) {
                return new ArrayList<>(); // Return empty list on error
            }
        });
    }
    
    /**
     * Get selectivity for a specific property value from ACTUAL database data
     */
    public double getValueSelectivity(String label, String property, Object value) {
        String cacheKey = "value_selectivity_" + label + "_" + property + "_" + value;
        
        return cache.computeIfAbsent(cacheKey, SELECTIVITY_CACHE_TTL, () -> {
            if (!allowDataQueries) {
                return Double.NaN;
            }
            try (Transaction tx = db.beginTx()) {
                // Calculate ACTUAL selectivity by checking if value exists and its frequency
                String valueQuery = "MATCH (n:" + label + ") " +
                                  "WHERE n." + property + " = $value " +
                                  "RETURN count(*) as valueCount";
                
                String totalQuery = "MATCH (n:" + label + ") " +
                                  "WHERE n." + property + " IS NOT NULL " +
                                  "RETURN count(*) as totalCount";
                
                // Get value count
                Result valueResult = executeGuarded(tx, valueQuery, Map.of("value", value));
                long valueCount = 0;
                if (valueResult.hasNext()) {
                    valueCount = ((Number) valueResult.next().get("valueCount")).longValue();
                }
                
                // Get total count
                Result totalResult = executeGuarded(tx, totalQuery);
                long totalCount = 0;
                if (totalResult.hasNext()) {
                    totalCount = ((Number) totalResult.next().get("totalCount")).longValue();
                }
                
                // Calculate actual selectivity
                if (totalCount > 0) {
                    double selectivity = (double) valueCount / totalCount;
                    System.out.println("STATS: Actual selectivity for " + label + "." + property + 
                                     " = " + value + ": " + String.format("%.4f", selectivity) + 
                                     " (" + valueCount + "/" + totalCount + ")");
                    return selectivity;
                }
                
                // If no data found, value doesn't exist
                return 0.0;
                
            } catch (Exception e) {
                System.err.println("ERROR: Failed to calculate value selectivity for " + label + "." + property + " = " + value + ": " + e.getMessage());
                return Double.NaN;
            }
        });
    }
    
    private void logStatsWarning(String section, Exception e) {
        String message = e != null ? e.getMessage() : "unknown error";
        String key = section + ":" + (message != null ? message : "");
        if (statsWarningMessages.add(key)) {
            System.err.println("Failed to get " + section + " via APOC/db.stats API: " + message);
        }
    }
}
