package com.whyquery.neo4j.rewriting;

import java.util.*;

/**
 * User preferences for guiding the query rewriting process
 */
public class UserPreferences {
    
    // Operation preferences (lower values = preferred)
    private final Map<ModificationOperation.Type, Double> operationPenalties = new HashMap<>();
    
    // Label preferences
    private final Set<String> preferredLabels = new HashSet<>();
    private final Set<String> avoidedLabels = new HashSet<>();
    
    // Relationship type preferences  
    private final Set<String> preferredRelationshipTypes = new HashSet<>();
    private final Set<String> avoidedRelationshipTypes = new HashSet<>();
    
    // Property preferences
    private final Set<String> criticalProperties = new HashSet<>();
    private final Set<String> relaxableProperties = new HashSet<>();
    
    // General preferences
    private boolean preferOptionalMatch = false;
    private boolean preserveOrderBy = true;
    private boolean preserveLimit = true;
    private double maxSemanticDistance = 50.0;
    
    public UserPreferences() {
        initializeDefaultPenalties();
    }
    
    private void initializeDefaultPenalties() {
        // Default penalties - can be customized
        operationPenalties.put(ModificationOperation.Type.DELETE_PREDICATE, 1.0);
        operationPenalties.put(ModificationOperation.Type.RELAX_ENDPOINT_PREDICATE, 0.8);
        operationPenalties.put(ModificationOperation.Type.RELAX_PROPERTY, 2.0);
        operationPenalties.put(ModificationOperation.Type.RELAX_LABEL, 3.0);
        operationPenalties.put(ModificationOperation.Type.MAKE_OPTIONAL, 4.0);
        operationPenalties.put(ModificationOperation.Type.DELETE_RELATIONSHIP, 5.0);
        operationPenalties.put(ModificationOperation.Type.DELETE_NODE, 10.0);
    }
    
    /**
     * Get penalty for a specific operation type
     */
    public double getOperationPenalty(ModificationOperation.Type operationType) {
        return operationPenalties.getOrDefault(operationType, 5.0);
    }
    
    /**
     * Set penalty for an operation type
     */
    public void setOperationPenalty(ModificationOperation.Type operationType, double penalty) {
        operationPenalties.put(operationType, penalty);
    }
    
    /**
     * Add a preferred label (lower penalty for keeping it)
     */
    public void addPreferredLabel(String label) {
        preferredLabels.add(label);
        avoidedLabels.remove(label);
    }
    
    /**
     * Add an avoided label (higher penalty for keeping it)
     */
    public void addAvoidedLabel(String label) {
        avoidedLabels.add(label);
        preferredLabels.remove(label);
    }
    
    /**
     * Add a preferred relationship type
     */
    public void addPreferredRelationshipType(String relationshipType) {
        preferredRelationshipTypes.add(relationshipType);
        avoidedRelationshipTypes.remove(relationshipType);
    }
    
    /**
     * Add an avoided relationship type
     */
    public void addAvoidedRelationshipType(String relationshipType) {
        avoidedRelationshipTypes.add(relationshipType);
        preferredRelationshipTypes.remove(relationshipType);
    }
    
    /**
     * Mark a property as critical (avoid relaxing)
     */
    public void addCriticalProperty(String property) {
        criticalProperties.add(property);
        relaxableProperties.remove(property);
    }
    
    /**
     * Mark a property as relaxable (prefer to relax over deletion)
     */
    public void addRelaxableProperty(String property) {
        relaxableProperties.add(property);
        criticalProperties.remove(property);
    }
    
    /**
     * Check if a label is preferred
     */
    public boolean isPreferredLabel(String label) {
        return preferredLabels.contains(label);
    }
    
    /**
     * Check if a label should be avoided
     */
    public boolean isAvoidedLabel(String label) {
        return avoidedLabels.contains(label);
    }
    
    /**
     * Check if a relationship type is preferred
     */
    public boolean isPreferredRelationshipType(String relationshipType) {
        return preferredRelationshipTypes.contains(relationshipType);
    }
    
    /**
     * Check if a relationship type should be avoided
     */
    public boolean isAvoidedRelationshipType(String relationshipType) {
        return avoidedRelationshipTypes.contains(relationshipType);
    }
    
    /**
     * Check if a property is critical
     */
    public boolean isCriticalProperty(String property) {
        return criticalProperties.contains(property);
    }
    
    /**
     * Check if a property is relaxable
     */
    public boolean isRelaxableProperty(String property) {
        return relaxableProperties.contains(property);
    }
    
    /**
     * Get label preference penalty (0.0 = preferred, 1.0 = neutral, 2.0 = avoided)
     */
    public double getLabelPenalty(String label) {
        if (isPreferredLabel(label)) return 0.0;
        if (isAvoidedLabel(label)) return 2.0;
        return 1.0;
    }
    
    /**
     * Get relationship type preference penalty
     */
    public double getRelationshipTypePenalty(String relationshipType) {
        if (isPreferredRelationshipType(relationshipType)) return 0.0;
        if (isAvoidedRelationshipType(relationshipType)) return 2.0;
        return 1.0;
    }
    
    /**
     * Get property preference penalty
     */
    public double getPropertyPenalty(String property) {
        if (isRelaxableProperty(property)) return 0.5;
        if (isCriticalProperty(property)) return 3.0;
        return 1.0;
    }
    
    // Getters and setters for general preferences
    public boolean isPreferOptionalMatch() { return preferOptionalMatch; }
    public void setPreferOptionalMatch(boolean preferOptionalMatch) { 
        this.preferOptionalMatch = preferOptionalMatch; 
    }
    
    public boolean isPreserveOrderBy() { return preserveOrderBy; }
    public void setPreserveOrderBy(boolean preserveOrderBy) { 
        this.preserveOrderBy = preserveOrderBy; 
    }
    
    public boolean isPreserveLimit() { return preserveLimit; }
    public void setPreserveLimit(boolean preserveLimit) { 
        this.preserveLimit = preserveLimit; 
    }
    
    public double getMaxSemanticDistance() { return maxSemanticDistance; }
    public void setMaxSemanticDistance(double maxSemanticDistance) { 
        this.maxSemanticDistance = maxSemanticDistance; 
    }
    
    /**
     * Create user preferences optimized for minimal changes
     */
    public static UserPreferences createMinimalChanges() {
        UserPreferences prefs = new UserPreferences();
        prefs.setOperationPenalty(ModificationOperation.Type.DELETE_PREDICATE, 0.5);
        prefs.setOperationPenalty(ModificationOperation.Type.RELAX_PROPERTY, 1.0);
        prefs.setOperationPenalty(ModificationOperation.Type.RELAX_LABEL, 2.0);
        prefs.setOperationPenalty(ModificationOperation.Type.MAKE_OPTIONAL, 5.0);
        prefs.setOperationPenalty(ModificationOperation.Type.DELETE_RELATIONSHIP, 10.0);
        prefs.setOperationPenalty(ModificationOperation.Type.DELETE_NODE, 20.0);
        prefs.setMaxSemanticDistance(25.0);
        return prefs;
    }
    
    /**
     * Create user preferences optimized for result completeness
     */
    public static UserPreferences createResultCompleteness() {
        UserPreferences prefs = new UserPreferences();
        prefs.setOperationPenalty(ModificationOperation.Type.DELETE_NODE, 5.0);
        prefs.setOperationPenalty(ModificationOperation.Type.DELETE_RELATIONSHIP, 3.0);
        prefs.setOperationPenalty(ModificationOperation.Type.MAKE_OPTIONAL, 2.0);
        prefs.setOperationPenalty(ModificationOperation.Type.RELAX_LABEL, 2.0);
        prefs.setOperationPenalty(ModificationOperation.Type.RELAX_PROPERTY, 1.0);
        prefs.setOperationPenalty(ModificationOperation.Type.DELETE_PREDICATE, 1.0);
        prefs.setMaxSemanticDistance(100.0);
        prefs.setPreferOptionalMatch(true);
        return prefs;
    }
    
    @Override
    public String toString() {
        return String.format("UserPreferences{penalties=%s, preferredLabels=%s, avoidedLabels=%s}", 
                           operationPenalties, preferredLabels, avoidedLabels);
    }
}
