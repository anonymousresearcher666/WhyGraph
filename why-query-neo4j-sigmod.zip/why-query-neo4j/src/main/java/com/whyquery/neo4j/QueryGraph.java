package com.whyquery.neo4j;

import java.util.*;

/**
 * Internal representation of a graph query
 */
public class QueryGraph {
    private Map<Integer, Vertex> vertices = new HashMap<>();
    private List<Edge> edges = new ArrayList<>();
    private String originalCypherQuery;
    
    public void addVertex(int id, String identifier, List<String> labels, Map<String, Object> properties) {
        vertices.put(id, new Vertex(id, identifier, labels, properties));
    }
    
    public void addEdge(int source, int target, String type, Map<String, Object> properties) {
        edges.add(new Edge(source, target, type, properties));
    }
    
    public String toJson() {
        return "{\"vertices\":" + vertices.size() + ",\"edges\":" + edges.size() + "}";
    }
    
    public int numVertices() {
        return vertices.size();
    }
    
    public int numEdges() {
        return edges.size();
    }
    
    public void setOriginalCypherQuery(String query) {
        this.originalCypherQuery = query;
    }
    
    public String getOriginalCypherQuery() {
        return originalCypherQuery;
    }
    
    // Analysis methods for why-query functionality
    public Set<String> getRequiredLabels() {
        Set<String> labels = new HashSet<>();
        for (Vertex vertex : vertices.values()) {
            labels.addAll(vertex.labels);
        }
        return labels;
    }
    
    public Set<String> getRequiredRelationshipTypes() {
        Set<String> types = new HashSet<>();
        for (Edge edge : edges) {
            types.add(edge.type);
        }
        return types;
    }
    
    public Map<String, Object> getPropertyConstraints() {
        Map<String, Object> constraints = new HashMap<>();
        
        // Collect property constraints from vertices
        for (Vertex vertex : vertices.values()) {
            for (Map.Entry<String, Object> prop : vertex.properties.entrySet()) {
                if (prop.getValue() != null) {
                    constraints.put(prop.getKey(), prop.getValue());
                }
            }
        }
        
        // Collect property constraints from edges
        for (Edge edge : edges) {
            for (Map.Entry<String, Object> prop : edge.properties.entrySet()) {
                if (prop.getValue() != null) {
                    constraints.put(edge.type + "." + prop.getKey(), prop.getValue());
                }
            }
        }
        
        return constraints;
    }
    
    public boolean requiresConnectivity() {
        // Query requires connectivity if it has edges or multiple vertices
        return !edges.isEmpty() || vertices.size() > 1;
    }
    
    public int getComplexity() {
        // Simple complexity metric: vertices + edges + constraints
        int complexity = vertices.size() + edges.size();
        
        // Add complexity for property constraints
        for (Vertex vertex : vertices.values()) {
            complexity += vertex.properties.size();
        }
        
        for (Edge edge : edges) {
            complexity += edge.properties.size();
        }
        
        return complexity;
    }
    
    public int getPatternDepth() {
        if (edges.isEmpty()) return 0;
        
        // Calculate the longest path in the query pattern
        Map<Integer, Set<Integer>> adjacency = new HashMap<>();
        for (Edge edge : edges) {
            adjacency.computeIfAbsent(edge.source, k -> new HashSet<>()).add(edge.target);
        }
        
        int maxDepth = 0;
        for (Integer startVertex : vertices.keySet()) {
            maxDepth = Math.max(maxDepth, calculateDepthFromVertex(startVertex, adjacency, new HashSet<>()));
        }
        
        return maxDepth;
    }
    
    private int calculateDepthFromVertex(Integer vertex, Map<Integer, Set<Integer>> adjacency, Set<Integer> visited) {
        if (visited.contains(vertex)) return 0;
        
        visited.add(vertex);
        int maxDepth = 0;
        
        Set<Integer> neighbors = adjacency.get(vertex);
        if (neighbors != null) {
            for (Integer neighbor : neighbors) {
                maxDepth = Math.max(maxDepth, 1 + calculateDepthFromVertex(neighbor, adjacency, new HashSet<>(visited)));
            }
        }
        
        return maxDepth;
    }
    
    public boolean hasOrderBy() {
        // This would be set by the parser - for now assume false
        // In a real implementation, this would be parsed from the Cypher query
        return false;
    }
    
    // Accessor methods for vertices and edges
    public Collection<Vertex> getNodes() {
        return vertices.values();
    }
    
    public List<Edge> getEdges() {
        return edges;
    }
    
    public Vertex getNodeById(int id) {
        return vertices.get(id);
    }
    
    public String getCypherQuery() {
        return originalCypherQuery;
    }
    
    public static class Vertex {
        public final int id;
        public final String identifier;
        public final List<String> labels;
        public final Map<String, Object> properties;
        
        public Vertex(int id, String identifier, List<String> labels, Map<String, Object> properties) {
            this.id = id;
            this.identifier = identifier;
            this.labels = labels != null ? labels : new ArrayList<>();
            this.properties = properties != null ? properties : new HashMap<>();
        }
        
        public List<String> getLabels() {
            return labels;
        }
        
        public Map<String, Object> getProperties() {
            return properties;
        }
        
        public String getIdentifier() {
            return identifier;
        }
    }
    
    public static class Edge {
        public final int source;
        public final int target;
        public final String type;
        public final Map<String, Object> properties;
        
        public Edge(int source, int target, String type, Map<String, Object> properties) {
            this.source = source;
            this.target = target;
            this.type = type;
            this.properties = properties != null ? properties : new HashMap<>();
        }
        
        public String getType() {
            return type;
        }
        
        public Map<String, Object> getProperties() {
            return properties;
        }
    }
}
