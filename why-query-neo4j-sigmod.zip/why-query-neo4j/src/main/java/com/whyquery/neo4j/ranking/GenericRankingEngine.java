package com.whyquery.neo4j.ranking;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.Result;

import java.util.*;

/**
 * Generic ranking engine that can create rankings for any entity type
 * based on various ranking strategies when explicit ranking properties are missing.
 */
public class GenericRankingEngine {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    
    public GenericRankingEngine(GraphDatabaseService db, Transaction tx) {
        this.db = db;
        this.tx = tx;
    }
    
    /**
     * Generate rankings for entities when no explicit ranking properties exist
     */
    public RankingStrategy generateRanking(String entityLabel, String entityProperty) {
        List<RankingStrategy> strategies = new ArrayList<>();
        
        // Strategy 1: Connectivity-based ranking (node degree)
        strategies.add(generateConnectivityRanking(entityLabel, entityProperty));
        
        // Strategy 2: Alphabetical ranking
        strategies.add(generateAlphabeticalRanking(entityLabel, entityProperty));
        
        // Strategy 3: Year-based ranking (if year property exists)
        strategies.add(generateTemporalRanking(entityLabel, entityProperty));
        
        // Strategy 4: Relationship-weight ranking
        strategies.add(generateRelationshipWeightRanking(entityLabel, entityProperty));
        
        // Return the best strategy based on data availability
        return selectBestStrategy(strategies);
    }
    
    private RankingStrategy generateConnectivityRanking(String entityLabel, String entityProperty) {
        RankingStrategy strategy = new RankingStrategy("Connectivity Ranking", 
            "Rank entities by their network connectivity (number of relationships)");
        
        try {
            String query = String.format(
                "MATCH (n:%s) WHERE n.%s IS NOT NULL " +
                "RETURN n.%s as entity, size((n)-[]-()) as degree " +
                "ORDER BY degree DESC, entity ASC LIMIT 20",
                entityLabel, entityProperty, entityProperty
            );
            
            Result result = tx.execute(query);
            int rank = 1;
            while (result.hasNext()) {
                Map<String, Object> row = result.next();
                String entity = (String) row.get("entity");
                Number degree = (Number) row.get("degree");
                
                strategy.addRankedEntity(entity, rank++, degree.doubleValue(), 
                    "Connected to " + degree + " other entities");
            }
            
            strategy.setApplicable(strategy.getRankedEntities().size() > 0);
            strategy.setExplanation("Movies ranked by number of relationships (actors, directors, etc.)");
            
        } catch (Exception e) {
            strategy.setApplicable(false);
            strategy.setError("Failed to calculate connectivity: " + e.getMessage());
        }
        
        return strategy;
    }
    
    private RankingStrategy generateAlphabeticalRanking(String entityLabel, String entityProperty) {
        RankingStrategy strategy = new RankingStrategy("Alphabetical Ranking", 
            "Rank entities alphabetically by name/title");
        
        try {
            String query = String.format(
                "MATCH (n:%s) WHERE n.%s IS NOT NULL " +
                "RETURN n.%s as entity " +
                "ORDER BY entity ASC LIMIT 20",
                entityLabel, entityProperty, entityProperty
            );
            
            Result result = tx.execute(query);
            int rank = 1;
            while (result.hasNext()) {
                Map<String, Object> row = result.next();
                String entity = (String) row.get("entity");
                
                strategy.addRankedEntity(entity, rank++, rank, 
                    "Alphabetical position: " + rank);
            }
            
            strategy.setApplicable(strategy.getRankedEntities().size() > 0);
            strategy.setExplanation("Entities ranked alphabetically by " + entityProperty);
            
        } catch (Exception e) {
            strategy.setApplicable(false);
            strategy.setError("Failed to create alphabetical ranking: " + e.getMessage());
        }
        
        return strategy;
    }
    
    private RankingStrategy generateTemporalRanking(String entityLabel, String entityProperty) {
        RankingStrategy strategy = new RankingStrategy("Temporal Ranking", 
            "Rank entities by time-based properties (year, date)");
        
        try {
            // Try different temporal property names
            String[] temporalProps = {"released", "year", "born", "created", "updated"};
            String temporalProp = null;
            
            for (String prop : temporalProps) {
                String testQuery = String.format(
                    "MATCH (n:%s) WHERE n.%s IS NOT NULL RETURN count(n) as count",
                    entityLabel, prop
                );
                Result testResult = tx.execute(testQuery);
                if (testResult.hasNext()) {
                    Number count = (Number) testResult.next().get("count");
                    if (count.intValue() > 0) {
                        temporalProp = prop;
                        break;
                    }
                }
            }
            
            if (temporalProp != null) {
                String query = String.format(
                    "MATCH (n:%s) WHERE n.%s IS NOT NULL " +
                    "RETURN n.%s as entity, n.%s as temporal_value " +
                    "ORDER BY temporal_value DESC, entity ASC LIMIT 20",
                    entityLabel, temporalProp, entityProperty, temporalProp
                );
                
                Result result = tx.execute(query);
                int rank = 1;
                while (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    String entity = (String) row.get("entity");
                    Number temporalValue = (Number) row.get("temporal_value");
                    
                    strategy.addRankedEntity(entity, rank++, temporalValue.doubleValue(), 
                        temporalProp + ": " + temporalValue);
                }
                
                strategy.setApplicable(true);
                strategy.setExplanation("Entities ranked by " + temporalProp + " (newest first)");
            } else {
                strategy.setApplicable(false);
                strategy.setError("No temporal properties found");
            }
            
        } catch (Exception e) {
            strategy.setApplicable(false);
            strategy.setError("Failed to create temporal ranking: " + e.getMessage());
        }
        
        return strategy;
    }
    
    private RankingStrategy generateRelationshipWeightRanking(String entityLabel, String entityProperty) {
        RankingStrategy strategy = new RankingStrategy("Relationship Weight Ranking", 
            "Rank entities by weighted relationships (salary, budget, etc.)");
        
        try {
            // Find numeric properties in relationships
            String query = String.format(
                "MATCH (n:%s)-[r]->() WHERE n.%s IS NOT NULL " +
                "WITH n.%s as entity, " +
                "     sum(coalesce(r.salary, 0)) + " +
                "     sum(coalesce(r.budget, 0)) + " +
                "     sum(coalesce(r.fee, 0)) + " +
                "     sum(coalesce(r.investment, 0)) as total_weight " +
                "WHERE total_weight > 0 " +
                "RETURN entity, total_weight " +
                "ORDER BY total_weight DESC LIMIT 20",
                entityLabel, entityProperty, entityProperty
            );
            
            Result result = tx.execute(query);
            int rank = 1;
            while (result.hasNext()) {
                Map<String, Object> row = result.next();
                String entity = (String) row.get("entity");
                Number weight = (Number) row.get("total_weight");
                
                strategy.addRankedEntity(entity, rank++, weight.doubleValue(), 
                    "Total relationship weight: $" + weight);
            }
            
            strategy.setApplicable(strategy.getRankedEntities().size() > 0);
            strategy.setExplanation("Entities ranked by total monetary value of relationships");
            
        } catch (Exception e) {
            strategy.setApplicable(false);
            strategy.setError("Failed to calculate relationship weights: " + e.getMessage());
        }
        
        return strategy;
    }
    
    private RankingStrategy selectBestStrategy(List<RankingStrategy> strategies) {
        // Prefer strategies with more entities and meaningful differentiation
        return strategies.stream()
            .filter(RankingStrategy::isApplicable)
            .max(Comparator.comparing(s -> s.getRankedEntities().size() * s.getVariance()))
            .orElse(strategies.get(1)); // Default to alphabetical if nothing else works
    }
}