package com.whyquery.neo4j.paths;

/**
 * Types of path patterns that can be found in Cypher queries
 */
public enum PathPatternType {
    
    /**
     * Fixed-length path with single relationship
     */
    FIXED_LENGTH,
    
    /**
     * Variable-length path with [*min..max] syntax
     */
    VARIABLE_LENGTH,
    
    /**
     * Shortest path using shortestPath() function
     */
    SHORTEST_PATH,
    
    /**
     * All shortest paths using allShortestPaths() function
     */
    ALL_SHORTEST_PATHS,
    
    /**
     * Custom path pattern (complex expressions)
     */
    CUSTOM
}