package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Represents a path pattern found in a Cypher query
 */
public class PathPattern {
    
    private PathPatternType type;
    private String startVariable;
    private String endVariable;
    private String relationshipPattern;
    private List<String> relationshipTypes;
    private String direction;
    private int minLength;
    private int maxLength;
    private String weightProperty;
    private Map<String, Object> metadata;
    
    public PathPattern() {
        this.relationshipTypes = new ArrayList<>();
        this.metadata = new HashMap<>();
        this.direction = "OUT";
        this.minLength = 1;
        this.maxLength = 1;
    }
    
    public PathPatternType getType() {
        return type;
    }
    
    public void setType(PathPatternType type) {
        this.type = type;
    }
    
    public String getStartVariable() {
        return startVariable;
    }
    
    public void setStartVariable(String startVariable) {
        this.startVariable = startVariable;
    }
    
    public String getEndVariable() {
        return endVariable;
    }
    
    public void setEndVariable(String endVariable) {
        this.endVariable = endVariable;
    }
    
    public String getRelationshipPattern() {
        return relationshipPattern;
    }
    
    public void setRelationshipPattern(String relationshipPattern) {
        this.relationshipPattern = relationshipPattern;
    }
    
    public List<String> getRelationshipTypes() {
        return relationshipTypes;
    }
    
    public void setRelationshipTypes(List<String> relationshipTypes) {
        this.relationshipTypes = relationshipTypes;
    }
    
    public void addRelationshipType(String type) {
        this.relationshipTypes.add(type);
    }
    
    public String getDirection() {
        return direction;
    }
    
    public void setDirection(String direction) {
        this.direction = direction;
    }
    
    public int getMinLength() {
        return minLength;
    }
    
    public void setMinLength(int minLength) {
        this.minLength = minLength;
    }
    
    public int getMaxLength() {
        return maxLength;
    }
    
    public void setMaxLength(int maxLength) {
        this.maxLength = maxLength;
    }
    
    public String getWeightProperty() {
        return weightProperty;
    }
    
    public void setWeightProperty(String weightProperty) {
        this.weightProperty = weightProperty;
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    /**
     * Check if this is a variable-length pattern
     */
    public boolean isVariableLength() {
        return maxLength > minLength || maxLength == Integer.MAX_VALUE;
    }
    
    /**
     * Check if this pattern uses weighted paths
     */
    public boolean isWeighted() {
        return weightProperty != null && !weightProperty.trim().isEmpty();
    }
    
    /**
     * Check if this pattern has relationship type constraints
     */
    public boolean hasRelationshipTypes() {
        return !relationshipTypes.isEmpty();
    }
    
    /**
     * Get the length range as a string
     */
    public String getLengthRangeString() {
        if (minLength == maxLength) {
            return String.valueOf(minLength);
        } else if (maxLength == Integer.MAX_VALUE) {
            return minLength + "+";
        } else {
            return minLength + "-" + maxLength;
        }
    }
    
    /**
     * Get relationship types as a string
     */
    public String getRelationshipTypesString() {
        if (relationshipTypes.isEmpty()) {
            return "any";
        } else if (relationshipTypes.size() == 1) {
            return relationshipTypes.get(0);
        } else {
            return String.join("|", relationshipTypes);
        }
    }
    
    /**
     * Generate a Cypher pattern string
     */
    public String toCypherPattern() {
        StringBuilder pattern = new StringBuilder();
        
        // Start node
        if (startVariable != null) {
            pattern.append("(").append(startVariable).append(")");
        } else {
            pattern.append("()");
        }
        
        // Relationship
        String relDirection = getDirectionSymbol();
        pattern.append(relDirection.charAt(0)); // Opening direction symbol
        
        pattern.append("[");
        if (hasRelationshipTypes()) {
            pattern.append(":").append(getRelationshipTypesString());
        }
        
        if (isVariableLength()) {
            pattern.append("*");
            if (minLength > 1 || maxLength < Integer.MAX_VALUE) {
                pattern.append(getLengthRangeString());
            }
        }
        pattern.append("]");
        
        pattern.append(relDirection.charAt(1)); // Closing direction symbol
        
        // End node
        if (endVariable != null) {
            pattern.append("(").append(endVariable).append(")");
        } else {
            pattern.append("()");
        }
        
        return pattern.toString();
    }
    
    /**
     * Get direction symbols for Cypher
     */
    private String getDirectionSymbol() {
        switch (direction.toUpperCase()) {
            case "IN":
                return "<-";
            case "OUT":
                return "->";
            case "BOTH":
                return "--";
            default:
                return "->";
        }
    }
    
    /**
     * Calculate the estimated complexity of this pattern
     */
    public double getComplexityScore() {
        double complexity = 1.0;
        
        // Base complexity by type
        switch (type) {
            case FIXED_LENGTH:
                complexity = 1.0;
                break;
            case VARIABLE_LENGTH:
                complexity = 3.0;
                break;
            case SHORTEST_PATH:
                complexity = 5.0;
                break;
            case ALL_SHORTEST_PATHS:
                complexity = 7.0;
                break;
        }
        
        // Length range complexity
        if (isVariableLength()) {
            int range = maxLength == Integer.MAX_VALUE ? 10 : (maxLength - minLength);
            complexity += Math.log(range + 1);
        }
        
        // Relationship type complexity
        if (relationshipTypes.isEmpty()) {
            complexity += 1.0; // Any relationship type is more complex
        } else if (relationshipTypes.size() > 1) {
            complexity += 0.5 * relationshipTypes.size();
        }
        
        // Weighted path complexity
        if (isWeighted()) {
            complexity += 1.0;
        }
        
        return complexity;
    }
    
    @Override
    public String toString() {
        return "PathPattern{" +
               "type=" + type +
               ", length=" + getLengthRangeString() +
               ", relationshipTypes=" + getRelationshipTypesString() +
               ", direction='" + direction + '\'' +
               ", weighted=" + isWeighted() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        PathPattern that = (PathPattern) o;
        
        return minLength == that.minLength &&
               maxLength == that.maxLength &&
               type == that.type &&
               Objects.equals(startVariable, that.startVariable) &&
               Objects.equals(endVariable, that.endVariable) &&
               Objects.equals(relationshipTypes, that.relationshipTypes) &&
               Objects.equals(direction, that.direction);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(type, startVariable, endVariable, relationshipTypes, 
                          direction, minLength, maxLength);
    }
}