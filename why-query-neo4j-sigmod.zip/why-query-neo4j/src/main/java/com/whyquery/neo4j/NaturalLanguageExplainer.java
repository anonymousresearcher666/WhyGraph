package com.whyquery.neo4j;

import org.neo4j.logging.Log;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Natural Language Explainer for Why-Query Results
 * 
 * Transforms technical graph analysis output into user-friendly natural language explanations
 * using Large Language Models (LLMs). Supports multiple LLM providers and customizable prompts.
 */
public class NaturalLanguageExplainer {
    
    private final Log log;
    private final ExplanationConfig config;
    private final ExplanationPromptBuilder promptBuilder;
    
    public NaturalLanguageExplainer(Log log, Map<String, Object> options) {
        this.log = log;
        this.config = new ExplanationConfig(options);
        this.promptBuilder = new ExplanationPromptBuilder();
    }
    
    /**
     * Generate natural language explanation for why-empty results
     */
    public CompletableFuture<String> explainWhyEmpty(String originalQuery, 
                                                   Map<String, Object> technicalResult,
                                                   Map<String, Object> statistics) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildWhyEmptyPrompt(originalQuery, technicalResult, statistics);
                return callLLMWithData(prompt, "why-empty", originalQuery, technicalResult, statistics);
            } catch (Exception e) {
                log.error("Failed to generate why-empty explanation", e);
                return generateFallbackExplanation("why-empty", technicalResult);
            }
        });
    }
    
    /**
     * Generate LLM-guided minimal rewrites for why-empty, grounded in schema + diagnostics.
     */
    public CompletableFuture<String> suggestWhyEmptyRewrite(String originalQuery,
                                                            Map<String, Object> technicalResult,
                                                            Map<String, Object> statistics,
                                                            String schemaJson) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Map<String, Object> schemaMap = parseJsonToMap(schemaJson);
                String prompt = promptBuilder.buildWhyEmptyRewritePrompt(
                    originalQuery, technicalResult, statistics, schemaMap);
                
                // Bundle schema and diagnostics so the Python side receives structured context
                Map<String, Object> analysisPayload = new HashMap<>();
                if (technicalResult != null) {
                    analysisPayload.putAll(technicalResult);
                }
                if (schemaMap != null) {
                    analysisPayload.put("schema", schemaMap);
                }
                
                return callLLMWithData(prompt, "why-empty-rewrite", originalQuery, analysisPayload, statistics);
            } catch (Exception e) {
                log.error("Failed to generate why-empty rewrites", e);
                return "LLM rewrite suggestion failed: " + e.getMessage();
            }
        });
    }
    
    /**
     * Generate natural language explanation for why-so-few results
     */
    public CompletableFuture<String> explainWhySoFew(String originalQuery,
                                                   List<Map<String, Object>> modifications,
                                                   Map<String, Object> statistics,
                                                   long currentCount,
                                                   long targetCount) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildWhySoFewPrompt(originalQuery, modifications, 
                                                                statistics, currentCount, targetCount);
                
                // Create comprehensive data including actual counts
                Map<String, Object> analysisData = new HashMap<>();
                analysisData.put("modifications", modifications);
                analysisData.put("current_count", currentCount);
                analysisData.put("target_count", targetCount);
                analysisData.put("shortfall", targetCount - currentCount);
                
                return callLLMWithData(prompt, "why-so-few", originalQuery, analysisData, statistics);
            } catch (Exception e) {
                log.error("Failed to generate why-so-few explanation", e);
                return generateFallbackExplanation("why-so-few", Map.of(
                    "modifications", modifications,
                    "currentCount", currentCount,
                    "targetCount", targetCount
                ));
            }
        });
    }
    
    /**
     * Generate natural language explanation for why-so-many results
     */
    public CompletableFuture<String> explainWhySoMany(String originalQuery,
                                                    double cardinalityBound,
                                                    Map<String, Object> boundedSubgraph,
                                                    Map<String, Object> statistics) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildWhySoManyPrompt(originalQuery, cardinalityBound, 
                                                                 boundedSubgraph, statistics);
                
                // The threshold should already be in boundedSubgraph from Java implementation
                // Don't override it with cardinalityBound which is the actual result count
                return callLLMWithData(prompt, "why-so-many", originalQuery, boundedSubgraph, statistics);
            } catch (Exception e) {
                log.error("Failed to generate why-so-many explanation", e);
                return generateFallbackExplanation("why-so-many", boundedSubgraph);
            }
        });
    }
    
    /**
     * Generate natural language explanation for advanced C++ algorithm results
     */
    public CompletableFuture<String> explainAdvancedResult(String originalQuery,
                                                         String algorithm,
                                                         Map<String, Object> result,
                                                         Map<String, Object> statistics) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String prompt = promptBuilder.buildAdvancedPrompt(originalQuery, algorithm, result, statistics);
                return callLLMWithData(prompt, "advanced-" + algorithm.toLowerCase(), originalQuery, result, statistics);
            } catch (Exception e) {
                log.error("Failed to generate advanced algorithm explanation", e);
                return generateFallbackExplanation("advanced", result);
            }
        });
    }
    
    /**
     * Call Python LLM integration with full algorithmic data
     */
    private String callLLMWithData(String prompt, String analysisType, String originalQuery, 
                                  Map<String, Object> technicalResult, Map<String, Object> statistics) throws Exception {
        if (!config.isEnabled()) {
            log.info("LLM explanations disabled. Skipping analysis_type=" + analysisType);
            return generateFallbackExplanation(analysisType, technicalResult);
        }
        
        try {
            log.info(String.format("Invoking LLM via provider=%s model=%s for analysis_type=%s",
                config.getProvider(), config.getModel(), analysisType));
            // Prepare comprehensive data for Python script
            Map<String, Object> analysisData = new HashMap<>();
            analysisData.put("original_query", originalQuery);
            analysisData.put("analysis_type", analysisType);
            analysisData.put("technical_result", technicalResult);
            analysisData.put("statistics", statistics);
            analysisData.put("prompt", prompt);
            
            String analysisJson = mapToJson(analysisData);
            
            // Call Python LLM explainer script
            String pythonScript = findPythonScript();
            String pythonEnvironment = config.getPythonEnvironment();
            
            // Create a temporary shell script to avoid quoting issues
            String tempScript = createTempScript(
                pythonEnvironment,
                pythonScript,
                prompt,
                analysisType.replace("-", "_"),
                analysisJson,
                config.getResolvedConfigPath()
            );
            ProcessBuilder pb = new ProcessBuilder("bash", tempScript);
            
            pb.redirectErrorStream(true);
            Process process = pb.start();
            
            // Read output
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            
            // Wait for completion with timeout
            boolean finished = process.waitFor(30, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                return "LLM explanation timed out after 30 seconds";
            }
            
            int exitCode = process.exitValue();
            if (exitCode != 0) {
                log.error("Python LLM script failed with exit code: " + exitCode);
                return "LLM explanation script failed: " + output.toString();
            }
            
            String result = output.toString().trim();
            return result.isEmpty() ? "No explanation generated" : result;
            
        } catch (Exception e) {
            log.error("Python LLM integration failed", e);
            return "Failed to generate natural language explanation: " + e.getMessage();
        }
    }
    
    /**
     * Call Python LLM integration to generate explanation (legacy method)
     */
    private String callLLM(String prompt, String analysisType) throws Exception {
        if (!config.isEnabled()) {
            return generateFallbackExplanation(analysisType, Map.of("prompt", prompt));
        }
        
        try {
            // Prepare data for Python script
            Map<String, Object> analysisData = new HashMap<>();
            analysisData.put("query", prompt);
            analysisData.put("type", analysisType);
            
            String analysisJson = mapToJson(analysisData);
            
            // Call Python LLM explainer script
            String pythonScript = findPythonScript();
            String pythonEnvironment = config.getPythonEnvironment();
            
            // Create a temporary shell script to avoid quoting issues
            String tempScript = createTempScript(
                pythonEnvironment,
                pythonScript,
                prompt,
                analysisType.replace("-", "_"),
                analysisJson,
                config.getResolvedConfigPath()
            );
            ProcessBuilder pb = new ProcessBuilder("bash", tempScript);
            
            pb.redirectErrorStream(true);
            Process process = pb.start();
            
            // Read output
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            
            // Wait for completion with timeout
            boolean finished = process.waitFor(30, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                return "LLM explanation timed out after 30 seconds";
            }
            
            int exitCode = process.exitValue();
            if (exitCode != 0) {
                log.error("Python LLM script failed with exit code: " + exitCode);
                return "LLM explanation script failed: " + output.toString();
            }
            
            String result = output.toString().trim();
            return result.isEmpty() ? "No explanation generated" : result;
            
        } catch (Exception e) {
            log.error("Python LLM integration failed", e);
            return "Failed to generate natural language explanation: " + e.getMessage();
        }
    }
    
    /**
     * Create a temporary shell script to handle conda activation and Python execution
     */
    private String createTempScript(String environment, String pythonScript, String prompt,
                                   String analysisType, String analysisJson, String configPath) throws Exception {
        // Create temporary file
        java.io.File tempFile = java.io.File.createTempFile("llm_call_", ".sh");
        tempFile.deleteOnExit();
        
        // Write shell script content
        try (java.io.FileWriter writer = new java.io.FileWriter(tempFile)) {
            writer.write("#!/bin/bash\n");
            writer.write("set -e\n");
            writer.write("source ~/anaconda3/etc/profile.d/conda.sh\n");
            writer.write("conda activate " + environment + "\n");
            if (configPath != null && !configPath.isBlank()) {
                writer.write("export WHY_LLM_CONFIG=\"" + configPath.replace("\"", "\\\"") + "\"\n");
            }
            writer.write("python '" + pythonScript + "' ");
            writer.write("'" + prompt.replace("'", "'\"'\"'") + "' ");
            writer.write("'" + analysisType + "' ");
            writer.write("'" + analysisJson.replace("'", "'\"'\"'") + "'\n");
        }
        
        // Make executable
        tempFile.setExecutable(true);
        
        return tempFile.getAbsolutePath();
    }
    
    /**
     * Find the Python LLM explainer script
     */
    private String findPythonScript() {
        // Try multiple possible locations, plus an optional explicit override
        String override = System.getenv("WHYGRAPH_LLM_SCRIPT");
        String[] possiblePaths = {
            override,
            System.getProperty("user.dir") + "/src/main/python/llm_explainer.py",
            "src/main/python/llm_explainer.py",
            "../src/main/python/llm_explainer.py",
            "python/llm_explainer.py",
            "llm_explainer.py"
        };

        for (String path : possiblePaths) {
            if (path == null || path.isBlank()) {
                continue;
            }
            java.io.File file = new java.io.File(path);
            if (file.exists()) {
                log.info("Found Python script at: " + file.getAbsolutePath());
                return file.getAbsolutePath();
            }
        }

        log.warn("Python LLM script not found in any expected location; set WHYGRAPH_LLM_SCRIPT "
            + "to its absolute path or run from the repository root.");
        return null;
    }
    
    /**
     * Call OpenAI API
     */
    private String callOpenAI(String prompt) throws Exception {
        URL url = new URL("https://api.openai.com/v1/chat/completions");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + config.getApiKey());
        conn.setDoOutput(true);
        
        String jsonPayload = String.format(
            "{\"model\":\"%s\",\"messages\":[{\"role\":\"user\",\"content\":%s}],\"max_tokens\":%d,\"temperature\":%.1f}",
            config.getModel(),
            escapeJson(prompt),
            config.getMaxTokens(),
            config.getTemperature()
        );
        
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        }
        
        return parseOpenAIResponse(conn);
    }
    
    /**
     * Call Anthropic Claude API
     */
    private String callAnthropic(String prompt) throws Exception {
        URL url = new URL("https://api.anthropic.com/v1/messages");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", config.getApiKey());
        conn.setRequestProperty("anthropic-version", "2023-06-01");
        conn.setDoOutput(true);
        
        String jsonPayload = String.format(
            "{\"model\":\"%s\",\"max_tokens\":%d,\"messages\":[{\"role\":\"user\",\"content\":%s}]}",
            config.getModel(),
            config.getMaxTokens(),
            escapeJson(prompt)
        );
        
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        }
        
        return parseAnthropicResponse(conn);
    }
    
    /**
     * Call local Ollama instance
     */
    private String callOllama(String prompt) throws Exception {
        URL url = new URL(config.getEndpoint() + "/api/generate");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        log.info(String.format("Calling Ollama endpoint=%s model=%s", config.getEndpoint(), config.getModel()));
        
        String jsonPayload = String.format(
            "{\"model\":\"%s\",\"prompt\":%s,\"stream\":false,\"options\":{\"temperature\":%.1f}}",
            config.getModel(),
            escapeJson(prompt),
            config.getTemperature()
        );
        
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        }
        
        return parseOllamaResponse(conn);
    }
    
    /**
     * Call Azure OpenAI
     */
    private String callAzureOpenAI(String prompt) throws Exception {
        URL url = new URL(config.getEndpoint() + "/openai/deployments/" + config.getDeploymentName() + 
                         "/chat/completions?api-version=2023-12-01-preview");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("api-key", config.getApiKey());
        conn.setDoOutput(true);
        
        String jsonPayload = String.format(
            "{\"messages\":[{\"role\":\"user\",\"content\":%s}],\"max_tokens\":%d,\"temperature\":%.1f}",
            escapeJson(prompt),
            config.getMaxTokens(),
            config.getTemperature()
        );
        
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        }
        
        return parseOpenAIResponse(conn);
    }
    
    /**
     * Parse OpenAI/Azure OpenAI response
     */
    private String parseOpenAIResponse(HttpURLConnection conn) throws Exception {
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new RuntimeException("LLM API call failed with code: " + responseCode);
        }
        
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            
            // Simple JSON parsing for content
            String responseStr = response.toString();
            int contentStart = responseStr.indexOf("\"content\":\"") + 11;
            int contentEnd = responseStr.indexOf("\",", contentStart);
            if (contentEnd == -1) {
                contentEnd = responseStr.indexOf("\"}", contentStart);
            }
            
            if (contentStart > 10 && contentEnd > contentStart) {
                return responseStr.substring(contentStart, contentEnd)
                    .replace("\\n", "\n")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\");
            }
            
            throw new RuntimeException("Failed to parse LLM response");
        }
    }
    
    /**
     * Parse Anthropic response
     */
    private String parseAnthropicResponse(HttpURLConnection conn) throws Exception {
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new RuntimeException("Anthropic API call failed with code: " + responseCode);
        }
        
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            
            // Simple JSON parsing for text content
            String responseStr = response.toString();
            int textStart = responseStr.indexOf("\"text\":\"") + 8;
            int textEnd = responseStr.indexOf("\",", textStart);
            if (textEnd == -1) {
                textEnd = responseStr.indexOf("\"}", textStart);
            }
            
            if (textStart > 7 && textEnd > textStart) {
                return responseStr.substring(textStart, textEnd)
                    .replace("\\n", "\n")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\");
            }
            
            throw new RuntimeException("Failed to parse Anthropic response");
        }
    }
    
    /**
     * Parse Ollama response
     */
    private String parseOllamaResponse(HttpURLConnection conn) throws Exception {
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new RuntimeException("Ollama API call failed with code: " + responseCode);
        }
        
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            
            // Simple JSON parsing for response content
            String responseStr = response.toString();
            int responseStart = responseStr.indexOf("\"response\":\"") + 12;
            int responseEnd = responseStr.indexOf("\",", responseStart);
            if (responseEnd == -1) {
                responseEnd = responseStr.indexOf("\"}", responseStart);
            }
            
            if (responseStart > 11 && responseEnd > responseStart) {
                return responseStr.substring(responseStart, responseEnd)
                    .replace("\\n", "\n")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\");
            }
            
            throw new RuntimeException("Failed to parse Ollama response");
        }
    }
    
    /**
     * Generate fallback explanation when LLM is not available
     */
    private String generateFallbackExplanation(String analysisType, Map<String, Object> data) {
        switch (analysisType) {
            case "why-empty":
                return generateEmptyFallback(data);
            case "why-so-few":
                return generateSoFewFallback(data);
            case "why-so-many":
                return generateSoManyFallback(data);
            default:
                return "Technical analysis completed. LLM explanation not available - please check configuration.";
        }
    }
    
    private String generateEmptyFallback(Map<String, Object> data) {
        return "Your query returned no results. This typically happens when:\n" +
               "• Required data is missing from your graph\n" +
               "• Your WHERE conditions are too restrictive\n" +
               "• There are no matching patterns in the data\n\n" +
               "Check the technical analysis for specific missing components.";
    }
    
    private String generateSoFewFallback(Map<String, Object> data) {
        Object currentCount = data.get("currentCount");
        Object targetCount = data.get("targetCount");
        
        return String.format("Your query returned %s results but you expected at least %s.\n\n" +
                           "Common solutions include:\n" +
                           "• Relaxing WHERE clause constraints\n" +
                           "• Making some relationships optional\n" +
                           "• Expanding your search pattern\n" +
                           "• Adding more data to your graph\n\n" +
                           "See the suggested modifications for specific recommendations.",
                           currentCount, targetCount);
    }
    
    private String generateSoManyFallback(Map<String, Object> data) {
        return "Your query returned more results than expected. This usually means:\n" +
               "• Your graph has high connectivity between nodes\n" +
               "• Missing WHERE constraints allow too many matches\n" +
               "• Some relationships have very high cardinality\n\n" +
               "Consider adding selective predicates or relationship-direction constraints that preserve query intent.";
    }
    
    /**
     * Convert map to JSON string (recursive for nested objects)
     */
    private String mapToJson(Map<String, Object> map) {
        StringBuilder json = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!first) {
                json.append(",");
            }
            first = false;
            json.append("\"").append(entry.getKey()).append("\":");
            json.append(objectToJson(entry.getValue()));
        }
        json.append("}");
        return json.toString();
    }
    
    /**
     * Convert any object to JSON string
     */
    @SuppressWarnings("unchecked")
    private String objectToJson(Object value) {
        if (value == null) {
            return "null";
        } else if (value instanceof String) {
            return escapeJson((String) value);
        } else if (value instanceof Number || value instanceof Boolean) {
            return value.toString();
        } else if (value instanceof Map) {
            return mapToJson((Map<String, Object>) value);
        } else if (value instanceof java.util.List) {
            java.util.List<?> list = (java.util.List<?>) value;
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            for (Object item : list) {
                if (!first) {
                    json.append(",");
                }
                first = false;
                json.append(objectToJson(item));
            }
            json.append("]");
            return json.toString();
        } else {
            // For unknown types, convert to string and escape
            return escapeJson(value.toString());
        }
    }
    
    /**
     * Escape JSON strings properly
     */
    private String escapeJson(String text) {
        return "\"" + text.replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "\\r")
                        .replace("\t", "\\t") + "\"";
    }
    
    /**
     * Configuration class for LLM integration
     */
    public static class ExplanationConfig {
        private final Map<String, Object> options;
        private String resolvedConfigPath;
        
        public ExplanationConfig(Map<String, Object> options) {
            this.options = options != null ? options : new HashMap<>();
            // Load configuration from JSON file and merge
            loadJsonConfig();
        }
        
        private void loadJsonConfig() {
            File externalConfig = findExternalConfigFile();
            if (externalConfig != null) {
                try (InputStream input = new FileInputStream(externalConfig)) {
                    loadConfigFromStream(input, true);
                    resolvedConfigPath = externalConfig.getAbsolutePath();
                    System.out.println("WhyGraph LLM configuration loaded from " + externalConfig.getAbsolutePath());
                    return;
                } catch (Exception e) {
                    System.err.println("Failed to load external LLM configuration: " + e.getMessage());
                }
            }
            System.err.println("WhyGraph LLM configuration not found next to the plugin jar. LLM explanations are disabled.");
            options.put("enable_llm_explanations", false);
        }
        
        private void loadConfigFromStream(InputStream stream, boolean overrideExisting) {
            if (stream == null) {
                return;
            }
            try (InputStream input = stream) {
                ObjectMapper mapper = new ObjectMapper();
                Map<String, Object> root = mapper.readValue(input, new TypeReference<Map<String, Object>>() {});
                applySettingsFromRoot(root, overrideExisting);
            } catch (Exception e) {
                System.err.println("Failed to parse LLM configuration: " + e.getMessage());
            }
        }
        
        @SuppressWarnings("unchecked")
        private void applySettingsFromRoot(Map<String, Object> root, boolean overrideExisting) {
            if (root == null) {
                return;
            }
            Object settingsObj = root.get("llm_settings");
            if (settingsObj instanceof Map) {
                Map<String, Object> settings = (Map<String, Object>) settingsObj;
                for (Map.Entry<String, Object> entry : settings.entrySet()) {
                    String key = entry.getKey();
                    Object value = entry.getValue();
                    
                    if ("default_model".equals(key) && value != null) {
                        applyDefaultModel(value.toString(), overrideExisting);
                        continue;
                    }
                    
                    String normalizedKey = normalizeKey(key);
                    setOption(normalizedKey, value, overrideExisting);
                }
            }
        }
        
        private void setOption(String key, Object value, boolean overrideExisting) {
            if (key == null || value == null) {
                return;
            }
            if (!overrideExisting && options.containsKey(key)) {
                return;
            }
            options.put(key, value);
        }
        
        private String normalizeKey(String key) {
            switch (key) {
                case "enabled":
                    return "enable_llm_explanations";
                case "default_provider":
                    return "llm_provider";
                case "timeout_seconds":
                case "max_tokens":
                case "temperature":
                case "python_environment":
                case "endpoint":
                case "api_key":
                case "model":
                    return key;
                default:
                    return key;
            }
        }
        
        private void applyDefaultModel(String value, boolean overrideExisting) {
            if (value == null || value.isBlank()) {
                return;
            }
            String modelValue = value;
            String providerPrefix = null;
            int underscoreIndex = value.indexOf('_');
            if (underscoreIndex > 0) {
                providerPrefix = value.substring(0, underscoreIndex).toLowerCase(Locale.ROOT);
                modelValue = value.substring(underscoreIndex + 1);
            }
            
            if (providerPrefix != null) {
                switch (providerPrefix) {
                    case "ollama":
                        setOption("llm_provider", "ollama", overrideExisting);
                        break;
                    case "openai":
                        setOption("llm_provider", "openai", overrideExisting);
                        break;
                    case "anthropic":
                        setOption("llm_provider", "anthropic", overrideExisting);
                        break;
                    case "gemini":
                        setOption("llm_provider", "gemini", overrideExisting);
                        break;
                    default:
                        setOption("llm_provider", providerPrefix, overrideExisting);
                }
            } else if (value.toLowerCase(Locale.ROOT).contains("gpt")) {
                setOption("llm_provider", "openai", overrideExisting);
            }
            setOption("model", modelValue, overrideExisting);
        }
        
        private File findExternalConfigFile() {
            List<String> candidates = new ArrayList<>();
            String envPath = System.getenv("WHY_LLM_CONFIG");
            if (envPath != null && !envPath.isBlank()) {
                candidates.add(envPath);
            }
            String sysPath = System.getProperty("why.llm.config");
            if (sysPath != null && !sysPath.isBlank()) {
                candidates.add(sysPath);
            }
            File pluginDir = resolvePluginDirectory();
            if (pluginDir != null) {
                candidates.add(new File(pluginDir, "whygraph-llm-config.json").getAbsolutePath());
                candidates.add(new File(pluginDir, "llm-config.json").getAbsolutePath());
            }
            for (String candidate : candidates) {
                if (candidate == null || candidate.isBlank()) {
                    continue;
                }
                File file = new File(candidate);
                if (file.exists() && file.isFile()) {
                    return file;
                }
            }
            return null;
        }
        
        private File resolvePluginDirectory() {
            try {
                File jar = new File(NaturalLanguageExplainer.class.getProtectionDomain()
                        .getCodeSource().getLocation().toURI());
                File parent = jar.getParentFile();
                if (parent != null && parent.isDirectory()) {
                    return parent;
                }
            } catch (Exception ignored) { }
            return null;
        }
        
        public boolean isEnabled() {
            return (Boolean) options.getOrDefault("enable_llm_explanations", false);
        }
        
        public String getProvider() {
            return (String) options.getOrDefault("llm_provider", "openai");
        }
        
        public String getModel() {
            String provider = getProvider();
            switch (provider) {
                case "openai":
                    return (String) options.getOrDefault("model", "gpt-4");
                case "anthropic":
                    return (String) options.getOrDefault("model", "claude-3-sonnet-20240229");
                case "ollama":
                    return (String) options.getOrDefault("model", "llama2");
                case "azure":
                    return (String) options.getOrDefault("model", "gpt-4");
                default:
                    return "gpt-4";
            }
        }
        
        public String getApiKey() {
            return (String) options.get("api_key");
        }
        
        public String getEndpoint() {
            return (String) options.getOrDefault("endpoint", "http://localhost:11434");
        }
        
        public String getDeploymentName() {
            return (String) options.getOrDefault("deployment_name", "gpt-4");
        }
        
        public int getMaxTokens() {
            return ((Number) options.getOrDefault("max_tokens", 500)).intValue();
        }
        
        public double getTemperature() {
            return ((Number) options.getOrDefault("temperature", 0.7)).doubleValue();
        }
        
        public int getTimeoutSeconds() {
            return ((Number) options.getOrDefault("timeout_seconds", 30)).intValue();
        }
        
        public String getPythonEnvironment() {
            return (String) options.getOrDefault("python_environment", "python3");
        }
        
        public String getResolvedConfigPath() {
            return resolvedConfigPath;
        }
    }
    
    @SuppressWarnings("unchecked")
    private Map<String, Object> parseJsonToMap(String json) {
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(json, Map.class);
        } catch (Exception e) {
            log.warn("Failed to parse JSON for LLM context: " + e.getMessage());
            return null;
        }
    }
}
