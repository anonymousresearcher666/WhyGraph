package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.ast.CypherAST;
import java.util.*;

/**
 * Result of query rewriting operation containing the modified query and metadata
 */
public class RewritingResult {
    
    private String originalQuery;
    private String rewrittenQuery;
    private CypherAST rewrittenAST;
    private long targetCardinality;
    private long finalCardinality;
    private boolean success;
    private int iterations;
    private String explanation;
    private List<ModificationStep> modificationSteps = new ArrayList<>();
    private List<String> errors = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();
    private long executionTimeMs;
    private long estimatedRows = -1L;
    private long estimatedRowsCILower = -1L;
    private long estimatedRowsCIUpper = -1L;
    private double estimatedRowsConfidenceLevel = -1.0;
    private long queueMaxSize = -1L;
    private long statesExplored = -1L;
    private long schemaInconsistentPruned = -1L;
    private SearchDiagnostics searchDiagnostics = new SearchDiagnostics();
    private Map<String, Object> rootCauseSummary = new HashMap<>();
    // Optional A* trace
    private AStarTrace trace;

    public AStarTrace getTrace() {
        return trace;
    }

    public void setTrace(AStarTrace trace) {
        this.trace = trace;
    }
    
    // Multiple query alternatives with costs
    private List<QueryAlternative> alternatives = new ArrayList<>();
    private QueryAlternative bestAlternative;

    /**
     * Captures an A* search trace with per-step details.
     */
    public static class AStarTrace {
        public static class Step {
            public String astHash;
            public String parentAstHash;
            public String rewrittenQuery;
            public String operation;
            public String operationType;
            public int depth;
            public double edgeCost;
            public double plannerCost;
            public double planShapeAdjustment;
            public double statisticalComplexity;
            public double schemaPenalty;
            public double userPenalty;
            public double structuralPenalty;
            public double blockerAdjustment;
            public double learningAdjustment;
            public double unboundedPenalty;
            public double gScore;
            public double hScore;
            public double fScore;
            public long estimatedRows;
            public long boundLower;
            public long boundUpper;
            public String rootOperator;
            public boolean hasIndexAccess;
            public boolean hasFullScan;
            public String bottleneckOperator;
            public String anchorVariable;
            public String anchorProperty;
            public String anchorRelationshipType;
            public boolean goal;
        }

        private final java.util.List<Step> steps = new java.util.ArrayList<>();

        public void addStep(Step step) {
            steps.add(step);
        }

        public java.util.List<Step> getSteps() {
            return steps;
        }
    }

    /** Mutable per-rewrite counters and timers for experiment diagnostics. */
    public static class SearchDiagnostics {
        public long plannerCalls;
        public long plannerCacheHits;
        public long plannerTimeNanos;
        public long candidateCountCalls;
        public long candidateCountBudgetSkips;
        public long candidateCountUpperBoundSkips;
        public long witnessQueryCalls;
        public long witnessQueryTimeNanos;
        public long candidateCountCacheHits;
        public long candidateCountTimeNanos;
        public long parseTimeNanos;
        public long schemaCheckTimeNanos;
        public long boundTimeNanos;
        public long queueTimeNanos;
        public long canonicalizationTimeNanos;
        public long validationTimeNanos;
        public long candidatesGenerated;
        public long syntacticallyInvalid;
        public long schemaPruned;
        public long canonicalDuplicates;
        public long explainPlanned;
        public long frontierInserted;
        public long expanded;
        public long goalsFound;
        public long postHocValidated;
        public boolean budgetExhausted;
        public boolean returnedGeneratedIncumbent;
        public boolean rhoDecreaseCertified;
        public String heuristicMode = "indicator";
        private final List<Integer> instantiatedBranchingFactors = new ArrayList<>();

        public void recordBranchingFactor(int value) {
            instantiatedBranchingFactors.add(Math.max(0, value));
        }

        public Map<String, Object> asMap() {
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("plannerCalls", plannerCalls);
            out.put("plannerCacheHits", plannerCacheHits);
            out.put("plannerTimeMs", plannerTimeNanos / 1_000_000.0);
            out.put("candidateCountCalls", candidateCountCalls);
            out.put("candidateCountBudgetSkips", candidateCountBudgetSkips);
            out.put("candidateCountUpperBoundSkips", candidateCountUpperBoundSkips);
            out.put("witnessQueryCalls", witnessQueryCalls);
            out.put("witnessQueryTimeMs", witnessQueryTimeNanos / 1_000_000.0);
            out.put("candidateCountCacheHits", candidateCountCacheHits);
            out.put("candidateCountTimeMs", candidateCountTimeNanos / 1_000_000.0);
            out.put("parseTimeMs", parseTimeNanos / 1_000_000.0);
            out.put("schemaCheckTimeMs", schemaCheckTimeNanos / 1_000_000.0);
            out.put("boundTimeMs", boundTimeNanos / 1_000_000.0);
            out.put("queueTimeMs", queueTimeNanos / 1_000_000.0);
            out.put("canonicalizationTimeMs", canonicalizationTimeNanos / 1_000_000.0);
            out.put("validationTimeMs", validationTimeNanos / 1_000_000.0);
            out.put("candidatesGenerated", candidatesGenerated);
            out.put("syntacticallyInvalid", syntacticallyInvalid);
            out.put("schemaPruned", schemaPruned);
            out.put("canonicalDuplicates", canonicalDuplicates);
            out.put("explainPlanned", explainPlanned);
            out.put("frontierInserted", frontierInserted);
            out.put("expanded", expanded);
            out.put("goalsFound", goalsFound);
            out.put("postHocValidated", postHocValidated);
            out.put("budgetExhausted", budgetExhausted);
            out.put("returnedGeneratedIncumbent", returnedGeneratedIncumbent);
            out.put("rhoDecreaseCertified", rhoDecreaseCertified);
            out.put("heuristicMode", heuristicMode);
            List<Integer> sorted = new ArrayList<>(instantiatedBranchingFactors);
            Collections.sort(sorted);
            double median = 0.0;
            if (!sorted.isEmpty()) {
                int middle = sorted.size() / 2;
                median = sorted.size() % 2 == 0
                    ? (sorted.get(middle - 1) + sorted.get(middle)) / 2.0
                    : sorted.get(middle);
            }
            out.put("branchingFactorMedian", median);
            out.put("branchingFactorMax", sorted.isEmpty() ? 0 : sorted.get(sorted.size() - 1));
            out.put("branchingFactorStates", sorted.size());
            return out;
        }
    }
    
    // Getters and setters
    public String getOriginalQuery() { return originalQuery; }
    public void setOriginalQuery(String originalQuery) { this.originalQuery = originalQuery; }
    
    public String getRewrittenQuery() { return rewrittenQuery; }
    public void setRewrittenQuery(String rewrittenQuery) { this.rewrittenQuery = rewrittenQuery; }
    
    public CypherAST getRewrittenAST() { return rewrittenAST; }
    public void setRewrittenAST(CypherAST rewrittenAST) { this.rewrittenAST = rewrittenAST; }
    
    public long getTargetCardinality() { return targetCardinality; }
    public void setTargetCardinality(long targetCardinality) { this.targetCardinality = targetCardinality; }
    
    public long getFinalCardinality() { return finalCardinality; }
    public void setFinalCardinality(long finalCardinality) { this.finalCardinality = finalCardinality; }
    
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }
    
    public int getIterations() { return iterations; }
    public void setIterations(int iterations) { this.iterations = iterations; }
    
    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }
    
    public List<ModificationStep> getModificationSteps() { return modificationSteps; }
    public void setModificationSteps(List<ModificationStep> modificationSteps) { 
        this.modificationSteps = modificationSteps != null ? modificationSteps : new ArrayList<>(); 
    }
    
    public List<String> getErrors() { return errors; }
    public void addError(String error) { this.errors.add(error); }
    
    public List<String> getWarnings() { return warnings; }
    public void addWarning(String warning) { this.warnings.add(warning); }
    
    public long getExecutionTimeMs() { return executionTimeMs; }
    public void setExecutionTimeMs(long executionTimeMs) { this.executionTimeMs = executionTimeMs; }

    public long getEstimatedRows() { return estimatedRows; }
    public void setEstimatedRows(long estimatedRows) { this.estimatedRows = estimatedRows; }
    public long getEstimatedRowsCILower() { return estimatedRowsCILower; }
    public void setEstimatedRowsCILower(long estimatedRowsCILower) { this.estimatedRowsCILower = estimatedRowsCILower; }
    public long getEstimatedRowsCIUpper() { return estimatedRowsCIUpper; }
    public void setEstimatedRowsCIUpper(long estimatedRowsCIUpper) { this.estimatedRowsCIUpper = estimatedRowsCIUpper; }
    public double getEstimatedRowsConfidenceLevel() { return estimatedRowsConfidenceLevel; }
    public void setEstimatedRowsConfidenceLevel(double estimatedRowsConfidenceLevel) { this.estimatedRowsConfidenceLevel = estimatedRowsConfidenceLevel; }

    public long getQueueMaxSize() { return queueMaxSize; }
    public void setQueueMaxSize(long queueMaxSize) { this.queueMaxSize = queueMaxSize; }

    public long getStatesExplored() { return statesExplored; }
    public void setStatesExplored(long statesExplored) { this.statesExplored = statesExplored; }

    public long getSchemaInconsistentPruned() { return schemaInconsistentPruned; }
    public void setSchemaInconsistentPruned(long schemaInconsistentPruned) { this.schemaInconsistentPruned = schemaInconsistentPruned; }
    public SearchDiagnostics getSearchDiagnostics() { return searchDiagnostics; }
    public void setSearchDiagnostics(SearchDiagnostics searchDiagnostics) {
        this.searchDiagnostics = searchDiagnostics != null ? searchDiagnostics : new SearchDiagnostics();
    }
    public Map<String, Object> getRootCauseSummary() { return rootCauseSummary; }
    public void setRootCauseSummary(Map<String, Object> rootCauseSummary) {
        this.rootCauseSummary = rootCauseSummary != null ? rootCauseSummary : new HashMap<>();
    }
    
    /**
     * Check if the rewriting achieved the target cardinality
     */
    public boolean achievedTarget() {
        return success && finalCardinality >= targetCardinality;
    }
    
    /**
     * Get the cardinality improvement ratio
     */
    public double getImprovementRatio() {
        if (targetCardinality == 0) return finalCardinality > 0 ? Double.POSITIVE_INFINITY : 1.0;
        return (double) finalCardinality / targetCardinality;
    }
    
    /**
     * Get summary statistics
     */
    public Map<String, Object> getSummary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put("success", success);
        summary.put("originalQuery", originalQuery);
        summary.put("rewrittenQuery", rewrittenQuery);
        summary.put("targetCardinality", targetCardinality);
        summary.put("finalCardinality", finalCardinality);
        summary.put("achievedTarget", achievedTarget());
        summary.put("improvementRatio", getImprovementRatio());
        summary.put("iterations", iterations);
        summary.put("executionTimeMs", executionTimeMs);
        summary.put("queueMaxSize", queueMaxSize);
        summary.put("statesExplored", statesExplored);
        summary.put("schemaInconsistentPruned", schemaInconsistentPruned);
        summary.put("searchDiagnostics", searchDiagnostics.asMap());
        summary.put("rootCauseSummary", rootCauseSummary);
        summary.put("estimatedRowsCiLower", estimatedRowsCILower);
        summary.put("estimatedRowsCiUpper", estimatedRowsCIUpper);
        summary.put("estimatedRowsConfidenceLevel", estimatedRowsConfidenceLevel);
        summary.put("modificationCount", modificationSteps.size());
        summary.put("alternativeCount", alternatives != null ? alternatives.size() : 0);
        summary.put("errorCount", errors.size());
        summary.put("warningCount", warnings.size());
        return summary;
    }
    
    // Multiple alternatives support
    public List<QueryAlternative> getAlternatives() { return alternatives; }
    public void setAlternatives(List<QueryAlternative> alternatives) { this.alternatives = alternatives; }
    public void addAlternative(QueryAlternative alternative) { this.alternatives.add(alternative); }
    
    public QueryAlternative getBestAlternative() { return bestAlternative; }
    public void setBestAlternative(QueryAlternative bestAlternative) { this.bestAlternative = bestAlternative; }
    
    /**
     * Rank alternatives by overall score and set the best one
     */
    public void rankAlternatives() {
        if (!alternatives.isEmpty()) {
            alternatives.sort((a, b) -> Double.compare(a.getOverallScore(), b.getOverallScore()));
            bestAlternative = alternatives.get(0);
        }
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("RewritingResult{\n");
        sb.append("  success=").append(success).append("\n");
        sb.append("  originalQuery='").append(originalQuery).append("'\n");
        sb.append("  rewrittenQuery='").append(rewrittenQuery).append("'\n");
        sb.append("  targetCardinality=").append(targetCardinality).append("\n");
        sb.append("  finalCardinality=").append(finalCardinality).append("\n");
        sb.append("  iterations=").append(iterations).append("\n");
        sb.append("  modifications=").append(modificationSteps.size()).append("\n");
        sb.append("  errors=").append(errors.size()).append("\n");
        sb.append("  warnings=").append(warnings.size()).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
