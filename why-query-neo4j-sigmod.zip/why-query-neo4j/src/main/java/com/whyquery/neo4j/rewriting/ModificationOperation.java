package com.whyquery.neo4j.rewriting;

/**
 * Represents a single modification operation that can be applied to a Cypher AST
 */
public class ModificationOperation {
    
    public enum Type {
        // Relaxation operations (increase results) - for WHY_EMPTY, WHY_FEW
        DELETE_NODE,
        DELETE_RELATIONSHIP,
        DEL_EDGE,                  // formal alias of DELETE_RELATIONSHIP
        REPLACE_RELATIONSHIP_TYPE,
        FLIP_RELATIONSHIP_DIRECTION,
        DELETE_PREDICATE,
        RELAX_ENDPOINT_PREDICATE,  // remove one endpoint property predicate while preserving incident relationship pattern
        WEAKEN_PREDICATE,          // formal alias of RELAX_PROPERTY
        RELAX_LABEL,
        RELAX_PROPERTY,
        RELAX_NODE_PROPERTY,
        MAKE_OPTIONAL,
        REPAIR_END_LABEL,          // repair endpoint label using schema-compatible label
        REPAIR_BOTH_END_LABELS,    // repair both endpoint labels together using one schema-compatible triple;
                                   // seeded only when no single-endpoint repair reaches a compatible triple
        REPAIR_PROPERTY_KEY,       // replace a predicate's property key that no node of the variable's label
                                   // carries by a near-identical key of that label (e.g. naem -> name)

        // Restriction operations (decrease results) - for WHY_MANY
        ADD_PREDICATE,
        ADD_LABEL,
        ADD_EDGE,                  // formal alias of ADD_RELATIONSHIP
        ADD_RELATIONSHIP,
        STRENGTHEN_PREDICATE,      // formal alias of RESTRICT_PROPERTY
        RESTRICT_PROPERTY,
        ADD_LIMIT,
        ADD_ORDER_BY,
        
        // Ranking operations - for WHY_RANK
        MODIFY_ORDER_BY,
        ADD_RANKING_FACTOR,
        REMOVE_RANKING_FACTOR,
        CHANGE_RANKING_DIRECTION,
        ADJUST_RANKING_WEIGHT,
        ADD_SECONDARY_RANKING,
        
        // Path operations - for WHY_PATH  
        CHANGE_PATH_ALGORITHM,
        MODIFY_PATH_LENGTH,
        ADD_PATH_CONSTRAINT,
        REMOVE_PATH_CONSTRAINT,
        CHANGE_RELATIONSHIP_TYPES,
        ADD_PATH_WEIGHT,
        CHANGE_PATH_DIRECTION
    }
    
    private final Type type;
    private final String targetId;
    private final String targetLabel;
    private final String targetProperty;
    private final String targetVariable;
    private final Object[] range;
    
    public ModificationOperation(Type type, String targetId, String targetLabel, 
                               String targetProperty, Object[] range) {
        this(type, targetId, targetLabel, targetProperty, range, null);
    }
    
    public ModificationOperation(Type type, String targetId, String targetLabel,
                               String targetProperty, Object[] range, String targetVariable) {
        this.type = type;
        this.targetId = targetId;
        this.targetLabel = targetLabel;
        this.targetProperty = targetProperty;
        this.targetVariable = targetVariable;
        this.range = range;
    }
    
    public Type getType() { return type; }
    public String getTargetId() { return targetId; }
    public String getTargetLabel() { return targetLabel; }
    public String getTargetProperty() { return targetProperty; }
    public String getTargetVariable() { return targetVariable; }
    public String getTargetRelationshipType() { return targetLabel; } // Reuse for rel types
    public Object[] getRange() { return range; }
    
    @Override
    public String toString() {
        return String.format("ModificationOperation{type=%s, targetId='%s', targetLabel='%s', targetProperty='%s', targetVariable='%s'}", 
                           type, targetId, targetLabel, targetProperty, targetVariable);
    }
}
