package com.whyquery.neo4j.ranking;

/**
 * Types of ranking factors that can influence query result ordering
 */
public enum RankingFactorType {
    
    /**
     * Property-based ranking (e.g., movie.rating, person.age)
     */
    PROPERTY,
    
    /**
     * Node degree or relationship count
     */
    DEGREE,
    
    /**
     * Count aggregation function
     */
    COUNT,
    
    /**
     * Size of collections or strings
     */
    SIZE,
    
    /**
     * Aggregation functions (sum, avg, min, max)
     */
    AGGREGATION,
    
    /**
     * Path length or distance
     */
    PATH_LENGTH,
    
    /**
     * PageRank or other centrality measures
     */
    CENTRALITY,
    
    /**
     * Neo4j internal node/relationship ID
     */
    INTERNAL_ID,
    
    /**
     * Custom expression or function
     */
    EXPRESSION,
    
    /**
     * Temporal factors (creation time, modification time)
     */
    TEMPORAL,
    
    /**
     * Text relevance or similarity scores
     */
    RELEVANCE,
    
    /**
     * Random or pseudo-random ordering
     */
    RANDOM,
    
    /**
     * Generic ranking strategy (connectivity, alphabetical, etc.)
     */
    GENERIC
}