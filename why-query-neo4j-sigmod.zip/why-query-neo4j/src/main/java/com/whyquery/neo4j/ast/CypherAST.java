package com.whyquery.neo4j.ast;

import java.util.*;

/**
 * Formal Cypher Query AST representation following Definition 1 from the unified framework.
 * A Cypher query Q is represented as an AST A_Q = (N, E, ρ, σ) where:
 * - N = {n1, n2, ..., nk} (AST nodes)
 * - E ⊆ N × N (parent-child relationships)
 * - ρ: N → NodeType (node type function)
 * - σ: N → Attributes (node attributes function)
 */
public class CypherAST {
    
    // AST nodes
    private final Map<String, ASTNode> nodes;
    
    // Parent-child relationships (edge source -> list of targets)
    private final Map<String, List<String>> edges;
    
    // Root node of the AST
    private String rootNodeId;
    
    // Unique ID counter for nodes
    private int nodeIdCounter = 0;
    
    public CypherAST() {
        this.nodes = new HashMap<>();
        this.edges = new HashMap<>();
    }
    
    /**
     * Add a node to the AST
     */
    public String addNode(NodeType type, Map<String, Object> attributes) {
        String nodeId = "node_" + (++nodeIdCounter);
        ASTNode node = new ASTNode(nodeId, type, attributes);
        nodes.put(nodeId, node);
        edges.put(nodeId, new ArrayList<>());
        return nodeId;
    }
    
    /**
     * Add an edge between two nodes (parent-child relationship)
     */
    public void addEdge(String parentId, String childId) {
        if (!nodes.containsKey(parentId) || !nodes.containsKey(childId)) {
            throw new IllegalArgumentException("Both nodes must exist in the AST");
        }
        edges.get(parentId).add(childId);
    }
    
    /**
     * Set the root node of the AST
     */
    public void setRoot(String nodeId) {
        if (!nodes.containsKey(nodeId)) {
            throw new IllegalArgumentException("Root node must exist in the AST");
        }
        this.rootNodeId = nodeId;
    }
    
    /**
     * Get the root node
     */
    public ASTNode getRoot() {
        return rootNodeId != null ? nodes.get(rootNodeId) : null;
    }
    
    /**
     * Get a node by ID
     */
    public ASTNode getNode(String nodeId) {
        return nodes.get(nodeId);
    }

    /**
     * Replace a node while preserving its identifier, children, and parent links.
     * This is the safe primitive for transformations that only change a node's
     * syntactic role (for example MATCH to OPTIONAL MATCH).
     */
    public void replaceNodeType(String nodeId, NodeType newType) {
        ASTNode current = nodes.get(nodeId);
        if (current == null) {
            throw new IllegalArgumentException("Node must exist in the AST: " + nodeId);
        }
        if (newType == null) {
            throw new IllegalArgumentException("Replacement node type cannot be null");
        }
        nodes.put(nodeId, new ASTNode(nodeId, newType, current.getAttributes()));
    }
    
    /**
     * Get children of a node
     */
    public List<ASTNode> getChildren(String nodeId) {
        List<String> childIds = edges.get(nodeId);
        if (childIds == null) return new ArrayList<>();
        
        List<ASTNode> children = new ArrayList<>();
        for (String childId : childIds) {
            ASTNode child = nodes.get(childId);
            if (child != null) { // Null check to prevent NPE
                children.add(child);
            }
        }
        return children;
    }
    
    /**
     * Get all nodes of a specific type
     */
    public List<ASTNode> getNodesByType(NodeType type) {
        List<ASTNode> result = new ArrayList<>();
        for (ASTNode node : nodes.values()) {
            if (node.getType() == type) {
                result.add(node);
            }
        }
        return result;
    }
    
    /**
     * Get all variables referenced in the AST
     */
    public Set<String> getVariables() {
        Set<String> variables = new HashSet<>();
        for (ASTNode node : nodes.values()) {
            String variable = node.getAttribute("variable", String.class);
            if (variable != null) {
                variables.add(variable);
            }
        }
        return variables;
    }
    
    /**
     * Get variables that are bound (defined) in the AST
     */
    public Set<String> getBoundVariables() {
        Set<String> boundVars = new HashSet<>();
        
        // Variables are bound by Match patterns and Create statements
        for (ASTNode node : nodes.values()) {
            if (node.getType() == NodeType.NODE || node.getType() == NodeType.RELATIONSHIP) {
                String variable = node.getAttribute("variable", String.class);
                if (variable != null) {
                    boundVars.add(variable);
                }
            }
        }
        
        return boundVars;
    }
    
    /**
     * Get variables referenced in Return clause
     */
    public Set<String> getReturnVariables() {
        Set<String> returnVars = new HashSet<>();
        
        for (ASTNode returnNode : getNodesByType(NodeType.RETURN)) {
            for (ASTNode child : getChildren(returnNode.getId())) {
                if (child.getType() == NodeType.PROPERTY) {
                    String variable = child.getAttribute("variable", String.class);
                    if (variable != null) {
                        returnVars.add(variable);
                    }
                }
            }
        }
        
        return returnVars;
    }
    
    /**
     * Validate AST structure according to Definition 4 (AST Validity Preservation)
     */
    public ValidationResult validateAST() {
        ValidationResult result = new ValidationResult();
        
        // Check that all return variables are bound
        Set<String> returnVars = getReturnVariables();
        Set<String> boundVars = getBoundVariables();
        
        for (String returnVar : returnVars) {
            if (!boundVars.contains(returnVar)) {
                result.addError("Return variable '" + returnVar + "' is not bound");
            }
        }
        
        // Check AST structure integrity
        for (ASTNode node : nodes.values()) {
            switch (node.getType()) {
                case EQUALS: case NOT_EQUALS: case GREATER_THAN: case LESS_THAN:
                case GREATER_THAN_OR_EQUAL: case LESS_THAN_OR_EQUAL:
                    if (getChildren(node.getId()).size() != 2) {
                        result.addError("Comparison requires two operands: " + node.getId());
                    }
                    break;
                default:
                    break;
            }
        }
        if (rootNodeId == null) {
            result.addError("AST must have a root node");
        }
        
        // Check for cycles in the AST (should be a tree)
        if (hasCycles()) {
            result.addError("AST contains cycles");
        }
        
        return result;
    }
    
    /**
     * Check if the AST has cycles
     */
    private boolean hasCycles() {
        if (rootNodeId == null) return false;
        
        Set<String> visited = new HashSet<>();
        Set<String> recursionStack = new HashSet<>();
        
        return hasCyclesDFS(rootNodeId, visited, recursionStack);
    }
    
    private boolean hasCyclesDFS(String nodeId, Set<String> visited, Set<String> recursionStack) {
        visited.add(nodeId);
        recursionStack.add(nodeId);
        
        for (String childId : edges.get(nodeId)) {
            if (!visited.contains(childId)) {
                if (hasCyclesDFS(childId, visited, recursionStack)) {
                    return true;
                }
            } else if (recursionStack.contains(childId)) {
                return true;
            }
        }
        
        recursionStack.remove(nodeId);
        return false;
    }
    
    /**
     * Generate Cypher query from AST
     */
    public String generateCypher() {
        if (rootNodeId == null) {
            return "";
        }
        
        StringBuilder cypher = new StringBuilder();
        generateCypherRecursive(rootNodeId, cypher);
        return cypher.toString().trim();
    }
    
    /**
     * Get operator symbol for a node type
     */
    private String getOperatorSymbol(NodeType type) {
        switch (type) {
            case EQUALS: return "=";
            case GREATER_THAN: return ">";
            case LESS_THAN: return "<";
            case GREATER_THAN_OR_EQUAL: return ">=";
            case LESS_THAN_OR_EQUAL: return "<=";
            case NOT_EQUALS: return "<>";
            default: return "=";
        }
    }
    
    private void generateCypherRecursive(String nodeId, StringBuilder cypher) {
        if (nodeId == null || !nodes.containsKey(nodeId)) {
            return; // Skip deleted or invalid nodes
        }
        
        ASTNode node = nodes.get(nodeId);
        
        switch (node.getType()) {
            case QUERY:
                // Generate child clauses
                for (String childId : edges.get(nodeId)) {
                    generateCypherRecursive(childId, cypher);
                    cypher.append(" ");
                }
                break;
                
            case MATCH:
                cypher.append("MATCH ");
                List<String> matchChildren = edges.get(nodeId);
                if (matchChildren != null) {
                    for (int i = 0; i < matchChildren.size(); i++) {
                        if (i > 0) cypher.append(", ");
                        generateCypherRecursive(matchChildren.get(i), cypher);
                    }
                }
                break;
                
            case OPTIONAL_MATCH:
                cypher.append("OPTIONAL MATCH ");
                List<String> optChildren = edges.get(nodeId);
                if (optChildren != null) {
                    for (int i = 0; i < optChildren.size(); i++) {
                        if (i > 0) cypher.append(", ");
                        generateCypherRecursive(optChildren.get(i), cypher);
                    }
                }
                break;
                
            case WHERE:
                List<String> whereChildren = edges.get(nodeId);
                if (whereChildren != null && !whereChildren.isEmpty()) {
                    // Generate children first to check if any content exists
                    StringBuilder whereContent = new StringBuilder();
                    for (int i = 0; i < whereChildren.size(); i++) {
                        StringBuilder childContent = new StringBuilder();
                        generateCypherRecursive(whereChildren.get(i), childContent);
                        String childStr = childContent.toString().trim();
                        
                        // Only add non-empty children
                        if (!childStr.isEmpty()) {
                            if (whereContent.length() > 0) {
                                whereContent.append(" AND ");
                            }
                            whereContent.append(childStr);
                        }
                    }
                    
                    // Only add WHERE if there's actual content
                    if (whereContent.length() > 0) {
                        cypher.append("WHERE ").append(whereContent).append(" ");
                    }
                }
                break;
                
            case RETURN:
                cypher.append("RETURN ");
                List<String> returnChildren = edges.get(nodeId);
                for (int i = 0; i < returnChildren.size(); i++) {
                    if (i > 0) cypher.append(", ");
                    generateCypherRecursive(returnChildren.get(i), cypher);
                }
                break;
                
            case PATTERN:
                List<String> patternChildren = edges.get(nodeId);
                if (patternChildren != null) {
                    boolean prevWasNode = false;
                    for (String childId : patternChildren) {
                        ASTNode child = nodes.get(childId);
                        boolean currIsNode = child != null && child.getType() == NodeType.NODE;
                        if (prevWasNode && currIsNode) {
                            cypher.append(", ");
                        }
                        generateCypherRecursive(childId, cypher);
                        prevWasNode = currIsNode;
                    }
                }
                break;
                
            case NODE:
                String variable = node.getAttribute("variable", String.class);
                List<String> labels = node.getAttribute("labels", List.class);
                Map<String, Object> properties = node.getAttribute("properties", Map.class);
                
                cypher.append("(");
                if (variable != null) {
                    cypher.append(variable);
                }
                if (labels != null) {
                    for (String label : labels) {
                        cypher.append(":").append(label);
                    }
                }
                if (properties != null && !properties.isEmpty()) {
                    cypher.append(" {");
                    boolean first = true;
                    for (Map.Entry<String, Object> prop : properties.entrySet()) {
                        if (!first) cypher.append(", ");
                        cypher.append(prop.getKey()).append(": ");
                        if (prop.getValue() instanceof String) {
                            cypher.append("'").append(prop.getValue()).append("'");
                        } else {
                            cypher.append(prop.getValue());
                        }
                        first = false;
                    }
                    cypher.append("}");
                }
                cypher.append(")");
                break;
                
            case RELATIONSHIP:
                String relType = node.getAttribute("type", String.class);
                String direction = node.getAttribute("direction", String.class);

                boolean isIn = "IN".equalsIgnoreCase(direction);
                boolean isOut = "OUT".equalsIgnoreCase(direction);

                if (isIn) {
                    cypher.append("<-");
                } else {
                    cypher.append("-");
                }

                String relVariable = node.getAttribute("variable", String.class);
                Map<String, Object> relProperties = node.getAttribute("properties", Map.class);
                if (relType != null || relVariable != null || relProperties != null) {
                    cypher.append("[");
                    if (relVariable != null) cypher.append(relVariable);
                    if (relType != null) cypher.append(":").append(relType);
                    if (relProperties != null && !relProperties.isEmpty()) {
                        cypher.append(" {");
                        boolean firstRelProperty = true;
                        for (Map.Entry<String, Object> prop : relProperties.entrySet()) {
                            if (!firstRelProperty) cypher.append(", ");
                            cypher.append(prop.getKey()).append(": ");
                            if (prop.getValue() instanceof String) {
                                cypher.append("'").append(((String) prop.getValue())
                                    .replace("\\", "\\\\").replace("'", "\\'")).append("'");
                            } else cypher.append(prop.getValue());
                            firstRelProperty = false;
                        }
                        cypher.append("}");
                    }
                    cypher.append("]");
                }

                if (isOut) {
                    cypher.append("->");
                } else {
                    cypher.append("-");
                }
                break;
                
            case PROPERTY:
                String propVariable = node.getAttribute("variable", String.class);
                String propName = node.getAttribute("name", String.class);
                if (propVariable != null && propName != null) {
                    cypher.append(propVariable).append(".").append(propName);
                }
                break;
                
            case LITERAL:
                Object value = node.getAttribute("value", Object.class);
                if (value instanceof String) {
                    cypher.append("'").append(escapeCypherStringLiteral((String) value)).append("'");
                } else if (value != null) {
                    cypher.append(value);
                } else {
                    cypher.append("null");
                }
                break;

            case PREDICATE:
                String predicateExpression = node.getAttribute("expression", String.class);
                if (predicateExpression != null && !predicateExpression.isBlank()) {
                    cypher.append(predicateExpression);
                }
                break;
                
            case BINARY_OP:
                String operator = node.getAttribute("operator", String.class);
                List<String> operands = edges.get(nodeId);
                if (operands != null && operands.size() >= 2) {
                    generateCypherRecursive(operands.get(0), cypher);
                    cypher.append(" ").append(operator).append(" ");
                    generateCypherRecursive(operands.get(1), cypher);
                }
                break;
                
            case VARIABLE:
                String varName = node.getAttribute("name", String.class);
                if (varName != null) {
                    cypher.append(varName);
                }
                break;

            case COUNT:
                cypher.append("COUNT(");
                if (Boolean.TRUE.equals(node.getAttribute("distinct", Boolean.class))) {
                    cypher.append("DISTINCT ");
                }
                if (Boolean.TRUE.equals(node.getAttribute("wildcard", Boolean.class))) {
                    cypher.append("*");
                } else {
                    List<String> countChildren = edges.get(nodeId);
                    if (countChildren != null && !countChildren.isEmpty()) {
                        generateCypherRecursive(countChildren.get(0), cypher);
                    }
                }
                cypher.append(")");
                break;

            case ALIAS:
                List<String> aliasChildren = edges.get(nodeId);
                if (aliasChildren != null && !aliasChildren.isEmpty()) {
                    generateCypherRecursive(aliasChildren.get(0), cypher);
                }
                String aliasName = node.getAttribute("name", String.class);
                if (aliasName != null && !aliasName.isBlank()) {
                    cypher.append(" AS ").append(aliasName);
                }
                break;
                
            case AND:
                List<String> andOperands = edges.get(nodeId);
                if (andOperands != null && !andOperands.isEmpty()) {
                    for (int i = 0; i < andOperands.size(); i++) {
                        if (i > 0) cypher.append(" AND ");
                        generateCypherRecursive(andOperands.get(i), cypher);
                    }
                }
                break;
                
            case OR:
                List<String> orOperands = edges.get(nodeId);
                if (orOperands != null && !orOperands.isEmpty()) {
                    for (int i = 0; i < orOperands.size(); i++) {
                        if (i > 0) cypher.append(" OR ");
                        generateCypherRecursive(orOperands.get(i), cypher);
                    }
                }
                break;
                
            case EQUALS:
            case GREATER_THAN:
            case LESS_THAN:
            case GREATER_THAN_OR_EQUAL:
            case LESS_THAN_OR_EQUAL:
            case NOT_EQUALS:
                List<String> compOperands = edges.get(nodeId);
                if (compOperands != null && compOperands.size() >= 2) {
                    generateCypherRecursive(compOperands.get(0), cypher);
                    
                    // Get operator symbol
                    String opSymbol = getOperatorSymbol(node.getType());
                    cypher.append(" ").append(opSymbol).append(" ");
                    
                    generateCypherRecursive(compOperands.get(1), cypher);
                } else {
                    if (compOperands != null) {
                        for (int i = 0; i < compOperands.size(); i++) {
                            if (i > 0) cypher.append(" ? ");
                            generateCypherRecursive(compOperands.get(i), cypher);
                        }
                    }
                }
                break;
                
            case LIMIT:
                Object limitValue = node.getAttribute("value", Object.class);
                if (limitValue != null) {
                    cypher.append("LIMIT ").append(limitValue.toString());
                }
                break;
                
            case ORDER_BY:
                Object expression = node.getAttribute("expression", Object.class);
                if (expression != null) {
                    cypher.append("ORDER BY ").append(expression.toString());
                }
                break;
                
            default:
                // Handle other node types as needed
                break;
        }
    }

    private String escapeCypherStringLiteral(String value) {
        return value.replace("\\", "\\\\").replace("'", "\\'");
    }
    
    /**
     * Validate AST Transformation according to Theorem: AST Transformation Validity
     * Ensures the AST generates syntactically and semantically valid Cypher
     */
    public ValidationResult validateTransformation() {
        ValidationResult result = new ValidationResult();
        
        // 1. Check structural well-formedness
        ValidationResult structuralResult = validateAST();
        if (!structuralResult.isValid()) {
            result.addErrors(structuralResult.getErrors());
            return result;
        }
        
        // 2. Check variable binding consistency (symbol table validation)
        Set<String> declaredVariables = new HashSet<>();
        Set<String> usedVariables = new HashSet<>();
        
        validateVariableBinding(rootNodeId, declaredVariables, usedVariables);
        
        // Check that all used variables are declared
        for (String usedVar : usedVariables) {
            if (!declaredVariables.contains(usedVar)) {
                result.addError("Variable '" + usedVar + "' is used but not declared");
            }
        }
        
        // 3. Check generated query syntax
        try {
            String generatedQuery = generateCypher();
            if (generatedQuery.trim().isEmpty()) {
                result.addError("Generated query is empty");
            }
            
            // Basic syntax checks
            if (generatedQuery.contains("WHERE ") && !generatedQuery.matches(".*WHERE\\s+\\S+.*")) {
                result.addError("Invalid WHERE clause: empty or malformed");
            }
            
            if (generatedQuery.contains("RETURN ") && !generatedQuery.matches(".*RETURN\\s+\\S+.*")) {
                result.addError("Invalid RETURN clause: empty or malformed");
            }
            
        } catch (Exception e) {
            result.addError("Query generation failed: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Validate variable binding recursively (maintaining symbol table)
     */
    private void validateVariableBinding(String nodeId, Set<String> declaredVariables, Set<String> usedVariables) {
        if (nodeId == null || !nodes.containsKey(nodeId)) return;
        
        ASTNode node = nodes.get(nodeId);
        
        // Variables declared in nodes (patterns)
        if (node.getType() == NodeType.NODE || node.getType() == NodeType.RELATIONSHIP) {
            String variable = node.getAttribute("variable", String.class);
            if (variable != null) {
                declaredVariables.add(variable);
            }
        }
        
        // Variables used in properties and expressions
        if (node.getType() == NodeType.PROPERTY) {
            String variable = node.getAttribute("variable", String.class);
            if (variable != null) {
                usedVariables.add(variable);
            }
        }
        
        if (node.getType() == NodeType.VARIABLE) {
            String varName = node.getAttribute("name", String.class);
            if (varName != null) {
                usedVariables.add(varName);
            }
        }
        
        // Recursively validate children
        List<String> children = edges.get(nodeId);
        if (children != null) {
            for (String childId : children) {
                validateVariableBinding(childId, declaredVariables, usedVariables);
            }
        }
    }

    /**
     * Create a deep copy of this AST
     */
    public CypherAST deepCopy() {
        CypherAST copy = new CypherAST();
        
        // Copy all nodes with original IDs preserved
        for (ASTNode node : nodes.values()) {
            ASTNode copiedNode = new ASTNode(node.getId(), node.getType(), new HashMap<>(node.getAttributes()));
            copy.nodes.put(node.getId(), copiedNode);
            copy.edges.put(node.getId(), new ArrayList<>());
        }
        
        // Copy all edges
        for (Map.Entry<String, List<String>> edge : edges.entrySet()) {
            copy.edges.put(edge.getKey(), new ArrayList<>(edge.getValue()));
        }
        
        // Copy root and counter
        copy.rootNodeId = this.rootNodeId;
        copy.nodeIdCounter = this.nodeIdCounter;
        
        return copy;
    }
    
    /**
     * Get all nodes in the AST
     */
    public Collection<ASTNode> getAllNodes() {
        return nodes.values();
    }
    
    /**
     * Remove a node from the AST
     */
    public void removeNode(String nodeId) {
        if (nodeId == null || !nodes.containsKey(nodeId)) {
            return;
        }
        
        // Remove the node
        nodes.remove(nodeId);
        
        // Remove all edges involving this node
        edges.remove(nodeId);
        
        // Remove references to this node from other edges
        for (List<String> edgeList : edges.values()) {
            edgeList.removeIf(id -> id.equals(nodeId));
        }
        
        // Update root if necessary
        if (nodeId.equals(rootNodeId)) {
            rootNodeId = null;
        }
    }

    /**
     * Get edges map (for internal use)
     */
    public Map<String, List<String>> getEdges() {
        return edges;
    }
    
    /**
     * Validation result for AST validation
     */
    public static class ValidationResult {
        private final List<String> errors = new ArrayList<>();
        private final List<String> warnings = new ArrayList<>();
        
        public void addError(String error) {
            errors.add(error);
        }
        
        public void addErrors(List<String> errorList) {
            errors.addAll(errorList);
        }
        
        public void addWarning(String warning) {
            warnings.add(warning);
        }
        
        public boolean isValid() {
            return errors.isEmpty();
        }
        
        public List<String> getErrors() {
            return errors;
        }
        
        public List<String> getWarnings() {
            return warnings;
        }
    }
}
