package com.whyquery.neo4j.integration;

import com.whyquery.neo4j.ast.*;
import com.whyquery.neo4j.ranking.*;
import com.whyquery.neo4j.paths.*;
import com.whyquery.neo4j.rewriting.*;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.*;

/**
 * Integrates WhyRank and WhyPath systems with the existing A* framework
 * to provide unified why-query functionality.
 */
public class WhyRankPathIntegration {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    private final Neo4jStatistics statistics;
    private final RankingAnalyzer rankingAnalyzer;
    private final PathAnalyzer pathAnalyzer;
    private final QueryRewritingAStar astarRewriter;
    
    public WhyRankPathIntegration(GraphDatabaseService db, Transaction tx, Neo4jStatistics statistics, 
                                 QueryRewritingAStar astarRewriter) {
        this.db = db;
        this.tx = tx;
        this.statistics = statistics;
        this.astarRewriter = astarRewriter;
        this.rankingAnalyzer = new RankingAnalyzer(db, tx, statistics);
        this.pathAnalyzer = new PathAnalyzer(db, tx, statistics);
    }
    
    /**
     * Unified analysis for both ranking and path issues in a query
     */
    public UnifiedAnalysisResult analyzeQuery(String query, WhyQueryType queryType) {
        UnifiedAnalysisResult result = new UnifiedAnalysisResult();
        result.setOriginalQuery(query);
        result.setQueryType(queryType);
        
        try {
            // Parse query to AST
            CypherAST ast = parseQuery(query);
            
            // Analyze ranking if relevant
            if (hasRankingElements(query, queryType)) {
                RankingAnalysis rankingAnalysis = rankingAnalyzer.analyzeRanking(ast, query);
                result.setRankingAnalysis(rankingAnalysis);
                
                // Generate ranking alternatives
                if (rankingAnalysis.hasRanking()) {
                    AlternativeRankingGenerator rankingGenerator = new AlternativeRankingGenerator(db, tx, statistics);
                    List<RankingAlternative> rankingAlternatives = rankingGenerator.generateAlternatives(
                        rankingAnalysis, null, java.util.Collections.emptyList(), "");
                    result.setRankingAlternatives(rankingAlternatives);
                }
            }
            
            // Analyze paths if relevant
            if (hasPathElements(query, queryType)) {
                PathAnalysis pathAnalysis = pathAnalyzer.analyzePaths(ast, query);
                result.setPathAnalysis(pathAnalysis);
                
                // Generate path alternatives
                if (pathAnalysis.hasPathAlgorithms() || pathAnalysis.hasPathConstraints()) {
                    PathAlternativeGenerator pathGenerator = new PathAlternativeGenerator(db, tx, statistics);
                    List<PathAlternative> pathAlternatives = pathGenerator.generateAlternatives(pathAnalysis);
                    result.setPathAlternatives(pathAlternatives);
                }
            }
            
            // Generate unified explanations
            generateUnifiedExplanations(result);
            
            // Convert to A* modification operations
            List<ModificationOperation> modifications = generateModificationOperations(result);
            result.setModificationOperations(modifications);
            
        } catch (Exception e) {
            result.addError("Analysis failed: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Check if query has ranking elements
     */
    private boolean hasRankingElements(String query, WhyQueryType queryType) {
        return queryType == WhyQueryType.WHY_RANK ||
               query.toUpperCase().contains("ORDER BY") ||
               query.toUpperCase().contains("LIMIT");
    }
    
    /**
     * Check if query has path elements
     */
    private boolean hasPathElements(String query, WhyQueryType queryType) {
        return queryType == WhyQueryType.WHY_PATH ||
               pathAnalyzer.hasPathPatterns(query);
    }
    
    /**
     * Parse query to AST (simplified implementation)
     */
    private CypherAST parseQuery(String query) {
        try {
            return CypherASTBuilder.parseQuery(query);
        } catch (Exception e) {
            CypherAST ast = new CypherAST();
            Map<String, Object> queryAttrs = new HashMap<>();
            queryAttrs.put("query", query);
            String rootId = ast.addNode(NodeType.QUERY, queryAttrs);
            ast.setRoot(rootId);
            return ast;
        }
    }
    
    /**
     * Generate unified explanations combining ranking and path insights
     */
    private void generateUnifiedExplanations(UnifiedAnalysisResult result) {
        StringBuilder explanation = new StringBuilder();
        
        // Ranking explanation
        if (result.getRankingAnalysis() != null) {
            RankingExplanationGenerator rankingExplainer = new RankingExplanationGenerator();
            String rankingExplanation = rankingExplainer.explainRankingAnalysis(result.getRankingAnalysis());
            explanation.append("=== Ranking Analysis ===\n").append(rankingExplanation).append("\n");
        }
        
        // Path explanation
        if (result.getPathAnalysis() != null) {
            PathExplanationGenerator pathExplainer = new PathExplanationGenerator(statistics);
            String pathExplanation = pathExplainer.explainPathAnalysis(result.getPathAnalysis());
            explanation.append("=== Path Analysis ===\n").append(pathExplanation).append("\n");
        }
        
        // Combined insights
        if (result.getRankingAnalysis() != null && result.getPathAnalysis() != null) {
            explanation.append("=== Combined Insights ===\n");
            explanation.append(generateCombinedInsights(result));
        }
        
        result.setUnifiedExplanation(explanation.toString());
    }
    
    /**
     * Generate insights that combine ranking and path analysis
     */
    private String generateCombinedInsights(UnifiedAnalysisResult result) {
        StringBuilder insights = new StringBuilder();
        
        RankingAnalysis ranking = result.getRankingAnalysis();
        PathAnalysis path = result.getPathAnalysis();
        
        // Check for path-ranking interactions
        if (ranking.hasRanking() && path.hasPathAlgorithms()) {
            insights.append("• Query combines path finding with result ranking\n");
            
            if (path.getAlgorithmType() == PathAlgorithmType.SHORTEST_PATH) {
                insights.append("• Shortest path ensures minimal hops, then ranking determines order within equal-length paths\n");
            }
            
            if (ranking.getRankingType() == RankingType.IMPLICIT_DEGREE) {
                insights.append("• Path traversal may be influenced by node connectivity used in ranking\n");
            }
        }
        
        // Performance implications
        double pathComplexity = pathAnalyzer.calculatePathComplexity(path);
        int rankingFactors = ranking.getRankingFactors().size();
        
        if (pathComplexity > 5.0 && rankingFactors > 2) {
            insights.append("• High complexity query: complex path finding + multi-factor ranking\n");
            insights.append("• Consider simplifying either path constraints or ranking factors\n");
        }
        
        return insights.toString();
    }
    
    /**
     * Convert analysis results to A* modification operations
     */
    private List<ModificationOperation> generateModificationOperations(UnifiedAnalysisResult result) {
        List<ModificationOperation> operations = new ArrayList<>();
        
        // Convert ranking alternatives to operations
        if (result.getRankingAlternatives() != null) {
            for (RankingAlternative alternative : result.getRankingAlternatives()) {
                ModificationOperation op = convertRankingAlternativeToOperation(alternative);
                if (op != null) {
                    operations.add(op);
                }
            }
        }
        
        // Convert path alternatives to operations
        if (result.getPathAlternatives() != null) {
            for (PathAlternative alternative : result.getPathAlternatives()) {
                ModificationOperation op = convertPathAlternativeToOperation(alternative);
                if (op != null) {
                    operations.add(op);
                }
            }
        }
        
        return operations;
    }
    
    /**
     * Convert ranking alternative to modification operation
     */
    private ModificationOperation convertRankingAlternativeToOperation(RankingAlternative alternative) {
        ModificationOperation.Type operationType;
        
        switch (alternative.getType()) {
            case WEIGHT_ADJUSTMENT:
                operationType = ModificationOperation.Type.ADJUST_RANKING_WEIGHT;
                break;
            case ADD_FACTOR:
                operationType = ModificationOperation.Type.ADD_RANKING_FACTOR;
                break;
            case REMOVE_FACTOR:
                operationType = ModificationOperation.Type.REMOVE_RANKING_FACTOR;
                break;
            case DIRECTION_CHANGE:
                operationType = ModificationOperation.Type.CHANGE_RANKING_DIRECTION;
                break;
            case ALGORITHM_CHANGE:
                operationType = ModificationOperation.Type.MODIFY_ORDER_BY;
                break;
            default:
                return null;
        }
        
        return new ModificationOperation(operationType, "ranking", 
                                       alternative.getTitle(), 
                                       alternative.getDescription(), 
                                       new Object[]{alternative.getEffectivenessScore()});
    }
    
    /**
     * Convert path alternative to modification operation
     */
    private ModificationOperation convertPathAlternativeToOperation(PathAlternative alternative) {
        ModificationOperation.Type operationType;
        
        switch (alternative.getType()) {
            case ALGORITHM_CHANGE:
                operationType = ModificationOperation.Type.CHANGE_PATH_ALGORITHM;
                break;
            case CONSTRAINT_MODIFICATION:
            case CONSTRAINT_ADDITION:
                operationType = ModificationOperation.Type.ADD_PATH_CONSTRAINT;
                break;
            case CONSTRAINT_RELAXATION:
                operationType = ModificationOperation.Type.REMOVE_PATH_CONSTRAINT;
                break;
            case RELATIONSHIP_TYPE_CONSTRAINT:
                operationType = ModificationOperation.Type.CHANGE_RELATIONSHIP_TYPES;
                break;
            case WEIGHT_OPTIMIZATION:
                operationType = ModificationOperation.Type.ADD_PATH_WEIGHT;
                break;
            case DIRECTION_MODIFICATION:
                operationType = ModificationOperation.Type.CHANGE_PATH_DIRECTION;
                break;
            default:
                return null;
        }
        
        return new ModificationOperation(operationType, "path", 
                                       alternative.getTitle(), 
                                       alternative.getDescription(), 
                                       new Object[]{alternative.getEffectivenessScore()});
    }
    
    /**
     * Get improvement suggestions prioritized by effectiveness
     */
    public List<ImprovementSuggestion> getImprovementSuggestions(UnifiedAnalysisResult result) {
        List<ImprovementSuggestion> suggestions = new ArrayList<>();
        
        // Add ranking suggestions
        if (result.getRankingAlternatives() != null) {
            for (RankingAlternative alt : result.getRankingAlternatives()) {
                if (alt.isHighPriority()) {
                    ImprovementSuggestion suggestion = new ImprovementSuggestion();
                    suggestion.setCategory("Ranking");
                    suggestion.setTitle(alt.getTitle());
                    suggestion.setDescription(alt.getDescription());
                    suggestion.setModifiedQuery(alt.getModifiedQuery());
                    suggestion.setEffectiveness(alt.getEffectivenessScore());
                    suggestions.add(suggestion);
                }
            }
        }
        
        // Add path suggestions
        if (result.getPathAlternatives() != null) {
            for (PathAlternative alt : result.getPathAlternatives()) {
                if (alt.isHighlyRecommended()) {
                    ImprovementSuggestion suggestion = new ImprovementSuggestion();
                    suggestion.setCategory("Path");
                    suggestion.setTitle(alt.getTitle());
                    suggestion.setDescription(alt.getDescription());
                    suggestion.setModifiedQuery(alt.getModifiedQuery());
                    suggestion.setEffectiveness(alt.getEffectivenessScore());
                    suggestions.add(suggestion);
                }
            }
        }
        
        // Sort by effectiveness
        suggestions.sort((a, b) -> Double.compare(b.getEffectiveness(), a.getEffectiveness()));
        
        return suggestions;
    }
    
    /**
     * Types of why-queries supported
     */
    public enum WhyQueryType {
        WHY_EMPTY,
        WHY_FEW,
        WHY_MANY,
        WHY_RANK,
        WHY_PATH
    }
}
