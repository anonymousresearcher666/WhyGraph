package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Contains the results of path analysis for a Cypher query
 */
public class PathAnalysis {
    
    private String originalQuery;
    private PathAlgorithmType algorithmType;
    private List<PathPattern> pathPatterns;
    private PathConstraints constraints;
    private List<PathInstance> actualPaths;
    private Map<String, Object> analysisMetadata;
    
    public PathAnalysis() {
        this.pathPatterns = new ArrayList<>();
        this.actualPaths = new ArrayList<>();
        this.analysisMetadata = new HashMap<>();
    }
    
    public String getOriginalQuery() {
        return originalQuery;
    }
    
    public void setOriginalQuery(String originalQuery) {
        this.originalQuery = originalQuery;
    }
    
    public PathAlgorithmType getAlgorithmType() {
        return algorithmType;
    }
    
    public void setAlgorithmType(PathAlgorithmType algorithmType) {
        this.algorithmType = algorithmType;
    }
    
    public List<PathPattern> getPathPatterns() {
        return pathPatterns;
    }
    
    public void setPathPatterns(List<PathPattern> pathPatterns) {
        this.pathPatterns = pathPatterns;
    }
    
    public void addPathPattern(PathPattern pattern) {
        this.pathPatterns.add(pattern);
    }
    
    public PathConstraints getConstraints() {
        return constraints;
    }
    
    public void setConstraints(PathConstraints constraints) {
        this.constraints = constraints;
    }
    
    public List<PathInstance> getActualPaths() {
        return actualPaths;
    }
    
    public void setActualPaths(List<PathInstance> actualPaths) {
        this.actualPaths = actualPaths;
    }
    
    public void addActualPath(PathInstance path) {
        this.actualPaths.add(path);
    }
    
    public Map<String, Object> getAnalysisMetadata() {
        return analysisMetadata;
    }
    
    public void setAnalysisMetadata(Map<String, Object> analysisMetadata) {
        this.analysisMetadata = analysisMetadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.analysisMetadata.put(key, value);
    }
    
    /**
     * Check if the query uses path algorithms
     */
    public boolean hasPathAlgorithms() {
        return algorithmType != PathAlgorithmType.SIMPLE_TRAVERSAL && 
               algorithmType != PathAlgorithmType.FIXED_LENGTH;
    }
    
    /**
     * Check if paths have constraints
     */
    public boolean hasPathConstraints() {
        return constraints != null && (
            constraints.getMinLength() > 1 ||
            constraints.getMaxLength() < Integer.MAX_VALUE ||
            !constraints.getAllowedRelationshipTypes().isEmpty() ||
            constraints.getWeightProperty() != null
        );
    }
    
    /**
     * Get the most complex path pattern
     */
    public PathPattern getMostComplexPattern() {
        if (pathPatterns.isEmpty()) return null;
        
        return pathPatterns.stream()
            .max(Comparator.comparing(this::getPatternComplexity))
            .orElse(null);
    }
    
    /**
     * Calculate complexity score for a pattern
     */
    private double getPatternComplexity(PathPattern pattern) {
        double complexity = 0.0;
        
        switch (pattern.getType()) {
            case FIXED_LENGTH:
                complexity = 1.0;
                break;
            case VARIABLE_LENGTH:
                complexity = 3.0;
                break;
            case SHORTEST_PATH:
                complexity = 5.0;
                break;
            case ALL_SHORTEST_PATHS:
                complexity = 7.0;
                break;
        }
        
        // Add complexity for length range
        int lengthRange = pattern.getMaxLength() - pattern.getMinLength();
        complexity += lengthRange * 0.1;
        
        // Add complexity for multiple relationship types
        complexity += pattern.getRelationshipTypes().size() * 0.2;
        
        return complexity;
    }
    
    /**
     * Get patterns by type
     */
    public List<PathPattern> getPatternsByType(PathPatternType type) {
        List<PathPattern> filtered = new ArrayList<>();
        for (PathPattern pattern : pathPatterns) {
            if (pattern.getType() == type) {
                filtered.add(pattern);
            }
        }
        return filtered;
    }
    
    /**
     * Get average path length from actual paths
     */
    public double getAveragePathLength() {
        if (actualPaths.isEmpty()) return 0.0;
        
        return actualPaths.stream()
            .mapToInt(PathInstance::getLength)
            .average()
            .orElse(0.0);
    }
    
    /**
     * Get average path cost from actual paths
     */
    public double getAveragePathCost() {
        if (actualPaths.isEmpty()) return 0.0;
        
        return actualPaths.stream()
            .mapToDouble(PathInstance::getCost)
            .average()
            .orElse(0.0);
    }
    
    /**
     * Get paths sorted by length
     */
    public List<PathInstance> getPathsSortedByLength() {
        List<PathInstance> sorted = new ArrayList<>(actualPaths);
        sorted.sort(Comparator.comparing(PathInstance::getLength));
        return sorted;
    }
    
    /**
     * Get paths sorted by cost
     */
    public List<PathInstance> getPathsSortedByCost() {
        List<PathInstance> sorted = new ArrayList<>(actualPaths);
        sorted.sort(Comparator.comparing(PathInstance::getCost));
        return sorted;
    }
    
    /**
     * Check if all paths have the same length (indicating shortest path)
     */
    public boolean hasUniformPathLength() {
        if (actualPaths.size() < 2) return true;
        
        int firstLength = actualPaths.get(0).getLength();
        return actualPaths.stream().allMatch(p -> p.getLength() == firstLength);
    }
    
    /**
     * Get summary statistics for paths
     */
    public PathStatistics getPathStatistics() {
        PathStatistics stats = new PathStatistics();
        
        if (!actualPaths.isEmpty()) {
            List<Integer> lengths = actualPaths.stream()
                .mapToInt(PathInstance::getLength)
                .boxed()
                .sorted()
                .collect(java.util.stream.Collectors.toList());
            
            List<Double> costs = actualPaths.stream()
                .mapToDouble(PathInstance::getCost)
                .boxed()
                .sorted()
                .collect(java.util.stream.Collectors.toList());
            
            stats.minLength = lengths.get(0);
            stats.maxLength = lengths.get(lengths.size() - 1);
            stats.avgLength = lengths.stream().mapToInt(Integer::intValue).average().orElse(0.0);
            
            if (!costs.isEmpty()) {
                stats.minCost = costs.get(0);
                stats.maxCost = costs.get(costs.size() - 1);
                stats.avgCost = costs.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
            }
            
            stats.pathCount = actualPaths.size();
        }
        
        return stats;
    }
    
    @Override
    public String toString() {
        return "PathAnalysis{" +
               "algorithmType=" + algorithmType +
               ", patternCount=" + pathPatterns.size() +
               ", actualPathCount=" + actualPaths.size() +
               ", hasConstraints=" + hasPathConstraints() +
               '}';
    }
    
    /**
     * Path statistics summary
     */
    public static class PathStatistics {
        public int pathCount;
        public int minLength;
        public int maxLength;
        public double avgLength;
        public double minCost;
        public double maxCost;
        public double avgCost;
        
        @Override
        public String toString() {
            return String.format("PathStatistics{count=%d, length=[%d-%d, avg=%.1f], cost=[%.2f-%.2f, avg=%.2f]}",
                               pathCount, minLength, maxLength, avgLength, minCost, maxCost, avgCost);
        }
    }
}