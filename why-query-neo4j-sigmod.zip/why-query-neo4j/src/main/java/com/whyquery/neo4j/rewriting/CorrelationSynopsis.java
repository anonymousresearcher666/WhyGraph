package com.whyquery.neo4j.rewriting;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Offline correlation synopsis used to relax the independence assumption
 * without issuing runtime data queries.
 */
public class CorrelationSynopsis {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    static final class Interval {
        final double lower;
        final double upper;

        Interval(double lower, double upper) {
            this.lower = lower;
            this.upper = upper;
        }
    }

    private final Map<String, Interval> pairFactors = new HashMap<>();

    static CorrelationSynopsis loadFromConfiguredPath() {
        String configured = System.getProperty("why.correlation.synopsis.path");
        if (configured == null || configured.isBlank()) {
            configured = System.getenv("WHY_CORRELATION_SYNOPSIS_PATH");
        }
        if (configured == null || configured.isBlank()) {
            return new CorrelationSynopsis();
        }
        Path path = Paths.get(configured);
        if (!Files.exists(path)) {
            return new CorrelationSynopsis();
        }
        return load(path);
    }

    static CorrelationSynopsis load(Path path) {
        CorrelationSynopsis synopsis = new CorrelationSynopsis();
        try {
            JsonNode root = OBJECT_MAPPER.readTree(Files.readAllBytes(path));
            JsonNode pairs = root.get("pair_factors");
            if (pairs == null || !pairs.isArray()) {
                return synopsis;
            }
            Iterator<JsonNode> it = pairs.elements();
            while (it.hasNext()) {
                JsonNode row = it.next();
                String left = text(row, "left");
                String right = text(row, "right");
                if (left == null || right == null) {
                    continue;
                }
                double lower = bounded(row.path("lower").asDouble(1.0));
                double upper = bounded(row.path("upper").asDouble(1.0));
                if (lower > upper) {
                    double tmp = lower;
                    lower = upper;
                    upper = tmp;
                }
                synopsis.pairFactors.put(pairKey(left, right), new Interval(lower, upper));
            }
        } catch (Exception ignored) {
            return new CorrelationSynopsis();
        }
        return synopsis;
    }

    Interval factor(String left, String right) {
        if (left == null || right == null) {
            return new Interval(1.0, 1.0);
        }
        Interval interval = pairFactors.get(pairKey(left, right));
        return interval != null ? interval : new Interval(1.0, 1.0);
    }

    private static String pairKey(String left, String right) {
        return left.compareTo(right) <= 0 ? left + "||" + right : right + "||" + left;
    }

    private static String text(JsonNode node, String field) {
        JsonNode value = node.get(field);
        if (value == null || value.isNull()) {
            return null;
        }
        String s = value.asText();
        return s == null || s.isBlank() ? null : s.trim();
    }

    private static double bounded(double value) {
        if (!Double.isFinite(value) || value <= 0.0) {
            return 1.0;
        }
        return Math.max(0.05, Math.min(20.0, value));
    }
}

