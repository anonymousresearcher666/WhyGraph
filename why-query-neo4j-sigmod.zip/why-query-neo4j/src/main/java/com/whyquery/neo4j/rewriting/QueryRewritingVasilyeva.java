package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.CypherASTQueryGraphParser;
import com.whyquery.neo4j.QueryGraph;
import com.whyquery.neo4j.ast.ASTModificationOperations;
import com.whyquery.neo4j.ast.ASTNode;
import com.whyquery.neo4j.ast.CypherAST;
import com.whyquery.neo4j.ast.CypherASTBuilder;
import com.whyquery.neo4j.ast.NodeType;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.schema.SchemaGraph;
import com.whyquery.neo4j.schema.SchemaPattern;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Subgraph-based relaxation baseline (Vasilyeva-style):
 * MCS enumeration by structural deletions, optionally validated with data-driven counts.
 */
public class QueryRewritingVasilyeva {
    private static final Pattern LIMIT_PATTERN = Pattern.compile("(?i)\\bLIMIT\\s+(\\d+)");
    private static final int MAX_MCS_EDGES = 12;
    private static final Set<ModificationOperation.Type> DEFAULT_ALLOWED =
        Set.of(ModificationOperation.Type.DELETE_RELATIONSHIP);
    private static final Set<ModificationOperation.Type> DEFAULT_RESTRICT =
        Set.of(
            ModificationOperation.Type.ADD_PREDICATE,
            ModificationOperation.Type.ADD_LABEL,
            ModificationOperation.Type.ADD_RELATIONSHIP,
            ModificationOperation.Type.ADD_LIMIT,
            ModificationOperation.Type.RESTRICT_PROPERTY
        );

    private final RewritingConfig config;
    private final DatabaseSchemaCache schemaCache;
    private final SchemaGraph schemaGraph;
    private final boolean useSchema;
    private final boolean useFormalBounds;
    private final boolean enforceConnectedPatterns;
    private final boolean allowRelationshipDeletionRelaxation;
    private final Set<ModificationOperation.Type> allowedOperations;
    private final GraphDatabaseService db;
    private final boolean allowDataQueries;
    private final int queryTimeoutSeconds;
    private long rewriteDeadlineNanos = Long.MAX_VALUE;
    private final Map<String, Long> countCache = new HashMap<>();
    private static final ExecutorService COUNT_EXECUTOR = Executors.newCachedThreadPool();

    private WhyMode whyMode = WhyMode.WHY_EMPTY;
    private long minTarget = 0;
    private long maxTarget = 0;

    private static final class RelationshipEdge {
        private final String relId;
        private final String leftNodeId;
        private final String rightNodeId;
        private final String relType;

        private RelationshipEdge(String relId, String leftNodeId, String rightNodeId, String relType) {
            this.relId = relId;
            this.leftNodeId = leftNodeId;
            this.rightNodeId = rightNodeId;
            this.relType = relType;
        }
    }

    private static final class McsCandidate {
        private final CypherAST ast;
        private final List<ModificationStep> steps;
        private final int edgeCount;
        private final int nodeCount;
        private final long estimatedRows;
        private final long actualCount;
        private final SchemaGraph.SchemaBounds bounds;

        private McsCandidate(CypherAST ast, List<ModificationStep> steps, int edgeCount,
                             int nodeCount, long estimatedRows, long actualCount,
                             SchemaGraph.SchemaBounds bounds) {
            this.ast = ast;
            this.steps = steps;
            this.edgeCount = edgeCount;
            this.nodeCount = nodeCount;
            this.estimatedRows = estimatedRows;
            this.actualCount = actualCount;
            this.bounds = bounds;
        }
    }

    public QueryRewritingVasilyeva(GraphDatabaseService db, RewritingConfig config) {
        this(db, config, DatabaseSchemaCache.getShared(db));
    }

    public QueryRewritingVasilyeva(GraphDatabaseService db, RewritingConfig config, DatabaseSchemaCache schemaCache) {
        this.db = db;
        this.config = config != null ? config : new RewritingConfig();
        this.useSchema = this.config.isUseSchema();
        this.useFormalBounds = this.config.isUseFormalBounds();
        this.enforceConnectedPatterns = this.config.isEnforceConnectedPatterns();
        this.allowRelationshipDeletionRelaxation = this.config.isAllowRelationshipDeletionRelaxation();
        this.allowedOperations = this.config.getAllowedOperations() != null
            ? this.config.getAllowedOperations()
            : DEFAULT_ALLOWED;
        this.allowDataQueries = this.config.isAllowDataQueries();
        this.queryTimeoutSeconds = this.config.getDataDrivenTimeoutSeconds();
        this.schemaCache = schemaCache != null ? schemaCache : DatabaseSchemaCache.getShared(db);
        this.schemaGraph = this.schemaCache.buildSchemaGraph();
    }

    public RewritingResult rewriteQuery(String failedQuery, long targetCardinality,
                                        UserPreferences userPreferences, double modificationThreshold,
                                        WhyMode mode, long minTarget, long maxTarget) {
        long start = System.currentTimeMillis();
        rewriteDeadlineNanos = queryTimeoutSeconds > 0
            ? System.nanoTime() + TimeUnit.SECONDS.toNanos(queryTimeoutSeconds)
            : Long.MAX_VALUE;
        RewritingResult result = new RewritingResult();
        result.setOriginalQuery(failedQuery);
        result.setTargetCardinality(targetCardinality);
        this.whyMode = mode != null ? mode : WhyMode.WHY_EMPTY;

        switch (this.whyMode) {
            case WHY_EMPTY:
                this.minTarget = 1;
                this.maxTarget = Math.max(1, maxTarget > 0 ? maxTarget : targetCardinality);
                break;
            case WHY_FEW:
                this.minTarget = Math.max(1, minTarget);
                this.maxTarget = Math.max(this.minTarget, maxTarget > 0 ? maxTarget : Long.MAX_VALUE);
                break;
            case WHY_MANY:
                this.minTarget = 0;
                this.maxTarget = Math.max(1, maxTarget > 0 ? maxTarget : targetCardinality);
                break;
            default:
                this.minTarget = 1;
                this.maxTarget = Math.max(1, targetCardinality);
        }

        CypherAST originalAST = parseQuery(failedQuery);
        if (originalAST == null) {
            result.addError("Failed to parse query: " + failedQuery);
            result.setExecutionTimeMs(System.currentTimeMillis() - start);
            return result;
        }

        SchemaPattern initialPattern = buildSchemaPattern(originalAST);
        SchemaGraph.SchemaCompatibility initialCompat = schemaGraph.analyzeCompatibility(initialPattern);
        if (useSchema && !initialCompat.isConsistent()
            && !config.isForceRewriteAfterPrecheck()
            && !config.isForceAStarRewrite()) {
            result.addError("Query is schema-unsatisfiable; no compatible schema triples for one or more pattern edges.");
            result.setExecutionTimeMs(System.currentTimeMillis() - start);
            return result;
        }

        if (whyMode == WhyMode.WHY_MANY) {
            return rewriteWhyMany(originalAST, targetCardinality, start);
        }

        if (useMcsBaseline()) {
            RewritingResult mcsResult = rewriteByMcs(failedQuery, originalAST, targetCardinality, start);
            if (mcsResult != null) {
                return mcsResult;
            }
        }

        Deque<SearchState> queue = new ArrayDeque<>();
        String initHash = computeASTHash(originalAST);
        Set<String> visited = new HashSet<>();
        visited.add(initHash);
        queue.add(new SearchState(originalAST, new ArrayList<>()));

        int iterations = 0;
        long queueMax = 1;
        while (!queue.isEmpty() && iterations < config.getMaxIterations() && !deadlineExceeded()) {
            SearchState state = queue.poll();
            iterations++;

            SchemaGraph.SchemaBounds bounds = estimateBounds(state.ast);
            long estimatedRows = estimateCardinality(state.ast, bounds, state.ast.generateCypher());
            if (!state.steps.isEmpty() && isGoal(state.ast, bounds, state.steps.size(), estimatedRows)) {
                result.setSuccess(true);
                result.setRewrittenQuery(state.ast.generateCypher());
                result.setRewrittenAST(state.ast);
                result.setFinalCardinality(estimatedRows);
                result.setEstimatedRows(estimatedRows);
                result.setModificationSteps(state.steps);
                result.setIterations(iterations);
                result.setStatesExplored(iterations);
                result.setQueueMaxSize(queueMax);
                result.setExecutionTimeMs(System.currentTimeMillis() - start);
                return result;
            }

            List<ModificationOperation> operations = getApplicableOperations(state.ast);
            for (ModificationOperation op : operations) {
                ASTModificationOperations.ModificationResult modResult =
                    applyOperation(state.ast, op);
                if (!modResult.isSuccessful()) {
                    continue;
                }
                CypherAST nextAst = modResult.getModifiedAST();
                if (enforceConnectedPatterns && hasCartesianProduct(nextAst)) {
                    continue;
                }

                SchemaPattern nextPattern = buildSchemaPattern(nextAst);
                SchemaGraph.SchemaCompatibility compat = schemaGraph.analyzeCompatibility(nextPattern);
                if (useSchema && !compat.isConsistent()) {
                    continue;
                }

                String hash = computeASTHash(nextAst);
                if (!visited.add(hash)) {
                    continue;
                }

                List<ModificationStep> nextSteps = new ArrayList<>(state.steps);
                nextSteps.add(new ModificationStep(op, modResult.getChanges()));
                queue.add(new SearchState(nextAst, nextSteps));
            }

            queueMax = Math.max(queueMax, queue.size());
        }

        result.setSuccess(false);
        result.addError("No rewrite found within iteration limit.");
        result.setIterations(iterations);
        result.setStatesExplored(iterations);
        result.setQueueMaxSize(queueMax);
        result.setExecutionTimeMs(System.currentTimeMillis() - start);
        return result;
    }

    private RewritingResult rewriteWhyMany(CypherAST originalAST, long targetCardinality, long start) {
        RewritingResult result = new RewritingResult();
        result.setOriginalQuery(originalAST.generateCypher());
        result.setTargetCardinality(targetCardinality);

        Deque<SearchState> queue = new ArrayDeque<>();
        String initHash = computeASTHash(originalAST);
        Set<String> visited = new HashSet<>();
        visited.add(initHash);
        queue.add(new SearchState(originalAST, new ArrayList<>()));

        int iterations = 0;
        long queueMax = 1;
        while (!queue.isEmpty() && iterations < config.getMaxIterations() && !deadlineExceeded()) {
            SearchState state = queue.poll();
            iterations++;

            SchemaGraph.SchemaBounds bounds = estimateBounds(state.ast);
            long estimatedRows = estimateCardinality(state.ast, bounds, state.ast.generateCypher());
            if (!state.steps.isEmpty() && isGoal(state.ast, bounds, state.steps.size(), estimatedRows)) {
                result.setSuccess(true);
                result.setRewrittenQuery(state.ast.generateCypher());
                result.setRewrittenAST(state.ast);
                result.setFinalCardinality(estimatedRows);
                result.setEstimatedRows(estimatedRows);
                result.setModificationSteps(state.steps);
                result.setIterations(iterations);
                result.setStatesExplored(iterations);
                result.setQueueMaxSize(queueMax);
                result.setExecutionTimeMs(System.currentTimeMillis() - start);
                return result;
            }

            List<ModificationOperation> operations = getRestrictionOperations(state.ast);
            for (ModificationOperation op : operations) {
                ASTModificationOperations.ModificationResult modResult =
                    applyOperation(state.ast, op);
                if (!modResult.isSuccessful()) {
                    continue;
                }
                CypherAST nextAst = modResult.getModifiedAST();
                if (enforceConnectedPatterns && hasCartesianProduct(nextAst)) {
                    continue;
                }

                SchemaPattern nextPattern = buildSchemaPattern(nextAst);
                SchemaGraph.SchemaCompatibility compat = schemaGraph.analyzeCompatibility(nextPattern);
                if (useSchema && !compat.isConsistent()) {
                    continue;
                }

                String hash = computeASTHash(nextAst);
                if (!visited.add(hash)) {
                    continue;
                }

                List<ModificationStep> nextSteps = new ArrayList<>(state.steps);
                nextSteps.add(new ModificationStep(op, modResult.getChanges()));
                queue.add(new SearchState(nextAst, nextSteps));
            }

            queueMax = Math.max(queueMax, queue.size());
        }

        result.setSuccess(false);
        result.addError("No rewrite found within iteration limit.");
        result.setIterations(iterations);
        result.setStatesExplored(iterations);
        result.setQueueMaxSize(queueMax);
        result.setExecutionTimeMs(System.currentTimeMillis() - start);
        return result;
    }

    private boolean useMcsBaseline() {
        if (allowedOperations == null || allowedOperations.isEmpty()) {
            return false;
        }
        if (!allowedOperations.contains(ModificationOperation.Type.DELETE_RELATIONSHIP)
            || !allowedOperations.contains(ModificationOperation.Type.DELETE_NODE)) {
            return false;
        }
        for (ModificationOperation.Type type : allowedOperations) {
            if (type != ModificationOperation.Type.DELETE_RELATIONSHIP
                && type != ModificationOperation.Type.DELETE_NODE) {
                return false;
            }
        }
        return true;
    }

    private RewritingResult rewriteByMcs(String failedQuery, CypherAST originalAST,
                                         long targetCardinality, long start) {
        if (originalAST == null || failedQuery == null) {
            return null;
        }

        List<RelationshipEdge> relEdges = buildRelationshipEdges(originalAST);
        int relCount = relEdges.size();
        if (relCount > MAX_MCS_EDGES) {
            return null;
        }

        List<ASTNode> nodes = originalAST.getNodesByType(NodeType.NODE);
        List<String> nodeIds = new ArrayList<>();
        for (ASTNode node : nodes) {
            nodeIds.add(node.getId());
        }

        McsCandidate best = null;
        int iterations = 0;

        boolean requireConnected = true;
        for (int k = relCount; k >= 0; k--) {
            if (k == 0) {
                for (String nodeId : nodeIds) {
                    iterations++;
                    Set<String> keepNodes = Set.of(nodeId);
                    McsCandidate candidate = evaluateCandidate(originalAST, keepNodes, Set.of(), requireConnected);
                    if (candidate == null) {
                        continue;
                    }
                    if (bestCandidate(best, candidate)) {
                        best = candidate;
                    }
                }
            } else {
                List<int[]> combos = new ArrayList<>();
                buildCombos(relCount, k, 0, new int[k], 0, combos);
                for (int[] combo : combos) {
                    iterations++;
                    Set<String> keepRels = new HashSet<>();
                    Set<String> keepNodes = new HashSet<>();
                    for (int idx : combo) {
                        RelationshipEdge edge = relEdges.get(idx);
                        keepRels.add(edge.relId);
                        keepNodes.add(edge.leftNodeId);
                        keepNodes.add(edge.rightNodeId);
                    }
                    if (requireConnected && !isConnected(keepRels, relEdges, originalAST)) {
                        continue;
                    }
                    McsCandidate candidate = evaluateCandidate(originalAST, keepNodes, keepRels, requireConnected);
                    if (candidate == null) {
                        continue;
                    }
                    if (bestCandidate(best, candidate)) {
                        best = candidate;
                    }
                }
            }
            if (best != null && best.edgeCount == k) {
                break;
            }
        }

        RewritingResult result = new RewritingResult();
        result.setOriginalQuery(failedQuery);
        result.setTargetCardinality(targetCardinality);
        result.setIterations(iterations);
        result.setStatesExplored(iterations);
        result.setQueueMaxSize(iterations);
        result.setExecutionTimeMs(System.currentTimeMillis() - start);
        if (best == null) {
            result.setSuccess(false);
            result.addError("No rewrite found within MCS search space.");
            return result;
        }

        long finalCount = best.actualCount >= 0 ? best.actualCount : best.estimatedRows;
        result.setSuccess(true);
        result.setRewrittenQuery(best.ast.generateCypher());
        result.setRewrittenAST(best.ast);
        result.setFinalCardinality(finalCount);
        result.setEstimatedRows(best.estimatedRows);
        result.setModificationSteps(best.steps);
        return result;
    }

    private List<RelationshipEdge> buildRelationshipEdges(CypherAST ast) {
        List<RelationshipEdge> edges = new ArrayList<>();
        if (ast == null) {
            return edges;
        }
        for (ASTNode rel : ast.getNodesByType(NodeType.RELATIONSHIP)) {
            RelationshipNodes endpoints = extractRelationshipNodes(ast, rel.getId());
            if (endpoints == null) {
                continue;
            }
            String relType = rel.getAttribute("type", String.class);
            edges.add(new RelationshipEdge(rel.getId(), endpoints.leftNodeId, endpoints.rightNodeId, relType));
        }
        return edges;
    }

    private static void buildCombos(int n, int k, int start, int[] current, int depth, List<int[]> output) {
        if (depth == k) {
            output.add(current.clone());
            return;
        }
        for (int i = start; i <= n - (k - depth); i++) {
            current[depth] = i;
            buildCombos(n, k, i + 1, current, depth + 1, output);
        }
    }

    private boolean isConnected(Set<String> relIds, List<RelationshipEdge> edges, CypherAST ast) {
        Map<String, Set<String>> adjacency = new HashMap<>();
        Set<String> topologyNodes = new HashSet<>();
        for (RelationshipEdge edge : edges) {
            if (!relIds.contains(edge.relId)) {
                continue;
            }
            String left = topologyNodeKey(ast, edge.leftNodeId);
            String right = topologyNodeKey(ast, edge.rightNodeId);
            topologyNodes.add(left);
            topologyNodes.add(right);
            adjacency.computeIfAbsent(left, k -> new HashSet<>()).add(right);
            adjacency.computeIfAbsent(right, k -> new HashSet<>()).add(left);
        }
        if (topologyNodes.size() <= 1) {
            return true;
        }
        String start = topologyNodes.iterator().next();
        Deque<String> queue = new ArrayDeque<>();
        Set<String> visited = new HashSet<>();
        queue.add(start);
        visited.add(start);
        while (!queue.isEmpty()) {
            String current = queue.poll();
            Set<String> neighbors = adjacency.get(current);
            if (neighbors == null) {
                continue;
            }
            for (String next : neighbors) {
                if (visited.add(next)) {
                    queue.add(next);
                }
            }
        }
        return visited.containsAll(topologyNodes);
    }

    private String topologyNodeKey(CypherAST ast, String nodeId) {
        ASTNode node = ast != null ? ast.getNode(nodeId) : null;
        String variable = node != null ? node.getAttribute("variable", String.class) : null;
        return variable != null && !variable.isBlank() ? "var:" + variable : "id:" + nodeId;
    }

    private McsCandidate evaluateCandidate(CypherAST originalAST, Set<String> keepNodes,
                                           Set<String> keepRels, boolean requireConnected) {
        if (originalAST == null) {
            return null;
        }
        CypherAST candidateAst = originalAST.deepCopy();
        List<ModificationStep> steps = new ArrayList<>();
        Set<String> keepVariables = new HashSet<>();
        for (String nodeId : keepNodes) {
            ASTNode node = originalAST.getNode(nodeId);
            if (node != null) {
                String variable = node.getAttribute("variable", String.class);
                if (variable != null) {
                    keepVariables.add(variable);
                }
            }
        }
        for (ASTNode rel : candidateAst.getNodesByType(NodeType.RELATIONSHIP)) {
            if (keepRels.contains(rel.getId())) {
                continue;
            }
            ASTModificationOperations.ModificationResult mod =
                ASTModificationOperations.deleteRelationship(candidateAst, rel.getId());
            if (mod.isSuccessful()) {
                candidateAst = mod.getModifiedAST();
                steps.add(new ModificationStep(
                    new ModificationOperation(ModificationOperation.Type.DELETE_RELATIONSHIP, rel.getId(), null, null, null),
                    mod.getChanges()));
            }
        }
        for (ASTNode node : candidateAst.getNodesByType(NodeType.NODE)) {
            String variable = node.getAttribute("variable", String.class);
            if (keepNodes.contains(node.getId()) || keepVariables.contains(variable)) {
                continue;
            }
            ASTModificationOperations.ModificationResult mod =
                ASTModificationOperations.deleteNode(candidateAst, node.getId());
            if (mod.isSuccessful()) {
                candidateAst = mod.getModifiedAST();
                steps.add(new ModificationStep(
                    new ModificationOperation(ModificationOperation.Type.DELETE_NODE, node.getId(), null, null, null),
                    mod.getChanges()));
            }
        }

        // The full query is the MCS when it already has a data match.  Keeping
        // this zero-edit candidate is essential for topology suites whose
        // smaller cumulative templates are not empty.
        SchemaPattern pattern = buildSchemaPattern(candidateAst);
        SchemaGraph.SchemaCompatibility compat = schemaGraph.analyzeCompatibility(pattern);
        if (useSchema && !compat.isConsistent()) {
            return null;
        }

        SchemaGraph.SchemaBounds bounds = estimateBounds(candidateAst);
        long estimatedRows = estimateCardinality(candidateAst, bounds, candidateAst.generateCypher());
        long actualCount = -1L;
        if (allowDataQueries) {
            actualCount = countQuery(candidateAst.generateCypher());
            if (actualCount < 0) {
                return null;
            }
            if (!isGoalCount(actualCount)) {
                return null;
            }
        } else if (!isGoal(candidateAst, bounds, steps.size(), estimatedRows)) {
            return null;
        }

        int edgeCount = keepRels.size();
        int nodeCount = keepNodes.size();
        return new McsCandidate(candidateAst, steps, edgeCount, nodeCount, estimatedRows, actualCount, bounds);
    }

    private boolean bestCandidate(McsCandidate current, McsCandidate candidate) {
        if (candidate == null) {
            return false;
        }
        if (current == null) {
            return true;
        }
        if (candidate.edgeCount != current.edgeCount) {
            return candidate.edgeCount > current.edgeCount;
        }
        if (candidate.nodeCount != current.nodeCount) {
            return candidate.nodeCount > current.nodeCount;
        }
        long candidateCount = candidate.actualCount >= 0 ? candidate.actualCount : candidate.estimatedRows;
        long currentCount = current.actualCount >= 0 ? current.actualCount : current.estimatedRows;
        if (whyMode == WhyMode.WHY_MANY) {
            return candidateCount > currentCount;
        }
        return candidateCount > currentCount;
    }

    private CypherAST parseQuery(String cypherQuery) {
        try {
            return CypherASTBuilder.parseQuery(cypherQuery);
        } catch (Exception e) {
            return null;
        }
    }

    private SchemaPattern buildSchemaPattern(CypherAST ast) {
        try {
            if (ast == null) {
                return null;
            }
            QueryGraph queryGraph = CypherASTQueryGraphParser.fromAst(ast, ast.generateCypher());
            return SchemaPattern.from(queryGraph);
        } catch (Exception e) {
            return null;
        }
    }

    private List<ModificationOperation> getApplicableOperations(CypherAST ast) {
        List<ModificationOperation> operations = new ArrayList<>();
        boolean allowRelDeletion = allowedOperations.contains(ModificationOperation.Type.DELETE_RELATIONSHIP)
            && (whyMode != WhyMode.WHY_MANY || allowRelationshipDeletionRelaxation);
        if (allowRelDeletion) {
            List<RelationshipCandidate> candidates = new ArrayList<>();
            for (ASTNode rel : ast.getNodesByType(NodeType.RELATIONSHIP)) {
                long support = estimateRelationshipSupport(ast, rel);
                candidates.add(new RelationshipCandidate(rel.getId(), rel.getAttribute("type", String.class), support));
            }
            candidates.sort(Comparator.comparingLong(c -> c.support));
            for (RelationshipCandidate candidate : candidates) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.DELETE_RELATIONSHIP,
                    candidate.relId,
                    candidate.relType,
                    null,
                    null
                ));
            }
        }
        if (allowedOperations.contains(ModificationOperation.Type.DELETE_NODE)) {
            for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.DELETE_NODE,
                    node.getId(),
                    null,
                    null,
                    null
                ));
            }
        }
        return operations;
    }

    private List<ModificationOperation> getRestrictionOperations(CypherAST ast) {
        List<ModificationOperation> operations = new ArrayList<>();
        if (ast == null) {
            return operations;
        }

        if (config.isAllowAddLimit() && allowsRestriction(ModificationOperation.Type.ADD_LIMIT)
            && ast.getNodesByType(NodeType.LIMIT).isEmpty()) {
            if (maxTarget <= Integer.MAX_VALUE) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.ADD_LIMIT,
                    "limit",
                    null,
                    null,
                    new Object[]{(int) maxTarget}
                ));
            }
        }

        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String nodeId = node.getId();
            List<String> labels = node.getAttribute("labels", List.class);
            String label = labels != null && !labels.isEmpty() ? labels.get(0) : null;

            if (label != null && allowsRestriction(ModificationOperation.Type.ADD_PREDICATE)) {
                DatabaseSchemaCache.PropertyInfo best = null;
                String bestProp = null;
                for (Map.Entry<String, DatabaseSchemaCache.PropertyInfo> entry :
                    schemaCache.getPropertyDetailsForLabel(label).entrySet()) {
                    DatabaseSchemaCache.PropertyInfo info = entry.getValue();
                    if (info == null) {
                        continue;
                    }
                    double sel = info.getSelectivity();
                    if (best == null || sel < best.getSelectivity()) {
                        best = info;
                        bestProp = entry.getKey();
                    }
                }
                if (best != null && bestProp != null) {
                    Object value = null;
                    List<Object> common = best.getCommonValues();
                    if (common != null && !common.isEmpty()) {
                        value = common.get(0);
                    }
                    if (value == null) {
                        value = best.getAlternativeValue(null);
                    }
                    if (value != null) {
                        operations.add(new ModificationOperation(
                            ModificationOperation.Type.ADD_PREDICATE,
                            nodeId,
                            label,
                            bestProp,
                            new Object[]{"EQUALS", value}
                        ));
                    }
                }
            }

            if (allowsRestriction(ModificationOperation.Type.ADD_LABEL)) {
                String nextLabel = pickAdditionalLabel(labels);
                if (nextLabel != null) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.ADD_LABEL,
                        nodeId,
                        nextLabel,
                        null,
                        null
                    ));
                }
            }

            if (label != null && allowsRestriction(ModificationOperation.Type.ADD_RELATIONSHIP)) {
                String relType = pickRelationshipType(label);
                if (relType != null) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.ADD_RELATIONSHIP,
                        nodeId,
                        relType,
                        null,
                        null
                    ));
                }
            }
        }

        operations.sort(Comparator
            .comparing((ModificationOperation op) -> op.getType().name())
            .thenComparing(ModificationOperation::getTargetId, Comparator.nullsLast(String::compareTo)));
        return operations;
    }

    private ASTModificationOperations.ModificationResult applyOperation(CypherAST ast, ModificationOperation operation) {
        switch (operation.getType()) {
            case DELETE_NODE:
                return ASTModificationOperations.deleteNode(ast, operation.getTargetId());
            case DELETE_RELATIONSHIP:
                return ASTModificationOperations.deleteRelationship(ast, operation.getTargetId());
            case ADD_PREDICATE:
                return ASTModificationOperations.addPredicate(ast, operation.getTargetId(),
                    operation.getTargetProperty(), operation.getRange());
            case ADD_LABEL:
                return ASTModificationOperations.addLabel(ast, operation.getTargetId(), operation.getTargetLabel());
            case ADD_RELATIONSHIP:
                return ASTModificationOperations.addRelationship(ast, operation.getTargetId(), operation.getTargetLabel());
            case RESTRICT_PROPERTY:
                return ASTModificationOperations.restrictProperty(ast, operation.getTargetId(),
                    operation.getTargetProperty(), operation.getRange());
            case ADD_LIMIT:
                return ASTModificationOperations.addLimit(ast, operation.getRange());
            default:
                ASTModificationOperations.ModificationResult result = new ASTModificationOperations.ModificationResult();
                result.addError("Unsupported operation: " + operation.getType());
                return result;
        }
    }

    private SchemaGraph.SchemaBounds estimateBounds(CypherAST ast) {
        SchemaPattern pattern = buildSchemaPattern(ast);
        SchemaGraph.SchemaCompatibility compat = schemaGraph.analyzeCompatibility(pattern);
        if (useFormalBounds && compat != null && compat.isConsistent()) {
            return computeFormalBounds(pattern, compat);
        }
        return schemaGraph.estimateBounds(pattern);
    }

    private long estimateCardinality(CypherAST ast, SchemaGraph.SchemaBounds bounds, String query) {
        SchemaGraph.SchemaBounds adjusted = applyPredicatesToBounds(ast, bounds);
        long upper = adjusted != null ? adjusted.getUpperBound() : -1L;
        long limit = extractLimitValue(query);
        if (upper >= 0 && limit >= 0) {
            return Math.min(upper, limit);
        }
        return upper;
    }

    private long countQuery(String query) {
        if (!allowDataQueries || query == null || deadlineExceeded()) {
            return -1L;
        }
        Long cached = countCache.get(query);
        if (cached != null) {
            return cached;
        }
        long cap = countCap();
        String countQuery;
        if (cap > 0) {
            countQuery = "CALL () { " + query + " } WITH * LIMIT " + cap + " RETURN count(*) AS cnt";
        } else {
            countQuery = "CALL () { " + query + " } RETURN count(*) AS cnt";
        }
        if (queryTimeoutSeconds <= 0) {
            try (Transaction tx = db.beginTx()) {
                Result result = tx.execute(countQuery);
                long cnt = 0L;
                if (result.hasNext()) {
                    Object val = result.next().get("cnt");
                    if (val instanceof Number) {
                        cnt = ((Number) val).longValue();
                    } else if (val != null) {
                        cnt = Long.parseLong(val.toString());
                    }
                }
                tx.commit();
                countCache.put(query, cnt);
                return cnt;
            } catch (Exception e) {
                countCache.put(query, -1L);
                return -1L;
            }
        }

        AtomicReference<Transaction> txRef = new AtomicReference<>();
        Callable<Long> task = () -> {
            try (Transaction tx = db.beginTx()) {
                txRef.set(tx);
                Result result = tx.execute(countQuery);
                long cnt = 0L;
                if (result.hasNext()) {
                    Object val = result.next().get("cnt");
                    if (val instanceof Number) {
                        cnt = ((Number) val).longValue();
                    } else if (val != null) {
                        cnt = Long.parseLong(val.toString());
                    }
                }
                tx.commit();
                return cnt;
            }
        };

        Future<Long> future = COUNT_EXECUTOR.submit(task);
        try {
            long remainingNanos = Math.max(1L, rewriteDeadlineNanos - System.nanoTime());
            long remainingSeconds = Math.max(1L, TimeUnit.NANOSECONDS.toSeconds(remainingNanos) + 1L);
            long cnt = future.get(Math.min(queryTimeoutSeconds, remainingSeconds), TimeUnit.SECONDS);
            countCache.put(query, cnt);
            return cnt;
        } catch (TimeoutException e) {
            Transaction tx = txRef.get();
            if (tx != null) {
                tx.terminate();
            }
            future.cancel(true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            // Fall through to failure.
        }

        countCache.put(query, -1L);
        return -1L;
    }

    private boolean deadlineExceeded() {
        return System.nanoTime() >= rewriteDeadlineNanos;
    }

    private long countCap() {
        switch (whyMode) {
            case WHY_EMPTY:
                return 1L;
            case WHY_FEW:
            case WHY_MANY:
                if (maxTarget >= Long.MAX_VALUE - 1) {
                    return -1L;
                }
                return Math.max(1L, maxTarget + 1);
            default:
                return -1L;
        }
    }

    private long extractLimitValue(String query) {
        if (query == null) {
            return -1L;
        }
        Matcher matcher = LIMIT_PATTERN.matcher(query);
        if (matcher.find()) {
            try {
                return Long.parseLong(matcher.group(1));
            } catch (NumberFormatException ignored) {
                return -1L;
            }
        }
        return -1L;
    }

    private boolean isGoal(CypherAST ast, SchemaGraph.SchemaBounds bounds, int modificationsApplied, long estimatedCardinality) {
        if (modificationsApplied == 0) {
            return false;
        }
        long mergedLower = -1;
        long mergedUpper = -1;
        if (bounds != null) {
            SchemaGraph.SchemaBounds adjusted = applyPredicatesToBounds(ast, bounds);
            if (adjusted != null) {
                mergedLower = adjusted.getLowerBound();
                mergedUpper = adjusted.getUpperBound();
            }
        } else if (estimatedCardinality >= 0) {
            mergedLower = estimatedCardinality;
            mergedUpper = estimatedCardinality;
        }
        switch (whyMode) {
            case WHY_EMPTY:
                if (mergedLower >= 0) {
                    return mergedLower > 0;
                }
                return mergedUpper > 0;
            case WHY_FEW:
                if (mergedLower >= 0 && mergedUpper >= 0) {
                    return mergedLower >= minTarget && mergedUpper <= maxTarget;
                }
                return false;
            case WHY_MANY:
                if (mergedUpper >= 0) {
                    return mergedUpper <= maxTarget;
                }
                return false;
            default:
                return false;
        }
    }

    private boolean isGoalCount(long count) {
        switch (whyMode) {
            case WHY_EMPTY:
                return count > 0;
            case WHY_FEW:
                return count >= minTarget && count <= maxTarget;
            case WHY_MANY:
                return count <= maxTarget;
            default:
                return false;
        }
    }

    private SchemaGraph.SchemaBounds applyPredicatesToBounds(CypherAST ast, SchemaGraph.SchemaBounds bounds) {
        if (bounds == null || ast == null) {
            return bounds;
        }
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        double product = 1.0;
        for (ASTNode node : ast.getAllNodes()) {
            if (node != null && isPredicateNode(node)) {
                product *= predicateSelectivity(ast, node, varLabelMap);
                if (product == 0.0) {
                    break;
                }
            }
        }
        long lower = bounds.getLowerBound();
        long upper = bounds.getUpperBound();
        if (product <= 0.0) {
            return new SchemaGraph.SchemaBounds(0L, 0L);
        }
        long newLower = Math.max(0L, Math.round(lower * product));
        long newUpper = Math.max(0L, Math.round(upper * product));
        if (whyMode == WhyMode.WHY_MANY) {
            return new SchemaGraph.SchemaBounds(0L, newUpper);
        }
        return new SchemaGraph.SchemaBounds(newLower, Math.max(newLower, newUpper));
    }

    private boolean isPredicateNode(ASTNode node) {
        if (node == null) {
            return false;
        }
        switch (node.getType()) {
            case EQUALS:
            case NOT_EQUALS:
            case GREATER_THAN:
            case GREATER_THAN_OR_EQUAL:
            case LESS_THAN:
            case LESS_THAN_OR_EQUAL:
            case CONTAINS:
            case STARTS_WITH:
                return true;
            default:
                return false;
        }
    }

    private double predicateSelectivity(CypherAST ast, ASTNode predicate, Map<String, String> varLabelMap) {
        if (ast == null || predicate == null) {
            return 1.0;
        }
        List<ASTNode> children = ast.getChildren(predicate.getId());
        if (children == null || children.isEmpty()) {
            return 1.0;
        }
        ASTNode prop = null;
        ASTNode lit = null;
        for (ASTNode child : children) {
            if (child == null) {
                continue;
            }
            if (prop == null && child.getType() == NodeType.PROPERTY) {
                prop = child;
            } else if (lit == null && child.getType() == NodeType.LITERAL) {
                lit = child;
            }
        }
        if (prop == null) {
            return 1.0;
        }
        String variable = prop.getAttribute("variable", String.class);
        String property = prop.getAttribute("name", String.class);
        String label = variable != null ? varLabelMap.get(variable) : null;
        double base = (label != null && property != null)
            ? schemaCache.getPropertySelectivity(label, property)
            : 0.5;
        base = Math.max(0.0, Math.min(1.0, base));

        Object value = lit != null && lit.getType() == NodeType.LITERAL ? lit.getAttribute("value", Object.class) : null;
        if (looksImpossibleLiteral(value)) {
            return 0.0;
        }

        switch (predicate.getType()) {
            case NOT_EQUALS:
                return Math.max(0.0, Math.min(1.0, 1.0 - base));
            case GREATER_THAN:
            case GREATER_THAN_OR_EQUAL:
            case LESS_THAN:
            case LESS_THAN_OR_EQUAL:
                return 0.5;
            case CONTAINS:
            case STARTS_WITH:
                return 0.2;
            case EQUALS:
            default:
                return base;
        }
    }

    private boolean looksImpossibleLiteral(Object value) {
        if (!(value instanceof String)) {
            return false;
        }
        String s = ((String) value).trim();
        if (s.isEmpty()) {
            return false;
        }
        return s.contains("XX_NON_EXISTING") || s.contains("XX-NON-EXISTING");
    }

    private Map<String, String> buildVariableLabelMap(CypherAST ast) {
        Map<String, String> map = new HashMap<>();
        if (ast == null) {
            return map;
        }
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String var = node.getAttribute("variable", String.class);
            List<String> labels = node.getAttribute("labels", List.class);
            if (var != null && labels != null && !labels.isEmpty()) {
                map.put(var, labels.get(0));
            }
        }
        return map;
    }

    private boolean allowsRestriction(ModificationOperation.Type type) {
        if (!DEFAULT_RESTRICT.contains(type)) {
            return allowedOperations == null || allowedOperations.contains(type);
        }
        if (allowedOperations == null || allowedOperations.contains(type)) {
            return true;
        }
        for (ModificationOperation.Type op : allowedOperations) {
            if (DEFAULT_RESTRICT.contains(op)) {
                return false;
            }
        }
        return true;
    }

    private String pickAdditionalLabel(List<String> existing) {
        String best = null;
        long bestCount = Long.MAX_VALUE;
        Set<String> current = existing == null ? Set.of() : new HashSet<>(existing);
        for (String label : schemaCache.getAllLabels()) {
            if (current.contains(label)) {
                continue;
            }
            long count = schemaGraph.getLabelCount(label);
            if (count > 0 && count < bestCount) {
                bestCount = count;
                best = label;
            }
        }
        return best;
    }

    private String pickRelationshipType(String sourceLabel) {
        if (sourceLabel == null) {
            return null;
        }
        String best = null;
        long bestCount = Long.MAX_VALUE;
        for (SchemaGraph.SchemaTriple triple : schemaGraph.getSchemaTriples().keySet()) {
            if (!sourceLabel.equals(triple.getSourceLabel())) {
                continue;
            }
            SchemaGraph.TripleStats stats = schemaGraph.getSchemaTriples().get(triple);
            long count = stats != null ? stats.getEdgeCount() : Long.MAX_VALUE;
            if (count > 0 && count < bestCount) {
                bestCount = count;
                best = triple.getRelationshipType();
            }
        }
        return best;
    }

    private String computeASTHash(CypherAST ast) {
        return Integer.toString(ast.generateCypher().hashCode());
    }

    private static final class RelationshipCandidate {
        private final String relId;
        private final String relType;
        private final long support;

        private RelationshipCandidate(String relId, String relType, long support) {
            this.relId = relId;
            this.relType = relType;
            this.support = support;
        }
    }

    private static final class RelationshipEndpoints {
        private final Set<String> leftLabels;
        private final Set<String> rightLabels;

        private RelationshipEndpoints(Set<String> leftLabels, Set<String> rightLabels) {
            this.leftLabels = leftLabels;
            this.rightLabels = rightLabels;
        }
    }

    private static final class RelationshipNodes {
        private final String leftNodeId;
        private final String rightNodeId;

        private RelationshipNodes(String leftNodeId, String rightNodeId) {
            this.leftNodeId = leftNodeId;
            this.rightNodeId = rightNodeId;
        }
    }

    private boolean hasCartesianProduct(CypherAST ast) {
        if (ast == null) {
            return false;
        }
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }
            int nodeCount = 0;
            int relCount = 0;
            NodeType prev = null;
            for (ASTNode element : elements) {
                if (element == null) {
                    continue;
                }
                NodeType type = element.getType();
                if (type == NodeType.NODE) {
                    nodeCount++;
                    if (prev == NodeType.NODE) {
                        return true;
                    }
                    prev = NodeType.NODE;
                } else if (type == NodeType.RELATIONSHIP) {
                    relCount++;
                    if (prev == NodeType.RELATIONSHIP) {
                        return true;
                    }
                    prev = NodeType.RELATIONSHIP;
                }
            }
            if (nodeCount > 1 && relCount == 0) {
                return true;
            }
        }
        return false;
    }

    private long estimateRelationshipSupport(CypherAST ast, ASTNode rel) {
        if (ast == null || rel == null) {
            return 0L;
        }
        String relType = rel.getAttribute("type", String.class);
        if (relType == null || relType.isBlank()) {
            return 0L;
        }
        RelationshipEndpoints endpoints = extractRelationshipEndpoints(ast, rel.getId());
        if (endpoints == null) {
            return 0L;
        }
        String direction = rel.getAttribute("direction", String.class);
        Set<String> srcLabels = endpoints.leftLabels;
        Set<String> dstLabels = endpoints.rightLabels;
        if ("IN".equalsIgnoreCase(direction)) {
            srcLabels = endpoints.rightLabels;
            dstLabels = endpoints.leftLabels;
        }
        long support = minPositiveEdgeCount(srcLabels, relType, dstLabels);
        if (support <= 0) {
            support = maxEdgeCount(srcLabels, relType, dstLabels);
        }
        return support;
    }

    private RelationshipEndpoints extractRelationshipEndpoints(CypherAST ast, String relationshipId) {
        if (ast == null || relationshipId == null) {
            return null;
        }
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }
            for (int i = 0; i < elements.size(); i++) {
                ASTNode element = elements.get(i);
                if (element == null || element.getType() != NodeType.RELATIONSHIP) {
                    continue;
                }
                if (!relationshipId.equals(element.getId())) {
                    continue;
                }
                Set<String> leftLabels = labelSetForNode(i > 0 ? elements.get(i - 1) : null);
                Set<String> rightLabels = labelSetForNode(i < elements.size() - 1 ? elements.get(i + 1) : null);
                return new RelationshipEndpoints(leftLabels, rightLabels);
            }
        }
        return null;
    }

    private RelationshipNodes extractRelationshipNodes(CypherAST ast, String relationshipId) {
        if (ast == null || relationshipId == null) {
            return null;
        }
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }
            for (int i = 0; i < elements.size(); i++) {
                ASTNode element = elements.get(i);
                if (element == null || element.getType() != NodeType.RELATIONSHIP) {
                    continue;
                }
                if (!relationshipId.equals(element.getId())) {
                    continue;
                }
                ASTNode left = i > 0 ? elements.get(i - 1) : null;
                ASTNode right = i < elements.size() - 1 ? elements.get(i + 1) : null;
                if (left == null || right == null) {
                    return null;
                }
                return new RelationshipNodes(left.getId(), right.getId());
            }
        }
        return null;
    }

    private Set<String> labelSetForNode(ASTNode node) {
        if (node == null || node.getType() != NodeType.NODE) {
            return Set.of(SchemaPattern.ANY_LABEL);
        }
        List<String> labels = node.getAttribute("labels", List.class);
        if (labels == null || labels.isEmpty()) {
            return Set.of(SchemaPattern.ANY_LABEL);
        }
        return new HashSet<>(labels);
    }

    private long maxEdgeCount(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (schemaGraph == null || relType == null || relType.isBlank()) {
            return 0L;
        }
        long max = 0L;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry :
            schemaGraph.getSchemaTriples().entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (!relType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (!labelSetMatches(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!labelSetMatches(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            SchemaGraph.TripleStats stats = entry.getValue();
            if (stats == null) {
                continue;
            }
            long count = stats.getEdgeCount();
            if (count > max) {
                max = count;
            }
        }
        return max;
    }

    private long minPositiveEdgeCount(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (schemaGraph == null || relType == null || relType.isBlank()) {
            return 0L;
        }
        long min = Long.MAX_VALUE;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry :
            schemaGraph.getSchemaTriples().entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (!relType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (!labelSetMatches(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!labelSetMatches(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            SchemaGraph.TripleStats stats = entry.getValue();
            if (stats == null) {
                continue;
            }
            long count = stats.getEdgeCount();
            if (count > 0 && count < min) {
                min = count;
            }
        }
        return min == Long.MAX_VALUE ? 0L : min;
    }

    private boolean labelSetMatches(Set<String> labels, String schemaLabel) {
        if (labels == null || labels.isEmpty()) {
            return true;
        }
        if (labels.contains(SchemaPattern.ANY_LABEL)) {
            return true;
        }
        return labels.contains(schemaLabel);
    }

    private SchemaGraph.SchemaBounds computeFormalBounds(SchemaPattern pattern,
                                                         SchemaGraph.SchemaCompatibility compatibility) {
        if (pattern == null || pattern.isEmpty() || compatibility == null || !compatibility.isConsistent()) {
            return schemaGraph.estimateBounds(pattern);
        }

        List<SchemaPattern.EdgePattern> edges = pattern.getEdges();
        if (edges.isEmpty()) {
            return schemaGraph.estimateBounds(pattern);
        }

        Map<Integer, Set<String>> nodeLabels = new HashMap<>();
        for (SchemaPattern.EdgePattern e : edges) {
            nodeLabels.computeIfAbsent(e.getSourceId(), k -> new HashSet<>()).addAll(e.getSourceLabels());
            nodeLabels.computeIfAbsent(e.getTargetId(), k -> new HashSet<>()).addAll(e.getTargetLabels());
        }

        Map<Integer, Double> nodeEstimates = new HashMap<>();
        for (Map.Entry<Integer, Set<String>> entry : nodeLabels.entrySet()) {
            nodeEstimates.put(entry.getKey(), (double) estimateNodeCount(entry.getValue()));
        }

        int startNode = edges.get(0).getSourceId();
        Set<Integer> visited = new HashSet<>();
        visited.add(startNode);
        List<SchemaPattern.EdgePattern> remaining = new ArrayList<>(edges);
        List<SchemaPattern.EdgePattern> treeEdges = new ArrayList<>();
        while (visited.size() < nodeLabels.size()) {
            SchemaPattern.EdgePattern best = null;
            double bestWeight = Double.MAX_VALUE;
            for (SchemaPattern.EdgePattern e : remaining) {
                boolean connects = visited.contains(e.getSourceId()) ^ visited.contains(e.getTargetId());
                if (!connects) {
                    continue;
                }
                double w = estimateMaxOutDegree(e, compatibility, nodeLabels);
                if (w < bestWeight) {
                    bestWeight = w;
                    best = e;
                }
            }
            if (best == null) {
                break;
            }
            treeEdges.add(best);
            visited.add(best.getSourceId());
            visited.add(best.getTargetId());
            remaining.remove(best);
        }
        List<SchemaPattern.EdgePattern> cycleEdges = new ArrayList<>(remaining);

        Map<Integer, List<SchemaPattern.EdgePattern>> treeAdj = new HashMap<>();
        for (SchemaPattern.EdgePattern e : treeEdges) {
            treeAdj.computeIfAbsent(e.getSourceId(), k -> new ArrayList<>()).add(e);
            treeAdj.computeIfAbsent(e.getTargetId(), k -> new ArrayList<>()).add(e);
        }
        Map<Integer, Integer> parent = new HashMap<>();
        List<Integer> postorder = new ArrayList<>();
        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(startNode);
        parent.put(startNode, -1);
        while (!stack.isEmpty()) {
            int cur = stack.pop();
            postorder.add(cur);
            List<SchemaPattern.EdgePattern> adj = treeAdj.getOrDefault(cur, List.of());
            for (SchemaPattern.EdgePattern e : adj) {
                int nxt = e.getSourceId() == cur ? e.getTargetId() : e.getSourceId();
                if (parent.containsKey(nxt)) {
                    continue;
                }
                parent.put(nxt, cur);
                stack.push(nxt);
            }
        }
        java.util.Collections.reverse(postorder);

        Map<Integer, Double> ub = new HashMap<>();
        Map<Integer, Double> lb = new HashMap<>();

        for (int nodeId : postorder) {
            double nHat = nodeEstimates.getOrDefault(nodeId, 1.0);
            double curUb = nHat;
            double curLb = nHat;
            List<SchemaPattern.EdgePattern> adj = treeAdj.getOrDefault(nodeId, List.of());
            for (SchemaPattern.EdgePattern e : adj) {
                int child = e.getSourceId() == nodeId ? e.getTargetId() : e.getSourceId();
                if (parent.getOrDefault(child, -1) != nodeId) {
                    continue;
                }
                SchemaGraph.TripleStats stats = chooseTripleStats(compatibility.getCompatibleTriples().get(e));
                if (stats == null) {
                    continue;
                }
                double childUb = ub.getOrDefault(child, nodeEstimates.getOrDefault(child, 1.0));
                double childLb = lb.getOrDefault(child, nodeEstimates.getOrDefault(child, 1.0));
                double outMax = estimateMaxOutDegree(stats, nodeLabels.getOrDefault(nodeId, Set.of(SchemaPattern.ANY_LABEL)));
                double outAvg = Math.max(1.0, stats.getAvgOutDegree());

                double edgeCap = Math.max(1.0, stats.getEdgeCount());
                double childUbClamped = Math.min(childUb, edgeCap);
                curUb *= Math.min(outMax, childUbClamped);

                double lbFactor = outAvg * (childLb / Math.max(1.0, nodeEstimates.getOrDefault(child, 1.0)));
                double edgeLowerCap = Math.min(edgeCap, lbFactor);
                curLb *= Math.max(0.0, edgeLowerCap);
            }
            if (curLb > curUb) {
                curLb = curUb;
            }
            ub.put(nodeId, curUb);
            lb.put(nodeId, curLb);
        }

        double upper = ub.getOrDefault(startNode, 0.0);
        double lower = lb.getOrDefault(startNode, 0.0);

        for (SchemaPattern.EdgePattern e : cycleEdges) {
            SchemaGraph.TripleStats stats = chooseTripleStats(compatibility.getCompatibleTriples().get(e));
            if (stats == null) {
                continue;
            }
            double srcN = nodeEstimates.getOrDefault(e.getSourceId(), 1.0);
            double dstN = nodeEstimates.getOrDefault(e.getTargetId(), 1.0);
            double delta = (srcN > 0 && dstN > 0) ? ((double) stats.getEdgeCount() / (srcN * dstN)) : 0.0;
            double multiplier = Math.min(1.0, delta);
            upper *= multiplier;
            lower *= multiplier;
        }

        long lbRounded = Math.max(0L, Math.round(lower));
        long ubRounded = Math.max(0L, Math.round(upper));
        return new SchemaGraph.SchemaBounds(lbRounded, ubRounded);
    }

    private long estimateNodeCount(Set<String> labels) {
        if (labels == null || labels.isEmpty() || labels.contains(SchemaPattern.ANY_LABEL)) {
            return Math.max(1L, schemaGraph.getTotalNodeCount());
        }
        long min = Long.MAX_VALUE;
        for (String l : labels) {
            long c = schemaGraph.getLabelCount(l);
            if (c > 0 && c < min) {
                min = c;
            }
        }
        if (min == Long.MAX_VALUE) {
            return Math.max(1L, schemaGraph.getTotalNodeCount());
        }
        return Math.max(1L, min);
    }

    private SchemaGraph.TripleStats chooseTripleStats(List<SchemaGraph.SchemaTriple> triples) {
        if (triples == null || triples.isEmpty()) {
            return null;
        }
        SchemaGraph.TripleStats best = null;
        long bestEdges = -1;
        for (SchemaGraph.SchemaTriple t : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                t.getSourceLabel(), t.getRelationshipType(), t.getTargetLabel());
            if (stats == null) {
                continue;
            }
            if (stats.getEdgeCount() > bestEdges) {
                bestEdges = stats.getEdgeCount();
                best = stats;
            }
        }
        return best;
    }

    private double estimateMaxOutDegree(SchemaPattern.EdgePattern edge,
                                        SchemaGraph.SchemaCompatibility compatibility,
                                        Map<Integer, Set<String>> nodeLabels) {
        SchemaGraph.TripleStats stats = chooseTripleStats(compatibility.getCompatibleTriples().get(edge));
        if (stats == null) {
            return Double.MAX_VALUE;
        }
        return estimateMaxOutDegree(stats, nodeLabels.getOrDefault(edge.getSourceId(), Set.of(SchemaPattern.ANY_LABEL)));
    }

    private double estimateMaxOutDegree(SchemaGraph.TripleStats stats, Set<String> srcLabels) {
        double avg = Math.max(1.0, stats.getAvgOutDegree());
        double maxOut = stats.getMaxOutDegree() > 0.0 ? stats.getMaxOutDegree() : avg;
        double labelCount = 0.0;
        for (String l : srcLabels == null || srcLabels.isEmpty()
            ? List.of(SchemaPattern.ANY_LABEL) : srcLabels) {
            labelCount = Math.max(labelCount, (double) schemaGraph.getLabelCount(l));
        }
        double perLabel = labelCount > 0 ? (double) stats.getEdgeCount() / labelCount : stats.getEdgeCount();
        return Math.max(1.0, Math.max(Math.max(maxOut, avg), perLabel));
    }

    private static final class SearchState {
        private final CypherAST ast;
        private final List<ModificationStep> steps;

        private SearchState(CypherAST ast, List<ModificationStep> steps) {
            this.ast = ast;
            this.steps = steps;
        }
    }
}
