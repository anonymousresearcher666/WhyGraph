package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Represents an alternative path strategy with specific optimization goals
 */
public class PathStrategy {
    
    private String name;
    private String description;
    private String costFunction;
    private String modifiedQuery;
    private String expectedBenefit;
    private double estimatedEffectiveness;
    private Map<String, Object> parameters;
    private List<String> tradeoffs;
    
    public PathStrategy() {
        this.parameters = new HashMap<>();
        this.tradeoffs = new ArrayList<>();
        this.estimatedEffectiveness = 0.5; // Default neutral effectiveness
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getCostFunction() {
        return costFunction;
    }
    
    public void setCostFunction(String costFunction) {
        this.costFunction = costFunction;
    }
    
    public String getModifiedQuery() {
        return modifiedQuery;
    }
    
    public void setModifiedQuery(String modifiedQuery) {
        this.modifiedQuery = modifiedQuery;
    }
    
    public String getExpectedBenefit() {
        return expectedBenefit;
    }
    
    public void setExpectedBenefit(String expectedBenefit) {
        this.expectedBenefit = expectedBenefit;
    }
    
    public double getEstimatedEffectiveness() {
        return estimatedEffectiveness;
    }
    
    public void setEstimatedEffectiveness(double estimatedEffectiveness) {
        this.estimatedEffectiveness = estimatedEffectiveness;
    }
    
    public Map<String, Object> getParameters() {
        return parameters;
    }
    
    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }
    
    public void addParameter(String key, Object value) {
        this.parameters.put(key, value);
    }
    
    public List<String> getTradeoffs() {
        return tradeoffs;
    }
    
    public void setTradeoffs(List<String> tradeoffs) {
        this.tradeoffs = tradeoffs;
    }
    
    public void addTradeoff(String tradeoff) {
        this.tradeoffs.add(tradeoff);
    }
    
    /**
     * Check if this strategy is recommended (high effectiveness)
     */
    public boolean isRecommended() {
        return estimatedEffectiveness >= 0.7;
    }
    
    /**
     * Check if this strategy is experimental (low confidence)
     */
    public boolean isExperimental() {
        return estimatedEffectiveness < 0.4;
    }
    
    /**
     * Get strategy priority level
     */
    public StrategyPriority getPriority() {
        if (estimatedEffectiveness >= 0.8) {
            return StrategyPriority.HIGH;
        } else if (estimatedEffectiveness >= 0.6) {
            return StrategyPriority.MEDIUM;
        } else if (estimatedEffectiveness >= 0.4) {
            return StrategyPriority.LOW;
        } else {
            return StrategyPriority.EXPERIMENTAL;
        }
    }
    
    /**
     * Generate a complete strategy description
     */
    public String getFullDescription() {
        StringBuilder desc = new StringBuilder();
        
        desc.append(name).append(": ").append(description);
        
        if (expectedBenefit != null && !expectedBenefit.trim().isEmpty()) {
            desc.append("\nBenefit: ").append(expectedBenefit);
        }
        
        if (!tradeoffs.isEmpty()) {
            desc.append("\nTradeoffs: ").append(String.join(", ", tradeoffs));
        }
        
        desc.append("\nEffectiveness: ").append(String.format("%.1f%%", estimatedEffectiveness * 100));
        desc.append(" (").append(getPriority().toString().toLowerCase()).append(" priority)");
        
        return desc.toString();
    }
    
    /**
     * Compare effectiveness with another strategy
     */
    public int compareEffectiveness(PathStrategy other) {
        return Double.compare(this.estimatedEffectiveness, other.estimatedEffectiveness);
    }
    
    @Override
    public String toString() {
        return "PathStrategy{" +
               "name='" + name + '\'' +
               ", costFunction='" + costFunction + '\'' +
               ", effectiveness=" + String.format("%.2f", estimatedEffectiveness) +
               ", priority=" + getPriority() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        PathStrategy that = (PathStrategy) o;
        
        return Objects.equals(name, that.name) &&
               Objects.equals(costFunction, that.costFunction) &&
               Objects.equals(modifiedQuery, that.modifiedQuery);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(name, costFunction, modifiedQuery);
    }
    
    /**
     * Strategy priority levels
     */
    public enum StrategyPriority {
        HIGH,
        MEDIUM, 
        LOW,
        EXPERIMENTAL
    }
}