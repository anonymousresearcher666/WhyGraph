package com.whyquery.neo4j.rewriting;

import com.whyquery.neo4j.CypherParser;
import com.whyquery.neo4j.CypherASTQueryGraphParser;
import com.whyquery.neo4j.QueryGraph;
import com.whyquery.neo4j.ast.*;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import com.whyquery.neo4j.schema.DatabaseSchemaCache;
import com.whyquery.neo4j.schema.SchemaGraph;
import com.whyquery.neo4j.schema.SchemaPattern;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.Result;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A*-Based Query Rewriting with Neo4j Statistics Integration
 * Implementation of Algorithm 1: WhyGraph A*-Based Rewriting from the unified framework
 */
public class QueryRewritingAStar {
    private final GraphDatabaseService db;
    private final Neo4jStatistics statistics;
    private final DatabaseSchemaCache schemaCache;
    private SchemaGraph schemaGraph;
    private final RewritingConfig config;
    private final boolean useSchema;
    private final boolean usePlannerStats;
    private final boolean formalBoundsRequested;
    private final boolean useFormalBounds;
    private final String cardinalityEstimator;
    private final LabelProbabilityCardinalityEstimator labelProbabilityEstimator;
    private final boolean useSoftUpperBounds;
    private final boolean useCalibratedBounds;
    private double heuristicRho;
    private final double heuristicWeight;
    private final double schemaPenaltyWeight;
    private final double costEpsilon;
    private final boolean allowUnboundedOps;
    private final double unboundedPenalty;
    private final boolean allowAddLimit;
    private final boolean useAdmissibleHeuristic;
    private final boolean enforceConnectedPatterns;
    private final boolean allowRelationshipRepairs;
    private final boolean allowDataQueries;
    private final boolean strictEstimateOnly;
    private final int maxCandidateCountCalls;
    private final boolean candidateCountUpperBoundGate;
    private final int candidateExecutionTimeoutSeconds;
    private long rewriteDeadlineNanos = Long.MAX_VALUE;
    private final boolean uncertaintyAwareSearch;
    private final double uncertaintyPenaltyWeight;
    private final boolean learningGuidanceEnabled;
    private final double learningGuidanceStrength;
    private final int learningMinSupport;
    private final boolean paretoFrontierEnabled;
    private final boolean strictTheoremMode;
    private final Set<ModificationOperation.Type> allowedOperations;
    private final RewritingResult.AStarTrace trace;
    private RewritingResult.SearchDiagnostics diagnostics = new RewritingResult.SearchDiagnostics();
    private WhyMode whyMode = WhyMode.WHY_EMPTY;
    private long minTarget = 0;
    private long maxTarget = 0;
    private String originalQueryForRun;
    private Neo4jStatistics.QueryPlanStatistics originalPlanStats;
    private int originalNodeCount = 0;
    private int originalRelationshipCount = 0;
    private int originalPredicateCount = 0;
    private boolean originalLikelySchemaClose = false;
    private Set<String> originalHardPredicateBlockers = Set.of();
    /** Original predicates whose key no node of the variable's label carries and for which a
     *  near-identical key of that label exists: repaired rather than deleted. */
    private Set<String> originalPropertyKeyRepairTargets = Set.of();
    private Set<String> originalSoftPredicateBlockers = Set.of();
    private static final int COMMON_VALUES_SAMPLE_CAP = 10;
    private Map<String, Map<String, Object>> whyNotPropertyBindings = Map.of();
    private Map<String, List<Long>> whyNotIdBindings = Map.of();
    private final Map<String, Boolean> whyNotRecoveryCache = new ConcurrentHashMap<>();
    private static final Pattern LIMIT_PATTERN = Pattern.compile("(?i)\\bLIMIT\\s+(\\d+)");
    private static final String CYCLE_BACKBONE_RELAXATION = "CYCLE_BACKBONE";
    
    // Performance tracking and plan memoization
    private final Map<String, Double> operationCostHistory = new ConcurrentHashMap<>();
    private final Map<String, Long> operationAttemptHistory = new ConcurrentHashMap<>();
    private final Map<String, Long> operationSuccessHistory = new ConcurrentHashMap<>();
    private final Map<String, PlanStatsCacheEntry> planStatsCache = new ConcurrentHashMap<>();
    private final Map<String, Long> actualGoalCountCache = new ConcurrentHashMap<>();
    private final Map<String, Map<String, Double>> relPropertySelectivityCache = new ConcurrentHashMap<>();
    private final Map<String, List<String>> relTypePropertiesCache = new ConcurrentHashMap<>();
    private final CorrelationSynopsis correlationSynopsis;
    private final EstimatorConfidenceModel confidenceModel;
    private double averageExpansionRatio = 2.0; // ρ_avg from the heuristic formula
    
    // Selectivity-driven predicate generation limits
    private static final double PROPERTY_SELECTIVITY_MAX = 0.5; // skip unselective properties
    private static final double REL_PROPERTY_SELECTIVITY_MAX = 0.5;
    private static final double VALUE_SELECTIVITY_MAX = 0.2;    // keep only highly selective values
    private static final int MAX_PROPERTIES_PER_NODE = 3;       // cap predicates per node
    private static final int MAX_PROPERTIES_PER_REL = 2;
    private static final int MAX_RELTYPE_REPLACEMENTS = 3;

    public QueryRewritingAStar(GraphDatabaseService db, Neo4jStatistics statistics, RewritingConfig config) {
        this(db, statistics, config, DatabaseSchemaCache.getShared(db));
    }

    public QueryRewritingAStar(GraphDatabaseService db,
                               Neo4jStatistics statistics,
                               RewritingConfig config,
                               DatabaseSchemaCache schemaCache) {
        this.db = db;
        this.config = config != null ? config : new RewritingConfig();
        this.usePlannerStats = this.config.isUsePlannerStats();
        this.cardinalityEstimator = this.config.getCardinalityEstimator();
        this.useSoftUpperBounds = this.config.isUseSoftUpperBounds();
        this.useCalibratedBounds = this.config.isUseCalibratedBounds();
        this.heuristicRho = Math.max(1.01, this.config.getHeuristicRho());
        this.strictTheoremMode = this.config.isStrictTheoremMode();
        this.heuristicWeight = strictTheoremMode
            ? 1.0
            : Math.max(1.0, this.config.getWeightedAStarWeight());
        this.schemaPenaltyWeight = this.config.getGamma();
        this.costEpsilon = this.config.getCostEpsilon();
        this.useAdmissibleHeuristic = strictTheoremMode || this.config.isUseAdmissibleHeuristic();
        this.allowUnboundedOps = this.config.isAllowUnboundedOps();
        this.unboundedPenalty = this.config.getUnboundedPenalty();
        this.allowAddLimit = !strictTheoremMode && this.config.isAllowAddLimit();
        this.enforceConnectedPatterns = strictTheoremMode || this.config.isEnforceConnectedPatterns();
        this.allowRelationshipRepairs = this.config.isAllowRelationshipRepairs();
        this.allowDataQueries = this.config.isAllowDataQueries();
        this.strictEstimateOnly = this.config.isStrictEstimateOnly();
        this.maxCandidateCountCalls = this.config.getMaxCandidateCountCalls();
        this.candidateCountUpperBoundGate = this.config.isCandidateCountUpperBoundGate();
        this.candidateExecutionTimeoutSeconds =
            Math.max(0, this.config.getDataDrivenTimeoutSeconds());
        this.uncertaintyAwareSearch = !strictTheoremMode && this.config.isUncertaintyAwareSearch();
        this.uncertaintyPenaltyWeight = this.config.getUncertaintyPenaltyWeight();
        this.learningGuidanceEnabled = !strictTheoremMode && this.config.isLearningGuidanceEnabled();
        this.learningGuidanceStrength = this.config.getLearningGuidanceStrength();
        this.learningMinSupport = this.config.getLearningMinSupport();
        this.paretoFrontierEnabled = !strictTheoremMode && this.config.isParetoFrontierEnabled();
        this.allowedOperations = this.config.getAllowedOperations();
        this.statistics = statistics;
        // Always load schema snapshots into memory; "useSchema" only controls pruning/penalties.
        this.schemaCache = schemaCache != null ? schemaCache : DatabaseSchemaCache.getShared(db);
        // A schema snapshot invalidated by a later commit is not guaranteed to
        // over-approximate the live graph, so it cannot safely prune states.
        this.useSchema = this.config.isUseSchema() && this.schemaCache.isSnapshotFresh();
        // Formal max-degree bounds are certificates, not heuristics.  A persisted
        // snapshot may only participate while it matches Neo4j's durable
        // last-committed transaction id.
        this.formalBoundsRequested = this.config.isUseFormalBounds();
        this.useFormalBounds = this.formalBoundsRequested && this.schemaCache.isSnapshotFresh();
        this.schemaGraph = this.schemaCache.buildSchemaGraph();
        this.labelProbabilityEstimator = new LabelProbabilityCardinalityEstimator(this.schemaCache);
        this.correlationSynopsis = CorrelationSynopsis.loadFromConfiguredPath();
        this.confidenceModel = EstimatorConfidenceModel.loadFromConfiguredPath();
        this.trace = new RewritingResult.AStarTrace();
        if (useAdmissibleHeuristic) {
            this.heuristicRho = Math.max(this.heuristicRho, computeBoundedRho());
        }
    }

    public void setWhyNotBindings(Map<String, Map<String, Object>> propertyBindings,
                                  Map<String, List<Long>> idBindings) {
        this.whyNotPropertyBindings = sanitizePropertyBindings(propertyBindings);
        this.whyNotIdBindings = sanitizeIdBindings(idBindings);
        this.whyNotRecoveryCache.clear();
    }

    private Map<String, Map<String, Object>> sanitizePropertyBindings(Map<String, Map<String, Object>> bindings) {
        if (bindings == null || bindings.isEmpty()) {
            return Map.of();
        }
        Map<String, Map<String, Object>> sanitized = new LinkedHashMap<>();
        for (Map.Entry<String, Map<String, Object>> entry : bindings.entrySet()) {
            String var = entry.getKey();
            if (var == null || var.isBlank() || entry.getValue() == null || entry.getValue().isEmpty()) {
                continue;
            }
            Map<String, Object> props = new LinkedHashMap<>();
            for (Map.Entry<String, Object> prop : entry.getValue().entrySet()) {
                if (prop.getKey() != null && !prop.getKey().isBlank()) {
                    props.put(prop.getKey(), prop.getValue());
                }
            }
            if (!props.isEmpty()) {
                sanitized.put(var, props);
            }
        }
        return sanitized.isEmpty() ? Map.of() : Collections.unmodifiableMap(sanitized);
    }

    private Map<String, List<Long>> sanitizeIdBindings(Map<String, List<Long>> bindings) {
        if (bindings == null || bindings.isEmpty()) {
            return Map.of();
        }
        Map<String, List<Long>> sanitized = new LinkedHashMap<>();
        for (Map.Entry<String, List<Long>> entry : bindings.entrySet()) {
            String var = entry.getKey();
            List<Long> ids = entry.getValue();
            if (var == null || var.isBlank() || ids == null || ids.isEmpty()) {
                continue;
            }
            List<Long> clean = new ArrayList<>();
            for (Long id : ids) {
                if (id != null && id >= 0) {
                    clean.add(id);
                }
            }
            if (!clean.isEmpty()) {
                sanitized.put(var, Collections.unmodifiableList(clean));
            }
        }
        return sanitized.isEmpty() ? Map.of() : Collections.unmodifiableMap(sanitized);
    }
    
    private String findParentPredicate(CypherAST ast, String nodeId) {
        for (Map.Entry<String, List<String>> entry : ast.getEdges().entrySet()) {
            if (entry.getValue().contains(nodeId)) {
                ASTNode parent = ast.getNode(entry.getKey());
                if (parent != null && isPredicateNode(parent)) {
                    return parent.getId();
                }
            }
        }
        return null;
    }

    private double calculateWeightedFScore(double gScore, double hScore) {
        return gScore + (heuristicWeight * hScore);
    }

    private void setOriginalPlannerContext(String query) {
        this.originalQueryForRun = query;
        this.originalPlanStats = usePlannerStats && query != null
            ? getPlannerStatistics(query)
            : new Neo4jStatistics.QueryPlanStatistics(-1L, -1L, -1L);
    }

    private void applyPlanDetails(RewritingResult.AStarTrace.Step step,
                                  Neo4jStatistics.QueryPlanStatistics planStats) {
        if (step == null || planStats == null) {
            return;
        }
        step.rootOperator = planStats.getRootOperator();
        step.hasIndexAccess = planStats.hasIndexAccess();
        step.hasFullScan = planStats.hasFullScan();
        step.bottleneckOperator = planStats.getBottleneckOperator();
        step.anchorVariable = planStats.getAnchorVariable();
        step.anchorProperty = planStats.getAnchorProperty();
        step.anchorRelationshipType = planStats.getAnchorRelationshipType();
    }

    private double calculatePlanShapeAdjustment(Neo4jStatistics.QueryPlanStatistics planStats) {
        if (!usePlannerStats || planStats == null) {
            return 0.0;
        }
        double adjustment = 0.0;
        if (planStats.hasIndexAccess()) {
            adjustment -= 0.35;
            if (originalPlanStats != null && !originalPlanStats.hasIndexAccess()) {
                adjustment -= 0.25;
            }
        }
        if (planStats.hasFullScan()) {
            adjustment += 0.40;
        }
        if (originalPlanStats != null && originalPlanStats.hasFullScan() && !planStats.hasFullScan()) {
            adjustment -= 0.25;
        }
        return adjustment;
    }

    private int operationAnchorPriority(ModificationOperation operation) {
        if (operation == null) {
            return 3;
        }
        boolean targetsHardBlocker = targetsOriginalPredicateBlocker(operation, originalHardPredicateBlockers);
        boolean targetsSoftBlocker = targetsOriginalPredicateBlocker(operation, originalSoftPredicateBlockers);
        if (whyMode == WhyMode.WHY_EMPTY) {
            if (targetsHardBlocker) {
                return 0;
            }
            if (targetsSoftBlocker) {
                return 1;
            }
            switch (operation.getType()) {
                case REPLACE_RELATIONSHIP_TYPE:
                case FLIP_RELATIONSHIP_DIRECTION:
                    return !originalHardPredicateBlockers.isEmpty() ? 3 : (originalLikelySchemaClose ? 0 : 1);
                case WEAKEN_PREDICATE:
                case RELAX_PROPERTY:
                case RELAX_NODE_PROPERTY:
                case RELAX_ENDPOINT_PREDICATE:
                case DELETE_PREDICATE:
                    return 1;
                case RELAX_LABEL:
                    return originalLikelySchemaClose ? 1 : 2;
                case DEL_EDGE:
                case DELETE_RELATIONSHIP:
                    return isCycleBackboneRelaxation(operation) ? 3 : 4;
                case MAKE_OPTIONAL:
                    return 4;
                case DELETE_NODE:
                    return 5;
                default:
                    break;
            }
        }
        if (whyMode == WhyMode.WHY_FEW) {
            if (targetsHardBlocker) {
                return 0;
            }
            if (targetsSoftBlocker) {
                return 1;
            }
        }
        if (whyMode == WhyMode.WHY_MANY) {
            switch (operation.getType()) {
                case ADD_PREDICATE:
                case STRENGTHEN_PREDICATE:
                case RESTRICT_PROPERTY:
                    return 0;
                default:
                    return 2;
            }
        }
        if (originalPlanStats == null) {
            return 1;
        }
        boolean propertyMatch =
            Objects.equals(originalPlanStats.getAnchorProperty(), operation.getTargetProperty()) &&
            (originalPlanStats.getAnchorVariable() == null ||
             operation.getTargetVariable() == null ||
             Objects.equals(originalPlanStats.getAnchorVariable(), operation.getTargetVariable()));
        boolean relationshipMatch =
            Objects.equals(originalPlanStats.getAnchorRelationshipType(), operation.getTargetRelationshipType());
        boolean variableMatch =
            originalPlanStats.getAnchorVariable() != null &&
            (Objects.equals(originalPlanStats.getAnchorVariable(), operation.getTargetVariable()) ||
             Objects.equals(originalPlanStats.getAnchorVariable(), operation.getTargetId()));

        switch (operation.getType()) {
            case DELETE_PREDICATE:
            case RELAX_ENDPOINT_PREDICATE:
            case WEAKEN_PREDICATE:
            case RELAX_PROPERTY:
            case RELAX_NODE_PROPERTY:
            case REPAIR_PROPERTY_KEY:
                return propertyMatch ? 0 : 2;
            case FLIP_RELATIONSHIP_DIRECTION:
            case REPLACE_RELATIONSHIP_TYPE:
                return relationshipMatch ? 0 : 2;
            case RELAX_LABEL:
            case DELETE_NODE:
            case DEL_EDGE:
            case DELETE_RELATIONSHIP:
            case MAKE_OPTIONAL:
            case REPAIR_END_LABEL:
            case REPAIR_BOTH_END_LABELS:
                return (propertyMatch || variableMatch || relationshipMatch) ? 1 : 2;
            default:
                return 2;
        }
    }

    private Comparator<ModificationOperation> buildOperationComparator() {
        Comparator<ModificationOperation> fallback = Comparator
            .comparing((ModificationOperation op) -> op.getType().name())
            .thenComparing(ModificationOperation::getTargetId, Comparator.nullsLast(String::compareTo))
            .thenComparing(ModificationOperation::getTargetVariable, Comparator.nullsLast(String::compareTo))
            .thenComparing(ModificationOperation::getTargetLabel, Comparator.nullsLast(String::compareTo))
            .thenComparing(ModificationOperation::getTargetProperty, Comparator.nullsLast(String::compareTo));
        return Comparator
            .comparingInt(this::operationAnchorPriority)
            .thenComparingDouble(this::learningGuidanceAdjustment)
            .thenComparingDouble(this::calculateStatisticalComplexity)
            .thenComparing(fallback);
    }

    private void captureOriginalRewriteContext(CypherAST ast,
                                               SchemaGraph.SchemaCompatibility compatibility,
                                               SemanticCheckResult semanticCheck) {
        if (ast == null) {
            originalNodeCount = 0;
            originalRelationshipCount = 0;
            originalPredicateCount = 0;
            originalLikelySchemaClose = false;
            originalHardPredicateBlockers = Set.of();
            originalSoftPredicateBlockers = Set.of();
            originalPropertyKeyRepairTargets = Set.of();
            return;
        }
        originalNodeCount = ast.getNodesByType(NodeType.NODE).size();
        originalRelationshipCount = ast.getNodesByType(NodeType.RELATIONSHIP).size();
        originalPredicateCount = astPredicateCount(ast);
        boolean semanticIssues = semanticCheck != null && !semanticCheck.isConsistent();
        boolean schemaIssues = compatibility != null && !compatibility.isConsistent();
        originalLikelySchemaClose = semanticIssues || schemaIssues;
        PredicateBlockerSummary blockers = analyzePredicateBlockers(ast);
        originalHardPredicateBlockers = blockers.hardPredicateIds;
        originalSoftPredicateBlockers = blockers.softPredicateIds;
        Set<String> keyRepairs = new LinkedHashSet<>();
        Map<String, String> varLabels = buildVariableLabelMap(ast);
        for (ASTNode predicate : ast.getAllNodes()) {
            if (predicate != null && isPredicateNode(predicate)
                && !propertyKeyRepairsFor(ast, predicate, varLabels).isEmpty()) {
                keyRepairs.add(predicate.getId());
            }
        }
        originalPropertyKeyRepairTargets = Set.copyOf(keyRepairs);
    }

    /** Near-identical keys of {@code label} for an unknown key: equal ignoring case and
     *  separators, or within optimal-string-alignment distance max(1, min(2, |key|/4)).
     *  At most three, closest first. Package-private and static for unit tests. */
    static List<String> propertyKeyRepairCandidates(String property, Set<String> labelKeys) {
        if (property == null || property.isBlank() || labelKeys == null || labelKeys.isEmpty()
            || labelKeys.contains(property)) {
            return List.of();
        }
        String norm = property.toLowerCase(Locale.ROOT).replaceAll("[_\\-]", "");
        int limit = Math.max(1, Math.min(2, property.length() / 4));
        List<String[]> scored = new ArrayList<>();
        for (String key : labelKeys) {
            if (key == null || key.isBlank()) {
                continue;
            }
            int d = key.toLowerCase(Locale.ROOT).replaceAll("[_\\-]", "").equals(norm)
                ? 0 : osaDistance(property.toLowerCase(Locale.ROOT), key.toLowerCase(Locale.ROOT));
            if (d <= limit) {
                scored.add(new String[]{String.format("%03d", d), key});
            }
        }
        scored.sort(Comparator.comparing((String[] x) -> x[0]).thenComparing(x -> x[1]));
        List<String> out = new ArrayList<>();
        for (String[] x : scored) {
            out.add(x[1]);
            if (out.size() == 3) {
                break;
            }
        }
        return out;
    }

    /** Optimal string alignment distance (Levenshtein plus adjacent transposition). */
    static int osaDistance(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] d = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++) d[i][0] = i;
        for (int j = 0; j <= m; j++) d[0][j] = j;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                d[i][j] = Math.min(Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1), d[i - 1][j - 1] + cost);
                if (i > 1 && j > 1 && a.charAt(i - 1) == b.charAt(j - 2) && a.charAt(i - 2) == b.charAt(j - 1)) {
                    d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
                }
            }
        }
        return d[n][m];
    }

    private List<String> propertyKeyRepairsFor(CypherAST ast, ASTNode predicate, Map<String, String> varLabels) {
        if (ast == null || predicate == null || schemaCache == null) {
            return List.of();
        }
        for (ASTNode child : ast.getChildren(predicate.getId())) {
            if (child != null && child.getType() == NodeType.PROPERTY) {
                String variable = child.getAttribute("variable", String.class);
                String key = child.getAttribute("name", String.class);
                String label = variable != null ? varLabels.get(variable) : null;
                if (label == null || key == null) {
                    return List.of();
                }
                Set<String> keys = schemaCache.getPropertiesForLabel(label);
                return propertyKeyRepairCandidates(key, keys);
            }
        }
        return List.of();
    }

    private boolean isDegenerateWhyEmptyRewrite(CypherAST ast,
                                                SchemaGraph.SchemaBounds bounds,
                                                long estimatedCardinality) {
        if (whyMode != WhyMode.WHY_EMPTY || ast == null) {
            return false;
        }
        int nodeCount = ast.getNodesByType(NodeType.NODE).size();
        int relationshipCount = ast.getNodesByType(NodeType.RELATIONSHIP).size();
        int predicateCount = astPredicateCount(ast);
        long lower = bounds != null ? bounds.getLowerBound() : estimatedCardinality;
        long upper = bounds != null ? bounds.getUpperBound() : estimatedCardinality;
        long effectiveUpper = upper >= 0 ? upper : Math.max(lower, estimatedCardinality);

        if (originalRelationshipCount > 0 && relationshipCount == 0 && nodeCount <= 1 && predicateCount == 0) {
            return true;
        }
        if (originalRelationshipCount > 0 && relationshipCount == 0 && nodeCount <= 1 && predicateCount > 0) {
            return true;
        }
        if (originalRelationshipCount > 0 &&
            relationshipCount == 0 &&
            nodeCount < Math.max(1, originalNodeCount) &&
            effectiveUpper > 500000L) {
            return true;
        }
        return originalPredicateCount > 1 &&
            predicateCount == 0 &&
            relationshipCount == 0 &&
            effectiveUpper > 100000L;
    }

    private boolean shouldRejectWhyEmptyCandidate(CypherAST ast,
                                                  String query,
                                                  ModificationOperation operation,
                                                  SchemaGraph.SchemaBounds bounds,
                                                  long estimatedCardinality) {
        if (whyMode != WhyMode.WHY_EMPTY) {
            return false;
        }
        if (isDegenerateWhyEmptyRewrite(ast, bounds, estimatedCardinality)) {
            return true;
        }
        int predicateCount = astPredicateCount(ast);
        long lower = bounds != null ? bounds.getLowerBound() : -1L;
        long upper = bounds != null ? bounds.getUpperBound() : -1L;
        if (originalPredicateCount > 0
            && predicateCount >= originalPredicateCount
            && lower == 0
            && upper == 0
            && estimatedCardinality > 0
            && operation != null
            && operation.getType() != ModificationOperation.Type.DELETE_PREDICATE
            && operation.getType() != ModificationOperation.Type.RELAX_ENDPOINT_PREDICATE
            && operation.getType() != ModificationOperation.Type.WEAKEN_PREDICATE
            && operation.getType() != ModificationOperation.Type.RELAX_PROPERTY
            && operation.getType() != ModificationOperation.Type.RELAX_NODE_PROPERTY
            && operation.getType() != ModificationOperation.Type.REPAIR_PROPERTY_KEY) {
            return true;
        }
        if (retainsOriginalHardPredicateBlocker(ast)) {
            // In why-empty mode, keep search focused on removing/relaxing blocker predicates first.
            if (operation == null) {
                return true;
            }
            ModificationOperation.Type t = operation.getType();
            boolean predicateTargeting =
                t == ModificationOperation.Type.DELETE_PREDICATE
                    || t == ModificationOperation.Type.RELAX_ENDPOINT_PREDICATE
                    || t == ModificationOperation.Type.WEAKEN_PREDICATE
                    || t == ModificationOperation.Type.RELAX_PROPERTY
                    || t == ModificationOperation.Type.RELAX_NODE_PROPERTY
                    || t == ModificationOperation.Type.REPAIR_PROPERTY_KEY;
            if (!predicateTargeting) {
                return true;
            }
        }
        if (operation == null || query == null) {
            return false;
        }
        String normalized = query.replaceAll("\\s+", " ").trim();
        if (operation.getType() == ModificationOperation.Type.DELETE_NODE ||
            operation.getType() == ModificationOperation.Type.DEL_EDGE ||
            operation.getType() == ModificationOperation.Type.DELETE_RELATIONSHIP) {
            if (normalized.matches("(?i)^MATCH \\([A-Za-z_][A-Za-z0-9_]*(:[A-Za-z_][A-Za-z0-9_]*)?\\) RETURN .+$")) {
                return true;
            }
        }
        return false;
    }

    private boolean targetsOriginalPredicateBlocker(ModificationOperation operation, Set<String> blockerIds) {
        if (operation == null || blockerIds == null || blockerIds.isEmpty()) {
            return false;
        }
        if (operation.getType() == ModificationOperation.Type.REPAIR_PROPERTY_KEY) {
            return blockerIds.contains(operation.getTargetId());
        }
        // A predicate whose misspelled key has a schema repair is a schema fault, not a
        // selective predicate: deleting it earns no blocker discount (the repair does).
        if (originalPropertyKeyRepairTargets.contains(operation.getTargetId())) {
            return false;
        }
        return (operation.getType() == ModificationOperation.Type.DELETE_PREDICATE
            || operation.getType() == ModificationOperation.Type.RELAX_ENDPOINT_PREDICATE)
            && blockerIds.contains(operation.getTargetId());
    }

    private boolean retainsOriginalHardPredicateBlocker(CypherAST ast) {
        if (ast == null || originalHardPredicateBlockers == null || originalHardPredicateBlockers.isEmpty()) {
            return false;
        }
        // A predicate's impossibility is a function of its variable's CURRENT label context (e.g. a
        // property-value predicate that is impossible under the original, wrong label can become
        // perfectly valid once a structural repair -- REPAIR_END_LABEL, RELAX_LABEL,
        // REPLACE_RELATIONSHIP_TYPE, FLIP_RELATIONSHIP_DIRECTION -- corrects that label, without the
        // repair ever needing to touch the predicate node itself. Re-derive PROVABLE impossibility
        // (unknown property / sentinel literal / out-of-range numeric / exhaustively-absent string)
        // against the candidate's current bindings, deliberately excluding the separate low-
        // selectivity classification used elsewhere for cost guidance: rarity is not impossibility,
        // and must not veto a structural fix just because the identifying predicate it leaves
        // untouched happens to be selective. Otherwise a legitimate structural fix that leaves a
        // now-harmless (or merely rare) predicate node in place is rejected as if it still blocked.
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        for (String predicateId : originalHardPredicateBlockers) {
            if (predicateId == null) {
                continue;
            }
            ASTNode node = ast.getNode(predicateId);
            if (node != null && isProvablyImpossiblePredicateValue(ast, node, varLabelMap)) {
                return true;
            }
        }
        return false;
    }

    private boolean isProvablyImpossiblePredicateValue(CypherAST ast, ASTNode predicate, Map<String, String> varLabelMap) {
        if (ast == null || predicate == null) {
            return false;
        }
        String expression = predicate.getAttribute("expression", String.class);
        if ("false".equalsIgnoreCase(expression)) {
            return true;
        }
        List<ASTNode> children = ast.getChildren(predicate.getId());
        if (children == null || children.size() < 2) {
            return false;
        }
        ASTNode propertyNode = null;
        ASTNode literalNode = null;
        for (ASTNode child : children) {
            if (child == null) {
                continue;
            }
            if (propertyNode == null && child.getType() == NodeType.PROPERTY) {
                propertyNode = child;
            } else if (literalNode == null && child.getType() == NodeType.LITERAL) {
                literalNode = child;
            }
        }
        if (propertyNode == null) {
            return false;
        }

        String variable = propertyNode.getAttribute("variable", String.class);
        String property = propertyNode.getAttribute("name", String.class);
        DatabaseSchemaCache.PropertyInfo info = resolvePropertyInfo(variable, property, varLabelMap);
        Object literalVal = literalNode != null ? literalNode.getAttribute("value") : null;

        if (info == null && property != null) {
            return true;
        }
        if (literalVal != null && looksImpossibleLiteral(literalVal)) {
            return true;
        }
        if (info != null && literalVal != null) {
            if (isNumericLiteral(literalVal)
                && info.getMinValue() instanceof Number
                && info.getMaxValue() instanceof Number) {
                double min = toDouble(info.getMinValue());
                double max = toDouble(info.getMaxValue());
                double literal = toDouble(literalVal);
                NodeType type = predicate.getType();
                return ((type == NodeType.GREATER_THAN || type == NodeType.GREATER_THAN_OR_EQUAL) && literal >= max)
                    || ((type == NodeType.LESS_THAN || type == NodeType.LESS_THAN_OR_EQUAL) && literal <= min)
                    || (type == NodeType.EQUALS && (literal < min || literal > max));
            } else if (literalVal instanceof String && predicate.getType() == NodeType.EQUALS) {
                List<Object> common = info.getCommonValues();
                // commonValues is a top-k (default 10, see DatabaseSchemaCache's "top_k" option)
                // most-frequent-value sample, not an exhaustive domain enumeration -- the same
                // caveat WhyQueryProcedures#findImplausibleValues already documents. For a
                // near-unique identifying property (e.g. a person's name), the sample is
                // essentially always full (hits the cap) and absence from it proves nothing. Only
                // trust absence as evidence of non-existence when the returned list is itself
                // smaller than the cap, i.e. every distinct value was actually captured.
                if (common != null && !common.isEmpty() && common.size() < COMMON_VALUES_SAMPLE_CAP) {
                    boolean present = common.stream().anyMatch(v -> v != null && v.toString().equals(literalVal.toString()));
                    return !present;
                }
            }
        }
        return false;
    }

    private PredicateBlockerSummary analyzePredicateBlockers(CypherAST ast) {
        if (ast == null) {
            return PredicateBlockerSummary.empty();
        }
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        Set<String> hard = new LinkedHashSet<>();
        Set<String> soft = new LinkedHashSet<>();

        for (ASTNode predicate : ast.getAllNodes()) {
            if (predicate == null || !isPredicateNode(predicate)) {
                continue;
            }
            String expression = predicate.getAttribute("expression", String.class);
            if ("false".equalsIgnoreCase(expression)) {
                hard.add(predicate.getId());
                continue;
            }
            List<ASTNode> children = ast.getChildren(predicate.getId());
            if (children == null || children.size() < 2) {
                continue;
            }
            boolean hasPropertyChild = children.stream().anyMatch(c -> c != null && c.getType() == NodeType.PROPERTY);
            if (!hasPropertyChild) {
                continue;
            }

            if (isProvablyImpossiblePredicateValue(ast, predicate, varLabelMap)) {
                hard.add(predicate.getId());
                continue;
            }

            double selectivity = predicateSelectivity(ast, predicate, varLabelMap);
            if (selectivity <= 0.001) {
                hard.add(predicate.getId());
            } else if (selectivity <= 0.02) {
                soft.add(predicate.getId());
            }
        }

        return new PredicateBlockerSummary(hard, soft);
    }

    private static final class PredicateBlockerSummary {
        final Set<String> hardPredicateIds;
        final Set<String> softPredicateIds;

        PredicateBlockerSummary(Set<String> hardPredicateIds, Set<String> softPredicateIds) {
            this.hardPredicateIds = hardPredicateIds == null ? Set.of() : Set.copyOf(hardPredicateIds);
            this.softPredicateIds = softPredicateIds == null ? Set.of() : Set.copyOf(softPredicateIds);
        }

        static PredicateBlockerSummary empty() {
            return new PredicateBlockerSummary(Set.of(), Set.of());
        }
    }

    private Map<String, Object> buildRootCauseSummary(CypherAST ast,
                                                      SchemaGraph.SchemaBounds bounds,
                                                      long schemaPruned,
                                                      int iterations,
                                                      double modificationThreshold) {
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("mode", whyMode.name());
        summary.put("status", "FAILED");
        summary.put("iterations", iterations);
        summary.put("schema_inconsistent_pruned", schemaPruned);
        summary.put("modification_threshold", modificationThreshold);

        SemanticCheckResult semantic = ast != null ? checkSemanticConsistency(ast) : SemanticCheckResult.consistent();
        if (!semantic.isConsistent()) {
            summary.put("schema_blockers", semantic.getViolations());
        }

        long lower = bounds != null ? bounds.getLowerBound() : -1L;
        long upper = bounds != null ? bounds.getUpperBound() : -1L;
        Map<String, Object> interval = new LinkedHashMap<>();
        interval.put("lower", lower);
        interval.put("upper", upper);
        interval.put("target_min", minTarget);
        interval.put("target_max", maxTarget);
        interval.put("distance_below_target", lower >= 0 ? Math.max(0L, minTarget - lower) : -1L);
        interval.put("distance_above_target", upper >= 0 ? Math.max(0L, upper - maxTarget) : -1L);
        summary.put("cardinality_interval", interval);
        summary.put("current_query_certifiably_impossible",
            bounds != null && bounds.getUpperBound() != Long.MAX_VALUE
                && isCertifiablyImpossible(semantic, bounds));
        summary.put("impossibility_scope", "current_query_under_snapshot_schema");
        summary.put("certificate_snapshot_transaction_id", schemaCache.getSnapshotTransactionId());
        summary.put("certificate_current_transaction_id", schemaCache.getCurrentTransactionId());
        summary.put("certificate_snapshot_fresh", schemaCache.isSnapshotFresh());
        summary.put("certificate_snapshot_status", schemaCache.getSnapshotFreshnessStatus());

        if (originalPlanStats != null) {
            Map<String, Object> bottleneck = new LinkedHashMap<>();
            bottleneck.put("root_operator", originalPlanStats.getRootOperator());
            bottleneck.put("has_index_access", originalPlanStats.hasIndexAccess());
            bottleneck.put("has_full_scan", originalPlanStats.hasFullScan());
            bottleneck.put("bottleneck_operator", originalPlanStats.getBottleneckOperator());
            bottleneck.put("bottleneck_details", originalPlanStats.getBottleneckDetails());
            bottleneck.put("bottleneck_estimated_rows", originalPlanStats.getBottleneckEstimatedRows());
            bottleneck.put("bottleneck_collapse_ratio", originalPlanStats.getBottleneckCollapseRatio());
            bottleneck.put("anchor_variable", originalPlanStats.getAnchorVariable());
            bottleneck.put("anchor_property", originalPlanStats.getAnchorProperty());
            bottleneck.put("anchor_relationship_type", originalPlanStats.getAnchorRelationshipType());
            summary.put("planner_bottleneck", bottleneck);
        }

        List<String> suggestions = new ArrayList<>();
        if (whyMode == WhyMode.WHY_EMPTY || whyMode == WhyMode.WHY_FEW || whyMode == WhyMode.WHY_NOT) {
            if (originalPlanStats != null && originalPlanStats.getAnchorProperty() != null) {
                suggestions.add("Relax or remove predicates on " +
                    originalPlanStats.getAnchorVariable() + "." + originalPlanStats.getAnchorProperty());
            }
            if (originalPlanStats != null && originalPlanStats.getAnchorRelationshipType() != null) {
                suggestions.add("Inspect relationship repairs around type " +
                    originalPlanStats.getAnchorRelationshipType());
            }
        } else if (whyMode == WhyMode.WHY_MANY) {
            suggestions.add("Add selective predicates or labels to reduce the result interval.");
            if (originalPlanStats != null && originalPlanStats.hasFullScan()) {
                suggestions.add("Prefer indexed restrictions over scan-heavy filters.");
            }
        }
        if (schemaPruned > 0) {
            suggestions.add("Enable additional repair operators or relax the modification threshold.");
        }
        summary.put("suggestions", suggestions);

        return summary;
    }

    /**
     * Sound but incomplete finite certificate for the current query. It never
     * claims that the bounded rewrite task itself is impossible.
     */
    private boolean isCertifiablyImpossible(SemanticCheckResult semantic,
                                            SchemaGraph.SchemaBounds bounds) {
        if (!mayUseFormalCertificate()) {
            return false;
        }
        if (semantic != null && !semantic.isConsistent()) {
            return true;
        }
        // Empty/few lone-node bounds may be histogram point estimates rounded
        // to zero. Only why-many supplies a conservative ceiling here.
        return whyMode == WhyMode.WHY_MANY && bounds != null && bounds.getUpperBound() == 0L;
    }

    /** Package-visible for the certificate freshness regression. */
    boolean mayUseFormalCertificate() {
        return useFormalBounds && schemaCache.isSnapshotFresh();
    }

    /** Package-visible for the formal predicate-fallback certification regression. */
    boolean mayUseWhyManyPredicateFallback() {
        return !formalBoundsRequested || mayUseFormalCertificate();
    }

    private double calculateUncertaintyPenalty(double uncertaintyWidth) {
        if (strictTheoremMode) {
            return 0.0;
        }
        if (!uncertaintyAwareSearch || uncertaintyPenaltyWeight <= 0.0) {
            return 0.0;
        }
        if (Double.isInfinite(uncertaintyWidth) || uncertaintyWidth <= 0.0) {
            return 0.0;
        }
        // Log-scaling avoids over-penalizing large graphs while still preferring lower-risk candidates.
        return uncertaintyPenaltyWeight * Math.log1p(uncertaintyWidth);
    }

    private double calculateGuidedFScore(double gScore, double hScore, double uncertaintyWidth) {
        if (!strictTheoremMode) {
            if ("uniform".equals(config.getFrontierOrder())) return gScore;
            if ("greedy".equals(config.getFrontierOrder())) return hScore;
        }
        return calculateWeightedFScore(gScore, hScore) + calculateUncertaintyPenalty(uncertaintyWidth);
    }

    private double learningGuidanceAdjustment(ModificationOperation operation) {
        if (strictTheoremMode) {
            return 0.0;
        }
        if (!learningGuidanceEnabled || learningGuidanceStrength <= 0.0 || operation == null) {
            return 0.0;
        }
        String opKey = operation.getType().toString();
        long attempts = operationAttemptHistory.getOrDefault(opKey, 0L);
        if (attempts < learningMinSupport) {
            return 0.0; // Safe fallback: no effect when support is low.
        }
        long successes = operationSuccessHistory.getOrDefault(opKey, 0L);
        double successRate = (double) successes / (double) Math.max(1L, attempts);
        double cost = operationCostHistory.getOrDefault(opKey, 1.0);
        // Convert historical cost into a bounded [0,1] scale.
        double normalizedCost = cost / (1.0 + cost);
        // Better priors should reduce effective cost.
        double prior = successRate - normalizedCost;
        return -learningGuidanceStrength * prior;
    }

    private double computeBoundedRho() {
        double rho = 2.0;
        long totalNodes = Math.max(1L, schemaGraph.getTotalNodeCount());
        for (String label : schemaCache.getAllLabels()) {
            long count = Math.max(1L, schemaGraph.getLabelCount(label));
            rho = Math.max(rho, (double) totalNodes / (double) count);
        }
        double minSelectivity = findMinPropertySelectivity();
        if (minSelectivity > 0.0) {
            rho = Math.max(rho, 1.0 / minSelectivity);
        }
        long maxEdgeCount = 1L;
        long minEdgeCount = Long.MAX_VALUE;
        for (SchemaGraph.TripleStats stats : schemaGraph.getSchemaTriples().values()) {
            if (stats == null) {
                continue;
            }
            long count = stats.getEdgeCount();
            if (count > maxEdgeCount) {
                maxEdgeCount = count;
            }
            if (count > 0 && count < minEdgeCount) {
                minEdgeCount = count;
            }
        }
        rho = Math.max(rho, Math.max(1.0, (double) maxEdgeCount));
        if (minEdgeCount != Long.MAX_VALUE && minEdgeCount > 0) {
            rho = Math.max(rho, (double) maxEdgeCount / (double) minEdgeCount);
        }
        return Math.max(1.01, rho);
    }

    private double findMinPropertySelectivity() {
        double min = Double.POSITIVE_INFINITY;
        for (String label : schemaCache.getAllLabels()) {
            for (String prop : schemaCache.getPropertiesForLabel(label)) {
                double sel = schemaCache.getPropertySelectivity(label, prop);
                if (sel > 0.0 && sel < min) {
                    min = sel;
                }
            }
        }
        return Double.isInfinite(min) ? 0.0 : min;
    }

    private SemanticCheckResult checkSemanticConsistency(CypherAST ast) {
        if (ast == null) {
            return SemanticCheckResult.consistent();
        }
        List<String> violations = new ArrayList<>();
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        Map<String, Map<String, Object>> keyValues = new HashMap<>();

        for (ASTNode predicate : ast.getAllNodes()) {
            if (predicate == null || !isPredicateNode(predicate)) {
                continue;
            }
            List<ASTNode> children = ast.getChildren(predicate.getId());
            if (children.size() < 2) {
                continue;
            }
            ASTNode left = children.get(0);
            ASTNode right = children.get(1);
            ASTNode propertyNode = left.getType() == NodeType.PROPERTY ? left :
                (right.getType() == NodeType.PROPERTY ? right : null);
            ASTNode literalNode = left.getType() == NodeType.LITERAL ? left :
                (right.getType() == NodeType.LITERAL ? right : null);

            if (propertyNode == null || literalNode == null) {
                continue;
            }
            String variable = propertyNode.getAttribute("variable", String.class);
            String property = propertyNode.getAttribute("name", String.class);
            Object literalValue = literalNode.getAttribute("value", Object.class);

            if (property == null) {
                continue;
            }

            // Snapshot type is sampled and numeric extrema are observed data,
            // not declared hard domains. They may guide diagnosis/ranking but
            // must never make a proof-critical consistency decision. In
            // particular, a threshold outside [min,max] is not generically
            // impossible without considering the comparison direction.

            String label = varLabelMap.get(variable);
            if (label != null && schemaCache.isKeyProperty(label, property) &&
                predicate.getType() == NodeType.EQUALS) {
                if (!recordKeyValue(keyValues, variable, property, literalValue)) {
                    violations.add("Key constraint violation for " + label + "." + property);
                }
            }
        }

        // Inline properties (if any remain unnormalized)
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String variable = node.getAttribute("variable", String.class);
            List<String> labels = node.getAttribute("labels", List.class);
            String label = (labels != null && !labels.isEmpty()) ? labels.get(0) : null;
            Map<String, Object> props = node.getAttribute("properties", Map.class);
            if (props == null || props.isEmpty()) {
                continue;
            }
            for (Map.Entry<String, Object> entry : props.entrySet()) {
                String property = entry.getKey();
                Object literalValue = entry.getValue();
                if (label != null && schemaCache.isKeyProperty(label, property)) {
                    if (!recordKeyValue(keyValues, variable, property, literalValue)) {
                        violations.add("Key constraint violation for " + label + "." + property);
                    }
                }
            }
        }

        return violations.isEmpty() ? SemanticCheckResult.consistent() : new SemanticCheckResult(false, violations);
    }

    private boolean recordKeyValue(Map<String, Map<String, Object>> keyValues,
                                   String variable,
                                   String property,
                                   Object literalValue) {
        if (variable == null || property == null) {
            return true;
        }
        Map<String, Object> props = keyValues.computeIfAbsent(variable, k -> new HashMap<>());
        if (!props.containsKey(property)) {
            props.put(property, literalValue);
            return true;
        }
        Object existing = props.get(property);
        return Objects.equals(existing, literalValue);
    }

    private boolean isOperationBounded(ModificationOperation operation, CypherAST ast) {
        if (operation == null) {
            return true;
        }
        switch (operation.getType()) {
            case MAKE_OPTIONAL:
                return isOptionalMatchFunctional(ast, operation.getTargetId());
            case DELETE_NODE:
                return isLeafNode(ast, operation.getTargetId());
            case DEL_EDGE:
            case DELETE_RELATIONSHIP:
                return isCycleBackboneRelaxation(operation, ast);
            case REPLACE_RELATIONSHIP_TYPE:
                return isRelationshipTypeReplacementBounded(ast, operation);
            case FLIP_RELATIONSHIP_DIRECTION:
                return isRelationshipFlipBounded(ast, operation);
            default:
                return true;
        }
    }

    private boolean isRelationshipTypeReplacementBounded(CypherAST ast, ModificationOperation operation) {
        if (ast == null || operation == null || schemaGraph == null) {
            return false;
        }
        String relId = operation.getTargetId();
        ASTNode rel = ast.getNode(relId);
        if (rel == null || rel.getType() != NodeType.RELATIONSHIP) {
            return false;
        }
        String oldType = rel.getAttribute("type", String.class);
        String newType = operation.getTargetLabel();
        if (oldType == null || newType == null || newType.isBlank()) {
            return false;
        }
        RelationshipEndpoints endpoints = extractRelationshipEndpoints(ast, relId);
        if (endpoints == null) {
            return false;
        }
        String direction = rel.getAttribute("direction", String.class);
        Set<String> srcLabels = endpoints.leftLabels;
        Set<String> dstLabels = endpoints.rightLabels;
        if ("IN".equalsIgnoreCase(direction)) {
            srcLabels = endpoints.rightLabels;
            dstLabels = endpoints.leftLabels;
        }
        long minOld = minPositiveEdgeCount(srcLabels, oldType, dstLabels);
        long maxNew = maxEdgeCount(srcLabels, newType, dstLabels);
        return minOld > 0 && maxNew > 0;
    }

    private boolean isRelationshipFlipBounded(CypherAST ast, ModificationOperation operation) {
        if (ast == null || operation == null || schemaGraph == null) {
            return false;
        }
        String relId = operation.getTargetId();
        ASTNode rel = ast.getNode(relId);
        if (rel == null || rel.getType() != NodeType.RELATIONSHIP) {
            return false;
        }
        String relType = rel.getAttribute("type", String.class);
        if (relType == null) {
            return false;
        }
        String direction = rel.getAttribute("direction", String.class);
        if (!"OUT".equalsIgnoreCase(direction) && !"IN".equalsIgnoreCase(direction)) {
            return false;
        }
        RelationshipEndpoints endpoints = extractRelationshipEndpoints(ast, relId);
        if (endpoints == null) {
            return false;
        }
        Set<String> srcLabels = endpoints.leftLabels;
        Set<String> dstLabels = endpoints.rightLabels;
        if ("IN".equalsIgnoreCase(direction)) {
            srcLabels = endpoints.rightLabels;
            dstLabels = endpoints.leftLabels;
        }
        long minOld = minPositiveEdgeCount(srcLabels, relType, dstLabels);
        long maxNew = maxEdgeCount(dstLabels, relType, srcLabels);
        return minOld > 0 && maxNew > 0;
    }

    private static final class RelationshipEndpoints {
        private final String leftNodeId;
        private final String rightNodeId;
        private final Set<String> leftLabels;
        private final Set<String> rightLabels;

        private RelationshipEndpoints(String leftNodeId, String rightNodeId, Set<String> leftLabels, Set<String> rightLabels) {
            this.leftNodeId = leftNodeId;
            this.rightNodeId = rightNodeId;
            this.leftLabels = leftLabels;
            this.rightLabels = rightLabels;
        }
    }

    private boolean hasCartesianProduct(CypherAST ast) {
        if (ast == null) {
            return false;
        }
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }
            int nodeCount = 0;
            int relCount = 0;
            Set<String> nodeVariables = new HashSet<>();
            NodeType prev = null;
            String previousNodeVariable = null;
            for (ASTNode element : elements) {
                if (element == null) {
                    continue;
                }
                NodeType type = element.getType();
                if (type == NodeType.NODE) {
                    nodeCount++;
                    String variable = element.getAttribute("variable", String.class);
                    if (variable != null && !variable.isBlank()) {
                        nodeVariables.add(variable);
                    }
                    if (prev == NodeType.NODE) {
                        if (variable == null || previousNodeVariable == null
                            || !variable.equals(previousNodeVariable)) {
                            return true;
                        }
                    }
                    prev = NodeType.NODE;
                    previousNodeVariable = variable;
                } else if (type == NodeType.RELATIONSHIP) {
                    relCount++;
                    if (prev == NodeType.RELATIONSHIP) {
                        return true;
                    }
                    prev = NodeType.RELATIONSHIP;
                    previousNodeVariable = null;
                }
            }
            int distinctNodes = nodeVariables.isEmpty() ? nodeCount : nodeVariables.size();
            if (distinctNodes > 1 && relCount == 0) {
                return true;
            }
        }
        return false;
    }

    private RelationshipEndpoints extractRelationshipEndpoints(CypherAST ast, String relationshipId) {
        if (ast == null || relationshipId == null) {
            return null;
        }
        ASTNode pattern = null;
        for (Map.Entry<String, List<String>> entry : ast.getEdges().entrySet()) {
            if (entry.getValue().contains(relationshipId)) {
                ASTNode parent = ast.getNode(entry.getKey());
                if (parent != null && parent.getType() == NodeType.PATTERN) {
                    pattern = parent;
                    break;
                }
            }
        }
        if (pattern == null) {
            return null;
        }
        List<ASTNode> elements = ast.getChildren(pattern.getId());
        if (elements == null || elements.isEmpty()) {
            return null;
        }
        int relIndex = -1;
        for (int i = 0; i < elements.size(); i++) {
            if (relationshipId.equals(elements.get(i).getId())) {
                relIndex = i;
                break;
            }
        }
        if (relIndex <= 0 || relIndex >= elements.size() - 1) {
            return null;
        }
        ASTNode left = elements.get(relIndex - 1);
        ASTNode right = elements.get(relIndex + 1);
        if (left == null || right == null ||
            left.getType() != NodeType.NODE || right.getType() != NodeType.NODE) {
            return null;
        }
        Set<String> leftLabels = collectNodeLabels(left);
        Set<String> rightLabels = collectNodeLabels(right);
        return new RelationshipEndpoints(left.getId(), right.getId(), leftLabels, rightLabels);
    }

    private Set<String> collectNodeLabels(ASTNode node) {
        if (node == null) {
            return Set.of();
        }
        List<String> labels = node.getAttribute("labels", List.class);
        if (labels == null || labels.isEmpty()) {
            return Set.of();
        }
        return new LinkedHashSet<>(labels);
    }

    private boolean labelSetMatches(Set<String> labels, String candidate) {
        if (labels == null || labels.isEmpty()) {
            return true;
        }
        if (labels.contains(SchemaPattern.ANY_LABEL)) {
            return true;
        }
        return labels.contains(candidate);
    }

    private List<String> candidateRelationshipTypes(Set<String> srcLabels,
                                                   Set<String> dstLabels,
                                                   String currentType) {
        if (schemaGraph == null || schemaGraph.getSchemaTriples().isEmpty()) {
            return List.of();
        }
        Map<String, Long> bestCounts = new HashMap<>();
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry :
            schemaGraph.getSchemaTriples().entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (!labelSetMatches(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!labelSetMatches(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            String relType = triple.getRelationshipType();
            if (relType == null || relType.isBlank() || relType.equals(currentType)) {
                continue;
            }
            long count = entry.getValue() != null ? entry.getValue().getEdgeCount() : 0L;
            bestCounts.merge(relType, count, Math::max);
        }
        List<String> ordered = new ArrayList<>();
        bestCounts.entrySet()
            .stream()
            .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
            .limit(MAX_RELTYPE_REPLACEMENTS)
            .forEach(entry -> ordered.add(entry.getKey()));
        return ordered;
    }

    private long maxEdgeCount(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (schemaGraph == null || relType == null || relType.isBlank()) {
            return 0L;
        }
        long max = 0L;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry :
            schemaGraph.getSchemaTriples().entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (!relType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (!labelSetMatches(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!labelSetMatches(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            SchemaGraph.TripleStats stats = entry.getValue();
            if (stats == null) {
                continue;
            }
            long count = stats.getEdgeCount();
            if (count > max) {
                max = count;
            }
        }
        return max;
    }

    private long minPositiveEdgeCount(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (schemaGraph == null || relType == null || relType.isBlank()) {
            return 0L;
        }
        long min = Long.MAX_VALUE;
        for (Map.Entry<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> entry :
            schemaGraph.getSchemaTriples().entrySet()) {
            SchemaGraph.SchemaTriple triple = entry.getKey();
            if (!relType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (!labelSetMatches(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!labelSetMatches(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            SchemaGraph.TripleStats stats = entry.getValue();
            if (stats == null) {
                continue;
            }
            long count = stats.getEdgeCount();
            if (count > 0 && count < min) {
                min = count;
            }
        }
        return min == Long.MAX_VALUE ? 0L : min;
    }

    private boolean isLeafNode(CypherAST ast, String nodeId) {
        if (ast == null || nodeId == null) {
            return false;
        }
        int degree = 0;
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }
            for (int i = 0; i < elements.size(); i++) {
                ASTNode element = elements.get(i);
                if (element == null || element.getType() != NodeType.RELATIONSHIP) {
                    continue;
                }
                if (i > 0 && elements.get(i - 1).getType() == NodeType.NODE &&
                    nodeId.equals(elements.get(i - 1).getId())) {
                    degree++;
                }
                if (i < elements.size() - 1 && elements.get(i + 1).getType() == NodeType.NODE &&
                    nodeId.equals(elements.get(i + 1).getId())) {
                    degree++;
                }
            }
        }
        return degree <= 1;
    }

    private boolean isOptionalMatchFunctional(CypherAST ast, String matchId) {
        if (ast == null || matchId == null || !useSchema) {
            return false;
        }
        ASTNode match = ast.getNode(matchId);
        if (match == null) {
            return false;
        }
        List<ASTNode> patterns = ast.getChildren(matchId);
        if (patterns == null || patterns.isEmpty()) {
            return false;
        }
        for (ASTNode pattern : patterns) {
            if (pattern.getType() != NodeType.PATTERN) {
                continue;
            }
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null) {
                continue;
            }
            for (int i = 0; i < elements.size(); i++) {
                ASTNode element = elements.get(i);
                if (element.getType() != NodeType.RELATIONSHIP) {
                    continue;
                }
                String relType = element.getAttribute("type", String.class);
                if (relType == null) {
                    return false;
                }
                String direction = element.getAttribute("direction", String.class);
                String srcLabel = null;
                if ("OUT".equalsIgnoreCase(direction)) {
                    if (i > 0 && elements.get(i - 1).getType() == NodeType.NODE) {
                        List<String> labels = elements.get(i - 1).getAttribute("labels", List.class);
                        if (labels != null && !labels.isEmpty()) {
                            srcLabel = labels.get(0);
                        }
                    }
                } else if ("IN".equalsIgnoreCase(direction)) {
                    if (i < elements.size() - 1 && elements.get(i + 1).getType() == NodeType.NODE) {
                        List<String> labels = elements.get(i + 1).getAttribute("labels", List.class);
                        if (labels != null && !labels.isEmpty()) {
                            srcLabel = labels.get(0);
                        }
                    }
                } else {
                    return false;
                }
                if (srcLabel == null || !schemaCache.isFunctionalRelationship(srcLabel, relType)) {
                    return false;
                }
            }
        }
        return true;
    }

    private static final class SemanticCheckResult {
        private final boolean consistent;
        private final List<String> violations;

        private SemanticCheckResult(boolean consistent, List<String> violations) {
            this.consistent = consistent;
            this.violations = violations != null ? violations : List.of();
        }

        static SemanticCheckResult consistent() {
            return new SemanticCheckResult(true, List.of());
        }

        boolean isConsistent() {
            return consistent;
        }

        List<String> getViolations() {
            return violations;
        }
    }

    private PredicateContext extractPredicateContext(CypherAST ast, String predicateId) {
        if (ast == null || predicateId == null) {
            return new PredicateContext(null, null);
        }
        ASTNode predicateNode = ast.getNode(predicateId);
        if (predicateNode == null) {
            return new PredicateContext(null, null);
        }
        List<ASTNode> children = ast.getChildren(predicateId);
        if (!children.isEmpty()) {
            ASTNode firstChild = children.get(0);
            if (firstChild.getType() == NodeType.PROPERTY) {
                String variable = firstChild.getAttribute("variable", String.class);
                String property = firstChild.getAttribute("name", String.class);
                return new PredicateContext(variable, property);
            }
        }
        return new PredicateContext(null, null);
    }
    
    /**
     * Main A*-based query rewriting algorithm
     * WhyGraph: A*-Based Rewriting with Neo4j Statistics (Algorithm 1)
     */
    public RewritingResult rewriteQuery(String failedQuery, long targetCardinality,
                                        UserPreferences userPreferences, double modificationThreshold) {
        return rewriteQuery(failedQuery, targetCardinality, userPreferences, modificationThreshold,
            WhyMode.WHY_EMPTY, 0, targetCardinality);
    }

    public RewritingResult rewriteQuery(String failedQuery, long targetCardinality,
                                       UserPreferences userPreferences, double modificationThreshold,
                                       WhyMode mode, long minTarget, long maxTarget) {
        
        rewriteDeadlineNanos = candidateExecutionTimeoutSeconds > 0
            ? System.nanoTime() + TimeUnit.SECONDS.toNanos(candidateExecutionTimeoutSeconds)
            : Long.MAX_VALUE;
        RewritingResult result = new RewritingResult();
        diagnostics = new RewritingResult.SearchDiagnostics();
        result.setSearchDiagnostics(diagnostics);
        result.setTrace(trace);
        result.setOriginalQuery(failedQuery);
        result.setTargetCardinality(targetCardinality);
        this.whyMode = mode != null ? mode : WhyMode.WHY_EMPTY;
        this.minTarget = Math.max(0, minTarget);
        this.maxTarget = Math.max(this.minTarget, maxTarget > 0 ? maxTarget : targetCardinality);
        switch (this.whyMode) {
            case WHY_EMPTY:
                // For why-empty, we search for a minimal relaxation that yields non-empty results.
                // Use bounds/statistics for goal checking; do not execute candidate queries.
                this.minTarget = 1;
                this.maxTarget = Math.max(this.minTarget, this.maxTarget);
                break;
            case WHY_MANY:
                this.minTarget = allowDataQueries && !strictEstimateOnly ? Math.max(1L, minTarget) : 0L;
                this.maxTarget = Math.max(1, maxTarget);
                break;
            case WHY_FEW:
                this.minTarget = Math.max(1, this.minTarget);
                this.maxTarget = Math.max(this.minTarget, this.maxTarget);
                break;
            case WHY_NOT:
                // WHY_NOT uses interval targets like WHY_FEW, with tuple-recovery checked upstream.
                this.minTarget = Math.max(1, this.minTarget);
                this.maxTarget = Math.max(this.minTarget, this.maxTarget);
                break;
            default:
                break;
        }
        diagnostics.rhoDecreaseCertified = certifyGlobalRhoDecrease();
        diagnostics.heuristicMode = diagnostics.rhoDecreaseCertified
            ? "rho_log_certificate"
            : "one_step_indicator";
        
        QueryGraph parsedQueryGraph = null;
        try {
            if (usePlannerStats) {
                try (Transaction tx = db.beginTx()) {
                    parsedQueryGraph = CypherParser.parse(failedQuery, tx);
                    tx.commit();
                }
            } else {
                parsedQueryGraph = CypherASTQueryGraphParser.parse(failedQuery);
            }
        } catch (Exception e) {
            System.err.println("Failed to parse query graph for fallback: " + e.getMessage());
        }
        
        // Reset per-run caches so each rewrite starts with a clean slate
        planStatsCache.clear();
        actualGoalCountCache.clear();
        whyNotRecoveryCache.clear();
        setOriginalPlannerContext(failedQuery);
        
        try {
            // Parse the failed query into AST representation
            long phaseStart = System.nanoTime();
            CypherAST originalAST = parseQuery(failedQuery);
            diagnostics.parseTimeNanos += System.nanoTime() - phaseStart;
            if (originalAST == null) {
                result.addError("Failed to parse query: " + failedQuery);
                return result;
            }
            
            String regeneratedQuery = originalAST.generateCypher();
            if (!regeneratedQuery.trim().equals(failedQuery.trim())) {
                // Preserve user formatting; continue with the original string for diagnostics.
            }

            // Normalize inline MATCH properties into explicit predicates to make them rewritable
            int predicatesBefore = astPredicateCount(originalAST);
            normalizeInlineProperties(originalAST);
            int predicatesAfter = astPredicateCount(originalAST);

            phaseStart = System.nanoTime();
            SemanticCheckResult semanticCheck = checkSemanticConsistency(originalAST);
            diagnostics.schemaCheckTimeNanos += System.nanoTime() - phaseStart;
            if (useSchema && !semanticCheck.isConsistent()
                && !strictTheoremMode
                && !config.isForceRewriteAfterPrecheck() && !config.isForceAStarRewrite()) {
                result.setSuccess(false);
                result.setExplanation(String.join("; ", semanticCheck.getViolations()));
                result.addError("Query is schema-unsatisfiable; semantic constraint violations detected.");
                result.setRewrittenQuery(failedQuery);
                result.setIterations(0);
                result.setRootCauseSummary(buildRootCauseSummary(originalAST, null, 0L, 0, modificationThreshold));
                return result;
            }

            pruneImpossiblePredicates(originalAST);

            if (allowAddLimit && whyMode == WhyMode.WHY_MANY &&
                originalAST.getNodesByType(NodeType.LIMIT).isEmpty()) {
                long limitValue = Math.max(1L, maxTarget);
                if (limitValue <= Integer.MAX_VALUE) {
                    ModificationOperation addLimitOp = new ModificationOperation(
                        ModificationOperation.Type.ADD_LIMIT,
                        "limit",
                        null,
                        null,
                        new Object[]{(int) limitValue}
                    );
                    ASTModificationOperations.ModificationResult limitResult =
                        ASTModificationOperations.addLimit(originalAST, addLimitOp.getRange());
                    if (limitResult.isSuccessful()) {
                        CypherAST limitedAst = limitResult.getModifiedAST();
                        SchemaPattern limitedPattern = buildSchemaPattern(limitedAst);
                        if (limitedPattern == null) {
                            limitedPattern = new SchemaPattern();
                        }
                        SchemaGraph.SchemaCompatibility limitedCompat = schemaGraph.analyzeCompatibility(limitedPattern);
                        if (!useSchema || limitedCompat.isConsistent()) {
                            SchemaGraph.SchemaBounds limitedBounds = schemaGraph.estimateBounds(limitedPattern);
                            if (useFormalBounds) {
                                SchemaGraph.SchemaBounds formalBounds = computeFormalBounds(limitedAst, limitedPattern, limitedCompat);
                                limitedBounds = mergeBoundsForWhyMany(limitedBounds, formalBounds);
                            }
                            limitedBounds = applyLimitToBounds(limitedBounds, limitedAst.generateCypher());
                            long estimated = estimateCardinality(limitedAst, limitedBounds, limitedAst.generateCypher());
                            if (isGoal(limitedAst, limitedBounds, 1, estimated)) {
                                result.setSuccess(true);
                                result.setRewrittenQuery(limitedAst.generateCypher());
                                result.setFinalCardinality(estimated);
                                result.setEstimatedRows(estimated);
                                result.setIterations(1);
                                result.setStatesExplored(1);
                                result.setQueueMaxSize(1);
                                ModificationStep step = new ModificationStep(addLimitOp, limitResult.getChanges());
                                result.setModificationSteps(List.of(step));
                                result.setExecutionTimeMs(0);
                                RewritingResult.AStarTrace.Step traceStep = new RewritingResult.AStarTrace.Step();
                                traceStep.astHash = computeASTHash(limitedAst);
                                traceStep.rewrittenQuery = limitedAst.generateCypher();
                                traceStep.operation = "ADD_LIMIT";
                                traceStep.operationType = ModificationOperation.Type.ADD_LIMIT.name();
                                traceStep.plannerCost = 0.0;
                                traceStep.statisticalComplexity = 0.0;
                                traceStep.schemaPenalty = 0.0;
                                traceStep.userPenalty = 0.0;
                                traceStep.gScore = 0.0;
                                traceStep.hScore = 0.0;
                                traceStep.fScore = 0.0;
                                traceStep.estimatedRows = estimated;
                                traceStep.boundLower = limitedBounds != null ? limitedBounds.getLowerBound() : -1;
                                traceStep.boundUpper = limitedBounds != null ? limitedBounds.getUpperBound() : -1;
                                applyPlanDetails(traceStep, usePlannerStats ? getPlannerStatistics(limitedAst.generateCypher()) : null);
                                traceStep.goal = true;
                                trace.addStep(traceStep);
                                result.setTrace(trace);
                                return result;
                            }
                        }
                    }
                }
            }
            
            // Initialize priority queue with (Q, g, f, ops)
            Comparator<SearchNode> nodeComparator = Comparator
                .comparing(SearchNode::getFScore)
                .thenComparing(SearchNode::getGScore)
                .thenComparing(SearchNode::getUncertaintyWidth)
                .thenComparingInt(node -> node.getOperations().size())
                .thenComparing(node -> computeASTHash(node.getAst()));
            PriorityQueue<SearchNode> priorityQueue = new PriorityQueue<>(nodeComparator);
            
            SchemaPattern initialPattern = buildSchemaPattern(originalAST);
            if (initialPattern == null) {
                initialPattern = new SchemaPattern();
            }
            SchemaGraph.SchemaCompatibility initialCompatibility = schemaGraph.analyzeCompatibility(initialPattern);
            captureOriginalRewriteContext(originalAST, initialCompatibility, semanticCheck);
            if (useSchema && !initialCompatibility.isConsistent()) {
                if (!strictTheoremMode
                    && !config.isForceRewriteAfterPrecheck() && !config.isForceAStarRewrite()) {
                    result.setSuccess(false);
                    result.setExplanation(describeSchemaViolations(initialCompatibility));
                    result.addError("Query is schema-unsatisfiable; no compatible schema triples for one or more pattern edges.");
                    result.setRewrittenQuery(failedQuery);
                    result.setIterations(0);
                    result.setRootCauseSummary(buildRootCauseSummary(originalAST, null, 0L, 0, modificationThreshold));
                    return result;
                }
                result.addWarning("Schema-inconsistent original query; attempting rewrite despite precheck.");
            }
            SchemaGraph.SchemaBounds initialBounds = schemaGraph.estimateBounds(initialPattern);
            if (useFormalBounds) {
                SchemaGraph.SchemaBounds formalBounds = computeFormalBounds(originalAST, initialPattern, initialCompatibility);
                if (whyMode == WhyMode.WHY_MANY) {
                    initialBounds = mergeBoundsForWhyMany(initialBounds, formalBounds);
                } else {
                    initialBounds = formalBounds;
                }
            }
            initialBounds = applyLimitToBounds(initialBounds, failedQuery);
            long initialPlanRows = usePlannerStats ? estimatePlanRows(originalAST) : -1L;
            double initialHScore = calculateHeuristic(originalAST, initialBounds, initialPlanRows);
            double initialUncertainty = estimateUncertaintyWidth(originalAST, initialBounds, initialPlanRows);
            double initialFScore = calculateGuidedFScore(0.0, initialHScore, initialUncertainty);
            SearchNode initialNode = new SearchNode(
                originalAST,
                initialPattern,
                initialBounds,
                initialCompatibility,
                0.0,
                initialFScore,
                initialPlanRows,
                initialUncertainty,
                new ArrayList<>()
            );
            // Trace initial state
            RewritingResult.AStarTrace.Step initStep = new RewritingResult.AStarTrace.Step();
            initStep.astHash = computeASTHash(originalAST);
            initStep.parentAstHash = null;
            initStep.rewrittenQuery = originalAST.generateCypher();
            initStep.operation = "INIT";
            initStep.operationType = "INIT";
            initStep.depth = 0;
            initStep.edgeCost = 0.0;
            initStep.plannerCost = initialPlanRows;
            initStep.planShapeAdjustment = 0.0;
            initStep.statisticalComplexity = 0.0;
            initStep.schemaPenalty = 0.0;
            initStep.userPenalty = 0.0;
            initStep.structuralPenalty = 0.0;
            initStep.blockerAdjustment = 0.0;
            initStep.learningAdjustment = 0.0;
            initStep.unboundedPenalty = 0.0;
            initStep.gScore = 0.0;
            initStep.hScore = initialHScore;
            initStep.fScore = initialFScore;
            initStep.estimatedRows = initialPlanRows;
            initStep.boundLower = initialBounds != null ? initialBounds.getLowerBound() : -1;
            initStep.boundUpper = initialBounds != null ? initialBounds.getUpperBound() : -1;
            applyPlanDetails(initStep, originalPlanStats);
            initStep.goal = false;
            trace.addStep(initStep);

            // WHY-MANY has a useful sound special case that should not pay for
            // thousands of EXPLAIN-ranked A* states: exact key equalities cap
            // selected variables at one.  Enumerate the small vertex subset
            // lattice by predicate count and return the first cardinality
            // layer containing a fresh formal certificate.  This is an exact
            // minimum-number-of-key-restrictions constructor over the finite
            // values stored in the snapshot; it does not claim global A*
            // cost-optimality over the full edit algebra.
            if (whyMode == WhyMode.WHY_MANY && formalBoundsRequested) {
                RewritingResult keyCertificate = tryWhyManyKeyRestrictionCertificate(
                    failedQuery,
                    parsedQueryGraph,
                    targetCardinality,
                    userPreferences,
                    modificationThreshold
                );
                if (keyCertificate != null && keyCertificate.isSuccess()) {
                    return keyCertificate;
                }
            }
            priorityQueue.offer(initialNode);
            
            // Snapshot-only: schemaGraph/schemaCache are loaded from disk snapshots only.
            
            Map<String, Double> bestGScore = new HashMap<>();
            bestGScore.put(initStep.astHash, 0.0);
            List<ModificationStep> modificationLog = new ArrayList<>();
            List<QueryAlternative> foundAlternatives = new ArrayList<>();
            List<ParetoRewriteCandidate> paretoFrontier = new ArrayList<>();
            QueryAlternative bestGoalAlternative = null;
            SearchNode bestGeneratedGoalNode = null;
            long bestGeneratedGoalEstimate = -1L;
            boolean returnedGeneratedIncumbent = false;
            int iterations = 0;
            int maxAlternatives = config.getMaxAlternatives(); // Get from config
            long schemaPruned = 0L;
            long queueMaxSize = Math.max(0L, priorityQueue.size());
            
            CypherAST lastExpandedAST = originalAST;
            SchemaGraph.SchemaBounds lastExpandedBounds = initialBounds;
            searchLoop:
            while (!priorityQueue.isEmpty() && iterations < config.getMaxIterations()) {
                if (executionDeadlineExceeded()) {
                    diagnostics.budgetExhausted = true;
                    break;
                }
                iterations++;
                
                long queueStart = System.nanoTime();
                SearchNode currentNode = priorityQueue.poll();
                diagnostics.queueTimeNanos += System.nanoTime() - queueStart;
                diagnostics.expanded++;
                CypherAST currentAST = currentNode.getAst();
                lastExpandedAST = currentAST;
                lastExpandedBounds = currentNode.getBounds();
                
                String currentQuery = currentAST.generateCypher();
                long estimatedCardinality = effectiveGoalEstimate(
                    estimateCardinality(currentAST, currentNode.getBounds(), currentQuery),
                    currentNode.getPlanEstimateRows()
                );

                SchemaGraph.SchemaBounds currentBounds = currentNode.getBounds();
                if (isGoal(currentAST, currentBounds, currentNode.getOperations().size(), estimatedCardinality)) {
                    diagnostics.goalsFound++;
                    if (currentNode.getOperations().isEmpty()
                        && sameCypherIgnoringWhitespace(currentQuery, failedQuery)) {
                        continue;
                    }
                    QueryAlternative candidate = buildAlternativeFromSearchNode(
                        currentNode, currentQuery, estimatedCardinality, iterations
                    );
                    if (candidate != null
                        && !sameCypherIgnoringWhitespace(candidate.getRewrittenQuery(), failedQuery)) {
                        foundAlternatives.add(candidate);
                        if (paretoFrontierEnabled) {
                            addToParetoFrontier(paretoFrontier, candidate, maxAlternatives);
                        }
                        if (bestGoalAlternative == null
                            || candidate.getOverallScore() < bestGoalAlternative.getOverallScore()) {
                            bestGoalAlternative = candidate;
                        }
                    }
                    // Continue search to collect a compact frontier unless disabled.
                    if (!paretoFrontierEnabled || (maxAlternatives > 0 && foundAlternatives.size() >= maxAlternatives)) {
                        break;
                    }
                    continue;
                }
                
                String astHash = computeASTHash(currentAST);
                Double bestKnown = bestGScore.get(astHash);
                if (bestKnown != null && currentNode.getGScore() > bestKnown + 1e-9) {
                    continue;
                }
                
                // Generate applicable modification operations
                List<ModificationOperation> applicableOps = getApplicableOperations(currentAST);
                diagnostics.recordBranchingFactor(applicableOps.size());
                diagnostics.candidatesGenerated += applicableOps.size();
                applicableOps.sort(buildOperationComparator());
                Map<ModificationOperation.Type, Long> opHistogram = new HashMap<>();
                for (ModificationOperation op : applicableOps) {
                    opHistogram.merge(op.getType(), 1L, Long::sum);
                }
                
                for (ModificationOperation operation : applicableOps) {
                    if (executionDeadlineExceeded()) {
                        diagnostics.budgetExhausted = true;
                        break searchLoop;
                    }
                    recordOperationAttempt(operation);
                    try {
                        // Apply modification operation
                        ASTModificationOperations.ModificationResult modResult = 
                            applyOperation(currentAST, operation);
                        
                        if (!modResult.isSuccessful()) {
                            continue;
                        }
                        
                        CypherAST newAST = modResult.getModifiedAST();
                        if (enforceConnectedPatterns && hasCartesianProduct(newAST)) {
                            continue;
                        }
                        long schemaStart = System.nanoTime();
                        SemanticCheckResult semanticCheckNew = checkSemanticConsistency(newAST);
                        diagnostics.schemaCheckTimeNanos += System.nanoTime() - schemaStart;
                        if (useSchema && !semanticCheckNew.isConsistent()) {
                            schemaPruned++;
                            diagnostics.schemaPruned++;
                            continue;
                        }
                        pruneImpossiblePredicates(newAST);
                        
                        // Apply AST Transformation Validity theorem - ENSURE validity
                        long validationStart = System.nanoTime();
                        CypherAST.ValidationResult validationResult = newAST.validateTransformation();
                        if (!validationResult.isValid()) {
                            // Fix the AST to make it valid instead of giving up
                            newAST = repairInvalidAST(newAST, validationResult);
                            
                            // Re-validate after repair
                            validationResult = newAST.validateTransformation();
                            if (!validationResult.isValid()) {
                                diagnostics.validationTimeNanos += System.nanoTime() - validationStart;
                                // If still can't fix, continue exploring other operations
                                continue;
                            }
                        }
                        
                        String newQuery = newAST.generateCypher();
                        
                        // ENSURE Cypher syntax is valid - fix if needed
                        newQuery = ensureValidCypherQuery(newQuery);
                        diagnostics.validationTimeNanos += System.nanoTime() - validationStart;
                        if (newQuery == null) {
                            diagnostics.syntacticallyInvalid++;
                            continue; // Only give up if absolutely unfixable
                        }
                        
                        SchemaPattern newPattern = buildSchemaPattern(newAST);
                        if (newPattern == null) {
                            continue;
                        }
                        SchemaGraph.SchemaCompatibility newCompatibility = schemaGraph.analyzeCompatibility(newPattern);
                        if (useSchema && !newCompatibility.isConsistent()) {
                            schemaPruned++;
                            diagnostics.schemaPruned++;
                            continue;
                        }
                        long boundStart = System.nanoTime();
                        SchemaGraph.SchemaBounds newBounds = schemaGraph.estimateBounds(newPattern);
                        if (useFormalBounds) {
                            SchemaGraph.SchemaBounds formalBounds = computeFormalBounds(newAST, newPattern, newCompatibility);
                            if (whyMode == WhyMode.WHY_MANY) {
                                newBounds = mergeBoundsForWhyMany(newBounds, formalBounds);
                            } else {
                                newBounds = formalBounds;
                            }
                        }
                        SchemaGraph.SchemaBounds limitedBounds = applyLimitToBounds(newBounds, newQuery);
                        diagnostics.boundTimeNanos += System.nanoTime() - boundStart;
                        
                        // Do not gate on syntactic distance; allow A* scoring and pruning to decide
                        
                        // Calculate costs using Neo4j statistics
                        Neo4jStatistics.QueryPlanStatistics newPlanStats = usePlannerStats
                            ? getPlannerStatistics(newQuery)
                            : new Neo4jStatistics.QueryPlanStatistics(-1L, 0L, 0L);
                        if (usePlannerStats) {
                            diagnostics.explainPlanned++;
                        }
                        double schemaPenalty = calculateSchemaPenalty(currentNode.getCompatibility(), newCompatibility);
                        if (Double.isInfinite(schemaPenalty)) {
                            schemaPruned++;
                            continue;
                        }
                        double operationCost = calculateStatisticsBasedOperationCost(
                            operation, newPlanStats, userPreferences, schemaPenalty
                        );
                        double learningAdjustment = learningGuidanceAdjustment(operation);
                        operationCost += learningAdjustment;
                        double appliedUnboundedPenalty = 0.0;
                        if (!isOperationBounded(operation, currentAST)) {
                            if (!allowUnboundedOps) {
                                continue;
                            }
                            appliedUnboundedPenalty = unboundedPenalty;
                            operationCost += appliedUnboundedPenalty;
                        }
                        
                        long snapshotRowsForState = estimateCardinality(newAST, limitedBounds, newQuery);
                        long newPlanRows = usePlannerStats && newPlanStats != null
                            ? newPlanStats.getEstimatedRows()
                            : -1L;
                        long estimatedRowsForState = effectiveGoalEstimate(snapshotRowsForState, newPlanRows);
                        if (shouldRejectWhyEmptyCandidate(newAST, newQuery, operation, limitedBounds, estimatedRowsForState)) {
                            continue;
                        }
                        double newGScore = currentNode.getGScore() + operationCost;
                        double newHScore = calculateHeuristic(newAST, limitedBounds, newPlanRows);
                        double uncertaintyWidth = estimateUncertaintyWidth(newAST, limitedBounds, estimatedRowsForState);
                        double newFScore = calculateGuidedFScore(newGScore, newHScore, uncertaintyWidth);
                        if (modificationThreshold > 0.0
                            && calculateWeightedFScore(newGScore, newHScore)
                               + calculateUncertaintyPenalty(uncertaintyWidth) > modificationThreshold) {
                            continue;
                        }

                        long canonicalStart = System.nanoTime();
                        String newHash = computeASTHash(newAST);
                        diagnostics.canonicalizationTimeNanos += System.nanoTime() - canonicalStart;
                        double bestScore = bestGScore.getOrDefault(newHash, Double.POSITIVE_INFINITY);
                        if (newGScore + 1e-9 >= bestScore) {
                            diagnostics.canonicalDuplicates++;
                            continue;
                        }
                        bestGScore.put(newHash, newGScore);
                        
                        // Create new operations list with debug logging
                        List<String> annotatedChanges = new ArrayList<>(modResult.getChanges());
                        annotatedChanges.add("Estimated rows (" + (usePlannerStats ? "planner" : "snapshot") + "): " + estimatedRowsForState);
                        List<ModificationStep> newOperations = new ArrayList<>(currentNode.getOperations());
                        ModificationStep newStep = new ModificationStep(operation, annotatedChanges);
                        newOperations.add(newStep);
                        
                        SearchNode newNode = new SearchNode(
                            newAST,
                            newPattern,
                            limitedBounds,
                            newCompatibility,
                            newGScore,
                            newFScore,
                            newPlanRows,
                            uncertaintyWidth,
                            newOperations
                        );
                        // Trace step
                        RewritingResult.AStarTrace.Step step = new RewritingResult.AStarTrace.Step();
                        step.astHash = newHash;
                        step.parentAstHash = astHash;
                        step.rewrittenQuery = newAST.generateCypher();
                        step.operation = operation.getTargetId();
                        step.operationType = operation.getType().name();
                        step.depth = newOperations.size();
                        step.edgeCost = operationCost;
                        step.plannerCost = calculatePlannerCost(newPlanStats);
                        step.planShapeAdjustment = calculatePlanShapeAdjustment(newPlanStats);
                        step.statisticalComplexity = calculateStatisticalComplexity(operation);
                        step.schemaPenalty = schemaPenalty;
                        step.userPenalty = config.getAlpha() * calculateUserPenalty(operation, userPreferences);
                        step.structuralPenalty = calculateModeSpecificStructuralPenalty(operation);
                        step.blockerAdjustment = calculatePredicateBlockerAdjustment(operation);
                        step.learningAdjustment = learningAdjustment;
                        step.unboundedPenalty = appliedUnboundedPenalty;
                        step.gScore = newGScore;
                        step.hScore = newHScore;
                        step.fScore = newFScore;
                        step.estimatedRows = newPlanRows;
                        step.boundLower = limitedBounds != null ? limitedBounds.getLowerBound() : -1;
                        step.boundUpper = limitedBounds != null ? limitedBounds.getUpperBound() : -1;
                        applyPlanDetails(step, newPlanStats);
                        step.goal = isGoal(newAST, limitedBounds, newOperations.size(), estimatedRowsForState);
                        trace.addStep(step);

                        if (step.goal && (bestGeneratedGoalNode == null
                            || newNode.getFScore() < bestGeneratedGoalNode.getFScore())) {
                            bestGeneratedGoalNode = newNode;
                            bestGeneratedGoalEstimate = estimatedRowsForState;
                        }

                        queueStart = System.nanoTime();
                        priorityQueue.offer(newNode);
                        diagnostics.queueTimeNanos += System.nanoTime() - queueStart;
                        diagnostics.frontierInserted++;
                        queueMaxSize = Math.max(queueMaxSize, priorityQueue.size());
                        updateOperationFeedback(operation, operationCost, true);
                        
                    } catch (Exception e) {
                        // Log error but continue with other operations
                        result.addWarning("Failed to apply operation " + operation.getType() + ": " + e.getMessage());
                    }
                }
            }

            if (iterations >= config.getMaxIterations() && !priorityQueue.isEmpty()) {
                diagnostics.budgetExhausted = true;
            }

            // An anytime search must not discard a sound goal that it already
            // generated merely because the queue budget expired before that
            // node was popped.  Returning this incumbent preserves the numeric
            // certificate but explicitly gives up the A* minimality claim.
            if (foundAlternatives.isEmpty() && bestGeneratedGoalNode != null) {
                QueryAlternative incumbent = buildAlternativeFromSearchNode(
                    bestGeneratedGoalNode,
                    bestGeneratedGoalNode.getAst().generateCypher(),
                    bestGeneratedGoalEstimate,
                    iterations
                );
                if (incumbent != null) {
                    foundAlternatives.add(incumbent);
                    bestGoalAlternative = incumbent;
                    returnedGeneratedIncumbent = true;
                    diagnostics.returnedGeneratedIncumbent = true;
                }
            }
            
            // A* algorithm completed - process found alternatives
            if (!foundAlternatives.isEmpty()) {
                if (paretoFrontierEnabled && !paretoFrontier.isEmpty()) {
                    foundAlternatives = paretoFrontier.stream()
                        .map(p -> p.alternative)
                        .collect(java.util.stream.Collectors.toList());
                }
                // Set alternatives in result
                result.setAlternatives(foundAlternatives);
                result.rankAlternatives(); // Sort by cost and set best alternative
                
                QueryAlternative best = result.getBestAlternative() != null
                    ? result.getBestAlternative()
                    : bestGoalAlternative;
                result.setRewrittenQuery(best.getRewrittenQuery());
                long bestRows = best.getEstimatedRows();
                result.setFinalCardinality(bestRows);
                result.setEstimatedRows(bestRows);
                result.setModificationSteps(best.getModifications());
                result.setExplanation(best.getExplanation());
                result.setSuccess(true);
                result.setIterations(iterations);
                result.setStatesExplored(iterations);
                result.setQueueMaxSize(queueMaxSize);
                result.setSchemaInconsistentPruned(schemaPruned);
                result.setTrace(trace);
                if (paretoFrontierEnabled && !paretoFrontier.isEmpty()) {
                    result.addWarning("Returning Pareto-frontier rewrites (minimality/risk/cost trade-off).");
                }
                if (returnedGeneratedIncumbent) {
                    result.addWarning(
                        "Returning a generated certified incumbent after the search budget was exhausted; "
                        + "A* minimality is not certified");
                }
                return result;
            } else {
                // These fallbacks generate and accept DELETE_PREDICATE / structural-relaxation /
                // full-relaxation candidates without ever consulting allowedOperations. That is
                // fine (and load-bearing for headline numbers) when the search is unrestricted, but
                // it silently defeats an explicit allowed_ops restriction (e.g. a WEAKEN_PREDICATE-
                // only fairness/parity audit): the caller asked "can the restricted search alone
                // solve this?" and deserves an honest failure, not an out-of-restriction candidate
                // smuggled in through a fallback that was never told about the restriction.
                boolean operationsRestricted = allowedOperations != null && !allowedOperations.isEmpty();
                if (mayUseHeuristicFallbacks() && !operationsRestricted
                    && (whyMode == WhyMode.WHY_EMPTY || whyMode == WhyMode.WHY_FEW || whyMode == WhyMode.WHY_NOT)) {
                    RewritingResult schemaRepair = trySchemaRepairFallback(
                        lastExpandedAST != null ? lastExpandedAST : originalAST,
                        failedQuery,
                        targetCardinality
                    );
                    if (schemaRepair != null && schemaRepair.isSuccess()) {
                        return schemaRepair;
                    }
                    RewritingResult fallback = tryPredicateRelaxationFallback(lastExpandedAST != null ? lastExpandedAST : originalAST,
                        failedQuery, targetCardinality);
                    if (fallback == null || !fallback.isSuccess()) {
                        RewritingResult structural = tryStructuralRelaxationFallback(lastExpandedAST != null ? lastExpandedAST : originalAST,
                            failedQuery, targetCardinality);
                        if (structural != null && structural.isSuccess()) {
                            return structural;
                        }
                        RewritingResult forced = forceFullRelaxation(lastExpandedAST != null ? lastExpandedAST : originalAST,
                            failedQuery, targetCardinality);
                        if (forced != null && forced.isSuccess()) {
                            return forced;
                        }
                    }
                    if (fallback != null && fallback.isSuccess()) {
                        return fallback;
                    } else if (fallback != null && !fallback.getErrors().isEmpty()) {
                        fallback.getErrors().forEach(result::addError);
                    }
                } else if (mayUseHeuristicFallbacks()
                    && whyMode == WhyMode.WHY_MANY && mayUseWhyManyPredicateFallback()) {
                    RewritingResult fallback = tryWhyManyPredicateFallback(failedQuery, parsedQueryGraph, targetCardinality);
                    if (fallback != null && fallback.isSuccess()) {
                        return fallback;
                    } else if (fallback != null && !fallback.getErrors().isEmpty()) {
                        fallback.getErrors().forEach(result::addError);
                    }
                }
                result.setSuccess(false);
                result.setIterations(iterations);
                result.setStatesExplored(iterations);
                result.setQueueMaxSize(queueMaxSize);
                result.setSchemaInconsistentPruned(schemaPruned);
                result.setRootCauseSummary(buildRootCauseSummary(lastExpandedAST, lastExpandedBounds, schemaPruned, iterations, modificationThreshold));
                result.addError("No valid alternatives found within modification threshold and iteration limit");
            }
            
        } catch (Exception e) {
            result.addError("Rewriting failed: " + e.getMessage());
            result.setSuccess(false);
            result.setRootCauseSummary(buildRootCauseSummary(null, null, 0L, 0, modificationThreshold));
        }

        // If no steps were recorded (should not happen), add a sentinel for debugging
        if (trace != null && trace.getSteps().isEmpty()) {
            RewritingResult.AStarTrace.Step sentinel = new RewritingResult.AStarTrace.Step();
            sentinel.rewrittenQuery = failedQuery;
            sentinel.operation = "NO_STEPS_RECORDED";
            sentinel.operationType = "SENTINEL";
            sentinel.gScore = 0.0;
            sentinel.hScore = 0.0;
            sentinel.fScore = 0.0;
            sentinel.goal = false;
            trace.addStep(sentinel);
        }
        
        return result;
    }

    public RewritingResult rewriteQueryGreedy(String failedQuery, long targetCardinality,
                                              UserPreferences userPreferences, double modificationThreshold) {
        return rewriteQueryGreedy(failedQuery, targetCardinality, userPreferences, modificationThreshold,
            WhyMode.WHY_EMPTY, 0, targetCardinality);
    }

    public RewritingResult rewriteQueryGreedy(String failedQuery, long targetCardinality,
                                              UserPreferences userPreferences, double modificationThreshold,
                                              WhyMode mode, long minTarget, long maxTarget) {
        if (strictTheoremMode) {
            return rewriteQuery(
                failedQuery,
                targetCardinality,
                userPreferences,
                modificationThreshold,
                mode,
                minTarget,
                maxTarget
            );
        }
        RewritingResult result = new RewritingResult();
        result.setTrace(trace);
        result.setOriginalQuery(failedQuery);
        result.setTargetCardinality(targetCardinality);
        this.whyMode = mode != null ? mode : WhyMode.WHY_EMPTY;
        this.minTarget = Math.max(0, minTarget);
        this.maxTarget = Math.max(this.minTarget, maxTarget > 0 ? maxTarget : targetCardinality);
        switch (this.whyMode) {
            case WHY_EMPTY:
                this.minTarget = 1;
                this.maxTarget = Math.max(this.minTarget, this.maxTarget);
                break;
            case WHY_MANY:
                this.minTarget = allowDataQueries && !strictEstimateOnly ? Math.max(1L, minTarget) : 0L;
                this.maxTarget = Math.max(1, maxTarget);
                break;
            case WHY_FEW:
                this.minTarget = Math.max(1, this.minTarget);
                this.maxTarget = Math.max(this.minTarget, this.maxTarget);
                break;
            case WHY_NOT:
                this.minTarget = Math.max(1, this.minTarget);
                this.maxTarget = Math.max(this.minTarget, this.maxTarget);
                break;
            default:
                break;
        }

        QueryGraph parsedQueryGraph = null;
        try {
            if (usePlannerStats) {
                try (Transaction tx = db.beginTx()) {
                    parsedQueryGraph = CypherParser.parse(failedQuery, tx);
                    tx.commit();
                }
            } else {
                parsedQueryGraph = CypherASTQueryGraphParser.parse(failedQuery);
            }
        } catch (Exception e) {
            System.err.println("Failed to parse query graph for fallback: " + e.getMessage());
        }

        planStatsCache.clear();
        whyNotRecoveryCache.clear();
        setOriginalPlannerContext(failedQuery);
        long startTime = System.currentTimeMillis();
        try {
            CypherAST originalAST = parseQuery(failedQuery);
            if (originalAST == null) {
                result.addError("Failed to parse query: " + failedQuery);
                return result;
            }

            normalizeInlineProperties(originalAST);
            SemanticCheckResult semanticCheck = checkSemanticConsistency(originalAST);
            if (useSchema && !semanticCheck.isConsistent()
                && !config.isForceRewriteAfterPrecheck() && !config.isForceAStarRewrite()) {
                result.setSuccess(false);
                result.setExplanation(String.join("; ", semanticCheck.getViolations()));
                result.addError("Query is schema-unsatisfiable; semantic constraint violations detected.");
                result.setRewrittenQuery(failedQuery);
                result.setIterations(0);
                result.setRootCauseSummary(buildRootCauseSummary(originalAST, null, 0L, 0, modificationThreshold));
                return result;
            }

            pruneImpossiblePredicates(originalAST);

            if (allowAddLimit && whyMode == WhyMode.WHY_MANY &&
                originalAST.getNodesByType(NodeType.LIMIT).isEmpty()) {
                long limitValue = Math.max(1L, maxTarget);
                if (limitValue <= Integer.MAX_VALUE) {
                    ModificationOperation addLimitOp = new ModificationOperation(
                        ModificationOperation.Type.ADD_LIMIT,
                        "limit",
                        null,
                        null,
                        new Object[]{(int) limitValue}
                    );
                    ASTModificationOperations.ModificationResult limitResult =
                        ASTModificationOperations.addLimit(originalAST, addLimitOp.getRange());
                    if (limitResult.isSuccessful()) {
                        CypherAST limitedAst = limitResult.getModifiedAST();
                        SchemaPattern limitedPattern = buildSchemaPattern(limitedAst);
                        if (limitedPattern == null) {
                            limitedPattern = new SchemaPattern();
                        }
                        SchemaGraph.SchemaCompatibility limitedCompat = schemaGraph.analyzeCompatibility(limitedPattern);
                        if (!useSchema || limitedCompat.isConsistent()) {
                            SchemaGraph.SchemaBounds limitedBounds = schemaGraph.estimateBounds(limitedPattern);
                            if (useFormalBounds) {
                                SchemaGraph.SchemaBounds formalBounds = computeFormalBounds(limitedAst, limitedPattern, limitedCompat);
                                limitedBounds = mergeBoundsForWhyMany(limitedBounds, formalBounds);
                            }
                            limitedBounds = applyLimitToBounds(limitedBounds, limitedAst.generateCypher());
                            long estimated = estimateCardinality(limitedAst, limitedBounds, limitedAst.generateCypher());
                            if (isGoal(limitedAst, limitedBounds, 1, estimated)) {
                                result.setSuccess(true);
                                result.setRewrittenQuery(limitedAst.generateCypher());
                                result.setFinalCardinality(estimated);
                                result.setEstimatedRows(estimated);
                                result.setIterations(1);
                                result.setStatesExplored(1);
                                result.setQueueMaxSize(1);
                                ModificationStep step = new ModificationStep(addLimitOp, limitResult.getChanges());
                                result.setModificationSteps(List.of(step));
                                result.setExecutionTimeMs(0);
                                return result;
                            }
                        }
                    }
                }
            }

            SchemaPattern initialPattern = buildSchemaPattern(originalAST);
            if (initialPattern == null) {
                initialPattern = new SchemaPattern();
            }
            SchemaGraph.SchemaCompatibility initialCompatibility = schemaGraph.analyzeCompatibility(initialPattern);
            captureOriginalRewriteContext(originalAST, initialCompatibility, semanticCheck);
            if (useSchema && !initialCompatibility.isConsistent()) {
                if (!config.isForceRewriteAfterPrecheck() && !config.isForceAStarRewrite()) {
                    result.setSuccess(false);
                    result.setExplanation(describeSchemaViolations(initialCompatibility));
                    result.addError("Query is schema-unsatisfiable; no compatible schema triples for one or more pattern edges.");
                    result.setRewrittenQuery(failedQuery);
                    result.setIterations(0);
                    result.setRootCauseSummary(buildRootCauseSummary(originalAST, null, 0L, 0, modificationThreshold));
                    return result;
                }
                result.addWarning("Schema-inconsistent original query; attempting rewrite despite precheck.");
            }
            SchemaGraph.SchemaBounds initialBounds = schemaGraph.estimateBounds(initialPattern);
            if (useFormalBounds) {
                SchemaGraph.SchemaBounds formalBounds = computeFormalBounds(originalAST, initialPattern, initialCompatibility);
                if (whyMode == WhyMode.WHY_MANY) {
                    initialBounds = mergeBoundsForWhyMany(initialBounds, formalBounds);
                } else {
                    initialBounds = formalBounds;
                }
            }
            initialBounds = applyLimitToBounds(initialBounds, failedQuery);
            long initialPlanRows = usePlannerStats ? estimatePlanRows(originalAST) : -1L;

            RewritingResult.AStarTrace.Step initStep = new RewritingResult.AStarTrace.Step();
            initStep.astHash = computeASTHash(originalAST);
            initStep.rewrittenQuery = originalAST.generateCypher();
            initStep.operation = "INIT";
            initStep.operationType = "INIT";
            initStep.plannerCost = initialPlanRows;
            initStep.statisticalComplexity = 0.0;
            initStep.schemaPenalty = 0.0;
            initStep.userPenalty = 0.0;
            initStep.gScore = 0.0;
            initStep.hScore = calculateHeuristic(originalAST, initialBounds, initialPlanRows);
            initStep.fScore = calculateGuidedFScore(0.0, initStep.hScore,
                estimateUncertaintyWidth(originalAST, initialBounds, initialPlanRows));
            initStep.estimatedRows = initialPlanRows;
            initStep.boundLower = initialBounds != null ? initialBounds.getLowerBound() : -1;
            initStep.boundUpper = initialBounds != null ? initialBounds.getUpperBound() : -1;
            applyPlanDetails(initStep, originalPlanStats);
            initStep.goal = false;
            trace.addStep(initStep);

            CypherAST currentAST = originalAST;
            SchemaGraph.SchemaCompatibility currentCompatibility = initialCompatibility;
            SchemaGraph.SchemaBounds currentBounds = initialBounds;
            double currentGScore = 0.0;
            List<ModificationStep> currentOperations = new ArrayList<>();
            Set<String> visited = new HashSet<>();
            Map<String, Double> bestGScore = new HashMap<>();
            bestGScore.put(initStep.astHash, 0.0);
            long schemaPruned = 0L;
            long queueMaxSize = 0L;
            int iterations = 0;

            Comparator<ModificationOperation> opComparator = buildOperationComparator();

            while (iterations < config.getMaxIterations()) {
                iterations++;
                String currentQuery = currentAST.generateCypher();
                long currentPlanRows = usePlannerStats ? estimatePlanRows(currentAST) : -1L;
                long estimatedCardinality = effectiveGoalEstimate(
                    estimateCardinality(currentAST, currentBounds, currentQuery),
                    currentPlanRows
                );
                if (isGoal(currentAST, currentBounds, currentOperations.size(), estimatedCardinality)) {
                    result.setSuccess(true);
                    result.setRewrittenQuery(currentQuery);
                    result.setFinalCardinality(estimatedCardinality);
                    result.setEstimatedRows(estimatedCardinality);
                    result.setIterations(iterations);
                    result.setStatesExplored(iterations);
                    result.setQueueMaxSize(queueMaxSize);
                    result.setSchemaInconsistentPruned(schemaPruned);
                    result.setModificationSteps(currentOperations);
                    break;
                }

                String currentHash = computeASTHash(currentAST);
                if (visited.contains(currentHash)) {
                    break;
                }
                visited.add(currentHash);

                List<ModificationOperation> applicableOps = getApplicableOperations(currentAST);
                if (applicableOps.isEmpty()) {
                    break;
                }
                applicableOps.sort(opComparator);
                queueMaxSize = Math.max(queueMaxSize, applicableOps.size());

                GreedyCandidate best = null;
                for (ModificationOperation operation : applicableOps) {
                    recordOperationAttempt(operation);
                    try {
                        ASTModificationOperations.ModificationResult modResult = applyOperation(currentAST, operation);
                        if (!modResult.isSuccessful()) {
                            continue;
                        }
                        CypherAST newAST = modResult.getModifiedAST();
                        if (enforceConnectedPatterns && hasCartesianProduct(newAST)) {
                            continue;
                        }
                        SemanticCheckResult semanticCheckNew = checkSemanticConsistency(newAST);
                        if (useSchema && !semanticCheckNew.isConsistent()) {
                            schemaPruned++;
                            continue;
                        }
                        pruneImpossiblePredicates(newAST);

                        CypherAST.ValidationResult validationResult = newAST.validateTransformation();
                        if (!validationResult.isValid()) {
                            newAST = repairInvalidAST(newAST, validationResult);
                            validationResult = newAST.validateTransformation();
                            if (!validationResult.isValid()) {
                                continue;
                            }
                        }

                        String newQuery = newAST.generateCypher();
                        newQuery = ensureValidCypherQuery(newQuery);
                        if (newQuery == null) {
                            continue;
                        }

                        SchemaPattern newPattern = buildSchemaPattern(newAST);
                        if (newPattern == null) {
                            continue;
                        }
                        SchemaGraph.SchemaCompatibility newCompatibility = schemaGraph.analyzeCompatibility(newPattern);
                        if (useSchema && !newCompatibility.isConsistent()) {
                            schemaPruned++;
                            continue;
                        }
                        SchemaGraph.SchemaBounds newBounds = schemaGraph.estimateBounds(newPattern);
                        if (useFormalBounds) {
                            SchemaGraph.SchemaBounds formalBounds = computeFormalBounds(newAST, newPattern, newCompatibility);
                            if (whyMode == WhyMode.WHY_MANY) {
                                newBounds = mergeBoundsForWhyMany(newBounds, formalBounds);
                            } else {
                                newBounds = formalBounds;
                            }
                        }
                        SchemaGraph.SchemaBounds limitedBounds = applyLimitToBounds(newBounds, newQuery);

                        Neo4jStatistics.QueryPlanStatistics newPlanStats = usePlannerStats
                            ? getPlannerStatistics(newQuery)
                            : new Neo4jStatistics.QueryPlanStatistics(-1L, 0L, 0L);
                        double schemaPenalty = calculateSchemaPenalty(currentCompatibility, newCompatibility);
                        if (Double.isInfinite(schemaPenalty)) {
                            schemaPruned++;
                            continue;
                        }
                        double operationCost = calculateStatisticsBasedOperationCost(
                            operation, newPlanStats, userPreferences, schemaPenalty
                        );
                        operationCost += learningGuidanceAdjustment(operation);
                        if (!isOperationBounded(operation, currentAST)) {
                            if (!allowUnboundedOps) {
                                continue;
                            }
                            operationCost += unboundedPenalty;
                        }
                        long snapshotRowsForState = estimateCardinality(newAST, limitedBounds, newQuery);
                        long newPlanRows = usePlannerStats && newPlanStats != null
                            ? newPlanStats.getEstimatedRows()
                            : -1L;
                        long estimatedRowsForState = effectiveGoalEstimate(snapshotRowsForState, newPlanRows);
                        if (shouldRejectWhyEmptyCandidate(newAST, newQuery, operation, limitedBounds, estimatedRowsForState)) {
                            continue;
                        }
                        double newGScore = currentGScore + operationCost;
                        double newHScore = calculateHeuristic(newAST, limitedBounds, newPlanRows);
                        double uncertaintyWidth = estimateUncertaintyWidth(newAST, limitedBounds, estimatedRowsForState);
                        double newFScore = calculateGuidedFScore(newGScore, newHScore, uncertaintyWidth);
                        if (modificationThreshold > 0.0
                            && calculateWeightedFScore(newGScore, newHScore)
                               + calculateUncertaintyPenalty(uncertaintyWidth) > modificationThreshold) {
                            continue;
                        }

                        String newHash = computeASTHash(newAST);
                        double bestScore = bestGScore.getOrDefault(newHash, Double.POSITIVE_INFINITY);
                        if (newGScore + 1e-9 >= bestScore) {
                            continue;
                        }
                        bestGScore.put(newHash, newGScore);

                        List<String> annotatedChanges = new ArrayList<>(modResult.getChanges());
                        annotatedChanges.add("Estimated rows (" + (usePlannerStats ? "planner" : "snapshot") + "): " + estimatedRowsForState);
                        List<ModificationStep> newOperations = new ArrayList<>(currentOperations);
                        ModificationStep newStep = new ModificationStep(operation, annotatedChanges);
                        newOperations.add(newStep);

                        GreedyCandidate candidate = new GreedyCandidate(
                            newAST,
                            newPattern,
                            newCompatibility,
                            limitedBounds,
                            newGScore,
                            newFScore,
                            newPlanRows,
                            uncertaintyWidth,
                            newOperations,
                            operation,
                            newPlanStats,
                            schemaPenalty,
                            estimatedRowsForState,
                            operationCost
                        );

                        if (best == null || candidate.isBetterThan(best, opComparator)) {
                            best = candidate;
                        }
                    } catch (Exception e) {
                        result.addWarning("Failed to apply operation " + operation.getType() + ": " + e.getMessage());
                    }
                }

                if (best == null) {
                    break;
                }

                currentAST = best.ast;
                currentCompatibility = best.compatibility;
                currentBounds = best.bounds;
                currentGScore = best.gScore;
                currentOperations = best.operations;

                RewritingResult.AStarTrace.Step step = new RewritingResult.AStarTrace.Step();
                step.astHash = computeASTHash(currentAST);
                step.rewrittenQuery = currentAST.generateCypher();
                step.operation = best.operation.getTargetId();
                step.operationType = best.operation.getType().name();
                step.plannerCost = calculatePlannerCost(best.planStats);
                step.statisticalComplexity = calculateStatisticalComplexity(best.operation);
                step.schemaPenalty = best.schemaPenalty;
                step.userPenalty = config.getAlpha() * calculateUserPenalty(best.operation, userPreferences);
                step.gScore = best.gScore;
                step.hScore = calculateHeuristic(currentAST, currentBounds, best.planRows);
                step.fScore = best.fScore;
                step.estimatedRows = best.planRows;
                step.boundLower = currentBounds != null ? currentBounds.getLowerBound() : -1;
                step.boundUpper = currentBounds != null ? currentBounds.getUpperBound() : -1;
                applyPlanDetails(step, best.planStats);
                step.goal = isGoal(currentAST, currentBounds, currentOperations.size(), best.estimatedRows);
                trace.addStep(step);

                updateOperationFeedback(best.operation, best.operationCost, true);
            }

            if (result.isSuccess()) {
                result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
                return result;
            }

            boolean operationsRestrictedGreedy = allowedOperations != null && !allowedOperations.isEmpty();
            if (!operationsRestrictedGreedy
                && (whyMode == WhyMode.WHY_EMPTY || whyMode == WhyMode.WHY_FEW || whyMode == WhyMode.WHY_NOT)) {
                RewritingResult schemaRepair = trySchemaRepairFallback(currentAST, failedQuery, targetCardinality);
                if (schemaRepair != null && schemaRepair.isSuccess()) {
                    return schemaRepair;
                }
                RewritingResult fallback = tryPredicateRelaxationFallback(currentAST, failedQuery, targetCardinality);
                if (fallback == null || !fallback.isSuccess()) {
                    RewritingResult structural = tryStructuralRelaxationFallback(currentAST, failedQuery, targetCardinality);
                    if (structural != null && structural.isSuccess()) {
                        return structural;
                    }
                    RewritingResult forced = forceFullRelaxation(currentAST, failedQuery, targetCardinality);
                    if (forced != null && forced.isSuccess()) {
                        return forced;
                    }
                }
                if (fallback != null && fallback.isSuccess()) {
                    return fallback;
                }
            } else if (whyMode == WhyMode.WHY_MANY && mayUseWhyManyPredicateFallback()) {
                RewritingResult fallback = tryWhyManyPredicateFallback(failedQuery, parsedQueryGraph, targetCardinality);
                if (fallback != null && fallback.isSuccess()) {
                    return fallback;
                }
            }

            result.setSuccess(false);
            result.setIterations(iterations);
            result.setStatesExplored(iterations);
            result.setQueueMaxSize(queueMaxSize);
            result.setSchemaInconsistentPruned(schemaPruned);
            result.setRootCauseSummary(buildRootCauseSummary(currentAST, currentBounds, schemaPruned, iterations, modificationThreshold));
            result.addError("No valid alternatives found within modification threshold and iteration limit");
        } catch (Exception e) {
            result.addError("Greedy rewriting failed: " + e.getMessage());
            result.setSuccess(false);
            result.setRootCauseSummary(buildRootCauseSummary(null, null, 0L, 0, modificationThreshold));
        }

        if (trace != null && trace.getSteps().isEmpty()) {
            RewritingResult.AStarTrace.Step sentinel = new RewritingResult.AStarTrace.Step();
            sentinel.rewrittenQuery = failedQuery;
            sentinel.operation = "NO_STEPS_RECORDED";
            sentinel.operationType = "SENTINEL";
            sentinel.gScore = 0.0;
            sentinel.hScore = 0.0;
            sentinel.fScore = 0.0;
            sentinel.goal = false;
            trace.addStep(sentinel);
        }

        result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
        return result;
    }
    
    /**
     * Calculate statistics-based operation cost following Definition 5
     * StatsOperationCost(op, plan, stats, U) = PlannerCost(plan) + StatisticalComplexity(op, stats) + α·UserPenalty(op, U)
     */
    private double calculateStatisticsBasedOperationCost(ModificationOperation operation, 
                                                       Neo4jStatistics.QueryPlanStatistics planStats,
                                                       UserPreferences userPreferences,
                                                       double schemaPenalty) {
        if (config.isUseUniformCost()) {
            if (Double.isInfinite(schemaPenalty)) {
                return schemaPenalty;
            }
            return Math.max(costEpsilon, 1.0 + schemaPenalty);
        }
        
        // PlannerCost(plan, m) = log(1 + estCost) +
        //   [m = WHY_MANY] * beta * log(1 + estimatedRows).
        // EXPLAIN exposes estimates only; dbHits is a PROFILE/runtime metric.
        double plannerCost = calculatePlannerCost(planStats);
        plannerCost += calculatePlanShapeAdjustment(planStats);
        
        // StatisticalComplexity(op, stats)
        double statisticalComplexity = calculateStatisticalComplexity(operation);
        
        // UserPenalty(op, U)
        double userPenalty = config.getAlpha() * calculateUserPenalty(operation, userPreferences);

        // Mode-specific guardrail against overly broad structural rewrites.
        double structuralPenalty = calculateModeSpecificStructuralPenalty(operation);
        double blockerAdjustment = calculatePredicateBlockerAdjustment(operation);
        
        double total = plannerCost + statisticalComplexity + userPenalty + structuralPenalty + schemaPenalty + blockerAdjustment;
        if (Double.isInfinite(total)) {
            return total;
        }
        return Math.max(costEpsilon, total);
    }

    private double calculatePlannerCost(Neo4jStatistics.QueryPlanStatistics planStats) {
        if (!usePlannerStats || planStats == null || !planStats.isPlanAvailable()) {
            return 1.0;
        }
        double estCost = Math.max(0L, planStats.getEstCost());
        double cost = Math.log1p(estCost);
        if (whyMode == WhyMode.WHY_MANY) {
            cost += config.getBeta() * Math.log1p(Math.max(0L, planStats.getEstimatedRows()));
        }
        return cost;
    }

    private double calculateModeSpecificStructuralPenalty(ModificationOperation operation) {
        if (operation == null) {
            return 0.0;
        }
        switch (whyMode) {
            case WHY_FEW:
                switch (operation.getType()) {
                    case REPAIR_PROPERTY_KEY:
                        return 0.25; // schema repair of a misspelled key: cheaper than deleting it
                    case DELETE_NODE:
                        return 250.0;
                    case DEL_EDGE:
                    case DELETE_RELATIONSHIP:
                        if (isCycleBackboneRelaxation(operation)) {
                            return 35.0;
                        }
                        return 120.0;
                    case MAKE_OPTIONAL:
                        return 120.0;
                    case RELAX_ENDPOINT_PREDICATE:
                        return 8.0;
                    case DELETE_PREDICATE:
                        return targetsOriginalPredicateBlocker(operation, originalHardPredicateBlockers)
                            || targetsOriginalPredicateBlocker(operation, originalSoftPredicateBlockers)
                            ? 0.5
                            : 8.0;
                    case RELAX_LABEL:
                        return !originalHardPredicateBlockers.isEmpty() || !originalSoftPredicateBlockers.isEmpty()
                            ? 45.0
                            : 18.0;
                    case WEAKEN_PREDICATE:
                    case RELAX_PROPERTY:
                    case RELAX_NODE_PROPERTY:
                    case REPAIR_END_LABEL:
                    case REPAIR_BOTH_END_LABELS:
                    case REPLACE_RELATIONSHIP_TYPE:
                    case FLIP_RELATIONSHIP_DIRECTION:
                        return !originalHardPredicateBlockers.isEmpty() ? 12.0 : 2.0;
                    default:
                        return 0.0;
                }
            case WHY_NOT:
                switch (operation.getType()) {
                    case REPAIR_PROPERTY_KEY:
                        return 0.25; // schema repair of a misspelled key: cheaper than deleting it
                    case DELETE_NODE:
                        return 320.0;
                    case DEL_EDGE:
                    case DELETE_RELATIONSHIP:
                        if (isCycleBackboneRelaxation(operation)) {
                            return 45.0;
                        }
                        return 180.0;
                    case MAKE_OPTIONAL:
                        return 180.0;
                    case DELETE_PREDICATE:
                    case RELAX_ENDPOINT_PREDICATE:
                        return targetsOriginalPredicateBlocker(operation, originalHardPredicateBlockers) ? 4.0 : 40.0;
                    case RELAX_LABEL:
                        return 22.0;
                    case WEAKEN_PREDICATE:
                    case RELAX_PROPERTY:
                    case RELAX_NODE_PROPERTY:
                        return targetsOriginalPredicateBlocker(operation, originalHardPredicateBlockers) ? 1.0 : 8.0;
                    case REPAIR_END_LABEL:
                    case REPAIR_BOTH_END_LABELS:
                    case REPLACE_RELATIONSHIP_TYPE:
                    case FLIP_RELATIONSHIP_DIRECTION:
                        return !originalHardPredicateBlockers.isEmpty() ? 20.0 : 2.0;
                    case ADD_PREDICATE:
                    case STRENGTHEN_PREDICATE:
                    case RESTRICT_PROPERTY:
                    case ADD_LABEL:
                    case ADD_EDGE:
                        return 6.0;
                    case ADD_LIMIT:
                        return 1000.0;
                    default:
                        return 0.0;
                }
            case WHY_EMPTY:
                switch (operation.getType()) {
                    case REPAIR_PROPERTY_KEY:
                        return 0.25; // schema repair of a misspelled key: cheaper than deleting it
                    case DELETE_NODE:
                        return 280.0;
                    case DEL_EDGE:
                    case DELETE_RELATIONSHIP:
                        if (isCycleBackboneRelaxation(operation)) {
                            return 40.0;
                        }
                        return 160.0;
                    case MAKE_OPTIONAL:
                        return 160.0;
                    case DELETE_PREDICATE:
                    case RELAX_ENDPOINT_PREDICATE:
                        return 35.0;
                    case RELAX_LABEL:
                        return 18.0;
                    case WEAKEN_PREDICATE:
                    case RELAX_PROPERTY:
                    case RELAX_NODE_PROPERTY:
                        return targetsOriginalPredicateBlocker(operation, originalHardPredicateBlockers) ? 0.5 : 3.0;
                    case REPAIR_END_LABEL:
                    case REPAIR_BOTH_END_LABELS:
                    case REPLACE_RELATIONSHIP_TYPE:
                    case FLIP_RELATIONSHIP_DIRECTION:
                        return !originalHardPredicateBlockers.isEmpty() ? 25.0 : (originalLikelySchemaClose ? 0.5 : 2.0);
                    default:
                        return 0.0;
                }
            default:
                return 0.0;
        }
    }

    private double calculatePredicateBlockerAdjustment(ModificationOperation operation) {
        if (operation == null) {
            return 0.0;
        }
        if (targetsOriginalPredicateBlocker(operation, originalHardPredicateBlockers)) {
            return -20.0;
        }
        if (targetsOriginalPredicateBlocker(operation, originalSoftPredicateBlockers)) {
            return -25.0;
        }
        if ((whyMode == WhyMode.WHY_EMPTY || whyMode == WhyMode.WHY_FEW || whyMode == WhyMode.WHY_NOT)
            && !originalHardPredicateBlockers.isEmpty()
            && (operation.getType() == ModificationOperation.Type.FLIP_RELATIONSHIP_DIRECTION
                || operation.getType() == ModificationOperation.Type.REPLACE_RELATIONSHIP_TYPE
                || operation.getType() == ModificationOperation.Type.DEL_EDGE
                || operation.getType() == ModificationOperation.Type.DELETE_RELATIONSHIP
                || operation.getType() == ModificationOperation.Type.DELETE_NODE
                || operation.getType() == ModificationOperation.Type.MAKE_OPTIONAL
                || operation.getType() == ModificationOperation.Type.RELAX_LABEL
                || operation.getType() == ModificationOperation.Type.REPAIR_END_LABEL
                || operation.getType() == ModificationOperation.Type.REPAIR_BOTH_END_LABELS)) {
            return 15.0;
        }
        return 0.0;
    }

    /**
     * Calculate statistical complexity based on operation type
     */
    private double calculateStatisticalComplexity(ModificationOperation operation) {
        switch (operation.getType()) {
            case DELETE_NODE:
            case RELAX_LABEL:
            case REPAIR_END_LABEL:
            case REPAIR_BOTH_END_LABELS:
            case ADD_LABEL:
                String label = operation.getTargetLabel();
                if (label != null) {
                    long nodeCount = statistics.getNodeCount(label);
                    return Math.log(Math.max(nodeCount, 1));
                }
                return 1.0;
                
            case DEL_EDGE:
            case DELETE_RELATIONSHIP:
            case REPLACE_RELATIONSHIP_TYPE:
            case FLIP_RELATIONSHIP_DIRECTION:
                String relType = operation.getTargetRelationshipType();
                if (relType != null) {
                    long relCount = statistics.getRelationshipCount(relType);
                    return Math.log(Math.max(relCount, 1));
                }
                return 1.0;
                
            case WEAKEN_PREDICATE:
            case RELAX_PROPERTY:
            case RELAX_NODE_PROPERTY:
                String propLabel = operation.getTargetLabel();
                String propName = operation.getTargetProperty();
                if (propLabel != null && propName != null) {
                    double selectivity = statistics.getPropertySelectivity(propLabel, propName);
                    return -Math.log(Math.max(selectivity, 0.001));
                }
                return 1.0;
            case DELETE_PREDICATE:
            case RELAX_ENDPOINT_PREDICATE:
                String delLabel = operation.getTargetLabel();
                String delProp = operation.getTargetProperty();
                if (delLabel != null && delProp != null) {
                    double sel = schemaCache.getPropertySelectivity(delLabel, delProp);
                    if (!Double.isNaN(sel) && sel > 0.0) {
                        return -Math.log(Math.max(sel, 0.001));
                    }
                }
                return 0.5;
                
            default:
                return 1.0;
        }
    }
    
    /**
     * Calculate user penalty based on preferences
     */
    private double calculateUserPenalty(ModificationOperation operation, UserPreferences userPreferences) {
        if (userPreferences == null) {
            return 0.0;
        }
        
        // Higher penalty for operations user wants to avoid
        return userPreferences.getOperationPenalty(operation.getType());
    }
    
    /**
     * Get applicable modification operations for the current AST
     * Returns operations based on the configured strategy
     */
    private List<ModificationOperation> getApplicableOperations(CypherAST ast) {
        List<ModificationOperation> operations = new ArrayList<>();
        String strategy = config.getOperationStrategy();
        
        // Apply operations based on strategy and why-mode directionality.
        if ("RELAX_ONLY".equals(strategy)) {
            // RELAXATION OPERATIONS ONLY (increase results) - for WHY_EMPTY, WHY_FEW
            addRelaxationOperations(ast, operations);
        } else if ("RESTRICT_ONLY".equals(strategy)) {
            // RESTRICTION OPERATIONS ONLY (decrease results) - for WHY_MANY
            addRestrictionOperations(ast, operations);
        } else {
            // AUTO defaults to mode-specific directionality to align with the formal framework.
            if (whyMode == WhyMode.WHY_MANY) {
                addRestrictionOperations(ast, operations);
            } else if (whyMode == WhyMode.WHY_NOT) {
                addRelaxationOperations(ast, operations);
            } else {
                addRelaxationOperations(ast, operations);
            }
        }

        if (allowedOperations != null && !allowedOperations.isEmpty()) {
            operations.removeIf(op -> !allowedOperations.contains(op.getType()));
        }
        if (whyMode != WhyMode.WHY_MANY || !allowAddLimit) {
            operations.removeIf(op -> op.getType() == ModificationOperation.Type.ADD_LIMIT);
        }
        operations.removeIf(op -> deletesProjectedElement(ast, op));

        if (whyMode != WhyMode.WHY_MANY) {
            if (!config.isAllowRelationshipDeletionRelaxation()) {
                operations.removeIf(op ->
                    (op.getType() == ModificationOperation.Type.DELETE_RELATIONSHIP
                     || op.getType() == ModificationOperation.Type.DEL_EDGE)
                    && !isCycleBackboneRelaxation(op, ast)
                );
            }
        }

        boolean forbidUnbounded = !allowUnboundedOps
            || (useAdmissibleHeuristic && whyMode != WhyMode.WHY_EMPTY);
        if (strictTheoremMode || forbidUnbounded) {
            operations.removeIf(op -> !isOperationBounded(op, ast));
        }

        return operations;
    }

    private boolean deletesProjectedElement(CypherAST ast, ModificationOperation op) {
        if (ast == null || op == null) {
            return false;
        }
        ModificationOperation.Type type = op.getType();
        if (type != ModificationOperation.Type.DELETE_NODE
            && type != ModificationOperation.Type.DEL_EDGE
            && type != ModificationOperation.Type.DELETE_RELATIONSHIP) {
            return false;
        }
        ASTNode target = ast.getNode(op.getTargetId());
        if (target == null) {
            return false;
        }
        String variable = target.getAttribute("variable", String.class);
        if (variable == null || variable.isBlank()) {
            return false;
        }
        return projectedVariables(ast).contains(variable);
    }

    private Set<String> projectedVariables(CypherAST ast) {
        Set<String> vars = new HashSet<>();
        if (ast == null) {
            return vars;
        }
        for (ASTNode ret : ast.getNodesByType(NodeType.RETURN)) {
            collectProjectedVariables(ast, ret.getId(), vars);
        }
        return vars;
    }

    private void collectProjectedVariables(CypherAST ast, String nodeId, Set<String> vars) {
        ASTNode node = ast.getNode(nodeId);
        if (node == null) {
            return;
        }
        if (node.getType() == NodeType.VARIABLE) {
            String name = node.getAttribute("name", String.class);
            if (name != null && !name.isBlank()) {
                vars.add(name);
            }
        }
        for (ASTNode child : ast.getChildren(nodeId)) {
            if (child != null) {
                collectProjectedVariables(ast, child.getId(), vars);
            }
        }
    }
    
    /**
     * Add relaxation operations that increase result count
     */
    private void addRelaxationOperations(CypherAST ast, List<ModificationOperation> operations) {
        // Predicate deletion and relaxation operations first (highest priority to fix empty results)
        addEndpointPredicateRelaxationOperations(ast, operations);
        addPredicateOperations(ast, operations);

        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            // Label relaxation operations
            List<String> labels = node.getAttribute("labels", List.class);
            if (labels != null) {
                for (String label : labels) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.RELAX_LABEL,
                        node.getId(),
                        label,
                        null, null
                    ));
                }
            }
            
            // Inline property relaxations (e.g., MATCH (n {prop: value}))
            Map<String, Object> inlineProps = node.getAttribute("properties", Map.class);
            if (inlineProps != null && !inlineProps.isEmpty() && labels != null && labels.size() == 1
                && schemaCache != null) {
                Set<String> labelKeys = schemaCache.getPropertiesForLabel(labels.get(0));
                for (String key : inlineProps.keySet()) {
                    for (String repaired : propertyKeyRepairCandidates(key, labelKeys)) {
                        operations.add(new ModificationOperation(
                            ModificationOperation.Type.REPAIR_PROPERTY_KEY,
                            node.getId(), labels.get(0), repaired, new Object[]{key},
                            node.getAttribute("variable", String.class)));
                    }
                }
            }
            if (inlineProps != null && !inlineProps.isEmpty()) {
                for (Map.Entry<String, Object> entry : inlineProps.entrySet()) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.RELAX_NODE_PROPERTY,
                        node.getId(),
                        node.getAttribute("variable", String.class),
                        entry.getKey(),
                        new Object[]{entry.getValue()}
                    ));
                }
            }
        }

        // Structural relaxations help when the full pattern does not exist.
        addStructuralRelaxationOperations(ast, operations);
        
        // OPTIONAL MATCH conversion operations
        for (ASTNode match : ast.getNodesByType(NodeType.MATCH)) {
            operations.add(new ModificationOperation(
                ModificationOperation.Type.MAKE_OPTIONAL,
                match.getId(),
                null, null, null
            ));
        }
    }

    private void addStructuralRelaxationOperations(CypherAST ast, List<ModificationOperation> operations) {
        if (ast == null) {
            return;
        }

        int totalNodes = ast.getNodesByType(NodeType.NODE).size();
        Map<String, Integer> nodeDegree = new HashMap<>();
        Map<String, String> nodeLabel = new HashMap<>();
        Set<String> relIds = new LinkedHashSet<>();

        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.isEmpty()) {
                continue;
            }

            for (int i = 0; i < elements.size(); i++) {
                ASTNode element = elements.get(i);
                if (element == null) {
                    continue;
                }
                if (element.getType() == NodeType.NODE) {
                    String nodeId = element.getId();
                    nodeDegree.putIfAbsent(nodeId, 0);
                    List<String> labels = element.getAttribute("labels", List.class);
                    if (labels != null && !labels.isEmpty()) {
                        nodeLabel.putIfAbsent(nodeId, labels.get(0));
                    }
                } else if (element.getType() == NodeType.RELATIONSHIP) {
                    relIds.add(element.getId());
                    if (i > 0 && elements.get(i - 1).getType() == NodeType.NODE) {
                        nodeDegree.merge(elements.get(i - 1).getId(), 1, Integer::sum);
                    }
                    if (i < elements.size() - 1 && elements.get(i + 1).getType() == NodeType.NODE) {
                        nodeDegree.merge(elements.get(i + 1).getId(), 1, Integer::sum);
                    }
                }
            }
        }

        if (allowRelationshipRepairs) {
            addRelationshipRepairOperations(ast, operations);
        }

        Set<String> cycleBackboneRelIds = findCycleBackboneRelationshipIds(ast);
        for (String relId : relIds) {
            ASTNode rel = ast.getNode(relId);
            String relType = rel != null ? rel.getAttribute("type", String.class) : null;
            operations.add(new ModificationOperation(
                ModificationOperation.Type.DEL_EDGE,
                relId,
                relType,
                cycleBackboneRelIds.contains(relId) ? CYCLE_BACKBONE_RELAXATION : null,
                null
            ));
        }

        if (totalNodes > 1) {
            for (Map.Entry<String, Integer> entry : nodeDegree.entrySet()) {
                if (entry.getValue() <= 1) {
                    String nodeId = entry.getKey();
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.DELETE_NODE,
                        nodeId,
                        nodeLabel.get(nodeId),
                        null,
                        null
                    ));
                }
            }
        }
    }

    private void addEndpointPredicateRelaxationOperations(CypherAST ast, List<ModificationOperation> operations) {
        if (ast == null || operations == null || whyMode == WhyMode.WHY_MANY) {
            return;
        }
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        Set<String> endpointVariables = collectEndpointVariables(ast);
        if (endpointVariables.isEmpty()) {
            return;
        }

        List<PredicateDeletionCandidate> candidates = new ArrayList<>();
        for (ASTNode node : ast.getAllNodes()) {
            if (!isPredicateNode(node)) {
                continue;
            }
            PredicateContext context = extractPredicateContext(ast, node.getId());
            if (context.variable == null || context.property == null || !endpointVariables.contains(context.variable)) {
                continue;
            }
            String label = varLabelMap.get(context.variable);
            double selectivity = label != null
                ? schemaCache.getPropertySelectivity(label, context.property)
                : Double.NaN;
            if (Double.isNaN(selectivity) || selectivity <= 0.0) {
                selectivity = 0.5;
            }
            Object literalValue = extractPredicateLiteral(ast, node);
            if (literalValue != null && looksImpossibleLiteral(literalValue)) {
                selectivity = 0.0;
            }
            candidates.add(new PredicateDeletionCandidate(node.getId(), context.variable, context.property, label, selectivity));
        }

        candidates.sort(Comparator
            .comparingDouble((PredicateDeletionCandidate c) -> c.selectivity)
            .thenComparing(c -> c.variable, Comparator.nullsLast(String::compareTo))
            .thenComparing(c -> c.property, Comparator.nullsLast(String::compareTo)));

        Set<String> seen = new HashSet<>();
        for (PredicateDeletionCandidate candidate : candidates) {
            String key = candidate.variable + "." + candidate.property;
            if (!seen.add(key)) {
                continue;
            }
            operations.add(new ModificationOperation(
                ModificationOperation.Type.RELAX_ENDPOINT_PREDICATE,
                candidate.predicateId,
                candidate.label,
                candidate.property,
                new Object[]{"PRESERVE_RELATIONSHIP_PATTERN", candidate.selectivity},
                candidate.variable
            ));
        }
    }

    private Set<String> collectEndpointVariables(CypherAST ast) {
        Set<String> variables = new LinkedHashSet<>();
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.size() < 3) {
                continue;
            }
            for (int i = 1; i < elements.size() - 1; i++) {
                ASTNode rel = elements.get(i);
                if (rel == null || rel.getType() != NodeType.RELATIONSHIP) {
                    continue;
                }
                ASTNode left = elements.get(i - 1);
                ASTNode right = elements.get(i + 1);
                addNodeVariable(variables, left);
                addNodeVariable(variables, right);
            }
        }
        return variables;
    }

    private void addNodeVariable(Set<String> variables, ASTNode node) {
        if (node == null || node.getType() != NodeType.NODE) {
            return;
        }
        String variable = node.getAttribute("variable", String.class);
        if (variable != null && !variable.isBlank()) {
            variables.add(variable);
        }
    }

    private Object extractPredicateLiteral(CypherAST ast, ASTNode predicateNode) {
        if (ast == null || predicateNode == null) {
            return null;
        }
        List<ASTNode> children = ast.getChildren(predicateNode.getId());
        if (children == null || children.size() < 2) {
            return null;
        }
        ASTNode valueNode = children.get(1);
        return valueNode != null && valueNode.getType() == NodeType.LITERAL
            ? valueNode.getAttribute("value", Object.class)
            : null;
    }

    private boolean isCycleBackboneRelaxation(ModificationOperation operation) {
        return operation != null
            && (operation.getType() == ModificationOperation.Type.DEL_EDGE
                || operation.getType() == ModificationOperation.Type.DELETE_RELATIONSHIP)
            && CYCLE_BACKBONE_RELAXATION.equals(operation.getTargetProperty());
    }

    private boolean isCycleBackboneRelaxation(ModificationOperation operation, CypherAST ast) {
        return isCycleBackboneRelaxation(operation)
            && findCycleBackboneRelationshipIds(ast).contains(operation.getTargetId());
    }

    private Set<String> findCycleBackboneRelationshipIds(CypherAST ast) {
        if (ast == null) {
            return Set.of();
        }

        Set<String> cycleRelIds = new LinkedHashSet<>();
        Map<String, String> parent = new HashMap<>();
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> elements = ast.getChildren(pattern.getId());
            if (elements == null || elements.size() < 3) {
                continue;
            }
            for (int i = 1; i < elements.size() - 1; i++) {
                ASTNode rel = elements.get(i);
                if (rel == null || rel.getType() != NodeType.RELATIONSHIP) {
                    continue;
                }
                ASTNode left = elements.get(i - 1);
                ASTNode right = elements.get(i + 1);
                if (left == null || right == null ||
                    left.getType() != NodeType.NODE || right.getType() != NodeType.NODE) {
                    continue;
                }

                String leftKey = queryGraphNodeKey(left);
                String rightKey = queryGraphNodeKey(right);
                addDisjointSet(parent, leftKey);
                addDisjointSet(parent, rightKey);
                String leftRoot = findDisjointSet(parent, leftKey);
                String rightRoot = findDisjointSet(parent, rightKey);
                if (Objects.equals(leftRoot, rightRoot)) {
                    cycleRelIds.add(rel.getId());
                } else {
                    parent.put(leftRoot, rightRoot);
                }
            }
        }
        return cycleRelIds;
    }

    private String queryGraphNodeKey(ASTNode node) {
        String variable = node != null ? node.getAttribute("variable", String.class) : null;
        if (variable != null && !variable.isBlank()) {
            return "var:" + variable;
        }
        return node != null ? "id:" + node.getId() : "id:null";
    }

    private void addDisjointSet(Map<String, String> parent, String key) {
        parent.putIfAbsent(key, key);
    }

    private String findDisjointSet(Map<String, String> parent, String key) {
        String root = parent.get(key);
        if (root == null || Objects.equals(root, key)) {
            parent.putIfAbsent(key, key);
            return key;
        }
        String compressed = findDisjointSet(parent, root);
        parent.put(key, compressed);
        return compressed;
    }

    private void addRelationshipRepairOperations(CypherAST ast, List<ModificationOperation> operations) {
        if (ast == null || operations == null) {
            return;
        }
        for (ASTNode rel : ast.getNodesByType(NodeType.RELATIONSHIP)) {
            if (rel == null) {
                continue;
            }
            String relId = rel.getId();
            String relType = rel.getAttribute("type", String.class);
            String direction = rel.getAttribute("direction", String.class);
            if ("OUT".equalsIgnoreCase(direction) || "IN".equalsIgnoreCase(direction)) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.FLIP_RELATIONSHIP_DIRECTION,
                    relId,
                    relType,
                    null,
                    null
                ));
            }
            RelationshipEndpoints endpoints = extractRelationshipEndpoints(ast, relId);
            if (endpoints == null) {
                continue;
            }
            Set<String> srcLabels = endpoints.leftLabels;
            Set<String> dstLabels = endpoints.rightLabels;
            if ("IN".equalsIgnoreCase(direction)) {
                srcLabels = endpoints.rightLabels;
                dstLabels = endpoints.leftLabels;
            }
            // Repair endpoint labels: propose schema-compatible label substitutions
            Set<String> repairedTargetLabels = candidateEndpointLabels(srcLabels, relType, true);
            for (String repairedTargetLabel : repairedTargetLabels) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.REPAIR_END_LABEL,
                    "IN".equalsIgnoreCase(direction) ? endpoints.leftNodeId : endpoints.rightNodeId,
                    repairedTargetLabel,
                    null,
                    null
                ));
            }
            Set<String> repairedSourceLabels = candidateEndpointLabels(dstLabels, relType, false);
            for (String repairedSourceLabel : repairedSourceLabels) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.REPAIR_END_LABEL,
                    "IN".equalsIgnoreCase(direction) ? endpoints.rightNodeId : endpoints.leftNodeId,
                    repairedSourceLabel,
                    null,
                    null
                ));
            }
            // Compound anomaly: when BOTH endpoint labels are wrong at once, holding either
            // side fixed at its current (wrong) value never matches a schema triple, so
            // neither single-endpoint repair above is ever generated -- a single-edit search
            // can never reach a schema-consistent successor no matter how many iterations it
            // is given, because the intermediate (still one-sided-wrong) state is pruned before
            // a second edit could ever be attempted. Seed the combined repair directly from
            // real schema triples so this case is reachable in one edit, exactly like a single
            // wrong label already is; this does not touch the consistency gate itself.
            if (repairedTargetLabels.isEmpty() && repairedSourceLabels.isEmpty()) {
                String srcNodeId = "IN".equalsIgnoreCase(direction) ? endpoints.rightNodeId : endpoints.leftNodeId;
                String dstNodeId = "IN".equalsIgnoreCase(direction) ? endpoints.leftNodeId : endpoints.rightNodeId;
                for (String[] pair : candidateEndpointLabelPairs(relType)) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.REPAIR_BOTH_END_LABELS,
                        srcNodeId,
                        pair[0],
                        null,
                        new Object[]{dstNodeId, pair[1]}
                    ));
                }
            }
            Set<String> candidates = new LinkedHashSet<>(candidateRelationshipTypes(srcLabels, dstLabels, relType));
            if ("BOTH".equalsIgnoreCase(direction)) {
                candidates.addAll(candidateRelationshipTypes(dstLabels, srcLabels, relType));
            }
            for (String candidate : candidates) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.REPLACE_RELATIONSHIP_TYPE,
                    relId,
                    candidate,
                    null,
                    null
                ));
            }
        }
    }

    private Set<String> candidateEndpointLabels(Set<String> oppositeSideLabels, String relationshipType, boolean forTarget) {
        if (schemaGraph == null || schemaGraph.getSchemaTriples().isEmpty()) {
            return Set.of();
        }
        Set<String> out = new LinkedHashSet<>();
        for (SchemaGraph.SchemaTriple triple : schemaGraph.getSchemaTriples().keySet()) {
            if (relationshipType != null && !relationshipType.isBlank()
                && !relationshipType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (forTarget) {
                if (labelSetMatches(oppositeSideLabels, triple.getSourceLabel())) {
                    addConcreteLabel(out, triple.getTargetLabel());
                }
            } else {
                if (labelSetMatches(oppositeSideLabels, triple.getTargetLabel())) {
                    addConcreteLabel(out, triple.getSourceLabel());
                }
            }
        }
        return out;
    }

    /**
     * Valid (sourceLabel, targetLabel) pairs for a relationship type, read directly from
     * real schema triples rather than conditioned on either endpoint's current (possibly
     * wrong) label. Only consulted when {@link #candidateEndpointLabels} finds no
     * single-endpoint repair in either direction -- see the compound-anomaly seeding above.
     */
    private List<String[]> candidateEndpointLabelPairs(String relationshipType) {
        if (schemaGraph == null || schemaGraph.getSchemaTriples().isEmpty()) {
            return List.of();
        }
        List<String[]> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (SchemaGraph.SchemaTriple triple : schemaGraph.getSchemaTriples().keySet()) {
            if (relationshipType != null && !relationshipType.isBlank()
                && !relationshipType.equals(triple.getRelationshipType())) {
                continue;
            }
            String sourceLabel = triple.getSourceLabel();
            String targetLabel = triple.getTargetLabel();
            if (sourceLabel == null || sourceLabel.isBlank() || SchemaPattern.ANY_LABEL.equals(sourceLabel)
                || targetLabel == null || targetLabel.isBlank() || SchemaPattern.ANY_LABEL.equals(targetLabel)) {
                continue;
            }
            String key = sourceLabel + "->" + targetLabel;
            if (seen.add(key)) {
                out.add(new String[]{sourceLabel, targetLabel});
            }
            if (out.size() >= 25) {
                break;
            }
        }
        return out;
    }

    private void addConcreteLabel(Set<String> labels, String candidate) {
        if (candidate != null && !candidate.isBlank() && !SchemaPattern.ANY_LABEL.equals(candidate)) {
            labels.add(candidate);
        }
    }
    
    private SchemaPattern buildSchemaPattern(CypherAST ast) {
        try {
            if (ast == null) {
                return null;
            }
            QueryGraph queryGraph = CypherASTQueryGraphParser.fromAst(ast, ast.generateCypher());
            return SchemaPattern.from(queryGraph);
        } catch (Exception e) {
            System.err.println("Failed to build schema pattern: " + e.getMessage());
            return null;
        }
    }

    private long estimateCardinality(CypherAST ast, SchemaGraph.SchemaBounds bounds, String query) {
        if (bounds != null && bounds.getLowerBound() == 0L && bounds.getUpperBound() == 0L) {
            return 0L;
        }
        if ("label_probability".equals(cardinalityEstimator)
            || "alhd".equals(cardinalityEstimator)
            || "a_lhd".equals(cardinalityEstimator)) {
            long estimate = labelProbabilityEstimator.estimate(ast, query);
            long limit = extractLimitValue(query);
            if (estimate >= 0 && limit >= 0) {
                return Math.min(estimate, limit);
            }
            if (estimate >= 0) {
                return estimate;
            }
        }
        SchemaGraph.SchemaBounds adjusted = useFormalBounds
            ? bounds
            : applyPredicatesToBounds(ast, bounds);
        long estimate = adjusted == null ? -1L
            : (whyMode == WhyMode.WHY_MANY
                ? adjusted.getUpperBound()
                : adjusted.getLowerBound());
        long limit = extractLimitValue(query);
        if (estimate >= 0 && limit >= 0) {
            return Math.min(estimate, limit);
        }
        return estimate;
    }

    private long estimateCardinalitySnapshot(CypherAST ast, String query) {
        try {
            SchemaPattern pattern = buildSchemaPattern(ast);
            SchemaGraph.SchemaCompatibility comp = schemaGraph.analyzeCompatibility(pattern);
            SchemaGraph.SchemaBounds bounds = useFormalBounds
                ? computeFormalBounds(ast, pattern, comp)
                : schemaGraph.estimateBounds(pattern);
            bounds = applyLimitToBounds(bounds, query);
            return estimateCardinality(ast, bounds, query);
        } catch (Exception e) {
            return -1L;
        }
    }

    private boolean looksImpossibleLiteral(Object value) {
        if (!(value instanceof String)) {
            return false;
        }
        String s = ((String) value).trim();
        if (s.isEmpty()) {
            return false;
        }
        String u = s.toUpperCase(Locale.ROOT);
        // Protocol sentinel literals used to force emptiness.
        return u.contains("XX_NON_EXISTING")
            || u.contains("XX-NON-EXISTING")
            || u.contains("NON_EXIST")
            || u.contains("NON-EXIST")
            || u.contains("DOES_NOT_EXIST")
            || u.contains("DOES-NOT-EXIST")
            || u.contains("NOT_EXIST")
            || u.contains("NOT-EXIST")
            || u.contains("UNSEEN_LITERAL");
    }

    private long effectiveGoalEstimate(long snapshotEstimate, long plannerEstimate) {
        // The published estimator deliberately does not fuse planner rows into
        // C_est. Planner estimates are ranking signals only.
        return snapshotEstimate;
    }

    private double predicateSelectivity(CypherAST ast, ASTNode predicate, Map<String, String> varLabelMap) {
        if (ast == null || predicate == null) {
            return 1.0;
        }
        List<ASTNode> children = ast.getChildren(predicate.getId());
        if (children == null || children.isEmpty()) {
            return 1.0;
        }
        ASTNode prop = null;
        ASTNode lit = null;
        for (ASTNode child : children) {
            if (child == null) {
                continue;
            }
            if (prop == null && child.getType() == NodeType.PROPERTY) {
                prop = child;
            } else if (lit == null && child.getType() == NodeType.LITERAL) {
                lit = child;
            }
        }
        if (prop == null || prop.getType() != NodeType.PROPERTY) {
            return 1.0;
        }
        String variable = prop.getAttribute("variable", String.class);
        String property = prop.getAttribute("name", String.class);
        String label = variable != null ? varLabelMap.get(variable) : null;
        double base = (label != null && property != null) ? schemaCache.getPropertySelectivity(label, property) : 0.5;
        base = Math.max(0.0, Math.min(1.0, base));

        Object value = lit != null && lit.getType() == NodeType.LITERAL ? lit.getAttribute("value", Object.class) : null;
        if (looksImpossibleLiteral(value)) {
            return 0.0;
        }

        switch (predicate.getType()) {
            case NOT_EQUALS:
                return Math.max(0.0, Math.min(1.0, 1.0 - base));
            case GREATER_THAN:
            case GREATER_THAN_OR_EQUAL:
            case LESS_THAN:
            case LESS_THAN_OR_EQUAL:
                if (value instanceof Number && label != null && property != null) {
                    List<Double> boundaries = schemaCache.getHistogramBoundaries(label, property);
                    if (boundaries != null && boundaries.size() >= 2) {
                        return rangeSelectivityFromHistogram(
                            boundaries, predicate.getType(), ((Number) value).doubleValue());
                    }
                }
                // No histogram available for this label/property: fall back to a
                // mid-selectivity assumption.
                return 0.5;
            case CONTAINS:
            case STARTS_WITH:
                return 0.2;
            case EQUALS:
            default:
                return base;
        }
    }

    /**
     * Estimate range-predicate selectivity from the snapshot's quantile
     * boundaries (min, interior percentiles, max, ascending), treating each
     * consecutive pair as an equal-population bucket and interpolating
     * linearly within the bucket containing {@code value}.
     */
    private double rangeSelectivityFromHistogram(List<Double> boundaries, NodeType comparisonType, double value) {
        int buckets = boundaries.size() - 1;
        double fractionBelow;
        if (value <= boundaries.get(0)) {
            fractionBelow = 0.0;
        } else if (value >= boundaries.get(boundaries.size() - 1)) {
            fractionBelow = 1.0;
        } else {
            int index = Collections.binarySearch(boundaries, value);
            if (index >= 0) {
                fractionBelow = (double) index / buckets;
            } else {
                int insertion = -index - 1;
                double lower = boundaries.get(insertion - 1);
                double upper = boundaries.get(insertion);
                double within = upper > lower ? (value - lower) / (upper - lower) : 0.0;
                fractionBelow = ((insertion - 1) + within) / buckets;
            }
        }
        fractionBelow = Math.max(0.0, Math.min(1.0, fractionBelow));
        switch (comparisonType) {
            case LESS_THAN:
            case LESS_THAN_OR_EQUAL:
                return fractionBelow;
            case GREATER_THAN:
            case GREATER_THAN_OR_EQUAL:
                return 1.0 - fractionBelow;
            default:
                return 0.5;
        }
    }

    private static final class SelectivityInterval {
        private final double lower;
        private final double upper;

        private SelectivityInterval(double lower, double upper) {
            this.lower = Math.max(0.0, Math.min(1.0, lower));
            this.upper = Math.max(this.lower, Math.min(1.0, upper));
        }
    }

    private String predicateKey(CypherAST ast, ASTNode predicate, Map<String, String> varLabelMap) {
        if (ast == null || predicate == null || varLabelMap == null) {
            return null;
        }
        List<ASTNode> children = ast.getChildren(predicate.getId());
        if (children == null || children.isEmpty()) {
            return null;
        }
        ASTNode prop = null;
        for (ASTNode child : children) {
            if (child != null && child.getType() == NodeType.PROPERTY) {
                prop = child;
                break;
            }
        }
        if (prop == null) {
            return null;
        }
        String variable = prop.getAttribute("variable", String.class);
        String property = prop.getAttribute("name", String.class);
        String label = variable != null ? varLabelMap.get(variable) : null;
        if (label == null || property == null || property.isBlank()) {
            return null;
        }
        return label + "." + property;
    }

    private SelectivityInterval estimatePredicateSelectivityInterval(CypherAST ast,
                                                                     List<ASTNode> predicates,
                                                                     Map<String, String> varLabelMap) {
        if (predicates == null || predicates.isEmpty()) {
            return new SelectivityInterval(1.0, 1.0);
        }
        double base = 1.0;
        List<String> keys = new ArrayList<>();
        for (ASTNode predicate : predicates) {
            if (predicate == null) {
                continue;
            }
            base *= predicateSelectivity(ast, predicate, varLabelMap);
            keys.add(predicateKey(ast, predicate, varLabelMap));
        }
        if (base <= 0.0) {
            return new SelectivityInterval(0.0, 0.0);
        }
        double corrLower = 1.0;
        double corrUpper = 1.0;
        for (int i = 0; i < keys.size(); i++) {
            String left = keys.get(i);
            if (left == null) {
                continue;
            }
            for (int j = i + 1; j < keys.size(); j++) {
                String right = keys.get(j);
                if (right == null) {
                    continue;
                }
                CorrelationSynopsis.Interval interval = correlationSynopsis.factor(left, right);
                corrLower *= interval.lower;
                corrUpper *= interval.upper;
            }
        }
        double lower = base * corrLower;
        double upper = base * corrUpper;
        return new SelectivityInterval(lower, upper);
    }

    private SchemaGraph.SchemaBounds applyPredicatesToBounds(CypherAST ast, SchemaGraph.SchemaBounds bounds) {
        if (bounds == null) {
            return null;
        }
        if (ast == null) {
            return bounds;
        }
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        List<ASTNode> predicates = new ArrayList<>();
        for (ASTNode node : ast.getAllNodes()) {
            if (node != null && isPredicateNode(node)) {
                predicates.add(node);
            }
        }
        long lower = bounds.getLowerBound();
        long upper = bounds.getUpperBound();
        if (whyMode == WhyMode.WHY_MANY) {
            // Conservative C_safe ignores non-key predicate selectivities. They
            // can rank candidates but cannot certify a why-many goal.
            return new SchemaGraph.SchemaBounds(0L, upper);
        }
        SelectivityInterval interval = estimatePredicateSelectivityInterval(ast, predicates, varLabelMap);
        double lowerSel = interval.lower;
        double upperSel = interval.upper;
        if (upperSel <= 0.0) {
            return new SchemaGraph.SchemaBounds(0L, 0L);
        }
        if (lower < 0 || upper < 0) {
            return bounds;
        }
        long newLower = Math.max(0L, Math.round(lower * lowerSel));
        long newUpper = Math.max(0L, Math.round(upper * upperSel));
        return new SchemaGraph.SchemaBounds(newLower, Math.max(newLower, newUpper));
    }

    private SchemaGraph.SchemaBounds mergeBoundsForWhyMany(SchemaGraph.SchemaBounds estimated,
                                                          SchemaGraph.SchemaBounds formal) {
        if (formal == null) {
            // A requested formal run must not silently certify from the
            // heuristic SchemaGraph.estimateBounds() value.  In particular,
            // min(edge counts) is not an upper bound for a multi-edge join.
            return null;
        }
        return new SchemaGraph.SchemaBounds(0L, formal.getUpperBound());
    }

    private boolean isGoal(CypherAST ast, SchemaGraph.SchemaBounds bounds, int modificationsApplied, long estimatedCardinality) {
        if (modificationsApplied == 0) {
            return false;
        }
        if (allowDataQueries && !strictEstimateOnly) {
            if (!shouldAcquireExactCandidateCount(bounds)) {
                return false;
            }
            if (whyMode == WhyMode.WHY_EMPTY && isDegenerateWhyEmptyRewrite(ast, bounds, estimatedCardinality)) {
                return false;
            }
            if ((whyMode == WhyMode.WHY_EMPTY || whyMode == WhyMode.WHY_FEW || whyMode == WhyMode.WHY_NOT)
                && retainsOriginalHardPredicateBlocker(ast)) {
                return false;
            }
            if (whyMode == WhyMode.WHY_NOT && !recoversWhyNotTuple(ast)) {
                return false;
            }
            return meetsActualGoal(countCandidateForGoal(ast.generateCypher(), candidateGoalCountCap()));
        }
        long mergedLower = -1;
        long mergedUpper = -1;
        if (bounds != null) {
            SchemaGraph.SchemaBounds adjusted = useFormalBounds
                ? bounds
                : applyPredicatesToBounds(ast, bounds);
            if (adjusted != null) {
                mergedLower = adjusted.getLowerBound();
                mergedUpper = adjusted.getUpperBound();
            }
        } else if (estimatedCardinality >= 0) {
            mergedLower = estimatedCardinality;
            mergedUpper = estimatedCardinality;
        }
        if (estimatedCardinality > 0 && mergedLower == 0 && mergedUpper == 0) {
            mergedLower = estimatedCardinality;
            mergedUpper = estimatedCardinality;
        }
        switch (whyMode) {
            case WHY_EMPTY:
                if (isDegenerateWhyEmptyRewrite(ast, bounds, estimatedCardinality)) {
                    return false;
                }
                if (retainsOriginalHardPredicateBlocker(ast)) {
                    return false;
                }
                // Why-empty/few use the point estimate as a heuristic goal;
                // only why-many treats the safe upper bound as a certificate.
                return estimatedCardinality >= minTarget
                    && (!hasFiniteUpperTarget() || estimatedCardinality <= maxTarget);
            case WHY_FEW:
                if (retainsOriginalHardPredicateBlocker(ast)) {
                    return false;
                }
                return estimatedCardinality >= minTarget
                    && (!hasFiniteUpperTarget() || estimatedCardinality <= maxTarget);
            case WHY_NOT:
                if (retainsOriginalHardPredicateBlocker(ast)) {
                    return false;
                }
                if (!recoversWhyNotTuple(ast)) {
                    return false;
                }
                return estimatedCardinality >= minTarget
                    && (!hasFiniteUpperTarget() || estimatedCardinality <= maxTarget);
            case WHY_MANY:
                // In estimate-only mode a why-many success is a formal upper-
                // bound certificate.  Do not silently downgrade it to a claim
                // based on a snapshot invalidated by a later commit.
                if (!mayUseFormalCertificate() || mergedUpper == Long.MAX_VALUE) {
                    // Saturation/missing proof fields are unavailable evidence,
                    // even when the caller supplies Long.MAX_VALUE as its target.
                    return false;
                }
                if (mergedLower >= 0 && mergedUpper >= 0) {
                    return mergedLower >= minTarget && mergedUpper <= maxTarget;
                }
                if (mergedUpper >= 0) {
                    if (mergedUpper > maxTarget) {
                        return false;
                    }
                    return mergedUpper >= minTarget;
                }
                return false;
            default:
                return false;
        }
    }

    private boolean recoversWhyNotTuple(CypherAST ast) {
        if (ast == null) {
            return false;
        }
        if ((whyNotPropertyBindings == null || whyNotPropertyBindings.isEmpty())
            && (whyNotIdBindings == null || whyNotIdBindings.isEmpty())) {
            // If the caller did not provide tuple bindings, keep interval-only behavior.
            return true;
        }
        String query = ast.generateCypher();
        String boundQuery = addWhyNotBindingsToQuery(query);
        if (boundQuery == null || boundQuery.isBlank()) {
            return false;
        }
        Boolean cached = whyNotRecoveryCache.get(boundQuery);
        if (cached != null) {
            return cached;
        }
        boolean recovered;
        if (allowDataQueries && !strictEstimateOnly) {
            recovered = countCandidateForGoal(boundQuery, 1L) > 0L;
        } else {
            // Preserve the default estimate-only invariant.
            recovered = estimateTupleRecovery(boundQuery);
        }
        whyNotRecoveryCache.put(boundQuery, recovered);
        return recovered;
    }

    private boolean estimateTupleRecovery(String boundQuery) {
        if (boundQuery == null || boundQuery.isBlank()) {
            return false;
        }
        if (usePlannerStats) {
            Neo4jStatistics.QueryPlanStatistics plan = getPlannerStatistics(boundQuery);
            return plan != null && plan.getEstimatedRows() > 0L;
        }
        try {
            CypherAST astBound = parseQuery(boundQuery);
            long est = astBound != null ? estimateCardinalitySnapshot(astBound, boundQuery) : -1L;
            return est > 0L;
        } catch (Exception ignored) {
            return false;
        }
    }

    private String addWhyNotBindingsToQuery(String query) {
        if (query == null || query.isBlank()) {
            return query;
        }
        List<String> predicates = new ArrayList<>();
        if (whyNotIdBindings != null) {
            for (Map.Entry<String, List<Long>> entry : whyNotIdBindings.entrySet()) {
                String var = entry.getKey();
                List<Long> ids = entry.getValue();
                if (var == null || var.isBlank() || ids == null || ids.isEmpty()) {
                    continue;
                }
                if (ids.size() == 1) {
                    predicates.add("id(" + var + ") = " + ids.get(0));
                } else {
                    predicates.add("id(" + var + ") IN " + ids.toString());
                }
            }
        }
        if (whyNotPropertyBindings != null) {
            for (Map.Entry<String, Map<String, Object>> entry : whyNotPropertyBindings.entrySet()) {
                String var = entry.getKey();
                Map<String, Object> props = entry.getValue();
                if (var == null || var.isBlank() || props == null || props.isEmpty()) {
                    continue;
                }
                for (Map.Entry<String, Object> prop : props.entrySet()) {
                    String key = prop.getKey();
                    if (key == null || key.isBlank()) {
                        continue;
                    }
                    predicates.add(var + "." + key + " = " + formatValue(prop.getValue()));
                }
            }
        }
        if (predicates.isEmpty()) {
            return query;
        }

        Matcher m = Pattern.compile("(?i)\\bRETURN\\b").matcher(query);
        int returnPos = -1;
        while (m.find()) {
            returnPos = m.start();
        }
        if (returnPos < 0) {
            return query;
        }
        String prefix = query.substring(0, returnPos).trim();
        String suffix = query.substring(returnPos);
        String clause = String.join(" AND ", predicates);
        if (Pattern.compile("(?i)\\bWHERE\\b").matcher(prefix).find()) {
            return prefix + " AND " + clause + " " + suffix;
        }
        return prefix + " WHERE " + clause + " " + suffix;
    }

    private String formatValue(Object value) {
        if (value instanceof Number || value instanceof Boolean) {
            return String.valueOf(value);
        }
        String text = value == null ? "" : escapeCypherStringLiteral(value.toString());
        return "'" + text + "'";
    }

    private boolean sameCypherIgnoringWhitespace(String left, String right) {
        return canonicalCypher(left).equals(canonicalCypher(right));
    }

    private String canonicalCypher(String query) {
        if (query == null) {
            return "";
        }
        return query.replaceAll("\\s+", " ").trim();
    }

    private long executeCountSubquery(String query) {
        if (query == null || query.isBlank()) {
            return -1L;
        }
        String normalized = query.trim();
        if (normalized.endsWith(";")) {
            normalized = normalized.substring(0, normalized.length() - 1).trim();
        }
        String countQuery = "CALL { " + normalized + " } RETURN count(*) AS n";
        try (Transaction tx = candidateExecutionTimeoutSeconds > 0
            ? db.beginTx(candidateExecutionTimeoutSeconds, TimeUnit.SECONDS)
            : db.beginTx()) {
            Result res = tx.execute(countQuery);
            if (res.hasNext()) {
                Object value = res.next().get("n");
                if (value instanceof Number) {
                    tx.commit();
                    return ((Number) value).longValue();
                }
            }
            tx.commit();
        } catch (Exception ignored) {
        }
        return -1L;
    }

    private double calculateHeuristic(CypherAST ast, SchemaGraph.SchemaBounds bounds, long planEstimateRows) {
        long lower = -1;
        long upper = -1;
        if (bounds != null) {
            SchemaGraph.SchemaBounds adjusted = useFormalBounds
                ? bounds
                : applyPredicatesToBounds(ast, bounds);
            if (adjusted != null) {
                lower = adjusted.getLowerBound();
                upper = adjusted.getUpperBound();
            }
        } else if (planEstimateRows >= 0) {
            lower = planEstimateRows;
            upper = planEstimateRows;
        }

        if (strictTheoremMode) {
            if (whyMode == WhyMode.WHY_MANY) {
                return upper >= 0L && upper <= maxTarget ? 0.0 : costEpsilon;
            }
            // Zero is the universally admissible choice for empty/few/not.
            return 0.0;
        }

        if (lower == 0L && upper == 0L) {
            return 0.0;
        }

        switch (whyMode) {
            case WHY_EMPTY:
                // For why-empty we target a non-empty rewrite; bounds are not monotone enough
                // to estimate remaining work without risking inadmissibility.
                return 0.0;
            case WHY_FEW:
                if (lower >= minTarget && upper <= maxTarget) {
                    return 0.0;
                }
                if (lower < minTarget) {
                    long mid = upper >= 0 ? Math.max(1L, Math.round((lower + upper) / 2.0)) : Math.max(1L, lower);
                    double ratioFew = (double) minTarget / Math.max(1, mid);
                    return logWithRho(ratioFew);
                }
                if (upper > maxTarget) {
                    double ratioFew = (double) upper / Math.max(1, maxTarget);
                    return logWithRho(ratioFew);
                }
                return 0.0;
            case WHY_NOT:
                // One-obstacle indicator min(m,1). Multi-witness calls are
                // decomposed by the procedure and summed outside this search.
                return recoversWhyNotTuple(ast) ? 0.0 : costEpsilon;
            case WHY_MANY:
                if ((lower == 0L && upper == 0L) || upper <= maxTarget) {
                    return 0.0;
                }
                if (diagnostics.rhoDecreaseCertified) {
                    return costEpsilon * logWithRho((double) upper / Math.max(1L, maxTarget));
                }
                // Default why-many guidance is an indicator on the safe upper
                // bound; log guidance requires the per-query certificate.
                return costEpsilon;
            default:
                return 0.0;
        }
    }

    private double estimateUncertaintyWidth(CypherAST ast, SchemaGraph.SchemaBounds bounds, long estimatedRows) {
        SchemaGraph.SchemaBounds adjusted = useFormalBounds
            ? bounds
            : applyPredicatesToBounds(ast, bounds);
        double widthFromBounds = Double.POSITIVE_INFINITY;
        if (adjusted == null) {
            widthFromBounds = Double.POSITIVE_INFINITY;
        } else {
            long lower = adjusted.getLowerBound();
            long upper = adjusted.getUpperBound();
            if (lower >= 0 && upper >= 0) {
                widthFromBounds = Math.max(0.0, (double) upper - (double) lower);
            }
        }
        EstimatorConfidenceModel.Interval ci = confidenceModel.interval(estimatedRows, whyMode);
        double widthFromCi = ci.lower >= 0 && ci.upper >= 0
            ? Math.max(0.0, (double) ci.width())
            : Double.POSITIVE_INFINITY;
        return Math.max(widthFromBounds, widthFromCi);
    }

    private double logWithRho(double value) {
        double base = heuristicRho <= 1.0 ? 2.0 : heuristicRho;
        return Math.max(0.0, Math.log(Math.max(1.0, value)) / Math.log(base));
    }

    /**
     * Conservative per-query certificate for the sharpened why-many heuristic.
     * Threshold strengthening leaves the structural bound unchanged (ratio 1).
     * Adding key equalities can drop the root population by arbitrarily more
     * than rho, so predicate addition/restriction must use the indicator.
     */
    private boolean certifyGlobalRhoDecrease() {
        if (whyMode != WhyMode.WHY_MANY || allowedOperations == null || allowedOperations.isEmpty()) {
            return false;
        }
        for (ModificationOperation.Type type : allowedOperations) {
            if (type != ModificationOperation.Type.STRENGTHEN_PREDICATE) {
                return false;
            }
        }
        return true;
    }

    private long estimateNodeCount(Set<String> labels) {
        if (labels == null || labels.isEmpty() || labels.contains(SchemaPattern.ANY_LABEL)) {
            return Math.max(1L, schemaGraph.getTotalNodeCount());
        }
        long min = Long.MAX_VALUE;
        for (String l : labels) {
            long c = schemaGraph.getLabelCount(l);
            if (c > 0 && c < min) {
                min = c;
            }
        }
        if (min == Long.MAX_VALUE) {
            return Math.max(1L, schemaGraph.getTotalNodeCount());
        }
        return Math.max(1L, min);
    }

    private double edgeWeight(SchemaPattern.EdgePattern edge, SchemaGraph.SchemaCompatibility compatibility) {
        List<SchemaGraph.SchemaTriple> triples = compatibility.getCompatibleTriples().get(edge);
        if (triples == null || triples.isEmpty()) {
            return Double.MAX_VALUE;
        }
        double best = Double.MAX_VALUE;
        for (SchemaGraph.SchemaTriple t : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                t.getSourceLabel(), t.getRelationshipType(), t.getTargetLabel());
            if (stats == null) {
                continue;
            }
            double w = Math.max(1.0, stats.getAvgOutDegree());
            if (w < best) {
                best = w;
            }
        }
        return best;
    }

    private SchemaGraph.TripleStats chooseTripleStats(List<SchemaGraph.SchemaTriple> triples) {
        if (triples == null || triples.isEmpty()) {
            return null;
        }
        SchemaGraph.TripleStats best = null;
        long bestEdges = -1;
        for (SchemaGraph.SchemaTriple t : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                t.getSourceLabel(), t.getRelationshipType(), t.getTargetLabel());
            if (stats == null) {
                continue;
            }
            if (stats.getEdgeCount() > bestEdges) {
                bestEdges = stats.getEdgeCount();
                best = stats;
            }
        }
        return best;
    }

    private double estimateMaxOutDegree(SchemaPattern.EdgePattern edge,
                                        SchemaGraph.SchemaCompatibility compatibility,
                                        Map<Integer, Set<String>> nodeLabels) {
        SchemaGraph.TripleStats stats = chooseTripleStats(compatibility.getCompatibleTriples().get(edge));
        if (stats == null) {
            return Double.MAX_VALUE;
        }
        return estimateMaxOutDegree(stats, nodeLabels.getOrDefault(edge.getSourceId(), Set.of(SchemaPattern.ANY_LABEL)));
    }

    private double conservativeEdgeUpperFactor(SchemaPattern.EdgePattern edge,
                                               SchemaGraph.SchemaCompatibility compatibility,
                                               Map<Integer, Set<String>> nodeLabels) {
        if (edge == null || compatibility == null) {
            return Double.MAX_VALUE;
        }
        List<SchemaGraph.SchemaTriple> triples = compatibility.getCompatibleTriples().get(edge);
        if (triples == null || triples.isEmpty()) {
            return Double.MAX_VALUE;
        }
        Set<String> srcLabels = nodeLabels != null
            ? nodeLabels.getOrDefault(edge.getSourceId(), Set.of(SchemaPattern.ANY_LABEL))
            : Set.of(SchemaPattern.ANY_LABEL);
        double sum = 0.0;
        for (SchemaGraph.SchemaTriple triple : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                triple.getSourceLabel(), triple.getRelationshipType(), triple.getTargetLabel());
            if (stats == null) {
                continue;
            }
            double maxOut = estimateMaxOutDegree(stats, srcLabels);
            if (schemaCache.isFunctionalRelationship(triple.getSourceLabel(), triple.getRelationshipType())) {
                maxOut = Math.min(maxOut, 1.0);
            }
            sum += maxOut;
        }
        return sum > 0.0 ? sum : Double.MAX_VALUE;
    }

    private double averageEdgeExpansionFactor(SchemaPattern.EdgePattern edge,
                                              SchemaGraph.SchemaCompatibility compatibility,
                                              Map<Integer, Set<String>> nodeLabels) {
        if (edge == null || compatibility == null) {
            return 1.0;
        }
        List<SchemaGraph.SchemaTriple> triples = compatibility.getCompatibleTriples().get(edge);
        if (triples == null || triples.isEmpty()) {
            return 1.0;
        }
        Set<String> srcLabels = nodeLabels != null
            ? nodeLabels.getOrDefault(edge.getSourceId(), Set.of(SchemaPattern.ANY_LABEL))
            : Set.of(SchemaPattern.ANY_LABEL);
        double sum = 0.0;
        int count = 0;
        for (SchemaGraph.SchemaTriple triple : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                triple.getSourceLabel(), triple.getRelationshipType(), triple.getTargetLabel());
            if (stats == null) {
                continue;
            }
            double avg = Math.max(1.0, stats.getAvgOutDegree());
            double labelCount = 0.0;
            for (String l : srcLabels == null || srcLabels.isEmpty() ? List.of(SchemaPattern.ANY_LABEL) : srcLabels) {
                labelCount = Math.max(labelCount, (double) schemaGraph.getLabelCount(l));
            }
            double perLabel = labelCount > 0 ? (double) stats.getEdgeCount() / labelCount : stats.getEdgeCount();
            sum += Math.max(1.0, Math.max(avg, perLabel));
            count++;
        }
        if (count == 0) {
            return 1.0;
        }
        return Math.max(1.0, sum / count);
    }

    private double conservativeEdgeCountUpper(SchemaPattern.EdgePattern edge,
                                              SchemaGraph.SchemaCompatibility compatibility) {
        if (edge == null || compatibility == null) {
            return 1.0;
        }
        List<SchemaGraph.SchemaTriple> triples = compatibility.getCompatibleTriples().get(edge);
        if (triples == null || triples.isEmpty()) {
            return 1.0;
        }
        double sum = 0.0;
        for (SchemaGraph.SchemaTriple triple : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                triple.getSourceLabel(), triple.getRelationshipType(), triple.getTargetLabel());
            if (stats == null) {
                continue;
            }
            sum += Math.max(0.0, stats.getEdgeCount());
        }
        return Math.max(1.0, sum);
    }

    private double estimateMaxOutDegree(SchemaGraph.TripleStats stats, Set<String> srcLabels) {
        double avg = Math.max(1.0, stats.getAvgOutDegree());
        double maxOut = stats.getMaxOutDegree() > 0.0 ? stats.getMaxOutDegree() : avg;
        double labelCount = 0.0;
        for (String l : srcLabels == null || srcLabels.isEmpty() ? List.of(SchemaPattern.ANY_LABEL) : srcLabels) {
            labelCount = Math.max(labelCount, (double) schemaGraph.getLabelCount(l));
        }
        double perLabel = labelCount > 0 ? (double) stats.getEdgeCount() / labelCount : stats.getEdgeCount();
        return Math.max(1.0, Math.max(Math.max(maxOut, avg), perLabel));
    }

    private String describeSchemaViolations(SchemaGraph.SchemaCompatibility compatibility) {
        if (compatibility == null) {
            return "Schema compatibility unknown.";
        }
        List<String> violations = new ArrayList<>();
        for (Map.Entry<SchemaPattern.EdgePattern, List<SchemaGraph.SchemaTriple>> entry :
            compatibility.getCompatibleTriples().entrySet()) {
            if (entry.getValue().isEmpty()) {
                SchemaPattern.EdgePattern edge = entry.getKey();
                violations.add(edge.getDescription());
            }
        }
        if (violations.isEmpty()) {
            return "Pattern is schema-consistent.";
        }
        return "Schema-inconsistent pattern edges: " + String.join("; ", violations);
    }

    private double calculateSchemaPenalty(SchemaGraph.SchemaCompatibility previous,
                                          SchemaGraph.SchemaCompatibility current) {
        if (!useSchema) {
            return 0.0;
        }
        if (current == null || !current.isConsistent()) {
            return Double.POSITIVE_INFINITY;
        }
        double delta = schemaGraph.deltaCompatibleTriples(previous, current);
        if (Double.isInfinite(delta)) {
            return Double.POSITIVE_INFINITY;
        }
        return schemaPenaltyWeight * delta;
    }

    private double calculateSemanticDistance(String originalQuery, String rewrittenQuery) {
        // Simple Levenshtein distance normalized by length
        int distance = levenshteinDistance(originalQuery, rewrittenQuery);
        int maxLength = Math.max(originalQuery.length(), rewrittenQuery.length());
        return maxLength > 0 ? (double) distance / maxLength : 0.0;
    }
    
    private Map<String, Double> getRelationshipPropertySelectivities(String relType) {
        return relPropertySelectivityCache.computeIfAbsent(relType, type -> {
            Map<String, Double> selectivities = new HashMap<>();
            for (String prop : getRelationshipPropertiesFromSchema(type)) {
                try {
                    double sel = statistics.getRelationshipPropertySelectivity(type, prop);
                    if (Double.isNaN(sel) || sel <= 0.0) {
                        sel = 1.0; // treat unknown as unselective to avoid over-restricting
                    }
                    selectivities.put(prop, sel);
                } catch (Exception e) {
                    System.err.println("Failed to fetch relationship property selectivity for " + type + "." + prop + ": " + e.getMessage());
                }
            }
            return selectivities;
        });
    }
    
    private List<String> getRelationshipPropertiesFromSchema(String relType) {
        return relTypePropertiesCache.computeIfAbsent(relType, type -> {
            if (!allowDataQueries) {
                return Collections.emptyList();
            }
            List<String> props = new ArrayList<>();
            try (Transaction tx = db.beginTx()) {
                String q = "CALL db.schema.relTypeProperties() YIELD relType, propertyName " +
                    "WHERE relType = $type RETURN DISTINCT propertyName";
                Map<String, Object> params = Map.of("type", type);
                Result result = tx.execute(q, params);
                while (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    Object prop = row.get("propertyName");
                    if (prop != null) {
                        props.add(prop.toString());
                    }
                }
                tx.commit();
            } catch (Exception e) {
                System.err.println("Failed to load relationship properties for type " + type + ": " + e.getMessage());
            }
            return props;
        });
    }
    
    /**
     * Calculate modification complexity score
     */
    private double calculateModificationComplexity(List<ModificationStep> modifications) {
        double complexity = 0.0;
        for (ModificationStep step : modifications) {
            // Different operation types have different complexity weights
            switch (step.getOperation().getType()) {
                case DELETE_PREDICATE:
                    complexity += 0.5; // Low complexity - just removing
                    break;
                case RELAX_LABEL:
                case REPAIR_END_LABEL:
                case REPAIR_BOTH_END_LABELS:
                case WEAKEN_PREDICATE:
                case RELAX_PROPERTY:
                    complexity += 0.7; // Medium complexity - changing constraints
                    break;
                case ADD_PREDICATE:
                case ADD_LABEL:
                case ADD_EDGE:
                case STRENGTHEN_PREDICATE:
                    complexity += 1.0; // High complexity - adding new constraints
                    break;
                case MAKE_OPTIONAL:
                    complexity += 0.3; // Low complexity - structural change
                    break;
                default:
                    complexity += 0.5; // Default complexity
                    break;
            }
        }
        return complexity;
    }
    
    /**
     * Estimate execution time based on query plan statistics
     */
    private double estimateExecutionTime(Neo4jStatistics.QueryPlanStatistics planStats) {
        // EXPLAIN-only proxy: time ~ log(estCost) + sqrt(estimatedRows) / 1000.
        return Math.log(planStats.getEstCost() + 1) + Math.sqrt(Math.max(0L, planStats.getEstimatedRows())) / 1000.0;
    }
    
    /**
     * Simple Levenshtein distance implementation
     */
    private int levenshteinDistance(String s1, String s2) {
        int[][] dp = new int[s1.length() + 1][s2.length() + 1];
        
        for (int i = 0; i <= s1.length(); i++) {
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0) {
                    dp[i][j] = j;
                } else if (j == 0) {
                    dp[i][j] = i;
                } else {
                    dp[i][j] = Math.min(dp[i - 1][j - 1] + (s1.charAt(i - 1) == s2.charAt(j - 1) ? 0 : 1),
                                       Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1));
                }
            }
        }
        
        return dp[s1.length()][s2.length()];
    }

    /**
     * Verify that operations actually produced the given query and correct if needed
     */
    private List<ModificationStep> verifyAndCorrectOperations(CypherAST originalAST, 
                                                            CypherAST currentAST, 
                                                            List<ModificationStep> reportedOperations,
                                                            String originalQuery, 
                                                            String currentQuery) {
        // Enhanced verification: check what actually changed between queries
        List<ModificationStep> verifiedOperations = new ArrayList<>();
        
        // Check if CONTAINS predicate was deleted
        if (originalQuery.contains("CONTAINS") && !currentQuery.contains("CONTAINS")) {
            ModificationOperation deleteOp = new ModificationOperation(
                ModificationOperation.Type.DELETE_PREDICATE, 
                "predicate_contains", null, null, null
            );
            ModificationStep correctStep = new ModificationStep(deleteOp, 
                Arrays.asList("Deleted predicate containing CONTAINS clause"));
            verifiedOperations.add(correctStep);
        }
        
        // Check if WHERE clause was deleted
        if (originalQuery.contains("WHERE") && !currentQuery.contains("WHERE")) {
            ModificationOperation deleteOp = new ModificationOperation(
                ModificationOperation.Type.DELETE_PREDICATE, 
                "where_clause", null, null, null
            );
            ModificationStep correctStep = new ModificationStep(deleteOp, 
                Arrays.asList("Deleted WHERE clause"));
            verifiedOperations.add(correctStep);
        }
        
        // Check if labels were removed (e.g., :Person -> empty)
        if (originalQuery.contains(":Person") && !currentQuery.contains(":Person")) {
            ModificationOperation relaxOp = new ModificationOperation(
                ModificationOperation.Type.RELAX_LABEL, 
                "person_label", null, null, null
            );
            ModificationStep correctStep = new ModificationStep(relaxOp, 
                Arrays.asList("Removed label 'Person'"));
            verifiedOperations.add(correctStep);
        }
        
        // Check if Employee label was removed
        if (originalQuery.contains(":Employee") && !currentQuery.contains(":Employee")) {
            ModificationOperation relaxOp = new ModificationOperation(
                ModificationOperation.Type.RELAX_LABEL, 
                "employee_label", null, null, null
            );
            ModificationStep correctStep = new ModificationStep(relaxOp, 
                Arrays.asList("Removed label 'Employee'"));
            verifiedOperations.add(correctStep);
        }
        
        // Check if any other labels were removed (generic check)
        String[] commonLabels = {"Movie", "Company", "Department"};
        for (String label : commonLabels) {
            if (originalQuery.contains(":" + label) && !currentQuery.contains(":" + label)) {
                ModificationOperation relaxOp = new ModificationOperation(
                    ModificationOperation.Type.RELAX_LABEL, 
                    label.toLowerCase() + "_label", null, null, null
                );
                ModificationStep correctStep = new ModificationStep(relaxOp, 
                    Arrays.asList("Removed label '" + label + "'"));
                verifiedOperations.add(correctStep);
            }
        }
        
        // Check if MATCH was converted to OPTIONAL MATCH
        if (originalQuery.startsWith("MATCH") && currentQuery.startsWith("OPTIONAL MATCH")) {
            ModificationOperation optionalOp = new ModificationOperation(
                ModificationOperation.Type.MAKE_OPTIONAL, 
                "match_clause", null, null, null
            );
            ModificationStep correctStep = new ModificationStep(optionalOp, 
                Arrays.asList("Converted MATCH to OPTIONAL MATCH"));
            verifiedOperations.add(correctStep);
        }
        
        // If operations were detected, return them
        if (!verifiedOperations.isEmpty()) {
            return verifiedOperations;
        }
        
        // If no clear transformation detected, return reported operations as fallback
        return reportedOperations;
    }

    /**
     * Add restriction operations that decrease result count
     */
    private void addRestrictionOperations(CypherAST ast, List<ModificationOperation> operations) {
        addExistingPredicateStrengtheningOperations(ast, operations);
        // Add predicates to existing nodes
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String variable = node.getAttribute("variable", String.class);
            List<String> labels = node.getAttribute("labels", List.class);
            
            if (variable != null && labels != null && !labels.isEmpty()) {
                String primaryLabel = labels.get(0);
                
                // Add common property constraints using database statistics
                addPropertyConstraints(operations, node.getId(), primaryLabel, variable);
            }
        }

        // Add predicates on relationship properties to tighten edge patterns
        addRelationshipPropertyConstraints(ast, operations);
    }

    private void addLabelRestrictions(CypherAST ast, List<ModificationOperation> operations) {
        if (!useSchema) {
            return;
        }
        Set<String> allLabels = schemaCache.getAllLabels();
        if (allLabels.isEmpty()) {
            return;
        }
        int maxAddsPerNode = 2;
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            List<String> labels = node.getAttribute("labels", List.class);
            Set<String> existing = labels != null ? new HashSet<>(labels) : new HashSet<>();
            int added = 0;
            for (String label : allLabels) {
                if (existing.contains(label)) {
                    continue;
                }
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.ADD_LABEL,
                    node.getId(),
                    label,
                    null,
                    null
                ));
                added++;
                if (added >= maxAddsPerNode) {
                    break;
                }
            }
        }
    }

    private void addEdgeRestrictions(CypherAST ast, List<ModificationOperation> operations) {
        // The theorem-grade ADD_EDGE restriction may only connect already-bound
        // endpoints. The legacy implementation creates a fresh endpoint, which
        // can increase bag cardinality, so it is intentionally not generated.
    }
    
    /**
     * Add property constraints based on ACTUAL database statistics
     */
    private void addPropertyConstraints(List<ModificationOperation> operations, String nodeId, 
                                      String label, String variable) {
        try {
            // Get ALL properties for this label from database statistics
            Map<String, Double> selectivitiesFromStats = statistics.getAllPropertySelectivities(label);
            Map<String, Double> propertySelectivities = new HashMap<>(selectivitiesFromStats);
            
            if (propertySelectivities.isEmpty()) {
                Set<String> schemaProps = schemaCache.getPropertiesForLabel(label);
                for (String prop : schemaProps) {
                    propertySelectivities.put(prop, schemaCache.getPropertySelectivity(label, prop));
                }
            }
            
            if (propertySelectivities.isEmpty()) {
                System.out.println("WHY-REWRITE: No properties available for label " + label + ". Consider creating an index (e.g. CREATE INDEX ON :" + label + "(id)) to expose selectivities.");
            }
            
            // Sort properties by selectivity ascending and keep a bounded number
            List<Map.Entry<String, Double>> sortedProps = new ArrayList<>(propertySelectivities.entrySet());
            sortedProps.removeIf(e -> {
                double sel = e.getValue();
                if (Double.isNaN(sel) || sel <= 0.0) {
                    sel = schemaCache.getPropertySelectivity(label, e.getKey());
                }
                return Double.isNaN(sel) || sel <= 0.0 || sel >= PROPERTY_SELECTIVITY_MAX;
            });
            sortedProps.sort(Comparator.comparingDouble(Map.Entry::getValue));
            
            int addedProps = 0;
            for (Map.Entry<String, Double> entry : sortedProps) {
                if (addedProps >= MAX_PROPERTIES_PER_NODE) {
                    break;
                }
                String property = entry.getKey();
                double selectivity = entry.getValue();
                if (Double.isNaN(selectivity) || selectivity <= 0.0) {
                    selectivity = schemaCache.getPropertySelectivity(label, property);
                }
                if (Double.isNaN(selectivity) || selectivity <= 0.0 || selectivity >= PROPERTY_SELECTIVITY_MAX) {
                    continue;
                }
                
                // Use most common values ranked by selectivity; pick the most selective one
                List<Object> commonValues = statistics.getMostCommonValues(label, property, 5);
                if ((commonValues == null || commonValues.isEmpty())) {
                    commonValues = schemaCache.getCommonValuesForProperty(label, property);
                }
                Object bestValue = null;
                double bestSel = Double.MAX_VALUE;
                if (commonValues != null) {
                    for (Object value : commonValues) {
                        double valueSelectivity = statistics.getValueSelectivity(label, property, value);
                        if (valueSelectivity == 0.0) {
                            valueSelectivity = schemaCache.getPropertySelectivity(label, property);
                        }
                        if (valueSelectivity > 0.0 && valueSelectivity < bestSel && valueSelectivity < VALUE_SELECTIVITY_MAX) {
                            bestSel = valueSelectivity;
                            bestValue = value;
                        }
                    }
                }
                
                if (bestValue != null) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.ADD_PREDICATE,
                        nodeId, label, property,
                        new Object[]{"EQUALS", bestValue, bestSel}
                    ));
                    System.out.println("STATS: Adding selective equals constraint " + property + " = '" + bestValue +
                        "' (selectivity: " + bestSel + ")");
                    addedProps++;
                    continue;
                }

                // If no sampled values are available, fall back to schema defaults so we can still restrict.
                DatabaseSchemaCache.PropertyInfo info = schemaCache.getPropertyInfo(label, property);
                Object fallbackValue = null;
                if (info != null) {
                    Object minVal = info.getMinValue();
                    Object maxVal = info.getMaxValue();
                    if (minVal instanceof Number && maxVal instanceof Number) {
                        Object[] range = calculateSelectiveRange(minVal, maxVal, selectivity);
                        operations.add(new ModificationOperation(
                            ModificationOperation.Type.STRENGTHEN_PREDICATE,
                            nodeId,
                            label,
                            property,
                            new Object[]{"RANGE", range[0], range[1]}
                        ));
                        addedProps++;
                        continue;
                    } else {
                        fallbackValue = info.getAlternativeValue(null);
                    }
                }
                if (fallbackValue != null) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.ADD_PREDICATE,
                        nodeId, label, property,
                        new Object[]{"EQUALS", fallbackValue, selectivity}
                    ));
                    System.out.println("STATS: Adding fallback equals constraint " + property + " = '" + fallbackValue +
                        "' (selectivity: " + selectivity + ")");
                    addedProps++;
                    continue;
                }
                
                // Fallback: add a NOT NULL constraint if it can filter some rows
                double nullPercentage = statistics.getPropertyNullPercentage(label, property);
                if (Double.isNaN(nullPercentage)) {
                    DatabaseSchemaCache.PropertyInfo infoForNulls = schemaCache.getPropertyInfo(label, property);
                    if (infoForNulls != null && infoForNulls.getTotalCount() > 0) {
                        nullPercentage = (double) infoForNulls.getNullCount() / infoForNulls.getTotalCount();
                    } else {
                        nullPercentage = 0.0;
                    }
                }
                if (nullPercentage > 0.1 && nullPercentage < 0.5) { // 10-50% null values
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.ADD_PREDICATE,
                        nodeId, label, property,
                        new Object[]{"NOT_NULL", nullPercentage}
                    ));
                    addedProps++;
                    System.out.println("STATS: Adding NOT NULL constraint for " + property +
                        " (null percentage: " + nullPercentage + ")");
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to get property statistics: " + e.getMessage());
        }
    }
    
    /**
     * Calculate selective range based on actual data distribution
     */
    private Object[] calculateSelectiveRange(Object minValue, Object maxValue, double selectivity) {
        if (minValue instanceof Number && maxValue instanceof Number) {
            double min = ((Number) minValue).doubleValue();
            double max = ((Number) maxValue).doubleValue();
            double range = max - min;
            
            // Use selectivity to determine how restrictive to be
            double restrictionFactor = Math.max(0.3, 1.0 - selectivity); // More selective = more restrictive
            double newRange = range * restrictionFactor;
            double center = min + (range / 2);
            
            double newMin = center - (newRange / 2);
            double newMax = center + (newRange / 2);
            
            // JSON extrema may mix Integer (e.g. zero) and Long. Never narrow
            // a histogram endpoint to 32 bits based only on its minimum.
            if ((minValue instanceof Byte || minValue instanceof Short
                    || minValue instanceof Integer || minValue instanceof Long)
                    && (maxValue instanceof Byte || maxValue instanceof Short
                    || maxValue instanceof Integer || maxValue instanceof Long)) {
                return new Object[]{Math.round(newMin), Math.round(newMax)};
            } else {
                return new Object[]{newMin, newMax};
            }
        }
        
        return new Object[]{minValue, maxValue};
    }
    
    /**
     * Add predicates that tighten relationship patterns using edge properties
     */
    private void addRelationshipPropertyConstraints(CypherAST ast, List<ModificationOperation> operations) {
        for (ASTNode rel : ast.getNodesByType(NodeType.RELATIONSHIP)) {
            String relType = rel.getAttribute("type", String.class);
            String variable = rel.getAttribute("variable", String.class);
            if (relType == null || variable == null) {
                continue;
            }
            
            Map<String, Double> propertySelectivities = getRelationshipPropertySelectivities(relType);
            if (propertySelectivities.isEmpty()) {
                continue;
            }
            
            List<Map.Entry<String, Double>> sortedProps = new ArrayList<>(propertySelectivities.entrySet());
            sortedProps.removeIf(e -> {
                double sel = e.getValue();
                return Double.isNaN(sel) || sel <= 0.0 || sel >= REL_PROPERTY_SELECTIVITY_MAX;
            });
            sortedProps.sort(Comparator.comparingDouble(Map.Entry::getValue));
            
            int added = 0;
            for (Map.Entry<String, Double> entry : sortedProps) {
                if (added >= MAX_PROPERTIES_PER_REL) {
                    break;
                }
                String property = entry.getKey();
                
                // EXISTS on a selective edge property reduces the result set without guessing values
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.ADD_PREDICATE,
                    rel.getId(),
                    relType,
                    property,
                    new Object[]{"EXISTS"}
                ));
                added++;
            }
        }
    }
    
    private void addPredicateOperations(CypherAST ast, List<ModificationOperation> operations) {
        // Find all predicate nodes
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        List<PredicateDeletionCandidate> candidates = new ArrayList<>();
        for (ASTNode node : ast.getAllNodes()) {
            if (isPredicateNode(node)) {
                String varName = null;
                String propName = null;
                String label = null;
                double selectivity = 0.5;
                Object literalValue = null;
                List<ASTNode> children = ast.getChildren(node.getId());
                if (!children.isEmpty()) {
                    ASTNode firstChild = children.get(0);
                    if (firstChild.getType() == NodeType.PROPERTY) {
                        varName = firstChild.getAttribute("variable", String.class);
                        propName = firstChild.getAttribute("name", String.class);
                    }
                    if (children.size() > 1) {
                        ASTNode secondChild = children.get(1);
                        if (secondChild.getType() == NodeType.LITERAL) {
                            literalValue = secondChild.getAttribute("value", Object.class);
                        }
                    }
                }
                if (varName != null) {
                    label = varLabelMap.get(varName);
                }
                if (label != null && propName != null) {
                    double sel = schemaCache.getPropertySelectivity(label, propName);
                    if (!Double.isNaN(sel) && sel > 0.0) {
                        selectivity = sel;
                    }
                }
                if (literalValue != null && looksImpossibleLiteral(literalValue)) {
                    selectivity = 0.0;
                }
                candidates.add(new PredicateDeletionCandidate(node.getId(), varName, propName, label, selectivity));
            }
        }
        candidates.sort(Comparator.comparingDouble(c -> c.selectivity));
        for (PredicateDeletionCandidate candidate : candidates) {
            operations.add(new ModificationOperation(
                ModificationOperation.Type.DELETE_PREDICATE,
                candidate.predicateId,
                candidate.label,
                candidate.property,
                null,
                candidate.variable
            ));
            ASTNode predNode = ast.getNode(candidate.predicateId);
            if (predNode != null) {
                addPropertyWeakeningOperations(ast, predNode, operations);
                for (String key : propertyKeyRepairsFor(ast, predNode, varLabelMap)) {
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.REPAIR_PROPERTY_KEY,
                        candidate.predicateId, candidate.label, key, null, candidate.variable));
                }
            }
        }
    }

    private static final class PredicateDeletionCandidate {
        final String predicateId;
        final String variable;
        final String property;
        final String label;
        final double selectivity;

        PredicateDeletionCandidate(String predicateId, String variable, String property, String label, double selectivity) {
            this.predicateId = predicateId;
            this.variable = variable;
            this.property = property;
            this.label = label;
            this.selectivity = selectivity;
        }
    }
    
    private void addPropertyWeakeningOperations(CypherAST ast, ASTNode predicateNode, List<ModificationOperation> operations) {
        if (predicateNode == null) {
            return;
        }
        List<ASTNode> children = ast.getChildren(predicateNode.getId());
        if (children.size() >= 2) {
            ASTNode propertyNode = children.get(0);
            ASTNode valueNode = children.get(1);
            
            if (propertyNode.getType() == NodeType.PROPERTY && valueNode.getType() == NodeType.LITERAL) {
                Object value = valueNode.getAttribute("value");
                if (value instanceof Number) {
                    String variable = propertyNode.getAttribute("variable", String.class);
                    String property = propertyNode.getAttribute("name", String.class);
                    String label = buildVariableLabelMap(ast).get(variable);
                    List<Double> boundaries = label != null
                        ? schemaCache.getHistogramBoundaries(label, property)
                        : Collections.emptyList();
                    List<Double> eligible = thresholdCandidates(
                        boundaries, ((Number) value).doubleValue(), predicateNode.getType(), true);
                    for (Double boundary : eligible) {
                        operations.add(new ModificationOperation(
                            ModificationOperation.Type.WEAKEN_PREDICATE,
                            predicateNode.getId(), label, property, new Object[]{boundary}, variable));
                    }
                    if (!eligible.isEmpty()) {
                        return;
                    }
                    // Create range around the value
                    double numValue = ((Number) value).doubleValue();
                    double range = Math.max(Math.abs(numValue) * 0.2, 1.0);
                    
                    operations.add(new ModificationOperation(
                        ModificationOperation.Type.WEAKEN_PREDICATE,
                        predicateNode.getId(),
                        propertyNode.getAttribute("variable", String.class),
                        propertyNode.getAttribute("name", String.class),
                        new Object[]{numValue - range, numValue + range}
                    ));
                }
            }
        }
    }

    private void addExistingPredicateStrengtheningOperations(CypherAST ast,
                                                              List<ModificationOperation> operations) {
        Map<String, String> labels = buildVariableLabelMap(ast);
        for (ASTNode predicate : ast.getAllNodes()) {
            if (predicate == null || !isRangeComparison(predicate.getType())) {
                continue;
            }
            ASTNode propertyNode = null;
            ASTNode literalNode = null;
            for (ASTNode child : ast.getChildren(predicate.getId())) {
                if (child.getType() == NodeType.PROPERTY) propertyNode = child;
                if (child.getType() == NodeType.LITERAL) literalNode = child;
            }
            if (propertyNode == null || literalNode == null) continue;
            Object value = literalNode.getAttribute("value");
            if (!(value instanceof Number)) continue;
            String variable = propertyNode.getAttribute("variable", String.class);
            String property = propertyNode.getAttribute("name", String.class);
            String label = labels.get(variable);
            List<Double> boundaries = label != null
                ? schemaCache.getHistogramBoundaries(label, property)
                : Collections.emptyList();
            for (Double boundary : thresholdCandidates(
                boundaries, ((Number) value).doubleValue(), predicate.getType(), false)) {
                operations.add(new ModificationOperation(
                    ModificationOperation.Type.STRENGTHEN_PREDICATE,
                    predicate.getId(), label, property, new Object[]{boundary}, variable));
            }
        }
    }

    private boolean isRangeComparison(NodeType type) {
        return type == NodeType.GREATER_THAN || type == NodeType.GREATER_THAN_OR_EQUAL
            || type == NodeType.LESS_THAN || type == NodeType.LESS_THAN_OR_EQUAL;
    }

    private List<Double> thresholdCandidates(List<Double> boundaries,
                                             double current,
                                             NodeType type,
                                             boolean weaken) {
        if (boundaries == null || boundaries.isEmpty() || !isRangeComparison(type)) {
            return Collections.emptyList();
        }
        boolean greater = type == NodeType.GREATER_THAN || type == NodeType.GREATER_THAN_OR_EQUAL;
        List<Double> eligible = boundaries.stream()
            .filter(Objects::nonNull)
            .filter(v -> weaken ? (greater ? v < current : v > current)
                                : (greater ? v > current : v < current))
            .sorted(Comparator.comparingDouble(v -> Math.abs(v - current)))
            .limit(config.getMaxThresholdCandidatesPerPredicate())
            .collect(Collectors.toList());
        return eligible;
    }
    
    private boolean isPredicateNode(ASTNode node) {
        NodeType type = node.getType();
        return type == NodeType.PREDICATE ||
               type == NodeType.EQUALS || type == NodeType.GREATER_THAN || 
               type == NodeType.LESS_THAN || type == NodeType.GREATER_THAN_OR_EQUAL ||
               type == NodeType.LESS_THAN_OR_EQUAL || type == NodeType.IN ||
               type == NodeType.CONTAINS || type == NodeType.STARTS_WITH;
    }

    /**
     * Remove any predicates that reference the same variable/property combination.
     */
    private void removeMatchingPredicates(CypherAST ast, String variable, String propertyName) {
        if (ast == null || variable == null || propertyName == null) {
            return;
        }
        Set<String> predicateIds = new HashSet<>();
        for (ASTNode propertyNode : ast.getNodesByType(NodeType.PROPERTY)) {
            String var = propertyNode.getAttribute("variable", String.class);
            String prop = propertyNode.getAttribute("name", String.class);
            if (variable.equals(var) && propertyName.equals(prop)) {
                String predicateId = findParentPredicate(ast, propertyNode.getId());
                if (predicateId != null) {
                    predicateIds.add(predicateId);
                }
            }
        }
        for (String predicateId : predicateIds) {
            removePredicateSubtree(ast, predicateId);
        }
        if (!predicateIds.isEmpty()) {
            removeEmptyWhereClauses(ast);
        }
    }

    /**
     * Remove a predicate node and its children to avoid dangling property/literal nodes.
     */
    private void removePredicateSubtree(CypherAST ast, String predicateId) {
        if (ast == null || predicateId == null) {
            return;
        }
        List<String> children = new ArrayList<>(ast.getEdges().getOrDefault(predicateId, Collections.emptyList()));
        for (String childId : children) {
            removePredicateSubtree(ast, childId);
        }
        ast.removeNode(predicateId);
    }

    /**
     * Drop predicates whose numeric thresholds are outside observed schema bounds (e.g., released > 200000).
     */
    private void pruneImpossiblePredicates(CypherAST ast) {
        // Do not mutate the query here. Predicate impossibility should guide ranking
        // and blocker detection, not silently rewrite the user's query before search.
    }
    
    /**
     * Apply a modification operation to an AST
     */
    private ASTModificationOperations.ModificationResult applyOperation(CypherAST ast, ModificationOperation operation) {
        switch (operation.getType()) {
            case DELETE_NODE:
                return ASTModificationOperations.deleteNode(ast, operation.getTargetId());
                
            case DELETE_RELATIONSHIP:
            case DEL_EDGE:
                return ASTModificationOperations.deleteRelationship(ast, operation.getTargetId());

            case REPLACE_RELATIONSHIP_TYPE:
                return ASTModificationOperations.replaceRelationshipType(
                    ast,
                    operation.getTargetId(),
                    operation.getTargetLabel()
                );

            case FLIP_RELATIONSHIP_DIRECTION:
                return ASTModificationOperations.flipRelationshipDirection(ast, operation.getTargetId());
                
            case REPAIR_PROPERTY_KEY: {
                ASTNode target = ast.getNode(operation.getTargetId());
                if (target != null && target.getType() == NodeType.NODE) {
                    Object[] r = operation.getRange();
                    return ASTModificationOperations.repairInlinePropertyKey(
                        ast, operation.getTargetId(), r != null && r.length > 0 ? String.valueOf(r[0]) : null,
                        operation.getTargetProperty());
                }
                return ASTModificationOperations.repairPropertyKey(
                    ast, operation.getTargetId(), operation.getTargetProperty());
            }

            case DELETE_PREDICATE:
            case RELAX_ENDPOINT_PREDICATE:
                PredicateContext predicateContext = operation.getTargetVariable() != null
                    ? new PredicateContext(operation.getTargetVariable(), operation.getTargetProperty())
                    : extractPredicateContext(ast, operation.getTargetId());
                ASTModificationOperations.ModificationResult deleteResult = ASTModificationOperations.deletePredicate(ast, operation.getTargetId());
                if (deleteResult.isSuccessful()) {
                    CypherAST cleaned = deleteResult.getModifiedAST();
                    removeMatchingPredicates(cleaned, predicateContext.variable, predicateContext.property);
                    removeEmptyWhereClauses(cleaned);
                    deleteResult.setModifiedAST(cleaned);
                }
                return deleteResult;

            case WEAKEN_PREDICATE:
                if (operation.getRange() != null && operation.getRange().length == 1) {
                    return ASTModificationOperations.replacePredicateThreshold(
                        ast, operation.getTargetId(), operation.getRange()[0]);
                }
                return ASTModificationOperations.relaxProperty(ast, operation.getTargetId(), operation.getRange());
                
            case RELAX_LABEL:
                return ASTModificationOperations.relaxLabel(ast, operation.getTargetId(), operation.getTargetLabel());
                
            case RELAX_PROPERTY:
                return ASTModificationOperations.relaxProperty(ast, operation.getTargetId(), operation.getRange());
            
            case RELAX_NODE_PROPERTY:
                return ASTModificationOperations.relaxNodeProperty(
                    ast,
                    operation.getTargetId(),
                    operation.getTargetProperty()
                );
                
            case MAKE_OPTIONAL:
                return ASTModificationOperations.makeOptionalMatch(ast, operation.getTargetId());

            case REPAIR_END_LABEL:
                return ASTModificationOperations.repairEndLabel(ast, operation.getTargetId(), operation.getTargetLabel());

            case REPAIR_BOTH_END_LABELS:
                return ASTModificationOperations.repairBothEndLabels(
                    ast,
                    operation.getTargetId(), operation.getTargetLabel(),
                    (String) operation.getRange()[0], (String) operation.getRange()[1]
                );

            // NEW RESTRICTION OPERATIONS for WHY_MANY
            case ADD_PREDICATE:
                return ASTModificationOperations.addPredicate(ast, operation.getTargetId(), 
                    operation.getTargetProperty(), operation.getRange());
                
            case ADD_LABEL:
                return ASTModificationOperations.addLabel(ast, operation.getTargetId(), operation.getTargetLabel());
                
            case ADD_EDGE:
            case ADD_RELATIONSHIP:
                return ASTModificationOperations.addRelationship(ast, operation.getTargetId(), operation.getTargetLabel());
                
            case STRENGTHEN_PREDICATE:
                if (operation.getRange() != null && operation.getRange().length == 1) {
                    return ASTModificationOperations.replacePredicateThreshold(
                        ast, operation.getTargetId(), operation.getRange()[0]);
                }
            case RESTRICT_PROPERTY:
                return ASTModificationOperations.restrictProperty(ast, operation.getTargetId(), 
                    operation.getTargetProperty(), operation.getRange());
            case ADD_LIMIT:
                ASTModificationOperations.ModificationResult disabledLimit =
                    new ASTModificationOperations.ModificationResult();
                disabledLimit.addError("ADD_LIMIT is disabled: limit-only rewrites do not explain cardinality.");
                return disabledLimit;
                
            case ADD_ORDER_BY:
                return ASTModificationOperations.addOrderBy(ast, operation.getTargetProperty(), operation.getRange());
                
            default:
                ASTModificationOperations.ModificationResult result = new ASTModificationOperations.ModificationResult();
                result.addError("Unknown operation type: " + operation.getType());
                return result;
        }
    }
    
    /**
     * Parse Cypher query into AST (placeholder - would use real parser)
     */
    private CypherAST parseQuery(String cypherQuery) {
        // This would integrate with a real Cypher parser
        // For now, return a simplified AST
        try {
            return CypherASTBuilder.parseQuery(cypherQuery);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Repair invalid AST according to AST Transformation Validity theorem
     */
    private CypherAST repairInvalidAST(CypherAST invalidAST, CypherAST.ValidationResult validationResult) {
        CypherAST repairedAST = invalidAST.deepCopy();
        
        for (String error : validationResult.getErrors()) {
            if (error.contains("Variable") && error.contains("used but not declared")) {
                // Extract variable name from error message
                String varName = extractVariableName(error);
                if (varName != null) {
                    // Add variable declaration by finding the first node pattern and adding variable
                    addVariableDeclaration(repairedAST, varName);
                }
            }
            
            if (error.contains("Invalid WHERE clause")) {
                // Remove empty WHERE clauses
                removeEmptyWhereClauses(repairedAST);
            }
            
            if (error.contains("Invalid RETURN clause")) {
                // Fix RETURN clause by adding declared variables
                fixReturnClause(repairedAST);
            }
        }
        
        return repairedAST;
    }
    
    /**
     * Fix missing predicate values in ANY query by extracting values from original query
     * Works with any variable names, property names, and data types
     */
    private String fixMissingPredicateValues(String modifiedQuery, String originalQuery) {
        if (modifiedQuery == null || originalQuery == null) {
            return modifiedQuery;
        }
        
        try {
            String result = modifiedQuery;
            
            // Step 1: Extract all property-value pairs from the original query
            Map<String, String> originalValues = extractPropertyValues(originalQuery);
            
            // Step 2: Find and fix missing values using original values as fallback
            result = fixMissingValuesWithOriginals(result, originalValues);
            
            // Step 3: For any remaining missing values, use intelligent defaults
            result = fixRemainingMissingValues(result);
            
            // Step 4: Fix broken logical operators
            result = fixBrokenLogicalOperators(result);
            
            return result;
            
        } catch (Exception e) {
            System.err.println("Failed to fix missing predicate values: " + e.getMessage());
            return modifiedQuery;
        }
    }
    
    /**
     * Extract property-value pairs from original query
     * Returns map like: {"p.city" -> "'NonExistentCity'", "p.age" -> "1"}
     */
    private Map<String, String> extractPropertyValues(String originalQuery) {
        Map<String, String> values = new HashMap<>();
        
        // Pattern: variable.property = value
        // Matches: p.city = 'London', node.age = 25, x.name = "John", etc.
        String pattern = "([a-zA-Z_][a-zA-Z0-9_]*)\\.([a-zA-Z_][a-zA-Z0-9_]*)\\s*=\\s*([^\\s,)]+(?:\\s+[^\\s,)]+)*)";
        
        java.util.regex.Pattern regex = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher matcher = regex.matcher(originalQuery);
        
        while (matcher.find()) {
            String variable = matcher.group(1);
            String property = matcher.group(2);
            String value = matcher.group(3).trim();
            
            // Store full property reference and its value
            String propertyRef = variable + "." + property;
            values.put(propertyRef, value);
        }
        
        return values;
    }
    
    /**
     * Fix missing values using original query values
     */
    private String fixMissingValuesWithOriginals(String query, Map<String, String> originalValues) {
        String result = query;
        
        // For each known property-value pair from original query
        for (Map.Entry<String, String> entry : originalValues.entrySet()) {
            String propertyRef = entry.getKey();
            String originalValue = entry.getValue();
            
            // Escape dots for regex
            String escapedPropRef = propertyRef.replace(".", "\\.");
            
            // Find pattern: "property =" without a value
            String missingValuePattern = escapedPropRef + "\\s*=\\s*(?=\\s|$|AND|OR|,|\\))";
            
            if (result.matches(".*" + missingValuePattern + ".*")) {
                // Replace with realistic alternative based on original value
                String newValue = generateAlternativeValue(originalValue);
                result = result.replaceAll(missingValuePattern, propertyRef + " = " + newValue);
            }
        }
        
        return result;
    }
    
    /**
     * Generate alternative value based on original value type and content
     */
    private String generateAlternativeValue(String originalValue) {
        // Remove surrounding quotes for analysis
        String cleaned = originalValue.replaceAll("^['\"]|['\"]$", "");
        
        // String values - use schema cache to get actual alternative values
        if (originalValue.startsWith("'") || originalValue.startsWith("\"")) {
            // For string values, we need context (label/property) to get real alternatives
            // Return modified original for now - this should be called with context
            return "'" + cleaned + "_alt'";
        }
        
        // Numeric values
        try {
            if (originalValue.contains(".")) {
                double num = Double.parseDouble(originalValue);
                return String.valueOf(num + 1.0); // Increment for variety
            } else {
                long num = Long.parseLong(originalValue);
                return String.valueOf(num + 1); // Increment for variety
            }
        } catch (NumberFormatException e) {
            // Not a number, treat as string - use simple alternative
            return "'" + cleaned + "_alt'";
        }
    }
    
    /**
     * Generate alternative string value using database schema cache
     */
    private String generateAlternativeStringValue(String original, String label, String property) {
        try {
            String cleanOriginal = original.replaceAll("^['\"]|['\"]$", "");
            
            // Get alternative value from schema cache
            Object altValue = schemaCache.getAlternativeValue(label, property, cleanOriginal);
            
            if (altValue != null) {
                if (altValue instanceof String) {
                    return "'" + altValue + "'";
                } else {
                    return "'" + altValue.toString() + "'";
                }
            }
            
            // Fallback: if no alternative found, return a generic one
            return "'alternative_value'";
            
        } catch (Exception e) {
            System.err.println("ERROR: Failed to get alternative value from schema cache: " + e.getMessage());
            return "'alternative_value'";
        }
    }
    
    /**
     * Fix any remaining missing values with database-driven defaults
     */
    private String fixRemainingMissingValues(String query) {
        String result = query;
        
        // Extract label information from the query
        String label = extractLabelFromQuery(query);
        if (label == null) {
            System.err.println("ERROR: Could not extract label from query: " + query);
            return result; // Return unchanged if we can't determine label
        }
        
        // Use actual property names for intelligent defaults
        java.util.regex.Pattern regex = java.util.regex.Pattern.compile("([a-zA-Z_][a-zA-Z0-9_]*)\\.([a-zA-Z_][a-zA-Z0-9_]*)\\s*=\\s*(?=\\s|$|AND|OR|,|\\))");
        java.util.regex.Matcher matcher = regex.matcher(result);
        
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String variable = matcher.group(1);
            String property = matcher.group(2);
            // Now pass both property and label to get database-driven default
            String replacement = variable + "." + property + " = " + getIntelligentDefault(property, label);
            matcher.appendReplacement(sb, replacement);
        }
        matcher.appendTail(sb);
        
        return sb.toString();
    }
    
    /**
     * Extract the primary label from a Cypher query
     */
    private String extractLabelFromQuery(String query) {
        // Pattern to match MATCH (variable:Label) constructs
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("MATCH\\s*\\([^:]*:([a-zA-Z_][a-zA-Z0-9_:]*)", java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher matcher = pattern.matcher(query);
        
        if (matcher.find()) {
            String labelPart = matcher.group(1);
            // Handle multiple labels like "Person:Employee" - take the first one
            String[] labels = labelPart.split(":");
            return labels[0].trim();
        }
        
        return null;
    }
    
    /**
     * Get intelligent default value using the database schema cache
     */
    private String getIntelligentDefault(String propertyName, String label) {
        try {
            // Use schema cache to get actual default value
            return schemaCache.getDefaultValueAsString(label, propertyName);
            
        } catch (Exception e) {
            System.err.println("ERROR: Failed to get default value from schema cache for " + label + "." + propertyName + ": " + e.getMessage());
            return "'default_value'";
        }
    }
    
    
    /**
     * Fix broken logical operators (AND AND, OR OR, dangling AND/OR)
     */
    private String fixBrokenLogicalOperators(String query) {
        String result = query;
        
        // Fix duplicate operators
        result = result.replaceAll("AND\\s+AND", "AND");
        result = result.replaceAll("OR\\s+OR", "OR");
        
        // Fix dangling operators at end
        result = result.replaceAll("\\s+AND\\s*(?=RETURN|$)", " ");
        result = result.replaceAll("\\s+OR\\s*(?=RETURN|$)", " ");
        
        // Fix operators without operands
        result = result.replaceAll("WHERE\\s+AND\\s+", "WHERE ");
        result = result.replaceAll("WHERE\\s+OR\\s+", "WHERE ");
        
        // Fix malformed WHERE clauses
        result = result.replaceAll("WHERE\\s+(?=RETURN)", "");
        
        return result;
    }
    
    /**
     * Ensure Cypher query is valid - fix common syntax issues
     */
    private String ensureValidCypherQuery(String query) {
        if (query == null || query.trim().isEmpty()) {
            return null;
        }
        
        // Step 1: Fix multiple spaces first
        query = query.replaceAll("\\s+", " ").trim();
        
        // Step 2: Fix empty WHERE clauses - comprehensive patterns
        query = query.replaceAll("WHERE\\s+RETURN", "RETURN");
        query = query.replaceAll("WHERE\\s*RETURN", "RETURN"); 
        query = query.replaceAll("WHERE\\s+$", "");
        query = query.replaceAll("WHERE\\s*$", "");
        
        // Step 3: Fix patterns like "MATCH (n) WHERE  RETURN n"
        query = query.replaceAll("WHERE\\s{2,}RETURN", "RETURN");
        query = query.replaceAll("WHERE\\s{2,}", "WHERE ");
        
        // Step 4: Clean up extra spaces around keywords
        query = query.replaceAll("MATCH\\s+", "MATCH ");
        query = query.replaceAll("WHERE\\s+", "WHERE ");
        query = query.replaceAll("RETURN\\s+", "RETURN ");
        
        // Step 5: Fix empty RETURN clauses
        if (query.contains("RETURN ") && query.matches(".*RETURN\\s*$")) {
            // Add a default variable if RETURN is empty
            if (query.contains("(n")) {
                query = query.replaceAll("RETURN\\s*$", "RETURN n");
            } else if (query.contains("(p")) {
                query = query.replaceAll("RETURN\\s*$", "RETURN p");
            } else {
                query = query.replaceAll("RETURN\\s*$", "RETURN *");
            }
        }
        
        // Step 6: Final cleanup - normalize all spacing
        query = query.replaceAll("\\s+", " ").trim();
        
        // Step 7: Validate final structure
        if (query.matches(".*WHERE\\s+RETURN.*")) {
            query = query.replaceAll("WHERE\\s+RETURN", "RETURN");
        }
        
        // Step 8: Ensure query doesn't end with WHERE
        if (query.endsWith(" WHERE")) {
            query = query.substring(0, query.length() - 6).trim();
        }
        
        return query;
    }
    
    private String extractVariableName(String errorMessage) {
        // Extract variable name from "Variable 'varname' is used but not declared"
        int start = errorMessage.indexOf("'") + 1;
        int end = errorMessage.lastIndexOf("'");
        if (start > 0 && end > start) {
            return errorMessage.substring(start, end);
        }
        return null;
    }

    private Map<String, String> buildVariableLabelMap(CypherAST ast) {
        Map<String, String> map = new HashMap<>();
        if (ast == null) {
            return map;
        }
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String var = node.getAttribute("variable", String.class);
            List<String> labels = node.getAttribute("labels", List.class);
            if (var != null && labels != null && !labels.isEmpty()) {
                map.put(var, labels.get(0));
            }
        }
        return map;
    }

    private com.whyquery.neo4j.schema.DatabaseSchemaCache.PropertyInfo resolvePropertyInfo(
        String variable, String property, Map<String, String> varLabelMap) {
        if (property == null || property.isBlank()) {
            return null;
        }
        String label = varLabelMap.get(variable);
        if (label != null) {
            com.whyquery.neo4j.schema.DatabaseSchemaCache.PropertyInfo info =
                schemaCache.getPropertyInfo(label, property);
            if (info != null) {
                return info;
            }
        }
        // Fallback: find any label that has this property uniquely
        com.whyquery.neo4j.schema.DatabaseSchemaCache.PropertyInfo found = null;
        for (String lbl : schemaCache.getAllLabels()) {
            com.whyquery.neo4j.schema.DatabaseSchemaCache.PropertyInfo info =
                schemaCache.getPropertyInfo(lbl, property);
            if (info != null) {
                if (found != null) {
                    return null; // ambiguous across labels
                }
                found = info;
            }
        }
        return found;
    }

    private boolean isNumericLiteral(Object val) {
        return val instanceof Number;
    }

    private double toDouble(Object val) {
        return val instanceof Number ? ((Number) val).doubleValue() : Double.NaN;
    }
    
    private void addVariableDeclaration(CypherAST ast, String varName) {
        // Find first node pattern and ensure it has the variable
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            String existingVar = node.getAttribute("variable", String.class);
            if (existingVar == null) {
                node.setAttribute("variable", varName);
                break;
            }
        }
    }
    
    private void removeEmptyWhereClauses(CypherAST ast) {
        // Remove WHERE nodes that have no children
        List<ASTNode> whereNodes = ast.getNodesByType(NodeType.WHERE);
        for (ASTNode whereNode : whereNodes) {
            List<String> children = ast.getEdges().get(whereNode.getId());
            if (children == null || children.isEmpty()) {
                ast.removeNode(whereNode.getId());
            }
        }
    }
    
    private void fixReturnClause(CypherAST ast) {
        // Ensure RETURN clause has at least one variable
        List<ASTNode> returnNodes = ast.getNodesByType(NodeType.RETURN);
        for (ASTNode returnNode : returnNodes) {
            List<String> children = ast.getEdges().get(returnNode.getId());
            if (children == null || children.isEmpty()) {
                // Add first declared variable to RETURN
                for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
                    String varName = node.getAttribute("variable", String.class);
                    if (varName != null) {
                        String varNodeId = ast.addNode(NodeType.VARIABLE, Map.of("name", varName));
                        ast.addEdge(returnNode.getId(), varNodeId);
                        break;
                    }
                }
            }
        }
    }

    /**
     * Validate that a query is syntactically correct
     */
    private boolean isValidCypherQuery(String query) {
        try {
            if (usePlannerStats) {
                // Use Neo4j's EXPLAIN to validate syntax without execution
                getPlannerStatistics(query);
            } else {
                // Snapshot/AST-only mode: validate by parsing into our AST
                CypherASTBuilder.parseQuery(query);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Return the whitespace-normalized generated Cypher used as the exact
     * syntactic state key. Despite the legacy method name, this is not a hash
     * and intentionally does not merge alpha-equivalent queries.
     */
    private String computeASTHash(CypherAST ast) {
        if (ast == null) {
            return "";
        }
        return ast.generateCypher().replaceAll("\\s+", " ").trim();
    }

    private boolean mayUseHeuristicFallbacks() {
        return !strictTheoremMode;
    }
    
    private Neo4jStatistics.QueryPlanStatistics getPlannerStatistics(String query) {
        if (!usePlannerStats) {
            return new Neo4jStatistics.QueryPlanStatistics(-1L, -1L, -1L);
        }
        if (!config.isEnableStatisticsCache()) {
            long started = System.nanoTime();
            diagnostics.plannerCalls++;
            try {
                return statistics.getQueryPlanStatistics(query);
            } finally {
                diagnostics.plannerTimeNanos += System.nanoTime() - started;
            }
        }
        
        long now = System.currentTimeMillis();
        PlanStatsCacheEntry cached = planStatsCache.get(query);
        if (cached != null && cached.expiresAt >= now) {
            diagnostics.plannerCacheHits++;
            return cached.stats;
        }

        long started = System.nanoTime();
        diagnostics.plannerCalls++;
        Neo4jStatistics.QueryPlanStatistics planStats;
        try {
            planStats = statistics.getQueryPlanStatistics(query);
        } finally {
            diagnostics.plannerTimeNanos += System.nanoTime() - started;
        }
        planStatsCache.put(query, new PlanStatsCacheEntry(planStats, now + config.getStatisticsCacheTTL()));
        return planStats;
    }
    
    private long estimateCardinalityFromPlan(String query) {
        try {
            Neo4jStatistics.QueryPlanStatistics stats = getPlannerStatistics(query);
            return stats != null ? stats.getEstimatedRows() : -1L;
        } catch (Exception e) {
            return -1L;
        }
    }
    
    private long estimatePlanRows(CypherAST ast) {
        try {
            String q = ast.generateCypher();
            return estimateCardinalityFromPlan(q);
        } catch (Exception ignored) {
            return -1L;
        }
    }
    
    private SchemaGraph.SchemaBounds applyLimitToBounds(SchemaGraph.SchemaBounds bounds, String query) {
        if (bounds == null) {
            return null;
        }
        long limit = extractLimitValue(query);
        if (limit >= 0) {
            long lower = Math.min(bounds.getLowerBound(), limit);
            long upper = Math.min(bounds.getUpperBound(), limit);
            return new SchemaGraph.SchemaBounds(lower, upper);
        }
        return bounds;
    }

    /**
     * Formal schema-aware cardinality bounds using a spanning-tree decomposition
     * with schema statistics. Approximates Definition~\\ref{def:card-bounds}.
     */
    /**
     * A pattern with no relationship edges (e.g. {@code MATCH (n:Place) WHERE n.id > X
     * RETURN n}) has no join structure for the tree-based bound below to reason about.
     * The previous fallback -- {@code schemaGraph.estimateBounds(pattern)} on an "empty"
     * pattern -- returns the sum of every label's population across the WHOLE schema,
     * ignoring both the query's own label and any WHERE predicates entirely: every
     * WEAKEN_PREDICATE candidate for a lone-node numeric range predicate collapsed to the
     * same nonsensical whole-database estimate regardless of the chosen threshold, which
     * inflated their heuristic/uncertainty cost enough to lose to modification_threshold
     * every time. Estimate the node's own label population instead, scaled by the product
     * of its own predicates' histogram-informed selectivities (same primitive already used
     * for operation cost via predicateSelectivity). Multiple edge-free nodes form a
     * Cartesian product, so both the point estimate and the safe why-many ceiling multiply
     * their per-node terms with saturation.
     */
    private SchemaGraph.SchemaBounds estimateLoneNodeBounds(CypherAST ast) {
        if (ast == null) {
            return schemaGraph.estimateBounds(null);
        }
        List<ASTNode> nodes = ast.getNodesByType(NodeType.NODE);
        if (nodes.isEmpty()) {
            return schemaGraph.estimateBounds(null);
        }
        Map<String, String> varLabelMap = buildVariableLabelMap(ast);
        long pointProduct = 1L;
        long safeUpperProduct = 1L;
        for (ASTNode node : nodes) {
            String variable = node.getAttribute("variable", String.class);
            String label = variable != null ? varLabelMap.get(variable) : null;
            long base = estimateNodeCount(label != null ? Set.of(label) : Set.of());
            // base (the exact recorded label population) is itself a SOUND upper bound
            // for this node regardless of any predicate: a WHERE filter can only shrink
            // the matching set, never grow it beyond the label's total count.
            safeUpperProduct = saturatedMultiply(safeUpperProduct, base);
            double selectivity = 1.0;
            for (ASTNode predicate : ast.getAllNodes()) {
                if (predicate == null || !isPredicateNode(predicate) || variable == null) {
                    continue;
                }
                List<ASTNode> children = ast.getChildren(predicate.getId());
                boolean touchesVariable = false;
                if (children != null) {
                    for (ASTNode child : children) {
                        if (child != null && child.getType() == NodeType.PROPERTY
                            && variable.equals(child.getAttribute("variable", String.class))) {
                            touchesVariable = true;
                            break;
                        }
                    }
                }
                if (touchesVariable) {
                    selectivity *= predicateSelectivity(ast, predicate, varLabelMap);
                }
            }
            long estimate = Math.max(0L, Math.round(base * selectivity));
            pointProduct = saturatedMultiply(pointProduct, estimate);
        }
        if (whyMode == WhyMode.WHY_MANY) {
            // why-many's success certificate must stay sound: the selectivity-scaled
            // point estimate below is not a proven bound (predicateSelectivity is a
            // histogram-interpolated estimate, not a worst case), so mergeBoundsForWhyMany
            // taking min(this, ...) could otherwise certify a false negative. Report the
            // exact label population as both bounds -- loose, but sound.
            return new SchemaGraph.SchemaBounds(0L, safeUpperProduct);
        }
        // Unlike the edge-based tree bound (a worst-case degree argument that genuinely
        // needs a lower/upper spread), predicateSelectivity() already returns a
        // histogram-interpolated point estimate -- the same value this codebase trusts
        // directly for cost ranking elsewhere. Treating it as a wide [10%, 100%] range
        // manufactures an artificial uncertainty width that then dominates the A* f-score
        // via the uncertainty-aware search penalty, rejecting an otherwise-correct
        // candidate. Use it as a point estimate (lower == upper) instead. This is safe
        // for why-empty/why-few/why-not, which the paper already scopes to point
        // estimates without a formal optimality guarantee (post-hoc validation covers
        // them), unlike why-many's certificate above.
        return new SchemaGraph.SchemaBounds(pointProduct, pointProduct);
    }

    private long saturatedMultiply(long left, long right) {
        if (left <= 0L || right <= 0L) {
            return 0L;
        }
        if (left > Long.MAX_VALUE / right) {
            return Long.MAX_VALUE;
        }
        return left * right;
    }

    private SchemaGraph.SchemaBounds computeFormalBounds(CypherAST ast,
                                                         SchemaPattern pattern,
                                                         SchemaGraph.SchemaCompatibility compatibility) {
        if (ast.getRoot() != null && Boolean.TRUE.equals(
                ast.getRoot().getAttribute("certificate_input_unsupported", Boolean.class))) {
            return new SchemaGraph.SchemaBounds(0L, Long.MAX_VALUE);
        }
        // The bag proof applies to mandatory patterns and conjunctive filters.
        // OR/NOT can invalidate a key cap; OPTIONAL and aggregation can create
        // rows without a matching relationship valuation. Never certify them.
        for (ASTNode node : ast.getAllNodes()) {
            switch (node.getType()) {
                case OPTIONAL_MATCH: case OR: case NOT: case XOR:
                case COUNT: case SUM: case AVG: case MIN: case MAX: case COLLECT:
                case WITH: case UNION: case UNION_ALL: case SUBQUERY: case CALL:
                case SHORTEST_PATH: case ALL_SHORTEST_PATHS:
                    return new SchemaGraph.SchemaBounds(0L, Long.MAX_VALUE);
                default:
                    break;
            }
        }
        // Some projections are retained as raw expression text by the parser.
        if (java.util.regex.Pattern.compile(
                "(?i)\\b(?:count|sum|avg|min|max|collect|stDev|stDevP|percentileCont|percentileDisc)\\s*\\(")
                .matcher(ast.generateCypher()).find()) {
            return new SchemaGraph.SchemaBounds(0L, Long.MAX_VALUE);
        }
        // The proof uses directed typed degrees; unsupported directions fail closed.
        for (ASTNode relationship : ast.getNodesByType(NodeType.RELATIONSHIP)) {
            String direction = relationship.getAttribute("direction", String.class);
            if (!"OUT".equals(direction) && !"IN".equals(direction)) {
                return new SchemaGraph.SchemaBounds(0L, Long.MAX_VALUE);
            }
        }
        if (pattern == null || pattern.isEmpty()) {
            return estimateLoneNodeBounds(ast);
        }
        if (compatibility == null || !compatibility.isConsistent()) {
            return new SchemaGraph.SchemaBounds(0L, 0L);
        }

        List<SchemaPattern.EdgePattern> edges = pattern.getEdges();
        if (edges.isEmpty()) {
            return schemaGraph.estimateBounds(pattern);
        }

        // Collect node labels per id
        Map<Integer, Set<String>> nodeLabels = new HashMap<>();
        for (SchemaPattern.EdgePattern e : edges) {
            nodeLabels.computeIfAbsent(e.getSourceId(), k -> new HashSet<>()).addAll(e.getSourceLabels());
            nodeLabels.computeIfAbsent(e.getTargetId(), k -> new HashSet<>()).addAll(e.getTargetLabels());
        }

        if (CypherASTQueryGraphParser.fromAst(ast, ast.generateCypher()).getNodes().size() > nodeLabels.size()) {
            return new SchemaGraph.SchemaBounds(0L, Long.MAX_VALUE);
        }

        // Conservative node populations omit predicate selectivity.
        Map<Integer, Double> nodeEstimates = new HashMap<>();
        for (Map.Entry<Integer, Set<String>> entry : nodeLabels.entrySet()) {
            nodeEstimates.put(entry.getKey(), (double) estimateNodeCount(entry.getValue()));
        }

        Map<Integer, NodePointEstimate> pointNodes = estimatePointNodes(ast, nodeLabels, compatibility);

        // Root at the smallest conservative node population, then grow a
        // minimum-factor tree.  Every choice is sound; this choice is tighter.
        int startNode = nodeEstimates.entrySet().stream()
            .min(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey)
            .orElse(edges.get(0).getSourceId());
        Set<Integer> visited = new HashSet<>();
        visited.add(startNode);
        List<SchemaPattern.EdgePattern> remaining = new ArrayList<>(edges);
        List<SchemaPattern.EdgePattern> treeEdges = new ArrayList<>();
        while (visited.size() < nodeLabels.size()) {
            SchemaPattern.EdgePattern best = null;
            double bestWeight = Double.MAX_VALUE;
            for (SchemaPattern.EdgePattern e : remaining) {
                boolean connects = visited.contains(e.getSourceId()) ^ visited.contains(e.getTargetId());
                if (!connects) continue;
                double w = conservativeEdgeUpperFactor(e, compatibility, nodeLabels);
                if (w < bestWeight) {
                    bestWeight = w;
                    best = e;
                }
            }
            if (best == null) {
                break; // disconnected pattern
            }
            treeEdges.add(best);
            visited.add(best.getSourceId());
            visited.add(best.getTargetId());
            remaining.remove(best);
        }
        if (visited.size() < nodeLabels.size()) {
            // A tree rooted in one connected component says nothing about the
            // Cartesian product with the omitted components.  Strict theorem
            // mode rejects disconnected patterns earlier; practical formal
            // mode must nevertheless fail closed instead of certifying from a
            // partial tree.  Edge-free Cartesian products are handled exactly
            // by estimateLoneNodeBounds() above.
            return new SchemaGraph.SchemaBounds(0L, Long.MAX_VALUE);
        }
        List<SchemaPattern.EdgePattern> cycleEdges = new ArrayList<>(remaining);

        // Orient the tree from the root
        Map<Integer, List<SchemaPattern.EdgePattern>> treeAdj = new HashMap<>();
        for (SchemaPattern.EdgePattern e : treeEdges) {
            treeAdj.computeIfAbsent(e.getSourceId(), k -> new ArrayList<>()).add(e);
            treeAdj.computeIfAbsent(e.getTargetId(), k -> new ArrayList<>()).add(e);
        }
        Map<Integer, Integer> parent = new HashMap<>();
        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(startNode);
        parent.put(startNode, -1);
        while (!stack.isEmpty()) {
            int cur = stack.pop();
            List<SchemaPattern.EdgePattern> adj = treeAdj.getOrDefault(cur, List.of());
            for (SchemaPattern.EdgePattern e : adj) {
                int nxt = e.getSourceId() == cur ? e.getTargetId() : e.getSourceId();
                if (parent.containsKey(nxt)) continue;
                parent.put(nxt, cur);
                stack.push(nxt);
            }
        }

        // The sound tree bound is the root population times one conservative
        // directional maximum-degree factor per tree edge.  Do not mix point
        // estimates, total child-subtree matches, or average degrees into this
        // value: each can be smaller than the true count on a join chain.
        double upper = safeTreeUpperForRoot(
            ast, startNode, treeEdges, edges, nodeLabels, compatibility);
        double minTreeUpper = exhaustiveMinSafeTreeUpper(ast, edges, nodeLabels, compatibility);
        if (Double.isFinite(minTreeUpper) && minTreeUpper >= 0.0) {
            upper = Math.min(upper, minTreeUpper);
        }
        NodePointEstimate rootPoint = pointNodes.getOrDefault(
            startNode, new NodePointEstimate(nodeEstimates.getOrDefault(startNode, 0.0),
                                             nodeEstimates.getOrDefault(startNode, 0.0)));
        double lower = rootPoint.withPredicates;
        for (Map.Entry<Integer, Integer> relation : parent.entrySet()) {
            int child = relation.getKey();
            int parentId = relation.getValue();
            if (parentId < 0) continue;
            SchemaPattern.EdgePattern treeEdge = null;
            for (SchemaPattern.EdgePattern edge : treeEdges) {
                if ((edge.getSourceId() == parentId && edge.getTargetId() == child)
                    || (edge.getTargetId() == parentId && edge.getSourceId() == child)) {
                    treeEdge = edge;
                    break;
                }
            }
            if (treeEdge == null) continue;
            NodePointEstimate childPoint = pointNodes.getOrDefault(
                child, new NodePointEstimate(nodeEstimates.getOrDefault(child, 1.0),
                                             nodeEstimates.getOrDefault(child, 1.0)));
            lower *= averageEdgeExpansionFactorDirected(treeEdge, parentId, compatibility)
                * childPoint.selectivityRatio();
        }

        // Cycle correction with density delta_e
        for (SchemaPattern.EdgePattern e : cycleEdges) {
            SchemaGraph.TripleStats stats = chooseTripleStats(compatibility.getCompatibleTriples().get(e));
            if (stats == null) continue;
            double srcN = pointNodes.getOrDefault(e.getSourceId(), NodePointEstimate.ONE).withoutPredicates;
            double dstN = pointNodes.getOrDefault(e.getTargetId(), NodePointEstimate.ONE).withoutPredicates;
            double delta = (srcN > 0 && dstN > 0) ? ((double) stats.getEdgeCount() / (srcN * dstN)) : 0.0;
            double multiplier = Math.min(1.0, delta);
            // Keep upper conservative; apply density correction only to lower estimate.
            lower *= multiplier;
        }

        // The node-only AGM backend counts distinct endpoint assignments, not
        // relationship valuations. It must not tighten a bag-cardinality certificate.

        // A positive lower estimate means the schema/selectivity model found no
        // reason this pattern is impossible; rounding a small-but-positive
        // probability down to 0 would conflate "rare" with "provably empty"
        // (that case is already handled explicitly above via SchemaBounds(0,0)
        // when the pattern is schema-inconsistent).
        long lbRounded = lower > 0.0 ? Math.max(1L, Math.round(lower)) : 0L;
        // Beyond exact integer precision, fail closed rather than round a proof
        // downward. Below it, integral degree products are represented exactly.
        long ubRounded = !Double.isFinite(upper) || upper >= 0x1.0p53
            ? Long.MAX_VALUE : Math.max(0L, (long) Math.ceil(upper));
        return new SchemaGraph.SchemaBounds(lbRounded, ubRounded);
    }

    private double safeTreeUpperForRoot(
        CypherAST ast,
        int root,
        List<SchemaPattern.EdgePattern> tree,
        List<SchemaPattern.EdgePattern> allEdges,
        Map<Integer, Set<String>> nodeLabels,
        SchemaGraph.SchemaCompatibility compatibility) {
        Set<Integer> keyBoundNodes = keyEqualityBoundNodes(ast);
        double value = keyBoundNodes.contains(root)
            ? 1.0
            : estimateNodeCount(nodeLabels.get(root));
        Set<Integer> visited = new HashSet<>();
        Deque<Integer> queue = new ArrayDeque<>();
        visited.add(root);
        queue.add(root);
        while (!queue.isEmpty()) {
            int parentId = queue.remove();
            for (SchemaPattern.EdgePattern edge : tree) {
                int child = -1;
                if (edge.getSourceId() == parentId && !visited.contains(edge.getTargetId())) {
                    child = edge.getTargetId();
                } else if (edge.getTargetId() == parentId && !visited.contains(edge.getSourceId())) {
                    child = edge.getSourceId();
                }
                if (child < 0) continue;
                double factor = conservativeEdgeUpperFactorDirected(
                    edge, parentId, compatibility, nodeLabels);
                // A unique child node can still be reached by parallel relationships.
                // Only the root population is capped by a node key.
                if (!Double.isFinite(factor) || factor < 0.0) return Double.POSITIVE_INFINITY;
                value *= factor;
                if (!Double.isFinite(value)) return Double.POSITIVE_INFINITY;
                visited.add(child);
                queue.add(child);
            }
        }
        Set<Integer> expected = new HashSet<>();
        for (SchemaPattern.EdgePattern edge : tree) {
            expected.add(edge.getSourceId());
            expected.add(edge.getTargetId());
        }
        if (!visited.containsAll(expected)) return Double.POSITIVE_INFINITY;
        // Non-tree atoms introduce relationship bindings under bag semantics.
        // Bound their multiplicity for fixed endpoints instead of dropping them.
        List<SchemaPattern.EdgePattern> omitted = new ArrayList<>(allEdges);
        for (SchemaPattern.EdgePattern edge : tree) omitted.remove(edge);
        for (SchemaPattern.EdgePattern edge : omitted) {
            double out = conservativeEdgeUpperFactorByDirection(edge, true, compatibility);
            double in = conservativeEdgeUpperFactorByDirection(edge, false, compatibility);
            double factor = Math.min(out, in);
            if (!Double.isFinite(factor) || factor < 0.0) return Double.POSITIVE_INFINITY;
            value *= factor;
            if (!Double.isFinite(value)) return Double.POSITIVE_INFINITY;
        }
        return value;
    }

    private double exhaustiveMinSafeTreeUpper(
        CypherAST ast,
        List<SchemaPattern.EdgePattern> edges,
        Map<Integer, Set<String>> nodeLabels,
        SchemaGraph.SchemaCompatibility compatibility) {
        Set<Integer> nodes = new LinkedHashSet<>();
        for (SchemaPattern.EdgePattern edge : edges) {
            nodes.add(edge.getSourceId());
            nodes.add(edge.getTargetId());
        }
        if (nodes.size() <= 1) return nodes.isEmpty() ? 0.0
            : safeTreeUpperForRoot(ast, nodes.iterator().next(), List.of(), edges, nodeLabels, compatibility);
        // Exact enumeration is intentionally limited to the small core
        // patterns covered by the theorem and evaluation.
        if (nodes.size() > 7 || edges.size() > 12) return Double.NaN;
        List<List<SchemaPattern.EdgePattern>> trees = new ArrayList<>();
        collectSpanningTrees(edges, nodes, 0, new ArrayList<>(), trees, 10_000);
        if (trees.isEmpty()) return Double.NaN;
        double best = Double.POSITIVE_INFINITY;
        for (List<SchemaPattern.EdgePattern> tree : trees) {
            for (Integer root : nodes) {
                double value = safeTreeUpperForRoot(ast, root, tree, edges, nodeLabels, compatibility);
                if (Double.isFinite(value)) best = Math.min(best, value);
            }
        }
        return best;
    }

    private void collectSpanningTrees(List<SchemaPattern.EdgePattern> edges,
                                      Set<Integer> nodes,
                                      int index,
                                      List<SchemaPattern.EdgePattern> chosen,
                                      List<List<SchemaPattern.EdgePattern>> out,
                                      int cap) {
        if (out.size() >= cap) return;
        int needed = nodes.size() - 1;
        if (chosen.size() == needed) {
            if (isSpanningTree(chosen, nodes)) out.add(new ArrayList<>(chosen));
            return;
        }
        if (index >= edges.size() || chosen.size() + (edges.size() - index) < needed) return;
        chosen.add(edges.get(index));
        collectSpanningTrees(edges, nodes, index + 1, chosen, out, cap);
        chosen.remove(chosen.size() - 1);
        collectSpanningTrees(edges, nodes, index + 1, chosen, out, cap);
    }

    private boolean isSpanningTree(List<SchemaPattern.EdgePattern> edges, Set<Integer> nodes) {
        Map<Integer, Integer> parent = new HashMap<>();
        for (Integer node : nodes) parent.put(node, node);
        for (SchemaPattern.EdgePattern edge : edges) {
            int a = findSet(parent, edge.getSourceId());
            int b = findSet(parent, edge.getTargetId());
            if (a == b) return false;
            parent.put(a, b);
        }
        int root = findSet(parent, nodes.iterator().next());
        return nodes.stream().allMatch(node -> findSet(parent, node) == root);
    }

    private int findSet(Map<Integer, Integer> parent, int node) {
        int p = parent.getOrDefault(node, node);
        if (p != node) {
            p = findSet(parent, p);
            parent.put(node, p);
        }
        return p;
    }

    private Set<Integer> keyEqualityBoundNodes(CypherAST ast) {
        Set<Integer> result = new HashSet<>();
        QueryGraph graph = CypherASTQueryGraphParser.fromAst(ast, ast.generateCypher());
        Map<String, Integer> idByVariable = new HashMap<>();
        Map<Integer, List<String>> labelsById = new HashMap<>();
        for (QueryGraph.Vertex vertex : graph.getNodes()) {
            idByVariable.put(vertex.identifier, vertex.id);
            labelsById.put(vertex.id, vertex.getLabels());
        }
        for (ASTNode predicate : ast.getAllNodes()) {
            if (predicate.getType() != NodeType.EQUALS) continue;
            ASTNode propertyNode = null;
            ASTNode literalNode = null;
            for (ASTNode child : ast.getChildren(predicate.getId())) {
                if (child.getType() == NodeType.PROPERTY) propertyNode = child;
                if (child.getType() == NodeType.LITERAL) literalNode = child;
            }
            if (propertyNode == null || literalNode == null) continue;
            String variable = propertyNode.getAttribute("variable", String.class);
            String property = propertyNode.getAttribute("name", String.class);
            Integer id = idByVariable.get(variable);
            if (id == null) continue;
            for (String label : labelsById.getOrDefault(id, List.of())) {
                if (schemaCache.isKeyProperty(label, property)) {
                    result.add(id);
                    break;
                }
            }
        }
        return result;
    }

    private static final class NodePointEstimate {
        static final NodePointEstimate ONE = new NodePointEstimate(1.0, 1.0);
        final double withoutPredicates;
        final double withPredicates;

        NodePointEstimate(double withoutPredicates, double withPredicates) {
            this.withoutPredicates = Math.max(0.0, withoutPredicates);
            this.withPredicates = Math.max(0.0, withPredicates);
        }

        double selectivityRatio() {
            if (withoutPredicates <= 0.0) return 0.0;
            return Math.max(0.0, Math.min(1.0, withPredicates / withoutPredicates));
        }
    }

    private Map<Integer, NodePointEstimate> estimatePointNodes(
        CypherAST ast,
        Map<Integer, Set<String>> nodeLabels,
        SchemaGraph.SchemaCompatibility compatibility) {
        Map<Integer, NodePointEstimate> out = new HashMap<>();
        QueryGraph graph = CypherASTQueryGraphParser.fromAst(ast, ast.generateCypher());
        Map<String, List<ASTNode>> predicatesByVariable = new HashMap<>();
        for (ASTNode predicate : ast.getAllNodes()) {
            if (!isPredicateNode(predicate)) continue;
            for (ASTNode child : ast.getChildren(predicate.getId())) {
                if (child != null && child.getType() == NodeType.PROPERTY) {
                    String variable = child.getAttribute("variable", String.class);
                    if (variable != null) {
                        predicatesByVariable.computeIfAbsent(variable, k -> new ArrayList<>()).add(predicate);
                    }
                    break;
                }
            }
        }
        for (QueryGraph.Vertex vertex : graph.getNodes()) {
            Set<String> labels = candidateLabelsForNode(vertex.id, nodeLabels, compatibility);
            if (labels.isEmpty()) labels = schemaCache.getAllLabels();
            boolean required = nodeLabels.getOrDefault(vertex.id, Set.of()).stream()
                .anyMatch(l -> !SchemaPattern.ANY_LABEL.equals(l));
            double n0 = required ? Double.POSITIVE_INFINITY : 0.0;
            double n = required ? Double.POSITIVE_INFINITY : 0.0;
            for (String label : labels) {
                double count = Math.max(0L, schemaGraph.getLabelCount(label));
                double selectivity = 1.0;
                for (ASTNode predicate : predicatesByVariable.getOrDefault(vertex.identifier, List.of())) {
                    selectivity *= predicateSelectivityForLabel(ast, predicate, vertex.identifier, label);
                }
                double adjusted = count * Math.max(0.0, Math.min(1.0, selectivity));
                if (required) {
                    n0 = Math.min(n0, count);
                    n = Math.min(n, adjusted);
                } else {
                    n0 += count;
                    n += adjusted;
                }
            }
            if (!Double.isFinite(n0)) n0 = estimateNodeCount(nodeLabels.get(vertex.id));
            if (!Double.isFinite(n)) n = n0;
            out.put(vertex.id, new NodePointEstimate(n0, n));
        }
        return out;
    }

    private Set<String> candidateLabelsForNode(int nodeId,
                                               Map<Integer, Set<String>> nodeLabels,
                                               SchemaGraph.SchemaCompatibility compatibility) {
        Set<String> required = new HashSet<>(nodeLabels.getOrDefault(nodeId, Set.of()));
        required.remove(SchemaPattern.ANY_LABEL);
        if (!required.isEmpty()) return required;
        Set<String> candidates = new HashSet<>();
        if (compatibility != null) {
            for (Map.Entry<SchemaPattern.EdgePattern, List<SchemaGraph.SchemaTriple>> entry
                : compatibility.getCompatibleTriples().entrySet()) {
                for (SchemaGraph.SchemaTriple triple : entry.getValue()) {
                    if (entry.getKey().getSourceId() == nodeId) candidates.add(triple.getSourceLabel());
                    if (entry.getKey().getTargetId() == nodeId) candidates.add(triple.getTargetLabel());
                }
            }
        }
        return candidates;
    }

    private double predicateSelectivityForLabel(CypherAST ast,
                                                ASTNode predicate,
                                                String variable,
                                                String label) {
        double selectivity = predicateSelectivity(ast, predicate, Map.of(variable, label));
        for (ASTNode child : ast.getChildren(predicate.getId())) {
            if (child != null && child.getType() == NodeType.PROPERTY) {
                String property = child.getAttribute("name", String.class);
                DatabaseSchemaCache.PropertyInfo info = schemaCache.getPropertyInfo(label, property);
                if (info != null && info.getTotalCount() > 0) {
                    double nonNull = 1.0 - ((double) info.getNullCount() / info.getTotalCount());
                    selectivity *= Math.max(0.0, Math.min(1.0, nonNull));
                }
                break;
            }
        }
        return Math.max(0.0, Math.min(1.0, selectivity));
    }

    private double conservativeEdgeUpperFactorDirected(
        SchemaPattern.EdgePattern edge,
        int parentId,
        SchemaGraph.SchemaCompatibility compatibility,
        Map<Integer, Set<String>> nodeLabels) {
        return conservativeEdgeUpperFactorByDirection(edge, edge.getSourceId() == parentId, compatibility);
    }

    private double conservativeEdgeUpperFactorByDirection(
        SchemaPattern.EdgePattern edge, boolean forward,
        SchemaGraph.SchemaCompatibility compatibility) {
        List<SchemaGraph.SchemaTriple> triples = compatibility.getCompatibleTriples().get(edge);
        if (triples == null || triples.isEmpty()) return Double.MAX_VALUE;
        double sum = 0.0;
        for (SchemaGraph.SchemaTriple triple : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                triple.getSourceLabel(), triple.getRelationshipType(), triple.getTargetLabel());
            if (stats == null) return Double.POSITIVE_INFINITY;
            double factor = forward ? stats.getMaxOutDegree() : stats.getMaxInDegree();
            if (factor <= 0.0 || !Double.isFinite(factor)) return Double.MAX_VALUE;
            sum += factor;
        }
        return sum > 0.0 ? sum : Double.MAX_VALUE;
    }

    private double averageEdgeExpansionFactorDirected(
        SchemaPattern.EdgePattern edge,
        int parentId,
        SchemaGraph.SchemaCompatibility compatibility) {
        List<SchemaGraph.SchemaTriple> triples = compatibility.getCompatibleTriples().get(edge);
        if (triples == null || triples.isEmpty()) return 1.0;
        boolean forward = edge.getSourceId() == parentId;
        double weighted = 0.0;
        double totalEdges = 0.0;
        for (SchemaGraph.SchemaTriple triple : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                triple.getSourceLabel(), triple.getRelationshipType(), triple.getTargetLabel());
            if (stats == null || stats.getEdgeCount() <= 0) continue;
            double avg = forward ? stats.getAvgOutDegree() : stats.getAvgInDegree();
            weighted += stats.getEdgeCount() * Math.max(0.0, avg);
            totalEdges += stats.getEdgeCount();
        }
        return totalEdges > 0.0 ? weighted / totalEdges : 1.0;
    }

    private double computeAgmUpperBound(Map<Integer, Double> nodeEstimates,
                                        List<SchemaPattern.EdgePattern> edges,
                                        SchemaGraph.SchemaCompatibility compatibility) {
        if (nodeEstimates.isEmpty()) {
            return -1.0;
        }
        Map<Integer, Integer> nodeIndex = new HashMap<>();
        int idx = 0;
        for (Integer nodeId : nodeEstimates.keySet()) {
            nodeIndex.put(nodeId, idx++);
        }

        List<double[]> constraints = new ArrayList<>();
        List<Double> bounds = new ArrayList<>();

        for (SchemaPattern.EdgePattern e : edges) {
            double edgeCount = estimateEdgeCountUpper(e, compatibility);
            double logSize = Math.log(Math.max(1.0, edgeCount));
            double[] row = new double[nodeIndex.size()];
            Integer src = nodeIndex.get(e.getSourceId());
            Integer tgt = nodeIndex.get(e.getTargetId());
            if (src != null) {
                row[src] = 1.0;
            }
            if (tgt != null) {
                row[tgt] = 1.0;
            }
            constraints.add(row);
            bounds.add(logSize);
        }

        for (Map.Entry<Integer, Double> entry : nodeEstimates.entrySet()) {
            double logSize = Math.log(Math.max(1.0, entry.getValue()));
            double[] row = new double[nodeIndex.size()];
            Integer pos = nodeIndex.get(entry.getKey());
            if (pos != null) {
                row[pos] = 1.0;
                constraints.add(row);
                bounds.add(logSize);
            }
        }

        double[][] A = constraints.toArray(new double[0][]);
        double[] b = new double[bounds.size()];
        for (int i = 0; i < bounds.size(); i++) {
            b[i] = bounds.get(i);
        }
        double[] c = new double[nodeIndex.size()];
        Arrays.fill(c, 1.0);

        SimplexSolver solver = new SimplexSolver(A, b, c);
        double opt = solver.solve();
        if (!Double.isFinite(opt)) {
            return -1.0;
        }
        return Math.exp(opt);
    }

    private double estimateEdgeCountUpper(SchemaPattern.EdgePattern edge,
                                          SchemaGraph.SchemaCompatibility compatibility) {
        if (compatibility == null || edge == null) {
            return 1.0;
        }
        List<SchemaGraph.SchemaTriple> triples = compatibility.getCompatibleTriples().get(edge);
        if (triples == null || triples.isEmpty()) {
            return 1.0;
        }
        double sum = 0.0;
        for (SchemaGraph.SchemaTriple triple : triples) {
            SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(
                triple.getSourceLabel(), triple.getRelationshipType(), triple.getTargetLabel());
            if (stats == null) {
                continue;
            }
            sum += Math.max(0.0, stats.getEdgeCount());
        }
        return Math.max(1.0, sum);
    }

    private static final class SimplexSolver {
        private static final double EPS = 1e-9;
        private static final double INF = 1e100;
        private final int m;
        private final int n;
        private final int[] B;
        private final int[] N;
        private final double[][] D;

        SimplexSolver(double[][] A, double[] b, double[] c) {
            m = b.length;
            n = c.length;
            B = new int[m];
            N = new int[n + 1];
            D = new double[m + 2][n + 2];
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    D[i][j] = A[i][j];
                }
            }
            for (int i = 0; i < m; i++) {
                B[i] = n + i;
                D[i][n] = -1.0;
                D[i][n + 1] = b[i];
            }
            for (int j = 0; j < n; j++) {
                N[j] = j;
                D[m][j] = -c[j];
            }
            N[n] = -1;
            D[m + 1][n] = 1.0;
        }

        private void pivot(int r, int s) {
            for (int i = 0; i < m + 2; i++) {
                if (i == r) {
                    continue;
                }
                for (int j = 0; j < n + 2; j++) {
                    if (j == s) {
                        continue;
                    }
                    D[i][j] -= D[r][j] * D[i][s] / D[r][s];
                }
            }
            for (int j = 0; j < n + 2; j++) {
                if (j != s) {
                    D[r][j] /= D[r][s];
                }
            }
            for (int i = 0; i < m + 2; i++) {
                if (i != r) {
                    D[i][s] /= -D[r][s];
                }
            }
            D[r][s] = 1.0 / D[r][s];
            int tmp = B[r];
            B[r] = N[s];
            N[s] = tmp;
        }

        private boolean simplex(int phase) {
            int x = phase == 1 ? m + 1 : m;
            while (true) {
                int s = -1;
                for (int j = 0; j <= n; j++) {
                    if (phase == 2 && N[j] == -1) {
                        continue;
                    }
                    if (s == -1 || D[x][j] < D[x][s] - EPS
                        || (Math.abs(D[x][j] - D[x][s]) <= EPS && N[j] < N[s])) {
                        s = j;
                    }
                }
                if (D[x][s] > -EPS) {
                    return true;
                }
                int r = -1;
                for (int i = 0; i < m; i++) {
                    if (D[i][s] <= EPS) {
                        continue;
                    }
                    if (r == -1) {
                        r = i;
                        continue;
                    }
                    double lhs = D[i][n + 1] / D[i][s];
                    double rhs = D[r][n + 1] / D[r][s];
                    if (lhs < rhs - EPS || (Math.abs(lhs - rhs) <= EPS && B[i] < B[r])) {
                        r = i;
                    }
                }
                if (r == -1) {
                    return false;
                }
                pivot(r, s);
            }
        }

        double solve() {
            int r = 0;
            for (int i = 1; i < m; i++) {
                if (D[i][n + 1] < D[r][n + 1]) {
                    r = i;
                }
            }
            if (D[r][n + 1] < -EPS) {
                pivot(r, n);
                if (!simplex(1) || D[m + 1][n + 1] < -EPS) {
                    return Double.NaN;
                }
                if (D[m + 1][n + 1] > EPS) {
                    return INF;
                }
                for (int i = 0; i < m; i++) {
                    if (B[i] == -1) {
                        int s = 0;
                        for (int j = 1; j <= n; j++) {
                            if (s == -1 || D[i][j] < D[i][s] - EPS
                                || (Math.abs(D[i][j] - D[i][s]) <= EPS && N[j] < N[s])) {
                                s = j;
                            }
                        }
                        pivot(i, s);
                    }
                }
            }
            if (!simplex(2)) {
                return INF;
            }
            return D[m][n + 1];
        }
    }
    
    private long extractLimitValue(String query) {
        if (query == null) {
            return -1L;
        }
        Matcher matcher = LIMIT_PATTERN.matcher(query);
        if (matcher.find()) {
            try {
                return Long.parseLong(matcher.group(1));
            } catch (NumberFormatException ignored) {
                return -1L;
            }
        }
        return -1L;
    }
    
    // executeQueryForCardinality intentionally removed to prevent runtime execution for counts

    private RewritingResult tryWhyManyPredicateFallback(String originalQuery,
                                                        QueryGraph queryGraph,
                                                        long targetCardinality) {
        RewritingResult failure = new RewritingResult();
        failure.setOriginalQuery(originalQuery);
        if (formalBoundsRequested && !mayUseFormalCertificate()) {
            failure.addError("Formal predicate fallback unavailable because the schema snapshot is stale");
            return failure;
        }
        if (queryGraph == null) {
            failure.addError("Fallback unavailable: query graph missing");
            return failure;
        }
        
        for (QueryGraph.Vertex vertex : queryGraph.getNodes()) {
            String identifier = vertex.getIdentifier();
            if (identifier == null || identifier.isBlank()) {
                continue;
            }
            for (String label : vertex.getLabels()) {
                Map<String, DatabaseSchemaCache.PropertyInfo> props =
                    schemaCache.getPropertyDetailsForLabel(label);
                if (props.isEmpty()) {
                    continue;
                }
                List<Map.Entry<String, DatabaseSchemaCache.PropertyInfo>> candidates =
                    new ArrayList<>(props.entrySet());
                candidates.sort(Comparator.comparingDouble(entry -> {
                    DatabaseSchemaCache.PropertyInfo info = entry.getValue();
                    return info != null ? info.getSelectivity() : Double.MAX_VALUE;
                }));
                
                for (Map.Entry<String, DatabaseSchemaCache.PropertyInfo> entry : candidates) {
                    DatabaseSchemaCache.PropertyInfo info = entry.getValue();
                    if (info == null) {
                        continue;
                    }
                    String property = entry.getKey();
                    List<Object> commonValues = statistics.getMostCommonValues(label, property, 5);
                    if (commonValues == null || commonValues.isEmpty()) {
                        commonValues = info.getCommonValues();
                    }
                    if ((commonValues == null || commonValues.isEmpty()) && info.getAlternativeValue(null) != null) {
                        commonValues = List.of(info.getAlternativeValue(null));
                    }
                    if (commonValues == null || commonValues.isEmpty()) {
                        // Last-resort fallback for string-like labels in sparse stats snapshots.
                        if ("name".equalsIgnoreCase(property)) {
                            commonValues = List.of("UNKNOWN");
                        } else {
                            continue;
                        }
                    }
                    for (Object value : commonValues) {
                        if (value == null) {
                            continue;
                        }
                        double valueSelectivity = statistics.getValueSelectivity(label, property, value);
                        if (valueSelectivity <= 0 && info.getSelectivity() > 0) {
                            valueSelectivity = info.getSelectivity();
                        }
                        if (valueSelectivity <= 0) {
                            valueSelectivity = Math.max(1.0 / Math.max(10.0, commonValues.size()), 0.0001);
                        }
                        valueSelectivity = Math.min(1.0, valueSelectivity);
                        long totalNodes = Math.max(1L, schemaCache.getLabelCount(label));
                        long estimatedNodes = Math.max(1L, Math.round(valueSelectivity * totalNodes));
                        long estimatedCardinality = estimateResultCardinality(vertex, label, estimatedNodes, queryGraph);
                        String predicate = identifier + "." + property + " = " + formatLiteral(value);
                        String candidateQuery = injectPredicate(originalQuery, predicate);
                        SchemaGraph.SchemaBounds candidateBounds = null;
                        long acceptedCardinality = estimatedCardinality;
                        if (formalBoundsRequested) {
                            CypherAST candidateAst = parseQuery(candidateQuery);
                            if (candidateAst == null) {
                                continue;
                            }
                            SchemaPattern candidatePattern = buildSchemaPattern(candidateAst);
                            SchemaGraph.SchemaCompatibility candidateCompatibility =
                                schemaGraph.analyzeCompatibility(candidatePattern);
                            if (useSchema && !candidateCompatibility.isConsistent()) {
                                continue;
                            }
                            candidateBounds = applyLimitToBounds(
                                computeFormalBounds(candidateAst, candidatePattern, candidateCompatibility),
                                candidateQuery);
                            acceptedCardinality = estimateCardinality(
                                candidateAst, candidateBounds, candidateQuery);
                            if (!isGoal(candidateAst, candidateBounds, 1, acceptedCardinality)) {
                                continue;
                            }
                        } else if (estimatedCardinality < minTarget
                                || estimatedCardinality > targetCardinality) {
                            continue;
                        }

                            RewritingResult success = new RewritingResult();
                            success.setOriginalQuery(originalQuery);
                            success.setRewrittenQuery(candidateQuery);
                            success.setFinalCardinality(acceptedCardinality);
                            success.setEstimatedRows(acceptedCardinality);
                            success.setTargetCardinality(targetCardinality);
                            success.setSuccess(true);
                            success.setIterations(1);
                            ModificationOperation op = new ModificationOperation(
                                ModificationOperation.Type.ADD_PREDICATE,
                                identifier,
                                label,
                                entry.getKey(),
                                new Object[]{"EQUALS", value}
                            );
                            ModificationStep step = new ModificationStep(
                                op,
                                List.of("Added predicate " + predicate.trim())
                            );
                            success.setModificationSteps(List.of(step));
                            success.addWarning(formalBoundsRequested
                                ? "WHY_MANY ceiling certified; non-emptiness requires exact validation"
                                : "Cardinality estimated using schema statistics");
                            // Attach trace info for transparency
                            success.setTrace(trace);
                            RewritingResult.AStarTrace.Step traceStep = new RewritingResult.AStarTrace.Step();
                            traceStep.operation = predicate;
                            traceStep.rewrittenQuery = candidateQuery;
                            traceStep.operationType = "FALLBACK_ADD_PREDICATE";
                            traceStep.plannerCost = 0.0;
                            traceStep.statisticalComplexity = calculateStatisticalComplexity(op);
                            traceStep.schemaPenalty = 0.0;
                            traceStep.userPenalty = 0.0;
                            traceStep.gScore = 0.0;
                            traceStep.hScore = 0.0;
                            traceStep.fScore = 0.0;
                            traceStep.estimatedRows = acceptedCardinality;
                            traceStep.boundLower = candidateBounds != null
                                ? candidateBounds.getLowerBound()
                                : estimatedCardinality;
                            traceStep.boundUpper = candidateBounds != null
                                ? candidateBounds.getUpperBound()
                                : estimatedCardinality;
                            traceStep.goal = true;
                            trace.addStep(traceStep);
                            return success;
                    }
                }
            }
        }
        
        failure.addError("Fallback predicate generation failed");
        return failure;
    }

    private RewritingResult tryWhyManyKeyRestrictionCertificate(
        String originalQuery,
        QueryGraph queryGraph,
        long targetCardinality,
        UserPreferences userPreferences,
        double modificationThreshold) {
        if (!mayUseFormalCertificate() || queryGraph == null || originalQuery == null
            || strictTheoremMode || (allowedOperations != null && !allowedOperations.isEmpty()
                && !allowedOperations.contains(ModificationOperation.Type.ADD_PREDICATE))) {
            return null;
        }

        Set<Integer> alreadyBound = Set.of();
        try {
            CypherAST originalAst = parseQuery(originalQuery);
            if (originalAst != null) alreadyBound = keyEqualityBoundNodes(originalAst);
        } catch (Exception ignored) {
            return null;
        }

        List<KeyRestriction> restrictions = new ArrayList<>();
        for (QueryGraph.Vertex vertex : queryGraph.getNodes()) {
            if (alreadyBound.contains(vertex.id)
                || vertex.identifier == null || vertex.identifier.isBlank()) {
                continue;
            }
            KeyRestriction selected = null;
            List<String> labels = new ArrayList<>(vertex.getLabels());
            Collections.sort(labels);
            for (String label : labels) {
                List<String> properties = new ArrayList<>(
                    schemaCache.getPropertyDetailsForLabel(label).keySet());
                Collections.sort(properties);
                for (String property : properties) {
                    if (!schemaCache.isKeyProperty(label, property)) continue;
                    DatabaseSchemaCache.PropertyInfo info =
                        schemaCache.getPropertyDetailsForLabel(label).get(property);
                    if (info == null) continue;
                    // Prefer the key of a node that attains the maximum degree on an
                    // incident query edge: such a node provably has that edge, so the
                    // restriction does not empty it. The constant never enters a bound.
                    Object value = degreeWitnessFor(queryGraph, vertex, label, property);
                    if (value == null) {
                        List<Object> values = info.getCommonValues();
                        value = values == null ? null
                            : values.stream().filter(Objects::nonNull).findFirst().orElse(null);
                    }
                    if (value == null) {
                        value = info.getAlternativeValue(null);
                    }
                    if (value == null) continue;
                    ModificationOperation operation = new ModificationOperation(
                        ModificationOperation.Type.ADD_PREDICATE,
                        vertex.identifier,
                        label,
                        property,
                        new Object[]{"EQUALS", value}
                    );
                    double cost = calculateStatisticsBasedOperationCost(
                        operation,
                        new Neo4jStatistics.QueryPlanStatistics(-1L, 0L, 0L),
                        userPreferences,
                        0.0
                    );
                    selected = new KeyRestriction(
                        vertex.id,
                        vertex.identifier,
                        label,
                        property,
                        value,
                        operation,
                        cost
                    );
                    break;
                }
                if (selected != null) break;
            }
            if (selected != null) restrictions.add(selected);
        }
        restrictions.sort(Comparator
            .comparing((KeyRestriction value) -> value.identifier)
            .thenComparing(value -> value.property));
        if (restrictions.isEmpty() || restrictions.size() > 20) return null;

        if (allowDataQueries && !strictEstimateOnly) {
            restrictions = bindRestrictionsToMatchingRow(originalQuery, restrictions);
            if (restrictions.isEmpty()) return null;
        }

        int size = restrictions.size();
        if (size > 20) return null; // keep the exact subset pass explicitly bounded
        long evaluated = 0L;
        for (int cardinality = 1; cardinality <= size; cardinality++) {
            long combinations = 1L << size;
            RewritingResult best = null;
            long bestUpper = Long.MAX_VALUE;
            double bestCost = Double.POSITIVE_INFINITY;
            for (long mask = 1L; mask < combinations; mask++) {
                if (executionDeadlineExceeded()) return best;
                if (Long.bitCount(mask) != cardinality) continue;
                List<KeyRestriction> chosen = new ArrayList<>();
                double pathCost = 0.0;
                for (int index = 0; index < size; index++) {
                    if ((mask & (1L << index)) == 0L) continue;
                    KeyRestriction restriction = restrictions.get(index);
                    chosen.add(restriction);
                    pathCost += restriction.cost;
                }
                if (modificationThreshold > 0.0 && pathCost > modificationThreshold) continue;
                evaluated++;
                String predicates = chosen.stream()
                    .map(KeyRestriction::predicate)
                    .collect(Collectors.joining(" AND "));
                String candidateQuery = injectPredicate(originalQuery, predicates);
                CypherAST candidateAst;
                try {
                    candidateAst = parseQuery(candidateQuery);
                } catch (Exception ignored) {
                    continue;
                }
                if (candidateAst == null) continue;
                SchemaPattern candidatePattern = buildSchemaPattern(candidateAst);
                SchemaGraph.SchemaCompatibility compatibility =
                    schemaGraph.analyzeCompatibility(candidatePattern);
                if (useSchema && !compatibility.isConsistent()) continue;
                SchemaGraph.SchemaBounds bounds = applyLimitToBounds(
                    computeFormalBounds(candidateAst, candidatePattern, compatibility),
                    candidateQuery);
                long accepted = bounds != null ? bounds.getUpperBound() : -1L;
                if (!isGoal(candidateAst, bounds, cardinality, accepted)) continue;
                if (allowDataQueries && !strictEstimateOnly) {
                    accepted = countCandidateForGoal(candidateQuery, candidateGoalCountCap());
                }
                if (accepted > bestUpper || (accepted == bestUpper && pathCost >= bestCost)) continue;

                RewritingResult success = new RewritingResult();
                success.setOriginalQuery(originalQuery);
                success.setRewrittenQuery(candidateQuery);
                success.setFinalCardinality(accepted);
                success.setEstimatedRows(accepted);
                success.setTargetCardinality(targetCardinality);
                success.setSuccess(true);
                success.setIterations((int) Math.min(Integer.MAX_VALUE, evaluated));
                success.setStatesExplored(evaluated);
                success.setQueueMaxSize(0L);
                List<ModificationStep> steps = chosen.stream()
                    .map(restriction -> new ModificationStep(
                        restriction.operation,
                        List.of("Added key restriction " + restriction.predicate())))
                    .collect(Collectors.toList());
                success.setModificationSteps(steps);
                success.setTrace(trace);
                success.setSearchDiagnostics(diagnostics);
                RewritingResult.AStarTrace.Step traceStep = new RewritingResult.AStarTrace.Step();
                traceStep.astHash = computeASTHash(candidateAst);
                traceStep.parentAstHash = computeASTHash(parseQuery(originalQuery));
                traceStep.rewrittenQuery = candidateQuery;
                traceStep.operation = "KEY_RESTRICTION_SET(" + cardinality + ")";
                traceStep.operationType = "KEY_RESTRICTION_CERTIFICATE";
                traceStep.edgeCost = pathCost;
                traceStep.plannerCost = 0.0;
                traceStep.statisticalComplexity = cardinality;
                traceStep.schemaPenalty = 0.0;
                traceStep.userPenalty = 0.0;
                traceStep.gScore = pathCost;
                traceStep.hScore = 0.0;
                traceStep.fScore = pathCost;
                traceStep.estimatedRows = accepted;
                traceStep.boundLower = bounds.getLowerBound();
                traceStep.boundUpper = bounds.getUpperBound();
                traceStep.depth = cardinality;
                traceStep.goal = true;
                trace.addStep(traceStep);
                success.addWarning(allowDataQueries && !strictEstimateOnly
                    ? "WHY_MANY key restrictions selected from a matching row and validated by bounded COUNT; global A* cost optimality is not claimed"
                    : "WHY_MANY ceiling certified by the minimum-cardinality key-restriction set; non-emptiness requires validation; global A* cost optimality is not claimed");
                best = success;
                bestUpper = accepted;
                bestCost = pathCost;
            }
            if (best != null) return best;
        }
        return null;
    }

    private List<KeyRestriction> bindRestrictionsToMatchingRow(
        String originalQuery, List<KeyRestriction> restrictions) {
        CypherAST original = parseQuery(originalQuery);
        if (original == null || original.getRoot() == null || Boolean.TRUE.equals(original.getRoot()
                .getAttribute("certificate_input_unsupported", Boolean.class))) return List.of();
        Matcher projection = Pattern.compile("(?i)\\bRETURN\\b").matcher(originalQuery);
        if (!projection.find() || executionDeadlineExceeded()) return List.of();
        List<String> fields = new ArrayList<>();
        for (int i = 0; i < restrictions.size(); i++) {
            KeyRestriction r = restrictions.get(i);
            fields.add(r.identifier + ".`" + r.property.replace("`", "``") + "` AS wg_key_" + i);
        }
        String witnessQuery = originalQuery.substring(0, projection.start())
            + " RETURN " + String.join(", ", fields) + " LIMIT 1";
        long remaining = Math.max(1L, TimeUnit.NANOSECONDS.toSeconds(
            Math.max(1L, rewriteDeadlineNanos - System.nanoTime())) + 1L);
        long started = System.nanoTime();
        diagnostics.witnessQueryCalls++;
        try (Transaction tx = db.beginTx(Math.min(candidateExecutionTimeoutSeconds, remaining), TimeUnit.SECONDS);
             Result rows = tx.execute(witnessQuery)) {
            if (!rows.hasNext()) return List.of();
            Map<String, Object> row = rows.next();
            List<KeyRestriction> bound = new ArrayList<>();
            for (int i = 0; i < restrictions.size(); i++) {
                Object value = row.get("wg_key_" + i);
                if (value == null) continue;
                KeyRestriction r = restrictions.get(i);
                ModificationOperation op = new ModificationOperation(
                    ModificationOperation.Type.ADD_PREDICATE, r.identifier, r.label,
                    r.property, new Object[]{"EQUALS", value});
                bound.add(new KeyRestriction(r.vertexId, r.identifier, r.label,
                    r.property, value, op, r.cost));
            }
            tx.commit();
            return bound;
        } catch (Exception ignored) {
            return List.of();
        } finally {
            diagnostics.witnessQueryTimeNanos += System.nanoTime() - started;
        }
    }

    private Object degreeWitnessFor(QueryGraph queryGraph, QueryGraph.Vertex vertex,
                                    String label, String property) {
        for (QueryGraph.Edge edge : queryGraph.getEdges()) {
            if (edge.type == null || edge.type.isBlank()) continue;
            boolean outgoing;
            int otherId;
            if (edge.source == vertex.id) {
                outgoing = true;
                otherId = edge.target;
            } else if (edge.target == vertex.id) {
                outgoing = false;
                otherId = edge.source;
            } else {
                continue;
            }
            QueryGraph.Vertex other = queryGraph.getNodeById(otherId);
            List<String> otherLabels = other == null ? List.of() : other.getLabels();
            Object value = schemaCache.getDegreeWitnessValue(label, edge.type, otherLabels, outgoing, property);
            if (value != null) return value;
        }
        return null;
    }

    private static final class KeyRestriction {
        final int vertexId;
        final String identifier;
        final String label;
        final String property;
        final Object value;
        final ModificationOperation operation;
        final double cost;

        KeyRestriction(int vertexId,
                       String identifier,
                       String label,
                       String property,
                       Object value,
                       ModificationOperation operation,
                       double cost) {
            this.vertexId = vertexId;
            this.identifier = identifier;
            this.label = label;
            this.property = property;
            this.value = value;
            this.operation = operation;
            this.cost = cost;
        }

        String predicate() {
            return identifier + "." + property + " = "
                + (value instanceof Number || value instanceof Boolean
                    ? value.toString()
                    : "'" + value.toString().replace("\\", "\\\\").replace("'", "\\'") + "'");
        }
    }
    
    private String injectPredicate(String query, String predicate) {
        Pattern wherePattern = Pattern.compile("(?i)\\bWHERE\\b");
        Matcher whereMatcher = wherePattern.matcher(query);
        if (whereMatcher.find()) {
            int insertPos = whereMatcher.end();
            String before = query.substring(0, insertPos);
            String after = query.substring(insertPos).trim();
            return before + " " + predicate + (after.isEmpty() ? "" : " AND " + after);
        }
        
        Pattern returnPattern = Pattern.compile("(?i)\\bRETURN\\b");
        Matcher returnMatcher = returnPattern.matcher(query);
        if (returnMatcher.find()) {
            int pos = returnMatcher.start();
            String before = query.substring(0, pos).trim();
            String after = query.substring(pos);
            String connector = before.isEmpty() ? "" : " ";
            return before + connector + "WHERE " + predicate + " " + after;
        }
        
        return query + " WHERE " + predicate;
    }
    
    private String formatLiteral(Object value) {
        if (value instanceof Number || value instanceof Boolean) {
            return value.toString();
        }
        String text = escapeCypherStringLiteral(value == null ? "" : value.toString());
        return "'" + text + "'";
    }

    private String escapeCypherStringLiteral(String value) {
        return value.replace("\\", "\\\\").replace("'", "\\'");
    }
    
    private long estimateResultCardinality(QueryGraph.Vertex vertex,
                                           String primaryLabel,
                                           long estimatedNodes,
                                           QueryGraph queryGraph) {
        if (primaryLabel == null) {
            return estimatedNodes;
        }
        for (QueryGraph.Edge edge : queryGraph.getEdges()) {
            if (edge.source == vertex.id) {
                QueryGraph.Vertex targetVertex = queryGraph.getNodeById(edge.target);
                if (targetVertex == null) {
                    continue;
                }
                for (String targetLabel : targetVertex.getLabels()) {
                    SchemaGraph.TripleStats stats = schemaGraph.getTripleStats(primaryLabel, edge.getType(), targetLabel);
                    if (stats != null && stats.getAvgOutDegree() > 0) {
                        return Math.max(1L, Math.round(estimatedNodes * stats.getAvgOutDegree()));
                    }
                }
            }
        }
        return estimatedNodes;
    }
    
    private static final class PlanStatsCacheEntry {
        private final Neo4jStatistics.QueryPlanStatistics stats;
        private final long expiresAt;
        
        private PlanStatsCacheEntry(Neo4jStatistics.QueryPlanStatistics stats, long expiresAt) {
            this.stats = stats;
            this.expiresAt = expiresAt;
        }
    }

    private QueryAlternative buildAlternativeFromSearchNode(SearchNode node,
                                                            String rewrittenQuery,
                                                            long estimatedRows,
                                                            int iterations) {
        if (node == null || rewrittenQuery == null) {
            return null;
        }
        Neo4jStatistics.QueryPlanStatistics planStats = usePlannerStats
            ? getPlannerStatistics(rewrittenQuery)
            : new Neo4jStatistics.QueryPlanStatistics(estimatedRows, 0L, 0L);
        double executionTime = estimateExecutionTime(planStats);
        double semanticDistance = node.getOperations() == null ? 0.0 : node.getOperations().size();
        String explanation = "Candidate rewrite with "
            + (node.getOperations() == null ? 0 : node.getOperations().size())
            + " modification(s), estimated rows=" + estimatedRows;
        return new QueryAlternative(
            rewrittenQuery,
            node.getOperations(),
            estimatedRows,
            node.getGScore(),
            semanticDistance,
            node.getFScore(),
            iterations,
            explanation,
            Math.max(0L, planStats.getEstCost()),
            Math.max(0L, estimatedRows),
            executionTime,
            semanticDistance
        );
    }

    private double targetDeviation(long estimatedRows) {
        if (estimatedRows < 0) {
            return Double.POSITIVE_INFINITY;
        }
        switch (whyMode) {
            case WHY_MANY:
                return Math.max(0L, estimatedRows - maxTarget);
            case WHY_EMPTY:
                return estimatedRows <= 0 ? Double.POSITIVE_INFINITY : 0.0;
            case WHY_FEW:
                if (estimatedRows < minTarget) {
                    return minTarget - estimatedRows;
                }
                if (estimatedRows > maxTarget) {
                    return estimatedRows - maxTarget;
                }
                return 0.0;
            case WHY_NOT:
                if (estimatedRows < minTarget) {
                    return minTarget - estimatedRows;
                }
                if (estimatedRows > maxTarget) {
                    return estimatedRows - maxTarget;
                }
                return 0.0;
            default:
                return 0.0;
        }
    }

    private void addToParetoFrontier(List<ParetoRewriteCandidate> frontier,
                                     QueryAlternative candidate,
                                     int maxAlternatives) {
        if (frontier == null || candidate == null) {
            return;
        }
        ParetoRewriteCandidate wrapped = new ParetoRewriteCandidate(
            candidate,
            candidate.getModifications() != null ? candidate.getModifications().size() : 0,
            targetDeviation(candidate.getEstimatedRows()),
            Math.max(0.0, candidate.getFScore())
        );
        Iterator<ParetoRewriteCandidate> it = frontier.iterator();
        while (it.hasNext()) {
            ParetoRewriteCandidate existing = it.next();
            if (existing.dominates(wrapped)) {
                return;
            }
            if (wrapped.dominates(existing)) {
                it.remove();
            }
        }
        frontier.add(wrapped);
        frontier.sort(Comparator.comparingDouble(ParetoRewriteCandidate::utilityScore));
        if (maxAlternatives > 0 && frontier.size() > maxAlternatives) {
            frontier.subList(maxAlternatives, frontier.size()).clear();
        }
    }
    
    private void recordOperationAttempt(ModificationOperation operation) {
        if (operation == null) {
            return;
        }
        String opKey = operation.getType().toString();
        operationAttemptHistory.merge(opKey, 1L, Long::sum);
    }

    private void recordOperationSuccess(ModificationOperation operation) {
        if (operation == null) {
            return;
        }
        String opKey = operation.getType().toString();
        operationSuccessHistory.merge(opKey, 1L, Long::sum);
    }

    /**
     * Update operation cost history for online learning.
     */
    private void updateOperationCostHistory(ModificationOperation operation, double cost) {
        String opKey = operation.getType().toString();
        Double historicalCost = operationCostHistory.get(opKey);
        
        if (historicalCost == null) {
            operationCostHistory.put(opKey, cost);
        } else {
            // Exponential moving average
            double alpha = 0.1;
            double newCost = alpha * cost + (1 - alpha) * historicalCost;
            operationCostHistory.put(opKey, newCost);
        }
        
        // Update average expansion ratio based on successful operations
        updateAverageExpansionRatio();
    }

    private void updateOperationFeedback(ModificationOperation operation, double cost, boolean accepted) {
        recordOperationAttempt(operation);
        if (accepted) {
            recordOperationSuccess(operation);
            updateOperationCostHistory(operation, Math.max(costEpsilon, cost));
        }
    }
    
    private void updateAverageExpansionRatio() {
        if (operationCostHistory.isEmpty()) return;
        
        double sum = operationCostHistory.values().stream().mapToDouble(Double::doubleValue).sum();
        double count = operationCostHistory.size();
        averageExpansionRatio = Math.max(sum / count, 1.1); // Minimum ratio of 1.1
    }
    
    /**
     * Generate explanation using statistics
     */
    private String generateStatisticsExplanation(List<ModificationStep> operations, 
                                                String originalQuery, String modifiedQuery,
                                                CypherAST originalAST, CypherAST modifiedAST) {
        StringBuilder explanation = new StringBuilder();
        explanation.append("Query Modification Explanation:\n\n");
        
        Neo4jStatistics.QueryPlanStatistics originalStats = getPlannerStatistics(originalQuery);
        Neo4jStatistics.QueryPlanStatistics modifiedStats = getPlannerStatistics(modifiedQuery);
        
        explanation.append("Original Query: ").append(originalQuery).append("\n");
        explanation.append("Modified Query: ").append(modifiedQuery).append("\n\n");
        
        explanation.append("Cardinality Analysis:\n");
        explanation.append("- Original estimated rows: ").append(originalStats.getEstimatedRows()).append("\n");
        explanation.append("- Modified estimated rows: ").append(modifiedStats.getEstimatedRows()).append("\n");
        explanation.append("- Cardinality increase factor: ")
                  .append(String.format("%.2f", (double) modifiedStats.getEstimatedRows() / Math.max(originalStats.getEstimatedRows(), 1)))
                  .append("\n\n");
        
        explanation.append("Performance Impact:\n");
        explanation.append("- Original estimated plan work: ").append(originalStats.getEstCost()).append("\n");
        explanation.append("- Modified estimated plan work: ").append(modifiedStats.getEstCost()).append("\n\n");
        
        explanation.append("Applied Modifications:\n");
        if (operations.isEmpty()) {
            explanation.append("   (No operations recorded - this may indicate an issue with modification tracking)\n");
        }
        
        for (int i = 0; i < operations.size(); i++) {
            ModificationStep step = operations.get(i);
            explanation.append(String.format("%d. %s\n", i + 1, step.getDescription()));
            
            // Show the detailed changes
            List<String> changes = step.getChanges();
            if (changes != null && !changes.isEmpty()) {
                for (String change : changes) {
                    explanation.append("   - ").append(change).append("\n");
                }
            } else {
                explanation.append("   - (No detailed changes recorded)\n");
            }
            
            // Add operation cost and statistics information
            ModificationOperation op = step.getOperation();
            explanation.append("   - Operation Type: ").append(op.getType()).append("\n");
            if (op.getTargetLabel() != null) {
                long nodeCount = statistics.getNodeCount(op.getTargetLabel());
                explanation.append("   - Node Count for ").append(op.getTargetLabel()).append(": ").append(nodeCount).append("\n");
            }
            if (op.getTargetProperty() != null && op.getTargetLabel() != null) {
                double selectivity = statistics.getPropertySelectivity(op.getTargetLabel(), op.getTargetProperty());
                explanation.append("   - Property Selectivity: ").append(String.format("%.3f", selectivity)).append("\n");
            }
            explanation.append("\n");
        }
        
        return explanation.toString();
    }
    
    private static class FallbackState {
        final CypherAST ast;
        final List<ModificationStep> steps;
        final LinkedHashSet<String> removedIds;
        final int depth;

        FallbackState(CypherAST ast, List<ModificationStep> steps, LinkedHashSet<String> removedIds, int depth) {
            this.ast = ast;
            this.steps = steps;
            this.removedIds = removedIds;
            this.depth = depth;
        }
    }

    private static class StructuralFallbackState {
        final CypherAST ast;
        final List<ModificationStep> steps;
        final LinkedHashSet<String> removedIds;
        final int depth;
        final double cost;

        StructuralFallbackState(CypherAST ast, List<ModificationStep> steps,
                                LinkedHashSet<String> removedIds, int depth, double cost) {
            this.ast = ast;
            this.steps = steps;
            this.removedIds = removedIds;
            this.depth = depth;
            this.cost = cost;
        }
    }

    private RewritingResult trySchemaRepairFallback(CypherAST baseAST,
                                                    String failedQuery,
                                                    long targetCardinality) {
        if (baseAST == null || !allowRelationshipRepairs) {
            return null;
        }
        List<ModificationOperation> ops = getApplicableOperations(baseAST).stream()
            .filter(op -> op.getType() == ModificationOperation.Type.FLIP_RELATIONSHIP_DIRECTION
                || op.getType() == ModificationOperation.Type.REPLACE_RELATIONSHIP_TYPE
                || op.getType() == ModificationOperation.Type.REPAIR_END_LABEL
                || op.getType() == ModificationOperation.Type.REPAIR_BOTH_END_LABELS)
            .sorted(buildOperationComparator())
            .limit(32)
            .collect(Collectors.toList());
        if (ops.isEmpty()) {
            return null;
        }

        for (ModificationOperation op : ops) {
            try {
                ASTModificationOperations.ModificationResult mod = applyOperation(baseAST, op);
                if (!mod.isSuccessful()) {
                    continue;
                }
                CypherAST repaired = mod.getModifiedAST();
                if (enforceConnectedPatterns && hasCartesianProduct(repaired)) {
                    continue;
                }
                SemanticCheckResult semantic = checkSemanticConsistency(repaired);
                if (useSchema && !semantic.isConsistent()) {
                    continue;
                }
                SchemaPattern pattern = buildSchemaPattern(repaired);
                if (pattern == null) {
                    continue;
                }
                SchemaGraph.SchemaCompatibility comp = schemaGraph.analyzeCompatibility(pattern);
                if (useSchema && !comp.isConsistent()) {
                    continue;
                }
                String candidateQuery = repaired.generateCypher().trim();
                if (candidateQuery.isEmpty()) {
                    continue;
                }
                if (sameCypherIgnoringWhitespace(candidateQuery, failedQuery)) {
                    continue;
                }
                SchemaGraph.SchemaBounds bounds = useFormalBounds
                    ? computeFormalBounds(repaired, pattern, comp)
                    : schemaGraph.estimateBounds(pattern);
                bounds = applyLimitToBounds(bounds, candidateQuery);
                long estimatedRows = estimateCardinality(repaired, bounds, candidateQuery);
                if (shouldRejectWhyEmptyCandidate(repaired, candidateQuery, op, bounds, estimatedRows)) {
                    continue;
                }
                if (!isGoal(repaired, bounds, 1, estimatedRows)) {
                    continue;
                }

                RewritingResult success = new RewritingResult();
                success.setOriginalQuery(failedQuery);
                success.setRewrittenQuery(candidateQuery);
                success.setTargetCardinality(targetCardinality);
                success.setFinalCardinality(estimatedRows);
                success.setEstimatedRows(estimatedRows);
                success.setSuccess(true);
                success.setIterations(1);
                List<String> changeLog = new ArrayList<>(mod.getChanges());
                changeLog.add("Estimated rows (" + (usePlannerStats ? "planner" : "snapshot") + "): " + estimatedRows);
                success.setModificationSteps(List.of(new ModificationStep(op, changeLog)));
                success.setExplanation("Fallback: deterministic schema repair using " + op.getType().name());
                success.setTrace(trace);

                RewritingResult.AStarTrace.Step traceStep = new RewritingResult.AStarTrace.Step();
                traceStep.operation = op.getTargetId();
                traceStep.rewrittenQuery = candidateQuery;
                traceStep.operationType = op.getType().name();
                traceStep.plannerCost = 0.0;
                traceStep.statisticalComplexity = calculateStatisticalComplexity(op);
                traceStep.schemaPenalty = 0.0;
                traceStep.userPenalty = 0.0;
                traceStep.gScore = traceStep.statisticalComplexity;
                traceStep.hScore = 0.0;
                traceStep.fScore = traceStep.gScore;
                traceStep.estimatedRows = estimatedRows;
                traceStep.boundLower = bounds != null ? bounds.getLowerBound() : -1;
                traceStep.boundUpper = bounds != null ? bounds.getUpperBound() : -1;
                traceStep.goal = true;
                trace.addStep(traceStep);
                return success;
            } catch (Exception ignored) {
            }
        }
        return null;
    }
    
    private RewritingResult tryPredicateRelaxationFallback(CypherAST baseAST,
                                                           String failedQuery,
                                                           long targetCardinality) {
        if (baseAST == null) {
            return null;
        }
        CypherAST workingAst = baseAST.deepCopy();
        List<String> predicateIds = collectPredicateIds(workingAst);
        if (predicateIds.isEmpty()) {
            return null;
        }
        int maxRelaxations = Math.min(4, predicateIds.size());
        Queue<FallbackState> queue = new ArrayDeque<>();
        queue.offer(new FallbackState(workingAst.deepCopy(), new ArrayList<>(), new LinkedHashSet<>(), 0));
        
        while (!queue.isEmpty()) {
            FallbackState state = queue.poll();
            
            if (!state.steps.isEmpty()) {
                String candidateQuery = state.ast.generateCypher().trim();
                if (!candidateQuery.isEmpty()) {
                    if (sameCypherIgnoringWhitespace(candidateQuery, failedQuery)) {
                        continue;
                    }
                    try {
                        SchemaPattern pattern = buildSchemaPattern(state.ast);
                        if (pattern == null) {
                            continue;
                        }
                        SchemaGraph.SchemaCompatibility comp = schemaGraph.analyzeCompatibility(pattern);
                        SchemaGraph.SchemaBounds bounds = useFormalBounds
                            ? computeFormalBounds(state.ast, pattern, comp)
                            : schemaGraph.estimateBounds(pattern);
                        bounds = applyLimitToBounds(bounds, candidateQuery);
                        long estimatedRows = estimateCardinality(state.ast, bounds, candidateQuery);
                        ModificationOperation lastOp = state.steps.isEmpty()
                            ? null
                            : state.steps.get(state.steps.size() - 1).getOperation();
                        if (shouldRejectWhyEmptyCandidate(state.ast, candidateQuery, lastOp, bounds, estimatedRows)) {
                            continue;
                        }
                        if (estimatedRows >= 0 && isGoal(state.ast, bounds, state.steps.size(), estimatedRows)) {
                            RewritingResult success = new RewritingResult();
                            success.setOriginalQuery(failedQuery);
                            success.setRewrittenQuery(candidateQuery);
                            success.setTargetCardinality(targetCardinality);
                            success.setFinalCardinality(estimatedRows);
                            success.setEstimatedRows(estimatedRows);
                            success.setSuccess(true);
                            success.setIterations(Math.max(1, state.steps.size()));
                            annotateStepsWithEstimate(state.steps, estimatedRows);
                            success.setModificationSteps(state.steps);
                            success.setExplanation("Fallback: removed " + state.steps.size() +
                                " predicate(s) (planner estimate: " + estimatedRows + ")");
                            success.setTrace(trace);

                            // Capture a trace step so planner costs remain visible even in fallback mode
                            ModificationStep lastStep = state.steps.isEmpty() ? null : state.steps.get(state.steps.size() - 1);
                            RewritingResult.AStarTrace.Step traceStep = new RewritingResult.AStarTrace.Step();
                            traceStep.operation = lastStep != null && lastStep.getOperation() != null
                                ? lastStep.getOperation().getTargetId()
                                : "FALLBACK_PREDICATE_RELAXATION";
                            traceStep.rewrittenQuery = candidateQuery;
                            traceStep.operationType = lastStep != null && lastStep.getOperation() != null
                                ? lastStep.getOperation().getType().name()
                                : "FALLBACK";
                            double plannerCost = 1.0;
                            if (usePlannerStats) {
                                Neo4jStatistics.QueryPlanStatistics planStats = getPlannerStatistics(candidateQuery);
                                if (planStats != null) {
                                    plannerCost = calculatePlannerCost(planStats);
                                }
                            }
                            traceStep.plannerCost = plannerCost;
                            traceStep.statisticalComplexity = lastStep != null ? calculateStatisticalComplexity(lastStep.getOperation()) : 0.0;
                            traceStep.schemaPenalty = 0.0;
                            traceStep.userPenalty = 0.0;
                            traceStep.gScore = traceStep.plannerCost;
                            traceStep.hScore = 0.0;
                            traceStep.fScore = traceStep.plannerCost;
                            traceStep.estimatedRows = estimatedRows;
                            traceStep.boundLower = -1;
                            traceStep.boundUpper = -1;
                            traceStep.goal = isGoal(state.ast, bounds, state.steps.size(), estimatedRows);
                            trace.addStep(traceStep);
                            return success;
                        }
                    } catch (Exception e) {
                        System.err.println("Fallback plan evaluation failed: " + e.getMessage());
                    }
                }
            }
            
            if (state.depth >= maxRelaxations) {
                continue;
            }
            
            for (String predicateId : predicateIds) {
                if (state.removedIds.contains(predicateId)) {
                    continue;
                }
                CypherAST nextAst = state.ast.deepCopy();
                PredicateContext context = extractPredicateContext(state.ast, predicateId);
                ASTModificationOperations.ModificationResult mod =
                    ASTModificationOperations.deletePredicate(nextAst, predicateId);
                if (!mod.isSuccessful()) {
                    continue;
                }
                removeEmptyWhereClauses(nextAst);
                removeMatchingPredicates(nextAst, context.variable, context.property);
                List<ModificationStep> nextSteps = new ArrayList<>(state.steps);
                List<String> changeLog = new ArrayList<>(mod.getChanges());
                changeLog.add("Removed predicate " + predicateId);
                ModificationOperation op = new ModificationOperation(
                    ModificationOperation.Type.DELETE_PREDICATE, predicateId, null, context.property, null, context.variable
                );
                nextSteps.add(new ModificationStep(op, changeLog));
                
                LinkedHashSet<String> nextRemoved = new LinkedHashSet<>(state.removedIds);
                nextRemoved.add(predicateId);
                queue.offer(new FallbackState(nextAst, nextSteps, nextRemoved, state.depth + 1));
            }
        }
        
        return null;
    }

    private RewritingResult tryStructuralRelaxationFallback(CypherAST baseAST,
                                                            String failedQuery,
                                                            long targetCardinality) {
        if (baseAST == null || !config.isAllowRelationshipDeletionRelaxation()) {
            return null;
        }
        List<String> relationshipIds = collectRelationshipIds(baseAST);
        if (relationshipIds.isEmpty()) {
            return null;
        }
        int maxRelaxations = Math.min(3, relationshipIds.size());
        Map<String, Double> removalCost = new HashMap<>();
        for (String relId : relationshipIds) {
            removalCost.put(relId, relationshipRemovalCost(baseAST, relId));
        }

        PriorityQueue<StructuralFallbackState> queue = new PriorityQueue<>(
            Comparator.comparingDouble((StructuralFallbackState s) -> s.cost)
                .thenComparingInt(s -> s.depth)
        );
        queue.offer(new StructuralFallbackState(baseAST.deepCopy(), new ArrayList<>(), new LinkedHashSet<>(), 0, 0.0));
        Set<String> visited = new HashSet<>();

        while (!queue.isEmpty()) {
            StructuralFallbackState state = queue.poll();
            String hash = computeASTHash(state.ast);
            if (!visited.add(hash)) {
                continue;
            }

            if (!state.steps.isEmpty()) {
                String candidateQuery = state.ast.generateCypher().trim();
                if (!candidateQuery.isEmpty()) {
                    if (sameCypherIgnoringWhitespace(candidateQuery, failedQuery)) {
                        continue;
                    }
                    try {
                        SchemaPattern pattern = buildSchemaPattern(state.ast);
                        if (pattern == null) {
                            continue;
                        }
                        SchemaGraph.SchemaCompatibility comp = schemaGraph.analyzeCompatibility(pattern);
                        if (useSchema && !comp.isConsistent()) {
                            continue;
                        }
                        SchemaGraph.SchemaBounds bounds = useFormalBounds
                            ? computeFormalBounds(state.ast, pattern, comp)
                            : schemaGraph.estimateBounds(pattern);
                        bounds = applyLimitToBounds(bounds, candidateQuery);
                        long estimatedRows = estimateCardinality(state.ast, bounds, candidateQuery);
                        ModificationOperation lastOp = state.steps.isEmpty()
                            ? null
                            : state.steps.get(state.steps.size() - 1).getOperation();
                        if (shouldRejectWhyEmptyCandidate(state.ast, candidateQuery, lastOp, bounds, estimatedRows)) {
                            continue;
                        }
                        if (estimatedRows >= 0 && isGoal(state.ast, bounds, state.steps.size(), estimatedRows)) {
                            RewritingResult success = new RewritingResult();
                            success.setOriginalQuery(failedQuery);
                            success.setRewrittenQuery(candidateQuery);
                            success.setTargetCardinality(targetCardinality);
                            success.setFinalCardinality(estimatedRows);
                            success.setEstimatedRows(estimatedRows);
                            success.setSuccess(true);
                            success.setIterations(Math.max(1, state.steps.size()));
                            annotateStepsWithEstimate(state.steps, estimatedRows);
                            success.setModificationSteps(state.steps);
                            success.setExplanation("Fallback: removed " + state.steps.size() +
                                " relationship(s) (planner estimate: " + estimatedRows + ")");
                            success.setTrace(trace);

                            RewritingResult.AStarTrace.Step traceStep = new RewritingResult.AStarTrace.Step();
                            ModificationStep lastStep = state.steps.get(state.steps.size() - 1);
                            traceStep.operation = lastStep.getOperation() != null
                                ? lastStep.getOperation().getTargetId()
                                : "FALLBACK_STRUCTURAL_RELAXATION";
                            traceStep.rewrittenQuery = candidateQuery;
                            traceStep.operationType = lastStep.getOperation() != null
                                ? lastStep.getOperation().getType().name()
                                : "FALLBACK";
                            double plannerCost = 1.0;
                            if (usePlannerStats) {
                                Neo4jStatistics.QueryPlanStatistics planStats = getPlannerStatistics(candidateQuery);
                                if (planStats != null) {
                                    plannerCost = calculatePlannerCost(planStats);
                                }
                            }
                            traceStep.plannerCost = plannerCost;
                            traceStep.statisticalComplexity = lastStep.getOperation() != null
                                ? calculateStatisticalComplexity(lastStep.getOperation())
                                : 0.0;
                            traceStep.schemaPenalty = 0.0;
                            traceStep.userPenalty = 0.0;
                            traceStep.gScore = traceStep.plannerCost;
                            traceStep.hScore = 0.0;
                            traceStep.fScore = traceStep.plannerCost;
                            traceStep.estimatedRows = estimatedRows;
                            traceStep.boundLower = bounds != null ? bounds.getLowerBound() : -1;
                            traceStep.boundUpper = bounds != null ? bounds.getUpperBound() : -1;
                            traceStep.goal = true;
                            trace.addStep(traceStep);
                            return success;
                        }
                    } catch (Exception e) {
                        System.err.println("Structural fallback evaluation failed: " + e.getMessage());
                    }
                }
            }

            if (state.depth >= maxRelaxations) {
                continue;
            }

            for (String relId : relationshipIds) {
                if (state.removedIds.contains(relId)) {
                    continue;
                }
                ASTModificationOperations.ModificationResult mod =
                    ASTModificationOperations.deleteRelationship(state.ast, relId);
                if (!mod.isSuccessful()) {
                    continue;
                }
                CypherAST nextAst = mod.getModifiedAST();
                if (enforceConnectedPatterns && hasCartesianProduct(nextAst)) {
                    continue;
                }

                List<ModificationStep> nextSteps = new ArrayList<>(state.steps);
                List<String> changeLog = new ArrayList<>(mod.getChanges());
                ModificationOperation op = new ModificationOperation(
                    ModificationOperation.Type.DELETE_RELATIONSHIP, relId, null, null, null
                );
                nextSteps.add(new ModificationStep(op, changeLog));

                LinkedHashSet<String> nextRemoved = new LinkedHashSet<>(state.removedIds);
                nextRemoved.add(relId);
                double nextCost = state.cost + removalCost.getOrDefault(relId, 1.0);
                queue.offer(new StructuralFallbackState(nextAst, nextSteps, nextRemoved, state.depth + 1, nextCost));
            }

            for (ASTNode node : state.ast.getNodesByType(NodeType.NODE)) {
                if (node == null || !isLeafNode(state.ast, node.getId())) {
                    continue;
                }
                String nodeId = node.getId();
                if (state.removedIds.contains(nodeId)) {
                    continue;
                }
                ASTModificationOperations.ModificationResult mod =
                    ASTModificationOperations.deleteNode(state.ast, nodeId);
                if (!mod.isSuccessful()) {
                    continue;
                }
                CypherAST nextAst = mod.getModifiedAST();
                if (enforceConnectedPatterns && hasCartesianProduct(nextAst)) {
                    continue;
                }
                List<ModificationStep> nextSteps = new ArrayList<>(state.steps);
                List<String> changeLog = new ArrayList<>(mod.getChanges());
                ModificationOperation op = new ModificationOperation(
                    ModificationOperation.Type.DELETE_NODE, nodeId, null, null, null
                );
                nextSteps.add(new ModificationStep(op, changeLog));

                LinkedHashSet<String> nextRemoved = new LinkedHashSet<>(state.removedIds);
                nextRemoved.add(nodeId);
                double nextCost = state.cost + nodeRemovalCost(node);
                queue.offer(new StructuralFallbackState(nextAst, nextSteps, nextRemoved, state.depth + 1, nextCost));
            }
        }

        return null;
    }

    /**
     * Last-resort relaxation: drop all predicates and inline properties to ensure a non-empty estimate.
     */
    private RewritingResult forceFullRelaxation(CypherAST baseAst, String originalQuery, long targetCardinality) {
        if (baseAst == null) {
            return null;
        }
        CypherAST relaxed = baseAst.deepCopy();

        // Remove all predicate nodes
        List<String> predicateIds = collectPredicateIds(relaxed);
        for (String predicateId : predicateIds) {
            removePredicateSubtree(relaxed, predicateId);
        }
        removeEmptyWhereClauses(relaxed);

        // Remove inline properties from nodes and relationships
        boolean removedInlineProperties = false;
        for (ASTNode node : relaxed.getNodesByType(NodeType.NODE)) {
            if (hasNonEmptyProperties(node)) {
                node.removeAttribute("properties");
                removedInlineProperties = true;
            }
        }
        for (ASTNode rel : relaxed.getNodesByType(NodeType.RELATIONSHIP)) {
            if (hasNonEmptyProperties(rel)) {
                rel.removeAttribute("properties");
                removedInlineProperties = true;
            }
        }

        if (predicateIds.isEmpty() && !removedInlineProperties) {
            return null;
        }

        String relaxedQuery = relaxed.generateCypher();
        if (sameCypherIgnoringWhitespace(relaxedQuery, originalQuery)) {
            return null;
        }
        SchemaPattern p = buildSchemaPattern(relaxed);
        if (p == null) {
            return null;
        }
        SchemaGraph.SchemaCompatibility comp = schemaGraph.analyzeCompatibility(p);
        SchemaGraph.SchemaBounds bounds = useFormalBounds
            ? computeFormalBounds(relaxed, p, comp)
            : schemaGraph.estimateBounds(p);
        bounds = applyLimitToBounds(bounds, relaxedQuery);
        long estimated = estimateCardinality(relaxed, bounds, relaxedQuery);
        if (shouldRejectWhyEmptyCandidate(relaxed, relaxedQuery, null, bounds, estimated)) {
            return null;
        }
        if (!isGoal(relaxed, bounds, 1, estimated)) {
            return null;
        }

        RewritingResult success = new RewritingResult();
        success.setOriginalQuery(originalQuery);
        success.setRewrittenQuery(relaxedQuery);
        success.setFinalCardinality(estimated);
        success.setEstimatedRows(estimated);
        success.setTargetCardinality(targetCardinality);
        success.setSuccess(true);
        success.setIterations(Math.max(1, predicateIds.size()));
        success.setTrace(trace);

        List<String> changes = new ArrayList<>();
        changes.add("Removed all predicates (" + predicateIds.size() + ")");
        changes.add("Removed inline properties from nodes/relationships");
        changes.add("Estimated rows: " + estimated);
        ModificationOperation op = new ModificationOperation(
            ModificationOperation.Type.DELETE_PREDICATE,
            "ALL",
            null,
            null,
            null,
            null
        );
        success.setModificationSteps(List.of(new ModificationStep(op, changes)));
        success.setExplanation("Forced relaxation to ensure non-empty result estimate");
        RewritingResult.AStarTrace.Step traceStep = new RewritingResult.AStarTrace.Step();
        traceStep.operation = "FORCE_FULL_RELAXATION";
        traceStep.rewrittenQuery = relaxedQuery;
        traceStep.operationType = "FALLBACK";
        double plannerCost = 1.0;
        if (usePlannerStats) {
            Neo4jStatistics.QueryPlanStatistics planStats = getPlannerStatistics(relaxedQuery);
            if (planStats != null) {
                plannerCost = calculatePlannerCost(planStats);
            }
        }
        traceStep.plannerCost = plannerCost;
        traceStep.statisticalComplexity = calculateStatisticalComplexity(op);
        traceStep.schemaPenalty = 0.0;
        traceStep.userPenalty = 0.0;
        traceStep.gScore = traceStep.plannerCost;
        traceStep.hScore = 0.0;
        traceStep.fScore = traceStep.plannerCost;
        traceStep.estimatedRows = estimated;
        traceStep.boundLower = bounds != null ? bounds.getLowerBound() : -1;
        traceStep.boundUpper = bounds != null ? bounds.getUpperBound() : -1;
        traceStep.goal = true;
        trace.addStep(traceStep);
        return success;
    }

    private boolean hasNonEmptyProperties(ASTNode node) {
        if (node == null || !node.hasAttribute("properties")) {
            return false;
        }
        Object properties = node.getAttribute("properties", Object.class);
        if (properties instanceof Map) {
            return !((Map<?, ?>) properties).isEmpty();
        }
        if (properties instanceof Collection) {
            return !((Collection<?>) properties).isEmpty();
        }
        return properties != null && !properties.toString().isBlank();
    }

    private List<String> collectPredicateIds(CypherAST ast) {
        List<String> ids = new ArrayList<>();
        for (ASTNode node : ast.getAllNodes()) {
            if (isPredicateNode(node)) {
                ids.add(node.getId());
            }
        }
        return ids;
    }

    private List<String> collectRelationshipIds(CypherAST ast) {
        List<String> ids = new ArrayList<>();
        if (ast == null) {
            return ids;
        }
        for (ASTNode node : ast.getNodesByType(NodeType.RELATIONSHIP)) {
            if (node != null) {
                ids.add(node.getId());
            }
        }
        return ids;
    }

    private double relationshipRemovalCost(CypherAST ast, String relId) {
        if (ast == null || relId == null) {
            return 1.0;
        }
        ASTNode rel = ast.getNode(relId);
        if (rel == null || rel.getType() != NodeType.RELATIONSHIP) {
            return 1.0;
        }
        String relType = rel.getAttribute("type", String.class);
        if (relType == null) {
            return 1.0;
        }
        RelationshipEndpoints endpoints = extractRelationshipEndpoints(ast, relId);
        if (endpoints == null) {
            return 1.0;
        }
        String direction = rel.getAttribute("direction", String.class);
        Set<String> srcLabels = endpoints.leftLabels;
        Set<String> dstLabels = endpoints.rightLabels;
        if ("IN".equalsIgnoreCase(direction)) {
            srcLabels = endpoints.rightLabels;
            dstLabels = endpoints.leftLabels;
        }
        long support = minPositiveEdgeCount(srcLabels, relType, dstLabels);
        if (support <= 0) {
            support = maxEdgeCount(srcLabels, relType, dstLabels);
        }
        if (support <= 0) {
            return 1.0;
        }
        return Math.log(support + 1.0);
    }

    private double nodeRemovalCost(ASTNode node) {
        if (node == null || statistics == null) {
            return 1.0;
        }
        List<String> labels = node.getAttribute("labels", List.class);
        String label = labels != null && !labels.isEmpty() ? labels.get(0) : null;
        if (label == null) {
            return 1.0;
        }
        long count = statistics.getNodeCount(label);
        return Math.log(Math.max(count, 1));
    }

    private int astPredicateCount(CypherAST ast) {
        int count = 0;
        for (ASTNode node : ast.getAllNodes()) {
            if (isPredicateNode(node)) {
                count++;
            }
        }
        return count;
    }
    
    private boolean meetsEstimatedGoal(long estimatedRows) {
        switch (whyMode) {
            case WHY_EMPTY:
                if (estimatedRows < minTarget) {
                    return false;
                }
                return !hasFiniteUpperTarget() || estimatedRows <= maxTarget;
            case WHY_FEW:
                if (estimatedRows < minTarget) {
                    return false;
                }
                return !hasFiniteUpperTarget() || estimatedRows <= maxTarget;
            case WHY_NOT:
                if (estimatedRows < minTarget) {
                    return false;
                }
                return !hasFiniteUpperTarget() || estimatedRows <= maxTarget;
            case WHY_MANY:
                if (estimatedRows > maxTarget) {
                    return false;
                }
                return estimatedRows >= minTarget;
            default:
                return false;
        }
    }
    
    private boolean meetsActualGoal(long actualRows) {
        if (actualRows < 0) {
            return false;
        }
        switch (whyMode) {
            case WHY_EMPTY:
                if (actualRows < minTarget) {
                    return false;
                }
                return !hasFiniteUpperTarget() || actualRows <= maxTarget;
            case WHY_FEW:
                if (actualRows < minTarget) {
                    return false;
                }
                return !hasFiniteUpperTarget() || actualRows <= maxTarget;
            case WHY_NOT:
                if (actualRows < minTarget) {
                    return false;
                }
                return !hasFiniteUpperTarget() || actualRows <= maxTarget;
            case WHY_MANY:
                if (actualRows > maxTarget) {
                    return false;
                }
                // A counted empty result is never a why-many repair. The
                // metadata-only goal intentionally certifies the ceiling only.
                return actualRows >= Math.max(1L, minTarget);
            default:
                return false;
        }
    }

    private long candidateGoalCountCap() {
        if (hasFiniteUpperTarget() && maxTarget < Long.MAX_VALUE - 1L) {
            return maxTarget + 1L;
        }
        return Math.max(1L, minTarget);
    }

    /**
     * A sound formal upper bound below the lower target proves that this
     * candidate cannot be a goal, so exact row evidence is unnecessary.
     * Unknown/stale/non-formal bounds fail open and acquire exact evidence.
     */
    private boolean shouldAcquireExactCandidateCount(SchemaGraph.SchemaBounds bounds) {
        if (!candidateCountUpperBoundGate || !useFormalBounds || bounds == null) {
            return true;
        }
        long upper = bounds.getUpperBound();
        if (upper >= 0L && upper < minTarget) {
            diagnostics.candidateCountUpperBoundSkips++;
            return false;
        }
        return true;
    }

    private long countCandidateForGoal(String query, long cap) {
        if (!allowDataQueries || strictEstimateOnly || query == null || query.isBlank()) {
            return -1L;
        }
        if (System.nanoTime() >= rewriteDeadlineNanos) {
            return -1L;
        }
        String normalized = query.strip().replaceFirst(";\\s*$", "");
        long safeCap = Math.max(1L, cap);
        String cacheKey = safeCap + "\n" + normalized;
        Long cached = actualGoalCountCache.get(cacheKey);
        if (cached != null) {
            diagnostics.candidateCountCacheHits++;
            return cached;
        }
        if (maxCandidateCountCalls > 0
            && diagnostics.candidateCountCalls >= maxCandidateCountCalls) {
            diagnostics.candidateCountBudgetSkips++;
            return -1L;
        }
        String wrapped = "CALL { " + normalized + " } WITH * LIMIT " + safeCap
            + " RETURN count(*) AS cnt";
        long count = -1L;
        long remainingNanos = Math.max(1L, rewriteDeadlineNanos - System.nanoTime());
        long remainingSeconds = Math.max(1L, TimeUnit.NANOSECONDS.toSeconds(remainingNanos) + 1L);
        long timeoutSeconds = Math.min(candidateExecutionTimeoutSeconds, remainingSeconds);
        long countStarted = System.nanoTime();
        diagnostics.candidateCountCalls++;
        try (Transaction tx = db.beginTx(timeoutSeconds, TimeUnit.SECONDS)) {
            Result result = tx.execute(wrapped);
            if (result.hasNext()) {
                Object value = result.next().get("cnt");
                if (value instanceof Number) {
                    count = ((Number) value).longValue();
                } else if (value != null) {
                    count = Long.parseLong(value.toString());
                }
            } else {
                count = 0L;
            }
            tx.commit();
        } catch (Exception ignored) {
            count = -1L;
        } finally {
            diagnostics.candidateCountTimeNanos += System.nanoTime() - countStarted;
        }
        diagnostics.postHocValidated++;
        actualGoalCountCache.put(cacheKey, count);
        return count;
    }

    private void ensureWithinExecutionDeadline() {
        if (System.nanoTime() >= rewriteDeadlineNanos) {
            throw new IllegalStateException(
                "Rewriting exceeded timeout_seconds=" + candidateExecutionTimeoutSeconds
            );
        }
    }

    private boolean executionDeadlineExceeded() {
        return System.nanoTime() >= rewriteDeadlineNanos;
    }

    private boolean hasFiniteUpperTarget() {
        return maxTarget > 0 && maxTarget < (Long.MAX_VALUE / 8);
    }
    
    private void annotateStepsWithEstimate(List<ModificationStep> steps, long estimatedRows) {
        if (steps == null || steps.isEmpty()) {
            return;
        }
        ModificationStep last = steps.get(steps.size() - 1);
        last.getChanges().add("Estimated rows (planner): " + estimatedRows);
    }
    
    /**
     * Convert inline MATCH properties into explicit WHERE predicates so standard operations can relax them.
     */
    private void normalizeInlineProperties(CypherAST ast) {
        if (ast == null) {
            return;
        }
        ASTNode whereNode = ensureWhereClause(ast);
        if (whereNode == null) {
            return;
        }
        
        List<ASTNode> nodeProps = ast.getNodesByType(NodeType.PROPERTY);
        boolean alreadyHasPredicates = false;
        for (ASTNode propNode : nodeProps) {
            String parentId = findParentPredicate(ast, propNode.getId());
            if (parentId != null) {
                ASTNode parent = ast.getNode(parentId);
                if (parent != null && isPredicateNode(parent)) {
                    alreadyHasPredicates = true;
                    break;
                }
            }
        }
        if (alreadyHasPredicates) {
            return;
        }
        // Node properties
        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            Map<String, Object> props = node.getAttribute("properties", Map.class);
            if (props == null || props.isEmpty()) {
                continue;
            }
            String variable = node.getAttribute("variable", String.class);
            if (variable == null || variable.isBlank()) {
                continue; // Unable to reference property without variable name
            }
            for (Map.Entry<String, Object> entry : props.entrySet()) {
                addInlinePredicate(ast, whereNode, variable, entry.getKey(), entry.getValue());
            }
            node.removeAttribute("properties");
        }
        
        // Relationship properties
        for (ASTNode rel : ast.getNodesByType(NodeType.RELATIONSHIP)) {
            Map<String, Object> props = rel.getAttribute("properties", Map.class);
            if (props == null || props.isEmpty()) {
                continue;
            }
            String variable = rel.getAttribute("variable", String.class);
            if (variable == null || variable.isBlank()) {
                continue;
            }
            for (Map.Entry<String, Object> entry : props.entrySet()) {
                addInlinePredicate(ast, whereNode, variable, entry.getKey(), entry.getValue());
            }
            rel.removeAttribute("properties");
        }
    }
    
    private ASTNode ensureWhereClause(CypherAST ast) {
        List<ASTNode> whereNodes = ast.getNodesByType(NodeType.WHERE);
        if (!whereNodes.isEmpty()) {
            return whereNodes.get(0);
        }
        ASTNode root = ast.getRoot();
        if (root == null) {
            return null;
        }
        String whereId = ast.addNode(NodeType.WHERE, new HashMap<>());
        ast.addEdge(root.getId(), whereId);
        reorderClause(ast, root.getId(), whereId);
        return ast.getNode(whereId);
    }
    
    private void reorderClause(CypherAST ast, String parentId, String childId) {
        List<String> children = ast.getEdges().get(parentId);
        if (children == null) {
            return;
        }
        int currentIndex = children.indexOf(childId);
        if (currentIndex < 0) {
            return;
        }
        children.remove(currentIndex);
        int insertIndex = children.size();
        for (int i = 0; i < children.size(); i++) {
            ASTNode child = ast.getNode(children.get(i));
            if (child == null) {
                continue;
            }
            if (child.getType() == NodeType.RETURN ||
                child.getType() == NodeType.ORDER_BY ||
                child.getType() == NodeType.LIMIT) {
                insertIndex = i;
                break;
            }
        }
        children.add(insertIndex, childId);
    }
    
    private void addInlinePredicate(CypherAST ast, ASTNode whereNode, String variable,
                                    String property, Object value) {
        if (whereNode == null || property == null || property.isBlank()) {
            return;
        }
        String equalsId = ast.addNode(NodeType.EQUALS, new HashMap<>());
        String propertyId = ast.addNode(NodeType.PROPERTY, Map.of(
            "variable", variable,
            "name", property
        ));
        String literalId = ast.addNode(NodeType.LITERAL, Map.of("value", value));
        ast.addEdge(equalsId, propertyId);
        ast.addEdge(equalsId, literalId);
        ast.addEdge(whereNode.getId(), equalsId);
    }
    
    private static class PredicateContext {
        final String variable;
        final String property;

        PredicateContext(String variable, String property) {
            this.variable = variable;
            this.property = property;
        }
    }

    /**
     * Search node for A* algorithm
     */
    private static class SearchNode {
        private final CypherAST ast;
        private final SchemaPattern pattern;
        private final SchemaGraph.SchemaBounds bounds;
        private final SchemaGraph.SchemaCompatibility compatibility;
        private final double gScore;
        private final double fScore;
        private final long planEstimateRows;
        private final double uncertaintyWidth;
        private final List<ModificationStep> operations;

        public SearchNode(CypherAST ast, SchemaPattern pattern, SchemaGraph.SchemaBounds bounds,
                          SchemaGraph.SchemaCompatibility compatibility,
                          double gScore, double fScore, long planEstimateRows, double uncertaintyWidth,
                          List<ModificationStep> operations) {
            this.ast = ast;
            this.pattern = pattern;
            this.bounds = bounds;
            this.compatibility = compatibility;
            this.gScore = gScore;
            this.fScore = fScore;
            this.planEstimateRows = planEstimateRows;
            this.uncertaintyWidth = uncertaintyWidth;
            this.operations = new ArrayList<>(operations);
        }

        public CypherAST getAst() { return ast; }
        public SchemaPattern getPattern() { return pattern; }
        public SchemaGraph.SchemaBounds getBounds() { return bounds; }
        public SchemaGraph.SchemaCompatibility getCompatibility() { return compatibility; }
        public double getGScore() { return gScore; }
        public double getFScore() { return fScore; }
        public long getPlanEstimateRows() { return planEstimateRows; }
        public double getUncertaintyWidth() { return uncertaintyWidth; }
        public List<ModificationStep> getOperations() { return operations; }
    }

    private static class GreedyCandidate {
        private final CypherAST ast;
        private final SchemaPattern pattern;
        private final SchemaGraph.SchemaCompatibility compatibility;
        private final SchemaGraph.SchemaBounds bounds;
        private final double gScore;
        private final double fScore;
        private final long planRows;
        private final double uncertaintyWidth;
        private final List<ModificationStep> operations;
        private final ModificationOperation operation;
        private final Neo4jStatistics.QueryPlanStatistics planStats;
        private final double schemaPenalty;
        private final long estimatedRows;
        private final double operationCost;

        private GreedyCandidate(CypherAST ast,
                                SchemaPattern pattern,
                                SchemaGraph.SchemaCompatibility compatibility,
                                SchemaGraph.SchemaBounds bounds,
                                double gScore,
                                double fScore,
                                long planRows,
                                double uncertaintyWidth,
                                List<ModificationStep> operations,
                                ModificationOperation operation,
                                Neo4jStatistics.QueryPlanStatistics planStats,
                                double schemaPenalty,
                                long estimatedRows,
                                double operationCost) {
            this.ast = ast;
            this.pattern = pattern;
            this.compatibility = compatibility;
            this.bounds = bounds;
            this.gScore = gScore;
            this.fScore = fScore;
            this.planRows = planRows;
            this.uncertaintyWidth = uncertaintyWidth;
            this.operations = operations;
            this.operation = operation;
            this.planStats = planStats;
            this.schemaPenalty = schemaPenalty;
            this.estimatedRows = estimatedRows;
            this.operationCost = operationCost;
        }

        private boolean isBetterThan(GreedyCandidate other,
                                     Comparator<ModificationOperation> opComparator) {
            if (other == null) {
                return true;
            }
            if (this.fScore < other.fScore) {
                return true;
            }
            if (this.fScore > other.fScore) {
                return false;
            }
            if (this.uncertaintyWidth < other.uncertaintyWidth) {
                return true;
            }
            if (this.uncertaintyWidth > other.uncertaintyWidth) {
                return false;
            }
            int cmp = opComparator.compare(this.operation, other.operation);
            if (cmp != 0) {
                return cmp < 0;
            }
            return this.estimatedRows < other.estimatedRows;
        }
    }

    private static class ParetoRewriteCandidate {
        private final QueryAlternative alternative;
        private final int modifications;
        private final double targetDeviation;
        private final double riskAwareCost;

        private ParetoRewriteCandidate(QueryAlternative alternative,
                                       int modifications,
                                       double targetDeviation,
                                       double riskAwareCost) {
            this.alternative = alternative;
            this.modifications = modifications;
            this.targetDeviation = targetDeviation;
            this.riskAwareCost = riskAwareCost;
        }

        private boolean dominates(ParetoRewriteCandidate other) {
            if (other == null) {
                return true;
            }
            boolean noWorse = this.modifications <= other.modifications
                && this.targetDeviation <= other.targetDeviation
                && this.riskAwareCost <= other.riskAwareCost;
            boolean strictlyBetter = this.modifications < other.modifications
                || this.targetDeviation < other.targetDeviation
                || this.riskAwareCost < other.riskAwareCost;
            return noWorse && strictlyBetter;
        }

        private double utilityScore() {
            return (0.5 * modifications) + (0.3 * targetDeviation) + (0.2 * riskAwareCost);
        }
    }
}
