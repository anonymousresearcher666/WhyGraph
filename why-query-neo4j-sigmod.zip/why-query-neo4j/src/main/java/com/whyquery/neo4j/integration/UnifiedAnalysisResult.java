package com.whyquery.neo4j.integration;

import com.whyquery.neo4j.ranking.*;
import com.whyquery.neo4j.paths.*;
import com.whyquery.neo4j.rewriting.ModificationOperation;

import java.util.*;

/**
 * Contains the unified results of WhyRank and WhyPath analysis
 */
public class UnifiedAnalysisResult {
    
    private String originalQuery;
    private WhyRankPathIntegration.WhyQueryType queryType;
    private RankingAnalysis rankingAnalysis;
    private PathAnalysis pathAnalysis;
    private List<RankingAlternative> rankingAlternatives;
    private List<PathAlternative> pathAlternatives;
    private List<ModificationOperation> modificationOperations;
    private String unifiedExplanation;
    private List<String> errors;
    private Map<String, Object> metadata;
    
    public UnifiedAnalysisResult() {
        this.rankingAlternatives = new ArrayList<>();
        this.pathAlternatives = new ArrayList<>();
        this.modificationOperations = new ArrayList<>();
        this.errors = new ArrayList<>();
        this.metadata = new HashMap<>();
    }
    
    public String getOriginalQuery() {
        return originalQuery;
    }
    
    public void setOriginalQuery(String originalQuery) {
        this.originalQuery = originalQuery;
    }
    
    public WhyRankPathIntegration.WhyQueryType getQueryType() {
        return queryType;
    }
    
    public void setQueryType(WhyRankPathIntegration.WhyQueryType queryType) {
        this.queryType = queryType;
    }
    
    public RankingAnalysis getRankingAnalysis() {
        return rankingAnalysis;
    }
    
    public void setRankingAnalysis(RankingAnalysis rankingAnalysis) {
        this.rankingAnalysis = rankingAnalysis;
    }
    
    public PathAnalysis getPathAnalysis() {
        return pathAnalysis;
    }
    
    public void setPathAnalysis(PathAnalysis pathAnalysis) {
        this.pathAnalysis = pathAnalysis;
    }
    
    public List<RankingAlternative> getRankingAlternatives() {
        return rankingAlternatives;
    }
    
    public void setRankingAlternatives(List<RankingAlternative> rankingAlternatives) {
        this.rankingAlternatives = rankingAlternatives;
    }
    
    public List<PathAlternative> getPathAlternatives() {
        return pathAlternatives;
    }
    
    public void setPathAlternatives(List<PathAlternative> pathAlternatives) {
        this.pathAlternatives = pathAlternatives;
    }
    
    public List<ModificationOperation> getModificationOperations() {
        return modificationOperations;
    }
    
    public void setModificationOperations(List<ModificationOperation> modificationOperations) {
        this.modificationOperations = modificationOperations;
    }
    
    public String getUnifiedExplanation() {
        return unifiedExplanation;
    }
    
    public void setUnifiedExplanation(String unifiedExplanation) {
        this.unifiedExplanation = unifiedExplanation;
    }
    
    public List<String> getErrors() {
        return errors;
    }
    
    public void setErrors(List<String> errors) {
        this.errors = errors;
    }
    
    public void addError(String error) {
        this.errors.add(error);
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    /**
     * Check if analysis found ranking issues
     */
    public boolean hasRankingIssues() {
        return rankingAnalysis != null && rankingAnalysis.hasRanking();
    }
    
    /**
     * Check if analysis found path issues
     */
    public boolean hasPathIssues() {
        return pathAnalysis != null && (pathAnalysis.hasPathAlgorithms() || 
                                       pathAnalysis.hasPathConstraints());
    }
    
    /**
     * Check if analysis was successful
     */
    public boolean isSuccessful() {
        return errors.isEmpty();
    }
    
    /**
     * Get all alternatives (ranking + path) sorted by effectiveness
     */
    public List<Object> getAllAlternativesSorted() {
        List<Object> allAlternatives = new ArrayList<>();
        allAlternatives.addAll(rankingAlternatives);
        allAlternatives.addAll(pathAlternatives);
        
        // Sort by effectiveness score
        allAlternatives.sort((a, b) -> {
            double scoreA = getEffectivenessScore(a);
            double scoreB = getEffectivenessScore(b);
            return Double.compare(scoreB, scoreA);
        });
        
        return allAlternatives;
    }
    
    /**
     * Get effectiveness score for any alternative type
     */
    private double getEffectivenessScore(Object alternative) {
        if (alternative instanceof RankingAlternative) {
            return ((RankingAlternative) alternative).getEffectivenessScore();
        } else if (alternative instanceof PathAlternative) {
            return ((PathAlternative) alternative).getEffectivenessScore();
        }
        return 0.0;
    }
    
    /**
     * Get top N recommendations across all categories
     */
    public List<Object> getTopRecommendations(int count) {
        List<Object> all = getAllAlternativesSorted();
        return all.subList(0, Math.min(count, all.size()));
    }
    
    /**
     * Get summary statistics
     */
    public AnalysisSummary getSummary() {
        AnalysisSummary summary = new AnalysisSummary();
        summary.queryType = queryType;
        summary.hasRankingAnalysis = rankingAnalysis != null;
        summary.hasPathAnalysis = pathAnalysis != null;
        summary.rankingAlternativeCount = rankingAlternatives.size();
        summary.pathAlternativeCount = pathAlternatives.size();
        summary.modificationOperationCount = modificationOperations.size();
        summary.hasErrors = !errors.isEmpty();
        summary.errorCount = errors.size();
        
        return summary;
    }
    
    @Override
    public String toString() {
        return "UnifiedAnalysisResult{" +
               "queryType=" + queryType +
               ", hasRanking=" + hasRankingIssues() +
               ", hasPath=" + hasPathIssues() +
               ", alternatives=" + (rankingAlternatives.size() + pathAlternatives.size()) +
               ", errors=" + errors.size() +
               '}';
    }
    
    /**
     * Summary statistics for the analysis
     */
    public static class AnalysisSummary {
        public WhyRankPathIntegration.WhyQueryType queryType;
        public boolean hasRankingAnalysis;
        public boolean hasPathAnalysis;
        public int rankingAlternativeCount;
        public int pathAlternativeCount;
        public int modificationOperationCount;
        public boolean hasErrors;
        public int errorCount;
        
        @Override
        public String toString() {
            StringBuilder summary = new StringBuilder();
            summary.append("Analysis for ").append(queryType).append(": ");
            
            if (hasRankingAnalysis) {
                summary.append("ranking (").append(rankingAlternativeCount).append(" alternatives), ");
            }
            
            if (hasPathAnalysis) {
                summary.append("path (").append(pathAlternativeCount).append(" alternatives), ");
            }
            
            summary.append(modificationOperationCount).append(" operations");
            
            if (hasErrors) {
                summary.append(", ").append(errorCount).append(" errors");
            }
            
            return summary.toString();
        }
    }
}