package com.whyquery.neo4j;

import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.Result;
import java.nio.ByteBuffer;
import java.util.*;

/**
 * Internal representation of the actual graph data
 */
public class DataGraph {
    private Map<Integer, Vertex> vertices = new HashMap<>();
    private List<Edge> edges = new ArrayList<>();
    private Transaction tx;
    
    // Schema information for intelligent query optimization
    private Set<String> schemaLabels = new HashSet<>();
    private Set<String> schemaRelationshipTypes = new HashSet<>();
    private Map<String, Integer> propertyCardinality = new HashMap<>();
    private Set<String> indexedProperties = new HashSet<>();
    private Map<String, Set<Object>> propertyValues = new HashMap<>();
    
    public void addVertex(int id, List<String> labels, Map<String, Object> properties) {
        vertices.put(id, new Vertex(id, labels, properties));
    }
    
    public void addEdge(int source, int target, String type, Map<String, Object> properties) {
        edges.add(new Edge(source, target, type, properties));
    }
    
    public String toJson() {
        return "{\"vertices\":" + vertices.size() + ",\"edges\":" + edges.size() + "}";
    }
    
    // Analysis methods for why-query functionality
    public void setTransaction(Transaction tx) {
        this.tx = tx;
    }
    
    public Transaction getTransaction() {
        return tx;
    }
    
    public Set<String> getAvailableLabels() {
        Set<String> labels = new HashSet<>();
        for (Vertex vertex : vertices.values()) {
            labels.addAll(vertex.labels);
        }
        return labels;
    }
    
    public Set<String> getAvailableRelationshipTypes() {
        Set<String> types = new HashSet<>();
        for (Edge edge : edges) {
            types.add(edge.type);
        }
        return types;
    }
    
    public boolean hasPropertyValue(String property, Object value) {
        // Check vertices
        for (Vertex vertex : vertices.values()) {
            if (vertex.properties.containsKey(property) && 
                Objects.equals(vertex.properties.get(property), value)) {
                return true;
            }
        }
        // Check edges
        for (Edge edge : edges) {
            if (edge.properties.containsKey(property) && 
                Objects.equals(edge.properties.get(property), value)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean hasConnectedComponents(Set<String> labels, Set<String> relTypes) {
        if (labels.isEmpty()) return true;
        
        // Find vertices with required labels
        Set<Integer> targetVertices = new HashSet<>();
        for (Vertex vertex : vertices.values()) {
            for (String label : labels) {
                if (vertex.labels.contains(label)) {
                    targetVertices.add(vertex.id);
                    break;
                }
            }
        }
        
        if (targetVertices.size() < 2) return targetVertices.size() == 1;
        
        // Check if any target vertices are connected via required relationship types
        for (Edge edge : edges) {
            if ((relTypes.isEmpty() || relTypes.contains(edge.type)) &&
                targetVertices.contains(edge.source) && 
                targetVertices.contains(edge.target)) {
                return true;
            }
        }
        
        return false;
    }
    
    public int getVertexCount() {
        return vertices.size();
    }
    
    public int getEdgeCount() {
        return edges.size();
    }
    
    public double calculateSelectivity(QueryGraph queryGraph) {
        // Simple selectivity estimation based on graph statistics
        double selectivity = 1.0;
        
        Set<String> queryLabels = queryGraph.getRequiredLabels();
        if (!queryLabels.isEmpty()) {
            int matchingVertices = 0;
            for (Vertex vertex : vertices.values()) {
                boolean hasAllLabels = true;
                for (String label : queryLabels) {
                    if (!vertex.labels.contains(label)) {
                        hasAllLabels = false;
                        break;
                    }
                }
                if (hasAllLabels) matchingVertices++;
            }
            selectivity *= (double) matchingVertices / Math.max(vertices.size(), 1);
        }
        
        // Factor in relationship type selectivity
        Set<String> queryRelTypes = queryGraph.getRequiredRelationshipTypes();
        if (!queryRelTypes.isEmpty()) {
            int matchingEdges = 0;
            for (Edge edge : edges) {
                if (queryRelTypes.contains(edge.type)) {
                    matchingEdges++;
                }
            }
            selectivity *= (double) matchingEdges / Math.max(edges.size(), 1);
        }
        
        return Math.max(selectivity, 0.001); // Minimum selectivity
    }
    
    public int getNodeCount(String label) {
        int count = 0;
        for (Vertex vertex : vertices.values()) {
            if (vertex.labels.contains(label)) {
                count++;
            }
        }
        return count;
    }
    
    public int getRelationshipCount(String type) {
        int count = 0;
        for (Edge edge : edges) {
            if (edge.type.equals(type)) {
                count++;
            }
        }
        return count;
    }
    
    public double getAverageDegree(String relType) {
        Map<Integer, Integer> degreeMap = new HashMap<>();
        
        for (Edge edge : edges) {
            if (edge.type.equals(relType)) {
                degreeMap.put(edge.source, degreeMap.getOrDefault(edge.source, 0) + 1);
                degreeMap.put(edge.target, degreeMap.getOrDefault(edge.target, 0) + 1);
            }
        }
        
        if (degreeMap.isEmpty()) return 0.0;
        
        int totalDegree = degreeMap.values().stream().mapToInt(Integer::intValue).sum();
        return (double) totalDegree / degreeMap.size();
    }
    
    public long countWithoutPropertyConstraint(String property, Object value) {
        if (tx == null) return 0L;
        
        try {
            // Execute real query to count nodes without the property constraint
            String countQuery = "MATCH (n) WHERE NOT (n." + property + " = $value) RETURN COUNT(n) as count";
            Map<String, Object> params = new HashMap<>();
            params.put("value", value);
            
            Result result = tx.execute(countQuery, params);
            if (result.hasNext()) {
                Object countObj = result.next().get("count");
                result.close();
                return countObj instanceof Number ? ((Number) countObj).longValue() : 0L;
            }
            result.close();
        } catch (Exception e) {
            // If specific query fails, return 0
            return 0L;
        }
        return 0L;
    }
    
    public long countWithOptionalRelationship(String relType) {
        if (tx == null) return 0L;
        
        try {
            // Execute real query to count what would match with OPTIONAL relationship
            String countQuery = "MATCH (n) OPTIONAL MATCH (n)-[:" + relType + "]->(m) RETURN COUNT(DISTINCT n) as count";
            
            Result result = tx.execute(countQuery);
            if (result.hasNext()) {
                Object countObj = result.next().get("count");
                result.close();
                return countObj instanceof Number ? ((Number) countObj).longValue() : 0L;
            }
            result.close();
        } catch (Exception e) {
            // If relationship type doesn't exist, just count all nodes
            try {
                Result result = tx.execute("MATCH (n) RETURN COUNT(n) as count");
                if (result.hasNext()) {
                    Object countObj = result.next().get("count");
                    result.close();
                    return countObj instanceof Number ? ((Number) countObj).longValue() : 0L;
                }
                result.close();
            } catch (Exception e2) {
                return 0L;
            }
        }
        return 0L;
    }
    
    public List<String> findSimilarLabels(String label) {
        List<String> similar = new ArrayList<>();
        Set<String> allLabels = getAvailableLabels();
        
        for (String existingLabel : allLabels) {
            if (!existingLabel.equals(label) && 
                (existingLabel.toLowerCase().contains(label.toLowerCase()) ||
                 label.toLowerCase().contains(existingLabel.toLowerCase()) ||
                 calculateLevenshteinDistance(label, existingLabel) <= 2)) {
                similar.add(existingLabel);
            }
        }
        
        return similar;
    }
    
    private int calculateLevenshteinDistance(String s1, String s2) {
        int[][] dp = new int[s1.length() + 1][s2.length() + 1];
        
        for (int i = 0; i <= s1.length(); i++) {
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0) {
                    dp[i][j] = j;
                } else if (j == 0) {
                    dp[i][j] = i;
                } else {
                    dp[i][j] = Math.min(Math.min(
                        dp[i-1][j] + 1,
                        dp[i][j-1] + 1),
                        dp[i-1][j-1] + (s1.charAt(i-1) == s2.charAt(j-1) ? 0 : 1)
                    );
                }
            }
        }
        
        return dp[s1.length()][s2.length()];
    }
    
    // Schema-aware methods for intelligent query optimization
    public void setSchemaInfo(Set<String> labels, Set<String> relTypes, 
                             Map<String, Integer> propCardinality, Set<String> indexed) {
        this.schemaLabels = new HashSet<>(labels);
        this.schemaRelationshipTypes = new HashSet<>(relTypes);
        this.propertyCardinality = new HashMap<>(propCardinality);
        this.indexedProperties = new HashSet<>(indexed);
    }
    
    public void addPropertyValues(String property, Set<Object> values) {
        this.propertyValues.put(property, new HashSet<>(values));
    }
    
    public Set<String> getSchemaLabels() {
        return new HashSet<>(schemaLabels);
    }
    
    public Set<String> getSchemaRelationshipTypes() {
        return new HashSet<>(schemaRelationshipTypes);
    }
    
    public boolean hasLabel(String label) {
        return schemaLabels.contains(label);
    }
    
    public boolean hasRelationshipType(String relType) {
        return schemaRelationshipTypes.contains(relType);
    }
    
    public boolean hasProperty(String property) {
        return propertyCardinality.containsKey(property);
    }
    
    public boolean isPropertyIndexed(String property) {
        return indexedProperties.contains(property);
    }
    
    public int getPropertyCardinality(String property) {
        return propertyCardinality.getOrDefault(property, 0);
    }
    
    public Set<String> getHighCardinalityProperties() {
        Set<String> highCard = new HashSet<>();
        int threshold = Math.max(getVertexCount() / 10, 10); // 10% of nodes or min 10
        for (Map.Entry<String, Integer> entry : propertyCardinality.entrySet()) {
            if (entry.getValue() > threshold) {
                highCard.add(entry.getKey());
            }
        }
        return highCard;
    }
    
    public Set<String> getLowCardinalityProperties() {
        Set<String> lowCard = new HashSet<>();
        int threshold = Math.max(getVertexCount() / 20, 5); // 5% of nodes or min 5
        for (Map.Entry<String, Integer> entry : propertyCardinality.entrySet()) {
            if (entry.getValue() <= threshold) {
                lowCard.add(entry.getKey());
            }
        }
        return lowCard;
    }
    
    public Set<String> getIndexedProperties() {
        return new HashSet<>(indexedProperties);
    }
    
    public List<String> getSuggestedAlternativeLabels(String queryLabel) {
        List<String> suggestions = new ArrayList<>();
        
        // Find exact matches first
        if (hasLabel(queryLabel)) {
            return suggestions; // No alternatives needed
        }
        
        // Find similar labels using multiple strategies
        for (String schemaLabel : schemaLabels) {
            int distance = calculateLevenshteinDistance(queryLabel.toLowerCase(), schemaLabel.toLowerCase());
            if (distance <= 2) {
                suggestions.add(schemaLabel);
            }
        }
        
        // Add semantic similarity (basic patterns)
        String queryLower = queryLabel.toLowerCase();
        for (String schemaLabel : schemaLabels) {
            String schemaLower = schemaLabel.toLowerCase();
            if (queryLower.contains(schemaLower) || schemaLower.contains(queryLower)) {
                if (!suggestions.contains(schemaLabel)) {
                    suggestions.add(schemaLabel);
                }
            }
        }
        
        return suggestions;
    }
    
    public List<String> getSuggestedAlternativeRelationships(String queryRelType) {
        List<String> suggestions = new ArrayList<>();
        
        if (hasRelationshipType(queryRelType)) {
            return suggestions; // No alternatives needed
        }
        
        for (String schemaRelType : schemaRelationshipTypes) {
            int distance = calculateLevenshteinDistance(queryRelType.toLowerCase(), schemaRelType.toLowerCase());
            if (distance <= 3) {
                suggestions.add(schemaRelType);
            }
        }
        
        return suggestions;
    }
    
    public String toSchemaAwareJson() {
        StringBuilder json = new StringBuilder("{");
        json.append("\"vertices\":").append(vertices.size()).append(",");
        json.append("\"edges\":").append(edges.size()).append(",");
        
        // Include actual schema labels
        json.append("\"schema_labels\":[");
        boolean first = true;
        for (String label : schemaLabels) {
            if (!first) json.append(",");
            json.append("\"").append(label.replace("\"", "\\\"")).append("\"");
            first = false;
        }
        json.append("],");
        
        // Include actual relationship types
        json.append("\"schema_relationships\":[");
        first = true;
        for (String relType : schemaRelationshipTypes) {
            if (!first) json.append(",");
            json.append("\"").append(relType.replace("\"", "\\\"")).append("\"");
            first = false;
        }
        json.append("],");
        
        // Include property cardinality information
        json.append("\"property_cardinality\":{");
        first = true;
        for (Map.Entry<String, Integer> entry : propertyCardinality.entrySet()) {
            if (!first) json.append(",");
            json.append("\"").append(entry.getKey().replace("\"", "\\\"")).append("\":").append(entry.getValue());
            first = false;
        }
        json.append("},");
        
        // Include indexed properties
        json.append("\"indexed_properties\":[");
        first = true;
        for (String prop : indexedProperties) {
            if (!first) json.append(",");
            json.append("\"").append(prop.replace("\"", "\\\"")).append("\"");
            first = false;
        }
        json.append("]");
        
        json.append("}");
        return json.toString();
    }
    
    public static class Vertex {
        public final int id;
        public final List<String> labels;
        public final Map<String, Object> properties;
        
        public Vertex(int id, List<String> labels, Map<String, Object> properties) {
            this.id = id;
            this.labels = labels;
            this.properties = properties;
        }
    }
    
    public static class Edge {
        public final int source;
        public final int target;
        public final String type;
        public final Map<String, Object> properties;
        
        public Edge(int source, int target, String type, Map<String, Object> properties) {
            this.source = source;
            this.target = target;
            this.type = type;
            this.properties = properties;
        }
    }
    
    // ==============================================================================
    // BINARY EXPORT METHODS FOR ZERO-COPY C++ COMMUNICATION
    // ==============================================================================
    
    /**
     * Export graph as binary buffer for efficient C++ processing
     * Eliminates JSON serialization overhead
     */
    public ByteBuffer toBinaryBuffer() {
        BinaryGraphBuilder builder = new BinaryGraphBuilder();
        
        // Add all vertices with their actual data
        for (Map.Entry<Integer, Vertex> entry : vertices.entrySet()) {
            Vertex vertex = entry.getValue();
            builder.addNode(
                vertex.id,
                vertex.labels,
                vertex.properties
            );
        }
        
        // Add all edges with their actual data
        for (Edge edge : edges) {
            builder.addEdge(
                generateEdgeId(edge), // Generate unique edge ID
                edge.source,
                edge.target,
                edge.type,
                edge.properties
            );
        }
        
        return builder.build();
    }
    
    /**
     * Get size information for binary buffer
     */
    public Map<String, Integer> getBinaryBufferInfo() {
        Map<String, Integer> info = new HashMap<>();
        info.put("vertex_count", vertices.size());
        info.put("edge_count", edges.size());
        info.put("label_count", getAvailableLabels().size());
        info.put("relationship_type_count", getAvailableRelationshipTypes().size());
        
        // Estimate buffer size
        int estimatedSize = 64; // Header
        estimatedSize += getAvailableLabels().size() * 20; // Label table
        estimatedSize += propertyCardinality.size() * 30; // Property table
        estimatedSize += vertices.size() * 50; // Node array
        estimatedSize += edges.size() * 60; // Edge array
        
        info.put("estimated_buffer_size", estimatedSize);
        return info;
    }
    
    /**
     * Create iterator for efficient streaming to binary buffer
     * Allows processing large graphs without loading everything in memory
     */
    public Iterator<Vertex> getVertexIterator() {
        return vertices.values().iterator();
    }
    
    public Iterator<Edge> getEdgeIterator() {
        return edges.iterator();
    }
    
    /**
     * Get distinct labels with statistics for C++ optimization
     */
    public Map<String, Integer> getLabelStatistics() {
        Map<String, Integer> stats = new HashMap<>();
        for (Vertex vertex : vertices.values()) {
            for (String label : vertex.labels) {
                stats.put(label, stats.getOrDefault(label, 0) + 1);
            }
        }
        return stats;
    }
    
    /**
     * Get relationship type statistics for C++ optimization
     */
    public Map<String, Integer> getRelationshipStatistics() {
        Map<String, Integer> stats = new HashMap<>();
        for (Edge edge : edges) {
            stats.put(edge.type, stats.getOrDefault(edge.type, 0) + 1);
        }
        return stats;
    }
    
    private long generateEdgeId(Edge edge) {
        // Generate unique edge ID from source, target, and type
        return ((long) edge.source << 32) | edge.target | edge.type.hashCode();
    }
    
    // Accessor methods for binary export
    public Collection<Vertex> getVertices() {
        return vertices.values();
    }
    
    public List<Edge> getEdges() {
        return edges;
    }
    
    // Note: getVertexCount() and getEdgeCount() already defined earlier in class
}