package com.whyquery.neo4j.paths;

/**
 * Types of path alternatives that can be suggested
 */
public enum PathAlternativeType {
    
    /**
     * Change the path algorithm (shortest path, variable-length, etc.)
     */
    ALGORITHM_CHANGE,
    
    /**
     * Modify or add path constraints (length, direction, etc.)
     */
    CONSTRAINT_MODIFICATION,
    
    /**
     * Relax existing constraints to find more paths
     */
    CONSTRAINT_RELAXATION,
    
    /**
     * Tighten constraints for more focused results
     */
    CONSTRAINT_TIGHTENING,
    
    /**
     * Add new constraints not present in original query
     */
    CONSTRAINT_ADDITION,
    
    /**
     * Modify relationship type constraints
     */
    RELATIONSHIP_TYPE_CONSTRAINT,
    
    /**
     * Add or modify weight-based path optimization
     */
    WEIGHT_OPTIMIZATION,
    
    /**
     * Performance-focused modifications
     */
    PERFORMANCE_OPTIMIZATION,
    
    /**
     * Add path filtering or post-processing
     */
    PATH_FILTERING,
    
    /**
     * Change path direction constraints
     */
    DIRECTION_MODIFICATION
}