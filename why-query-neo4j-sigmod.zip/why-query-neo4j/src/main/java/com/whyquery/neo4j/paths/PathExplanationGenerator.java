package com.whyquery.neo4j.paths;

import com.whyquery.neo4j.statistics.Neo4jStatistics;
import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Generates natural language explanations for path selection decisions
 * and alternative path recommendations.
 */
public class PathExplanationGenerator {
    
    private final DecimalFormat decimalFormat = new DecimalFormat("#.##");
    private final Neo4jStatistics statistics;
    
    public PathExplanationGenerator(Neo4jStatistics statistics) {
        this.statistics = statistics;
    }
    
    /**
     * Generate explanation for path analysis results
     */
    public String explainPathAnalysis(PathAnalysis analysis) {
        StringBuilder explanation = new StringBuilder();
        
        explanation.append("🔍 STATISTICS-BASED Path Analysis:\n\n");
        
        String query = analysis.getOriginalQuery().toLowerCase();
        String originalQuery = analysis.getOriginalQuery();
        
        // Extract labels FROM THE QUERY and validate against database catalog
        Set<String> queryLabels = extractLabelsFromQuery(originalQuery);
        Set<String> validLabels = new HashSet<>();
        Set<String> invalidLabels = new HashSet<>();
        
        // Check which labels from query actually exist in database
        Set<String> databaseLabels = statistics.getAllLabels();
        for (String label : queryLabels) {
            if (databaseLabels.contains(label)) {
                validLabels.add(label);
            } else {
                invalidLabels.add(label);
            }
        }
        
        // PERFORMANCE IMPACT BASED ON ACTUAL QUERY CONTENT
        explanation.append("⚡ PERFORMANCE IMPACT (based on YOUR specific query):\n");
        
        if (query.contains("shortestpath")) {
            // Calculate real impact based on labels ACTUALLY IN THE QUERY
            long totalCombinations = calculatePathCombinationsFromQuery(validLabels, invalidLabels, originalQuery);
            
            if (totalCombinations > 1000000) {
                explanation.append(String.format("🚨 MASSIVE SCALE: %,d potential path combinations!\n", totalCombinations));
                explanation.append("   This will likely crash or timeout your database\n");
            } else if (totalCombinations > 10000) {
                explanation.append(String.format("⚠️  HIGH LOAD: %,d potential path combinations\n", totalCombinations));
                explanation.append("   This may cause significant performance issues\n");
            } else if (totalCombinations > 100) {
                explanation.append(String.format("📊 MODERATE LOAD: %,d potential path combinations\n", totalCombinations));
                explanation.append("   Performance should be acceptable\n");
            } else {
                explanation.append(String.format("✅ LOW IMPACT: Only %,d potential path combinations\n", totalCombinations));
            }
            
            // Show analysis for labels ACTUALLY IN THE QUERY
            if (!hasSpecificNodeConstraints(originalQuery)) {
                explanation.append("\n📈 QUERY LABELS ANALYSIS:\n");
                
                if (!validLabels.isEmpty()) {
                    explanation.append("Valid labels in your query:\n");
                    for (String label : validLabels) {
                        long nodeCount = statistics.getNodeCount(label);
                        explanation.append(String.format("   %s nodes: %,d\n", label, nodeCount));
                    }
                }
                
                if (!invalidLabels.isEmpty()) {
                    explanation.append("❌ INVALID labels in your query:\n");
                    for (String label : invalidLabels) {
                        explanation.append(String.format("   %s: NOT FOUND in database\n", label));
                    }
                    explanation.append("💡 Check your label names - these don't exist!\n");
                }
                
                if (validLabels.isEmpty() && invalidLabels.isEmpty()) {
                    explanation.append("No specific labels found in query - analyzing all possible combinations\n");
                }
            }
        }
        
        // ALGORITHM CHOICE ANALYSIS
        explanation.append("\n🧠 ALGORITHM CHOICE ANALYSIS:\n");
        
        List<PathInstance> actualPaths = analysis.getActualPaths();
        int pathCount = actualPaths.size();
        
        if (query.contains("shortestpath(") && pathCount > 1) {
            explanation.append("🚨 POTENTIAL ISSUE: You used shortestPath() but multiple equally short paths exist!\n");
            explanation.append(String.format("   Found %d paths of the same length - you're only seeing 1 random one\n", pathCount));
            explanation.append("💡 SOLUTION: Use allShortestPaths() to see all equally short paths\n");
        }
        
        if (actualPaths.isEmpty() && query.contains("shortestpath") && !hasSpecificNodeConstraints(originalQuery)) {
            explanation.append("\n🚨 EXECUTION BLOCKED: Query too dangerous to execute\n");
            explanation.append("   Your pattern would cause massive performance issues or crashes\n");
            explanation.append("   This is why the analysis was skipped for your safety\n");
        }
        
        // CONCRETE SUGGESTIONS
        explanation.append("\n🎯 ACTIONABLE IMPROVEMENTS:\n");
        
        if (query.contains("shortestpath") && query.contains("-[*]-")) {
            explanation.append("1. Replace -[*]- with -[*1..4]- for safety\n");
        }
        
        if (!hasSpecificNodeConstraints(originalQuery)) {
            explanation.append("2. Add WHERE clauses with specific node properties\n");
            explanation.append("   Example: WHERE p1.name = 'John' AND p2.name = 'Jane'\n");
        }
        
        if (!query.contains("-[:")) {
            explanation.append("3. Add relationship types: -[:ACTED_IN|DIRECTED*]-\n");
        }
        
        return explanation.toString();
    }
    
    /**
     * Extract labels from Cypher query using regex (but validate against database)
     */
    private Set<String> extractLabelsFromQuery(String query) {
        Set<String> labels = new HashSet<>();
        Pattern labelPattern = Pattern.compile("\\(\\w*:(\\w+)\\)");
        Matcher matcher = labelPattern.matcher(query);
        
        while (matcher.find()) {
            labels.add(matcher.group(1));
        }
        
        return labels;
    }
    
    /**
     * Calculate potential path combinations based on query content
     */
    private long calculatePathCombinationsFromQuery(Set<String> validLabels, Set<String> invalidLabels, String query) {
        // If query has invalid labels, return 0 (no possible paths)
        if (!invalidLabels.isEmpty() && validLabels.isEmpty()) {
            return 0;
        }
        
        // If no labels found in query at all, fall back to database catalog
        if (validLabels.isEmpty() && invalidLabels.isEmpty()) {
            Set<String> allLabels = statistics.getAllLabels();
            return calculateAllPossibleCombinations(allLabels, query);
        }
        
        if (hasSpecificNodeConstraints(query)) {
            // If we have WHERE constraints, assume it's just a few specific nodes
            return Math.min(10, validLabels.size());
        }
        
        // Calculate combinations based on ACTUAL labels in the query
        return calculateAllPossibleCombinations(validLabels, query);
    }
    
    private long calculateAllPossibleCombinations(Set<String> labels, String query) {
        if (labels.isEmpty()) {
            return 0;
        }
        
        long totalCombinations = 0;
        List<String> labelList = new ArrayList<>(labels);
        
        for (int i = 0; i < labelList.size(); i++) {
            for (int j = i; j < labelList.size(); j++) {
                String label1 = labelList.get(i);
                String label2 = labelList.get(j);
                
                long count1 = statistics.getNodeCount(label1);
                long count2 = statistics.getNodeCount(label2);
                
                if (i == j) {
                    // Same label: N^2 for all pairs within label
                    totalCombinations += count1 * count1;
                } else {
                    // Different labels: N * M for cross-label pairs
                    totalCombinations += count1 * count2;
                }
            }
        }
        
        return totalCombinations;
    }
    
    /**
     * Check if query has specific node constraints (WHERE clauses with properties)
     */
    private boolean hasSpecificNodeConstraints(String query) {
        String lowerQuery = query.toLowerCase();
        return lowerQuery.contains("where") && 
               (lowerQuery.contains(".name") || lowerQuery.contains(".id") || 
                lowerQuery.contains("id(") || lowerQuery.contains("="));
    }
    
    /**
     * Explain why a specific path was selected
     */
    public String explainPathSelection(PathSelectionReason reason) {
        StringBuilder explanation = new StringBuilder();
        
        PathInstance chosen = reason.getChosenPath();
        explanation.append("Path Selection Explanation:\n\n");
        
        // Basic path info
        explanation.append(String.format("Selected path: %s\n", chosen.getDescription()));
        
        // Primary criterion
        explanation.append(String.format("Primary criterion: %s\n", reason.getPrimaryCriterion()));
        
        // Alternative analysis
        if (reason.hasAlternatives()) {
            explanation.append(String.format("\nAlternatives considered: %d paths\n", 
                                            reason.getAlternativePaths().size()));
            
            PathSelectionReason.SelectionSummary summary = reason.getSummary();
            explanation.append(String.format("Selection confidence: %.1f%%\n", summary.confidence * 100));
            
            if (summary.isClearChoice) {
                explanation.append("This was a clear choice based on the optimization criteria.\n");
            } else {
                explanation.append("This was a competitive choice among similar alternatives.\n");
            }
            
            // Decisive factors
            if (!reason.getDecisiveFactors().isEmpty()) {
                explanation.append("\nDecisive factors:\n");
                for (String factor : reason.getDecisiveFactors()) {
                    explanation.append("- ").append(factor).append("\n");
                }
            }
            
            // Most competitive comparison
            PathComparison competitive = reason.getMostCompetitiveComparison();
            if (competitive != null) {
                explanation.append("\nComparison with closest alternative:\n");
                explanation.append(explainPathComparison(competitive));
            }
        } else {
            explanation.append("\nNo alternative paths were available.\n");
        }
        
        return explanation.toString();
    }
    
    /**
     * Explain comparison between two paths
     */
    public String explainPathComparison(PathComparison comparison) {
        StringBuilder explanation = new StringBuilder();
        
        PathInstance pathA = comparison.getPathA();
        PathInstance pathB = comparison.getPathB();
        
        explanation.append(String.format("Comparing Path A (%s) vs Path B (%s):\n\n", 
                                        pathA.getDescription(), pathB.getDescription()));
        
        // Overall result
        PathComparison.ComparisonSummary summary = comparison.getSummary();
        if ("NEUTRAL".equals(summary.favoredPath)) {
            explanation.append("Both paths are equivalent across measured metrics.\n");
        } else {
            String favoredPath = "A".equals(summary.favoredPath) ? "A" : "B";
            explanation.append(String.format("Path %s is favored overall.\n", favoredPath));
        }
        
        // Metric breakdown
        List<PathComparison.CostMetric> significantMetrics = comparison.getMetricsBySignificance();
        if (!significantMetrics.isEmpty()) {
            explanation.append("\nMetric breakdown:\n");
            
            for (PathComparison.CostMetric metric : significantMetrics) {
                if (metric.isSignificant()) {
                    explanation.append(String.format("- %s: Path A = %s, Path B = %s → favors Path %s\n",
                                                    metric.getName(),
                                                    formatValue(metric.getValueA()),
                                                    formatValue(metric.getValueB()),
                                                    metric.getFavoredPath()));
                }
            }
        }
        
        return explanation.toString();
    }
    
    /**
     * Generate suggestions for path improvements
     */
    public String generatePathSuggestions(List<PathStrategy> strategies) {
        StringBuilder suggestions = new StringBuilder();
        
        suggestions.append("Path Optimization Suggestions:\n\n");
        
        if (strategies.isEmpty()) {
            suggestions.append("No alternative strategies identified.\n");
            return suggestions.toString();
        }
        
        // Group strategies by priority
        Map<PathStrategy.StrategyPriority, List<PathStrategy>> groupedStrategies = groupStrategiesByPriority(strategies);
        
        // High priority suggestions
        List<PathStrategy> highPriority = groupedStrategies.get(PathStrategy.StrategyPriority.HIGH);
        if (highPriority != null && !highPriority.isEmpty()) {
            suggestions.append("🔥 High Priority Recommendations:\n");
            for (int i = 0; i < Math.min(3, highPriority.size()); i++) {
                PathStrategy strategy = highPriority.get(i);
                suggestions.append(String.format("%d. %s\n", i + 1, explainStrategy(strategy)));
                suggestions.append("\n");
            }
        }
        
        // Medium priority suggestions
        List<PathStrategy> mediumPriority = groupedStrategies.get(PathStrategy.StrategyPriority.MEDIUM);
        if (mediumPriority != null && !mediumPriority.isEmpty()) {
            suggestions.append("⚡ Alternative Approaches:\n");
            for (int i = 0; i < Math.min(2, mediumPriority.size()); i++) {
                PathStrategy strategy = mediumPriority.get(i);
                suggestions.append(String.format("%d. %s\n", i + 1, explainStrategy(strategy)));
                suggestions.append("\n");
            }
        }
        
        // Experimental suggestions
        List<PathStrategy> experimental = groupedStrategies.get(PathStrategy.StrategyPriority.EXPERIMENTAL);
        if (experimental != null && !experimental.isEmpty()) {
            suggestions.append("🧪 Experimental Options:\n");
            PathStrategy strategy = experimental.get(0);
            suggestions.append("- ").append(explainStrategy(strategy)).append("\n");
        }
        
        return suggestions.toString();
    }
    
    /**
     * Explain a single path strategy
     */
    private String explainStrategy(PathStrategy strategy) {
        StringBuilder explanation = new StringBuilder();
        
        explanation.append(strategy.getName()).append(": ");
        explanation.append(strategy.getDescription());
        
        if (strategy.getExpectedBenefit() != null) {
            explanation.append(" → ").append(strategy.getExpectedBenefit());
        }
        
        explanation.append(String.format(" (effectiveness: %.0f%%)", strategy.getEstimatedEffectiveness() * 100));
        
        if (!strategy.getTradeoffs().isEmpty()) {
            explanation.append("\n   Tradeoffs: ").append(String.join(", ", strategy.getTradeoffs()));
        }
        
        return explanation.toString();
    }
    
    /**
     * Group strategies by priority
     */
    private Map<PathStrategy.StrategyPriority, List<PathStrategy>> groupStrategiesByPriority(List<PathStrategy> strategies) {
        Map<PathStrategy.StrategyPriority, List<PathStrategy>> grouped = new EnumMap<>(PathStrategy.StrategyPriority.class);
        
        for (PathStrategy strategy : strategies) {
            PathStrategy.StrategyPriority priority = strategy.getPriority();
            grouped.computeIfAbsent(priority, k -> new ArrayList<>()).add(strategy);
        }
        
        // Sort each priority group by effectiveness
        for (List<PathStrategy> group : grouped.values()) {
            group.sort((a, b) -> Double.compare(b.getEstimatedEffectiveness(), a.getEstimatedEffectiveness()));
        }
        
        return grouped;
    }
    
    /**
     * Explain a path pattern
     */
    private String explainPathPattern(PathPattern pattern) {
        StringBuilder explanation = new StringBuilder();
        
        switch (pattern.getType()) {
            case SHORTEST_PATH:
                explanation.append("Shortest path finding");
                break;
            case VARIABLE_LENGTH:
                explanation.append("Variable-length traversal");
                break;
            case FIXED_LENGTH:
                explanation.append("Fixed-length path");
                break;
            case ALL_SHORTEST_PATHS:
                explanation.append("All shortest paths finding");
                break;
            default:
                explanation.append("Custom path pattern");
                break;
        }
        
        // Add length information
        if (pattern.isVariableLength()) {
            explanation.append(String.format(" (%s hops)", pattern.getLengthRangeString()));
        } else {
            explanation.append(String.format(" (%d hop%s)", pattern.getMinLength(), 
                                            pattern.getMinLength() == 1 ? "" : "s"));
        }
        
        // Add relationship type information
        if (pattern.hasRelationshipTypes()) {
            explanation.append(String.format(" using %s relationships", pattern.getRelationshipTypesString()));
        }
        
        // Add direction information
        if (!"OUT".equals(pattern.getDirection())) {
            explanation.append(String.format(" (direction: %s)", pattern.getDirection().toLowerCase()));
        }
        
        // Add weight information
        if (pattern.isWeighted()) {
            explanation.append(String.format(" with weights by %s", pattern.getWeightProperty()));
        }
        
        return explanation.toString();
    }
    
    /**
     * Get algorithm description
     */
    private String getAlgorithmDescription(PathAlgorithmType algorithmType) {
        switch (algorithmType) {
            case SIMPLE_TRAVERSAL:
                return "Simple graph traversal";
            case FIXED_LENGTH:
                return "Fixed-length path traversal";
            case VARIABLE_LENGTH:
                return "Variable-length path exploration";
            case SHORTEST_PATH:
                return "Shortest path algorithm (BFS-based)";
            case ALL_SHORTEST_PATHS:
                return "All shortest paths algorithm";
            case WEIGHTED_SHORTEST_PATH:
                return "Weighted shortest path (Dijkstra's algorithm)";
            case A_STAR:
                return "A* pathfinding algorithm";
            case CUSTOM:
                return "Custom path algorithm";
            default:
                return "Unknown algorithm";
        }
    }
    
    /**
     * Format a numeric value for display
     */
    private String formatValue(double value) {
        if (value == (long) value) {
            return String.valueOf((long) value);
        } else {
            return decimalFormat.format(value);
        }
    }
    
    /**
     * Generate a comprehensive path report
     */
    public String generatePathReport(PathAnalysis analysis, PathSelectionReason selectionReason, 
                                   List<PathStrategy> strategies) {
        StringBuilder report = new StringBuilder();
        
        report.append("=== WhyPath Analysis Report ===\n\n");
        
        // Analysis section
        report.append(explainPathAnalysis(analysis));
        report.append("\n");
        
        // Selection reasoning section
        if (selectionReason != null) {
            report.append("=== Path Selection Reasoning ===\n\n");
            report.append(explainPathSelection(selectionReason));
            report.append("\n");
        }
        
        // Improvement suggestions section
        if (strategies != null && !strategies.isEmpty()) {
            report.append("=== Optimization Strategies ===\n\n");
            report.append(generatePathSuggestions(strategies));
        }
        
        return report.toString();
    }
}