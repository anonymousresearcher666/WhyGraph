package com.whyquery.neo4j;

import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

/**
 * Estimates query cardinality by actually executing the query
 */
public class CardinalityEstimator {
    private final DataGraph dataGraph;
    private final Transaction tx;
    
    public CardinalityEstimator(DataGraph dataGraph) {
        this.dataGraph = dataGraph;
        this.tx = dataGraph.getTransaction();
    }
    
    public CardinalityEstimator(DataGraph dataGraph, Transaction tx) {
        this.dataGraph = dataGraph;
        this.tx = tx;
    }
    
    public Long estimate(QueryGraph queryGraph) {
        return estimate(queryGraph.getOriginalCypherQuery());
    }
    
    public Long estimate(String cypherQuery) {
        if (cypherQuery == null || cypherQuery.trim().isEmpty()) {
            return 0L;
        }
        
        try {
            // Execute the actual query to get real cardinality
            Result result = tx.execute(cypherQuery);
            long count = 0;
            while (result.hasNext()) {
                result.next();
                count++;
            }
            result.close();
            return count;
            
        } catch (Exception e) {
            // If query execution fails, try to estimate based on pattern analysis
            try {
                // Extract count using simpler pattern matching
                String countQuery = convertToCountQuery(cypherQuery);
                Result countResult = tx.execute(countQuery);
                
                if (countResult.hasNext()) {
                    Object countObj = countResult.next().get("count");
                    countResult.close();
                    return countObj instanceof Number ? ((Number) countObj).longValue() : 0L;
                }
                countResult.close();
            } catch (Exception e2) {
                // Final fallback - return 0 for failed queries
                return 0L;
            }
            return 0L;
        }
    }
    
    private String convertToCountQuery(String originalQuery) {
        // Convert RETURN clause to COUNT(*)
        String upperQuery = originalQuery.toUpperCase();
        int returnIndex = upperQuery.lastIndexOf("RETURN");
        
        if (returnIndex != -1) {
            String beforeReturn = originalQuery.substring(0, returnIndex);
            return beforeReturn + "RETURN COUNT(*) as count";
        }
        
        // If no RETURN found, append count
        return originalQuery + " RETURN COUNT(*) as count";
    }
}