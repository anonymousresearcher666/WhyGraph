package com.whyquery.neo4j.ast;

import java.util.*;
import java.util.regex.*;

/**
 * Builder for creating Cypher AST from query strings
 * This is a simplified parser implementation - a full implementation would use ANTLR or similar
 */
public class CypherASTBuilder {
    
    /**
     * Parse a Cypher query string into an AST
     */
    public static CypherAST parseQuery(String cypherQuery) {
        if (cypherQuery == null || cypherQuery.trim().isEmpty()) {
            throw new IllegalArgumentException("Query cannot be null or empty");
        }
        
        CypherAST ast = new CypherAST();
        String normalizedQuery = normalizeOutsideQuotes(cypherQuery);
        normalizedQuery = desugarFixedLengthRelationships(normalizedQuery);

        try {
            // Create root query node
            String queryId = ast.addNode(NodeType.QUERY, new HashMap<>());
            ast.setRoot(queryId);
            // Retain a conservative input guard: this simplified parser does
            // not preserve every unsupported clause or Boolean connective.
            // Copies retain the flag even if regeneration drops such syntax.
            boolean unsupportedCertificateInput = Pattern.compile(
                "(?i)\\b(?:OR|NOT|XOR|OPTIONAL|WITH|UNION|CALL|UNWIND)\\b|"
                + "\\b(?:count|sum|avg|min|max|collect|stDev|stDevP|percentileCont|percentileDisc)\\s*\\(")
                .matcher(normalizedQuery).find();
            ast.getRoot().setAttribute("certificate_input_unsupported", unsupportedCertificateInput);
            
            // Parse different clauses
            parsePatternAndFilterClauses(ast, queryId, normalizedQuery);
            parseReturnClauses(ast, queryId, normalizedQuery);
            parseOtherClauses(ast, queryId, normalizedQuery);
            
            // Validate the resulting AST
            CypherAST.ValidationResult validation = ast.validateAST();
            if (!validation.isValid()) {
                throw new IllegalArgumentException("Invalid AST: " + validation.getErrors());
            }
            
            return ast;

        } catch (Exception e) {
            throw new RuntimeException("Failed to parse query: " + cypherQuery, e);
        }
    }

    private static String normalizeOutsideQuotes(String query) {
        StringBuilder normalized = new StringBuilder();
        char quote = 0;
        boolean space = false;
        for (int i = 0; i < query.length(); i++) {
            char c = query.charAt(i);
            if (quote == 0 && Character.isWhitespace(c)) {
                space = normalized.length() > 0;
                continue;
            }
            if (space) { normalized.append(' '); space = false; }
            normalized.append(c);
            if (quote != 0) {
                if (c == '\\' && i + 1 < query.length()) {
                    normalized.append(query.charAt(++i));
                } else if (c == quote) {
                    if (i + 1 < query.length() && query.charAt(i + 1) == quote) {
                        normalized.append(query.charAt(++i));
                    } else quote = 0;
                }
            } else if (c == '\'' || c == '"' || c == '`') quote = c;
        }
        return normalized.toString();
    }

    /** Same-length mask used only to locate top-level clause keywords. */
    private static String maskClauseContents(String query) {
        StringBuilder mask = new StringBuilder(query);
        char quote = 0;
        int depth = 0;
        for (int i = 0; i < query.length(); i++) {
            char c = query.charAt(i);
            if (quote != 0) {
                mask.setCharAt(i, ' ');
                if (c == '\\' && i + 1 < query.length()) {
                    mask.setCharAt(++i, ' ');
                } else if (c == quote) {
                    if (i + 1 < query.length() && query.charAt(i + 1) == quote) {
                        mask.setCharAt(++i, ' ');
                    } else quote = 0;
                }
                continue;
            }
            if (c == '\'' || c == '"' || c == '`') {
                quote = c; mask.setCharAt(i, ' '); continue;
            }
            if (c == '(' || c == '[' || c == '{') depth++;
            if (depth > 0) mask.setCharAt(i, ' ');
            if (c == ')' || c == ']' || c == '}') depth--;
        }
        return mask.toString();
    }

    private static void parsePatternAndFilterClauses(CypherAST ast, String queryId, String query) {
        // MATCH/WHERE order is semantic, especially for OPTIONAL MATCH. A
        // keyword inside a literal, identifier or pattern is not a clause.
        Matcher matcher = Pattern.compile(
            "(?i)(?<![\\w.])\\b(?:OPTIONAL\\s+MATCH|MATCH|WHERE|RETURN|WITH|ORDER\\s+BY|LIMIT|SKIP)\\b")
            .matcher(maskClauseContents(query));
        List<String> kinds = new ArrayList<>();
        List<Integer> starts = new ArrayList<>(), ends = new ArrayList<>();
        while (matcher.find()) {
            kinds.add(matcher.group().toUpperCase(java.util.Locale.ROOT));
            starts.add(matcher.start()); ends.add(matcher.end());
        }
        for (int i = 0; i < kinds.size(); i++) {
            String kind = kinds.get(i);
            String content = query.substring(ends.get(i),
                i + 1 < kinds.size() ? starts.get(i + 1) : query.length()).trim();
            NodeType type = kind.equals("WHERE") ? NodeType.WHERE
                : kind.equals("MATCH") ? NodeType.MATCH
                : kind.equals("OPTIONAL MATCH") ? NodeType.OPTIONAL_MATCH : null;
            if (type == null) continue;
            String id = ast.addNode(type, new HashMap<>());
            ast.addEdge(queryId, id);
            if (type == NodeType.WHERE) parseWhereExpression(ast, id, content);
            else parsePattern(ast, id, content);
        }
    }

    // Matches one relationship token, e.g. "-[:KNOWS*2..2]->", "<-[r:REPLY_OF*3]-", "-[*2]-".
    // Group 1: left marker ("<-" or "-"); group 2: bracket content; group 3: right marker ("->" or "-").
    private static final Pattern RELATIONSHIP_TOKEN = Pattern.compile("(<-|-)\\[([^\\]]*)\\](->|-)");
    // Matches a variable-length spec inside bracket content, anchored so it must be the tail of
    // the content (properties, if any, come after the type and before "*" in valid Cypher, so a
    // trailing "*min..max"/"*n"/"*" is unambiguous). Group 1: optional fixed/min count digits;
    // group 2: optional ".."; group 3: optional max count digits.
    private static final Pattern VAR_LENGTH_SPEC = Pattern.compile("\\*\\s*(\\d+)?\\s*(\\.\\.)?\\s*(\\d+)?\\s*$");

    /**
     * Rewrite fixed-count variable-length relationship atoms ("*N" or "*N..N", with no bound
     * variable referenced elsewhere in the query) into N literal chained single-hop atoms with
     * fresh anonymous intermediate nodes, e.g. "(a)-[:KNOWS*3]->(b)" becomes
     * "(a)-[:KNOWS]->(_vl0)-[:KNOWS]->(_vl1)-[:KNOWS]->(b)". This is pure syntactic sugar: a
     * fixed hop count has no combinatorial choice of path length, so it carries exactly the same
     * information as the expanded chain and needs no change to schema pruning, cost, or bound
     * computation -- those already handle ordinary multi-hop chains.
     * A ranged (min != max) or unbounded ("*", "*N..", "*..M") spec is left untouched here; the
     * later per-relationship parse step rejects it explicitly rather than silently misreading the
     * "*..." suffix as part of the relationship type, which is what happened before this method
     * existed. A bound relationship variable used elsewhere in the query is also left untouched,
     * since a chain of single-hop relationships cannot represent a single list-typed path
     * variable; that case is rejected the same way as an unsupported range.
     */
    static String desugarFixedLengthRelationships(String query) {
        Matcher tokenMatcher = RELATIONSHIP_TOKEN.matcher(query);
        StringBuilder result = new StringBuilder();
        int lastEnd = 0;
        int anonCounter = 0;
        while (tokenMatcher.find()) {
            String left = tokenMatcher.group(1);
            String content = tokenMatcher.group(2);
            String right = tokenMatcher.group(3);
            Matcher lenMatcher = VAR_LENGTH_SPEC.matcher(content);
            if (!lenMatcher.find()) {
                continue; // no "*" in this token; leave the default text as-is
            }
            String minStr = lenMatcher.group(1);
            boolean hasRange = lenMatcher.group(2) != null;
            String maxStr = lenMatcher.group(3);
            Long min = minStr != null ? Long.valueOf(minStr) : null;
            Long max = maxStr != null ? Long.valueOf(maxStr) : null;
            boolean fixed;
            long count;
            if (!hasRange && min != null) {
                fixed = true; // "*N"
                count = min;
            } else if (hasRange && min != null && min.equals(max)) {
                fixed = true; // "*N..N"
                count = min;
            } else {
                fixed = false;
                count = -1;
            }
            if (!fixed || count < 1) {
                continue; // ranged or unbounded: leave untouched for explicit rejection downstream
            }
            String withoutSpec = content.substring(0, lenMatcher.start()).trim();
            String variable = null;
            String typePart = withoutSpec;
            if (withoutSpec.contains(":")) {
                int colon = withoutSpec.indexOf(':');
                String varCandidate = withoutSpec.substring(0, colon).trim();
                if (!varCandidate.isEmpty()) {
                    variable = varCandidate;
                }
                typePart = withoutSpec.substring(colon + 1).trim();
            } else if (!withoutSpec.isEmpty() && !withoutSpec.contains("{")) {
                variable = withoutSpec;
                typePart = "";
            }
            if (variable != null) {
                String rest = query.substring(tokenMatcher.end());
                String before = query.substring(0, tokenMatcher.start());
                if (rest.matches("(?s).*\\b" + Pattern.quote(variable) + "\\b.*")
                    || before.matches("(?s).*\\b" + Pattern.quote(variable) + "\\b.*")) {
                    continue; // referenced elsewhere; cannot represent as a chain of plain hops
                }
            }
            StringBuilder chain = new StringBuilder();
            String hopBracket = "[" + (typePart.isEmpty() ? "" : ":" + typePart) + "]";
            for (long i = 0; i < count; i++) {
                chain.append(left).append(hopBracket).append(right);
                if (i < count - 1) {
                    chain.append("(_vl").append(anonCounter++).append(")");
                }
            }
            result.append(query, lastEnd, tokenMatcher.start()).append(chain);
            lastEnd = tokenMatcher.end();
        }
        result.append(query.substring(lastEnd));
        return result.toString();
    }

    /**
     * Parse MATCH and OPTIONAL MATCH clauses
     */
    private static void parseMatchClauses(CypherAST ast, String queryId, String query) {
        // Preserve clause boundaries: relationship uniqueness is scoped to one
        // MATCH clause. Folding successive MATCH clauses into a comma-separated
        // pattern can remove valid valuations that reuse a physical relationship.
        Pattern matchPattern = Pattern.compile(
            "(OPTIONAL\\s+)?MATCH\\s+(.+?)(?=\\s+(?:OPTIONAL\\s+)?MATCH\\b|\\s+WHERE|\\s+RETURN|\\s+WITH|\\s+ORDER\\s+BY|\\s+LIMIT|\\s*$)",
            Pattern.CASE_INSENSITIVE
        );
        
        Matcher matcher = matchPattern.matcher(query);
        
        while (matcher.find()) {
            boolean isOptional = matcher.group(1) != null;
            String patternText = matcher.group(2).trim();
            
            NodeType matchType = isOptional ? NodeType.OPTIONAL_MATCH : NodeType.MATCH;
            String matchId = ast.addNode(matchType, new HashMap<>());
            ast.addEdge(queryId, matchId);
            
            // Parse the pattern
            parsePattern(ast, matchId, patternText);
        }
    }
    
    /**
     * Parse WHERE clauses
     */
    private static void parseWhereClauses(CypherAST ast, String queryId, String query) {
        Pattern wherePattern = Pattern.compile(
            "WHERE\\s+(.+?)(?=\\s+RETURN|\\s+WITH|\\s+ORDER\\s+BY|\\s+LIMIT|\\s*$)",
            Pattern.CASE_INSENSITIVE
        );
        
        Matcher matcher = wherePattern.matcher(query);
        
        while (matcher.find()) {
            String whereText = matcher.group(1).trim();
            
            String whereId = ast.addNode(NodeType.WHERE, new HashMap<>());
            ast.addEdge(queryId, whereId);
            
            // Parse the where expression
            parseWhereExpression(ast, whereId, whereText);
        }
    }
    
    /**
     * Parse RETURN clauses
     */
    private static void parseReturnClauses(CypherAST ast, String queryId, String query) {
        Pattern returnPattern = Pattern.compile(
            "RETURN\\s+(.+?)(?=\\s+ORDER\\s+BY|\\s+LIMIT|\\s+SKIP|\\s*$)",
            Pattern.CASE_INSENSITIVE
        );
        
        Matcher matcher = returnPattern.matcher(query);
        
        while (matcher.find()) {
            String returnText = matcher.group(1).trim();
            
            String returnId = ast.addNode(NodeType.RETURN, new HashMap<>());
            ast.addEdge(queryId, returnId);
            
            // Parse return projections
            parseReturnProjections(ast, returnId, returnText);
        }
    }
    
    /**
     * Parse other clauses (ORDER BY, LIMIT, etc.)
     */
    private static void parseOtherClauses(CypherAST ast, String queryId, String query) {
        // ORDER BY
        Pattern orderByPattern = Pattern.compile(
            "ORDER\\s+BY\\s+(.+?)(?=\\s+LIMIT|\\s+SKIP|\\s*$)",
            Pattern.CASE_INSENSITIVE
        );
        Matcher orderMatcher = orderByPattern.matcher(query);
        if (orderMatcher.find()) {
            String orderByText = orderMatcher.group(1).trim();
            for (String rawItem : orderByText.split(",")) {
                String orderItem = rawItem.trim();
                if (orderItem.isEmpty()) {
                    continue;
                }

                Matcher itemMatcher = Pattern.compile(
                    "(.+?)(?:\\s+(ASC|DESC))?$",
                    Pattern.CASE_INSENSITIVE
                ).matcher(orderItem);

                String expression = orderItem;
                String direction = "ASC";
                if (itemMatcher.matches()) {
                    expression = itemMatcher.group(1).trim();
                    if (itemMatcher.group(2) != null) {
                        direction = itemMatcher.group(2).toUpperCase();
                    }
                }

                String orderById = ast.addNode(NodeType.ORDER_BY, Map.of(
                    "expression", expression,
                    "direction", direction
                ));
                ast.addEdge(queryId, orderById);
            }
        }
        
        // LIMIT
        Pattern limitPattern = Pattern.compile("LIMIT\\s+(\\d+)", Pattern.CASE_INSENSITIVE);
        Matcher limitMatcher = limitPattern.matcher(query);
        if (limitMatcher.find()) {
            String limitValue = limitMatcher.group(1);
            String limitId = ast.addNode(NodeType.LIMIT, Map.of("value", Integer.parseInt(limitValue)));
            ast.addEdge(queryId, limitId);
        }
    }
    
    /**
     * Parse a pattern like (a:Person)-[:KNOWS]->(b:Person)
     */
    private static void parsePattern(CypherAST ast, String matchId, String patternText) {
        String patternId = ast.addNode(NodeType.PATTERN, new HashMap<>());
        ast.addEdge(matchId, patternId);
        
        // Split pattern into elements: nodes and relationships
        List<PatternElement> elements = parsePatternElements(patternText);
        
        for (PatternElement element : elements) {
            String elementId = null;
            
            if (element.isNode()) {
                elementId = ast.addNode(NodeType.NODE, element.getAttributes());
            } else if (element.isRelationship()) {
                elementId = ast.addNode(NodeType.RELATIONSHIP, element.getAttributes());
            }
            
            if (elementId != null) {
                ast.addEdge(patternId, elementId);
            }
        }
    }
    
    /**
     * Parse pattern elements from pattern text
     */
    private static List<PatternElement> parsePatternElements(String patternText) {
        List<PatternElement> elements = new ArrayList<>();
        int index = 0;
        int length = patternText.length();
        
        while (index < length) {
            char ch = patternText.charAt(index);
            if (ch == '(') {
                int end = findMatchingParen(patternText, index);
                if (end == -1) {
                    break;
                }
                String nodeText = patternText.substring(index + 1, end);
                elements.add(parseNodeElement(nodeText));
                index = end + 1;
            } else if (ch == '-' || ch == '<') {
                int relStart = index;
                while (index < length && patternText.charAt(index) != '(') {
                    index++;
                }
                String relText = patternText.substring(relStart, index).trim();
                if (!relText.isEmpty()) {
                    elements.add(parseRelationshipElement(relText));
                }
            } else {
                index++;
            }
        }
        
        return elements;
    }

    private static int findMatchingParen(String text, int startIndex) {
        int depth = 0;
        for (int i = startIndex; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '(') {
                depth++;
            } else if (c == ')') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    /**
     * Parse a node element
     */
    private static PatternElement parseNodeElement(String nodeText) {
        Map<String, Object> attributes = new HashMap<>();
        
        // Parse variable and labels properly
        // First, separate the properties part if it exists
        String mainPart = nodeText.split("\\{")[0].trim(); // Remove properties part
        String[] parts = mainPart.split(":");
        
        // Parse variable
        if (parts.length > 0) {
            String variable = parts[0].trim();
            if (!variable.isEmpty()) {
                attributes.put("variable", variable);
            }
        }
        
        // Parse labels - all parts after the variable are labels
        List<String> labels = new ArrayList<>();
        for (int i = 1; i < parts.length; i++) {
            String label = parts[i].trim();
            if (!label.isEmpty()) {
                labels.add(label);
            }
        }
        if (!labels.isEmpty()) {
            attributes.put("labels", labels);
        }
        
        // Parse properties
        Map<String, Object> properties = parseProperties(nodeText);
        if (!properties.isEmpty()) {
            attributes.put("properties", properties);
        }
        
        return new PatternElement(true, false, attributes);
    }
    
    /**
     * Parse a relationship element
     */
    private static PatternElement parseRelationshipElement(String relText) {
        Map<String, Object> attributes = new HashMap<>();
        
        // Determine direction
        String direction = "BOTH";
        if (relText.startsWith("<-")) {
            direction = "IN";
        } else if (relText.endsWith("->")) {
            direction = "OUT";
        }
        attributes.put("direction", direction);
        
        // Extract content between [ and ]
        Pattern contentPattern = Pattern.compile("\\[([^\\]]*)\\]");
        Matcher matcher = contentPattern.matcher(relText);
        
        if (matcher.find()) {
            String content = matcher.group(1);
            if (VAR_LENGTH_SPEC.matcher(content).find()) {
                // Reached only for a "*" spec that desugarFixedLengthRelationships left alone:
                // a ranged/unbounded hop count, or a fixed count whose bound variable is
                // referenced elsewhere in the query. Reject explicitly rather than silently
                // parsing the "*..." suffix as part of the relationship type (the prior
                // behavior), which produced a schema-inconsistent triple with a misleading
                // error rather than an honest "not supported" diagnosis.
                throw new IllegalArgumentException(
                    "Unsupported relationship pattern: variable-length or unbounded hop count "
                    + "outside the core fragment ('" + relText + "'). Fixed-count patterns "
                    + "(e.g. *2 or *2..2) with no relationship variable used elsewhere are "
                    + "rewritten automatically; ranged (*1..3), unbounded (*, *1.., *..3), and "
                    + "carried-variable variable-length patterns are not supported.");
            }

            // Parse variable and type
            if (content.contains(":")) {
                String[] parts = content.split(":");
                if (parts.length > 0 && !parts[0].trim().isEmpty()) {
                    attributes.put("variable", parts[0].trim());
                }
                if (parts.length > 1) {
                    String typePart = parts[1].split("\\{")[0].trim();
                    if (!typePart.isEmpty()) {
                        attributes.put("type", typePart);
                    }
                }
            } else if (!content.trim().isEmpty() && !content.contains("{")) {
                // Just a variable
                attributes.put("variable", content.trim());
            }
            
            // Parse properties
            Map<String, Object> properties = parseProperties(content);
            if (!properties.isEmpty()) {
                attributes.put("properties", properties);
            }
        }
        
        return new PatternElement(false, true, attributes);
    }
    
    /**
     * Parse properties from text like {prop1: value1, prop2: value2}
     */
    private static Map<String, Object> parseProperties(String text) {
        Map<String, Object> properties = new HashMap<>();
        
        Pattern propPattern = Pattern.compile("\\{([^}]+)\\}");
        Matcher matcher = propPattern.matcher(text);
        
        if (matcher.find()) {
            String propsText = matcher.group(1);
            String[] propPairs = propsText.split(",");
            
            for (String pair : propPairs) {
                String[] keyValue = pair.split(":");
                if (keyValue.length == 2) {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();
                    
                    // Remove quotes and parse value
                    if (value.startsWith("'") && value.endsWith("'")) {
                        properties.put(key, value.substring(1, value.length() - 1));
                    } else if (value.startsWith("\"") && value.endsWith("\"")) {
                        properties.put(key, value.substring(1, value.length() - 1));
                    } else {
                        // Try to parse as number
                        try {
                            if (value.contains(".")) {
                                properties.put(key, Double.parseDouble(value));
                            } else {
                                properties.put(key, Long.parseLong(value));
                            }
                        } catch (NumberFormatException e) {
                            properties.put(key, value);
                        }
                    }
                }
            }
        }
        
        return properties;
    }
    
    /**
     * Parse WHERE expression
     */
    private static void parseWhereExpression(CypherAST ast, String whereId, String whereText) {
        // Simple expression parsing - would be more sophisticated in a real parser
        
        if (whereText.toLowerCase().contains(" and ")) {
            String andId = ast.addNode(NodeType.AND, new HashMap<>());
            ast.addEdge(whereId, andId);
            
            String[] parts = whereText.split("(?i)\\s+and\\s+");
            for (String part : parts) {
                parseSimplePredicate(ast, andId, part.trim());
            }
        } else if (whereText.toLowerCase().contains(" or ")) {
            String orId = ast.addNode(NodeType.OR, new HashMap<>());
            ast.addEdge(whereId, orId);
            
            String[] parts = whereText.split("(?i)\\s+or\\s+");
            for (String part : parts) {
                parseSimplePredicate(ast, orId, part.trim());
            }
        } else {
            parseSimplePredicate(ast, whereId, whereText);
        }
    }
    
    /**
     * Parse a simple predicate like "a.age > 30"
     */
    private static void parseSimplePredicate(CypherAST ast, String parentId, String predicateText) {
        String normalized = predicateText == null ? "" : predicateText.trim();
        if ("false".equalsIgnoreCase(normalized) || "true".equalsIgnoreCase(normalized)) {
            String predicateId = ast.addNode(NodeType.PREDICATE, Map.of(
                "expression", normalized.toLowerCase(Locale.ROOT)
            ));
            ast.addEdge(parentId, predicateId);
            return;
        }

        // Pattern for property comparisons: variable.property operator value
        Pattern predPattern = Pattern.compile("([a-zA-Z_][a-zA-Z0-9_]*)\\.([a-zA-Z_][a-zA-Z0-9_]*)\\s*(>=|<=|>|<|=|<>|!=)\\s*(.+)");
        Matcher matcher = predPattern.matcher(normalized);
        
        if (matcher.find()) {
            String variable = matcher.group(1);
            String property = matcher.group(2);
            String operator = matcher.group(3);
            String value = matcher.group(4);
            
            // Create predicate node
            NodeType operatorType = parseOperatorType(operator);
            String predicateId = ast.addNode(operatorType, Map.of("operator", operator));
            ast.addEdge(parentId, predicateId);
            
            // Create property node
            String propertyId = ast.addNode(NodeType.PROPERTY, Map.of(
                "variable", variable,
                "name", property
            ));
            ast.addEdge(predicateId, propertyId);
            
            // Create literal node
            Object parsedValue = parseValue(value);
            String literalId = ast.addNode(NodeType.LITERAL, Map.of("value", parsedValue));
            ast.addEdge(predicateId, literalId);
        }
    }
    
    /**
     * Parse RETURN projections
     */
    private static void parseReturnProjections(CypherAST ast, String returnId, String returnText) {
        String[] projections = returnText.split(",");
        
        for (String projection : projections) {
            projection = projection.trim();

            Matcher countMatcher = Pattern.compile(
                "(?i)^COUNT\\s*\\(\\s*(DISTINCT\\s+)?(\\*|[A-Za-z_]\\w*(?:\\.[A-Za-z_]\\w*)?)\\s*\\)(?:\\s+AS\\s+([A-Za-z_]\\w*))?$"
            ).matcher(projection);
            if (countMatcher.matches()) {
                Map<String, Object> attributes = new HashMap<>();
                attributes.put("distinct", countMatcher.group(1) != null);
                attributes.put("wildcard", "*".equals(countMatcher.group(2)));
                String countId = ast.addNode(NodeType.COUNT, attributes);
                String expression = countMatcher.group(2);
                if (!"*".equals(expression)) {
                    addProjectionExpression(ast, countId, expression);
                }
                String alias = countMatcher.group(3);
                if (alias != null) {
                    String aliasId = ast.addNode(NodeType.ALIAS, Map.of("name", alias));
                    ast.addEdge(aliasId, countId);
                    ast.addEdge(returnId, aliasId);
                } else {
                    ast.addEdge(returnId, countId);
                }
            } else if (projection.contains(".")) {
                // Property projection like "a.name"
                addProjectionExpression(ast, returnId, projection);
            } else {
                // Variable projection like "a"
                addProjectionExpression(ast, returnId, projection);
            }
        }
    }

    private static void addProjectionExpression(CypherAST ast, String parentId, String expression) {
        String[] parts = expression.trim().split("\\.");
        String expressionId;
        if (parts.length == 2) {
            expressionId = ast.addNode(NodeType.PROPERTY, Map.of(
                "variable", parts[0].trim(),
                "name", parts[1].trim()
            ));
        } else {
            expressionId = ast.addNode(NodeType.VARIABLE, Map.of("name", expression.trim()));
        }
        ast.addEdge(parentId, expressionId);
    }
    
    /**
     * Parse operator type from string
     */
    private static NodeType parseOperatorType(String operator) {
        switch (operator) {
            case "=": return NodeType.EQUALS;
            case ">": return NodeType.GREATER_THAN;
            case "<": return NodeType.LESS_THAN;
            case ">=": return NodeType.GREATER_THAN_OR_EQUAL;
            case "<=": return NodeType.LESS_THAN_OR_EQUAL;
            case "<>":
            case "!=": return NodeType.NOT_EQUALS;
            default: return NodeType.BINARY_OP;
        }
    }
    
    /**
     * Parse value from string
     */
    private static Object parseValue(String value) {
        value = value.trim();
        
        // Remove quotes
        if ((value.startsWith("'") && value.endsWith("'")) || 
            (value.startsWith("\"") && value.endsWith("\""))) {
            return value.substring(1, value.length() - 1);
        }
        
        // Try to parse as number
        try {
            if (value.contains(".")) {
                return Double.parseDouble(value);
            } else {
                return Long.parseLong(value);
            }
        } catch (NumberFormatException e) {
            return value;
        }
    }
    
    /**
     * Helper class for pattern elements
     */
    private static class PatternElement {
        private final boolean isNode;
        private final boolean isRelationship;
        private final Map<String, Object> attributes;
        
        public PatternElement(boolean isNode, boolean isRelationship, Map<String, Object> attributes) {
            this.isNode = isNode;
            this.isRelationship = isRelationship;
            this.attributes = attributes;
        }
        
        public boolean isNode() { return isNode; }
        public boolean isRelationship() { return isRelationship; }
        public Map<String, Object> getAttributes() { return attributes; }
    }
}
