package com.whyquery.neo4j.ranking;

import java.util.*;

/**
 * Represents a composition of ranking factors with their weights and directions.
 * Used to model alternative ranking approaches.
 */
public class RankingComposition {
    
    private final String name;
    private final List<RankingFactor> factors;
    private double totalWeight;
    private Map<String, Object> metadata;
    
    public RankingComposition(String name) {
        this.name = name;
        this.factors = new ArrayList<>();
        this.metadata = new HashMap<>();
        this.totalWeight = 0.0;
    }
    
    public String getName() {
        return name;
    }
    
    public List<RankingFactor> getFactors() {
        return factors;
    }
    
    public void addFactor(RankingFactor factor) {
        this.factors.add(factor);
        this.totalWeight += Math.abs(factor.getWeight());
    }
    
    public double getTotalWeight() {
        return totalWeight;
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    /**
     * Calculate the overall score for an entity using this composition
     */
    public double calculateScore(Map<String, Object> entityValues) {
        double score = 0.0;
        
        for (RankingFactor factor : factors) {
            Object value = entityValues.get(factor.getExpression());
            if (value != null) {
                score += factor.calculateContribution(value);
            }
        }
        
        return score;
    }
    
    /**
     * Generate a Cypher ORDER BY clause for this composition
     */
    public String generateOrderByClause() {
        if (factors.isEmpty()) {
            return "";
        }
        
        StringBuilder orderBy = new StringBuilder("ORDER BY ");
        
        for (int i = 0; i < factors.size(); i++) {
            if (i > 0) {
                orderBy.append(", ");
            }
            
            RankingFactor factor = factors.get(i);
            
            // Add weight if not 1.0
            if (Math.abs(factor.getWeight() - 1.0) > 0.001) {
                orderBy.append("(").append(factor.getExpression()).append(" * ")
                       .append(factor.getWeight()).append(")");
            } else {
                orderBy.append(factor.getExpression());
            }
            
            orderBy.append(" ").append(factor.getDirection());
        }
        
        return orderBy.toString();
    }
    
    /**
     * Get factors sorted by weight (descending)
     */
    public List<RankingFactor> getFactorsByImportance() {
        List<RankingFactor> sorted = new ArrayList<>(factors);
        sorted.sort((a, b) -> Double.compare(Math.abs(b.getWeight()), Math.abs(a.getWeight())));
        return sorted;
    }
    
    /**
     * Get the most important factor
     */
    public RankingFactor getPrimaryFactor() {
        List<RankingFactor> byImportance = getFactorsByImportance();
        return byImportance.isEmpty() ? null : byImportance.get(0);
    }
    
    /**
     * Check if this composition emphasizes a specific factor type
     */
    public boolean emphasizes(RankingFactorType type) {
        RankingFactor primary = getPrimaryFactor();
        return primary != null && primary.getType() == type;
    }
    
    /**
     * Get factor types used in this composition
     */
    public Set<RankingFactorType> getFactorTypes() {
        Set<RankingFactorType> types = new HashSet<>();
        for (RankingFactor factor : factors) {
            types.add(factor.getType());
        }
        return types;
    }
    
    /**
     * Calculate the diversity score of this composition
     * Higher score means more diverse factor types
     */
    public double getDiversityScore() {
        Set<RankingFactorType> types = getFactorTypes();
        return (double) types.size() / Math.max(1, factors.size());
    }
    
    /**
     * Check if this composition is balanced (no single factor dominates)
     */
    public boolean isBalanced() {
        if (factors.size() <= 1) return true;
        
        double maxWeight = 0.0;
        double sumWeights = 0.0;
        
        for (RankingFactor factor : factors) {
            double absWeight = Math.abs(factor.getWeight());
            maxWeight = Math.max(maxWeight, absWeight);
            sumWeights += absWeight;
        }
        
        // Balanced if no single factor accounts for more than 60% of total weight
        return maxWeight / sumWeights <= 0.6;
    }
    
    /**
     * Create a copy of this composition with normalized weights
     */
    public RankingComposition normalize() {
        RankingComposition normalized = new RankingComposition(name + " (Normalized)");
        
        if (totalWeight > 0) {
            for (RankingFactor factor : factors) {
                RankingFactor normalizedFactor = copyFactor(factor);
                normalizedFactor.setWeight(factor.getWeight() / totalWeight);
                normalized.addFactor(normalizedFactor);
            }
        }
        
        normalized.setMetadata(new HashMap<>(metadata));
        return normalized;
    }
    
    /**
     * Create a copy of a ranking factor
     */
    private RankingFactor copyFactor(RankingFactor original) {
        RankingFactor copy = new RankingFactor();
        copy.setType(original.getType());
        copy.setVariable(original.getVariable());
        copy.setProperty(original.getProperty());
        copy.setExpression(original.getExpression());
        copy.setDirection(original.getDirection());
        copy.setWeight(original.getWeight());
        copy.setMetadata(new HashMap<>(original.getMetadata()));
        return copy;
    }
    
    @Override
    public String toString() {
        return "RankingComposition{" +
               "name='" + name + '\'' +
               ", factorCount=" + factors.size() +
               ", totalWeight=" + totalWeight +
               ", diversity=" + String.format("%.2f", getDiversityScore()) +
               ", balanced=" + isBalanced() +
               '}';
    }
}