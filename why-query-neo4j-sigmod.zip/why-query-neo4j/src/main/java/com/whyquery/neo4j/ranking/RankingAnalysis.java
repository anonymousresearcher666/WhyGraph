package com.whyquery.neo4j.ranking;

import java.util.*;

/**
 * Contains the results of ranking analysis for a Cypher query
 */
public class RankingAnalysis {
    
    private String originalQuery;
    private RankingType rankingType;
    private List<RankingFactor> rankingFactors;
    private Map<String, Object> analysisMetadata;
    private RankingStrategy genericStrategy;
    
    public RankingAnalysis() {
        this.rankingFactors = new ArrayList<>();
        this.analysisMetadata = new HashMap<>();
    }
    
    public String getOriginalQuery() {
        return originalQuery;
    }
    
    public void setOriginalQuery(String originalQuery) {
        this.originalQuery = originalQuery;
    }
    
    public RankingType getRankingType() {
        return rankingType;
    }
    
    public void setRankingType(RankingType rankingType) {
        this.rankingType = rankingType;
    }
    
    public List<RankingFactor> getRankingFactors() {
        return rankingFactors;
    }
    
    public void setRankingFactors(List<RankingFactor> rankingFactors) {
        this.rankingFactors = rankingFactors;
    }
    
    public void addRankingFactor(RankingFactor factor) {
        this.rankingFactors.add(factor);
    }
    
    public Map<String, Object> getAnalysisMetadata() {
        return analysisMetadata;
    }
    
    public void setAnalysisMetadata(Map<String, Object> analysisMetadata) {
        this.analysisMetadata = analysisMetadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.analysisMetadata.put(key, value);
    }
    
    /**
     * Check if the query has explicit ranking
     */
    public boolean hasExplicitRanking() {
        return rankingType == RankingType.EXPLICIT_ORDER_BY;
    }
    
    /**
     * Check if the query has any form of ranking
     */
    public boolean hasRanking() {
        return rankingType != RankingType.NO_RANKING && !rankingFactors.isEmpty();
    }
    
    /**
     * Get ranking factors of a specific type
     */
    public List<RankingFactor> getFactorsByType(RankingFactorType type) {
        List<RankingFactor> factors = new ArrayList<>();
        for (RankingFactor factor : rankingFactors) {
            if (factor.getType() == type) {
                factors.add(factor);
            }
        }
        return factors;
    }
    
    /**
     * Get ranking factors for a specific variable
     */
    public List<RankingFactor> getFactorsForVariable(String variable) {
        List<RankingFactor> factors = new ArrayList<>();
        for (RankingFactor factor : rankingFactors) {
            if (variable.equals(factor.getVariable())) {
                factors.add(factor);
            }
        }
        return factors;
    }
    
    public RankingStrategy getGenericStrategy() {
        return genericStrategy;
    }
    
    public void setGenericStrategy(RankingStrategy genericStrategy) {
        this.genericStrategy = genericStrategy;
    }
    
    @Override
    public String toString() {
        return "RankingAnalysis{" +
               "rankingType=" + rankingType +
               ", factorCount=" + rankingFactors.size() +
               ", hasExplicitRanking=" + hasExplicitRanking() +
               '}';
    }
}