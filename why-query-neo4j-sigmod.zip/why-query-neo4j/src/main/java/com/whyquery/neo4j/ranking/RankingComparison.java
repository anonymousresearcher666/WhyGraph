package com.whyquery.neo4j.ranking;

import java.util.*;

/**
 * Represents a factor-by-factor comparison between two entities showing
 * why one ranks higher than the other.
 */
public class RankingComparison {
    
    private final String entityA;
    private final String entityB;
    private final List<FactorContribution> factorContributions;
    private double overallDifference;
    private String favoredEntity;
    
    public RankingComparison(String entityA, String entityB) {
        this.entityA = entityA;
        this.entityB = entityB;
        this.factorContributions = new ArrayList<>();
    }
    
    public String getEntityA() {
        return entityA;
    }
    
    public String getEntityB() {
        return entityB;
    }
    
    public List<FactorContribution> getFactorContributions() {
        return factorContributions;
    }
    
    public void addFactorContribution(FactorContribution contribution) {
        this.factorContributions.add(contribution);
    }
    
    public double getOverallDifference() {
        return overallDifference;
    }
    
    public String getFavoredEntity() {
        return favoredEntity;
    }
    
    /**
     * Calculate the overall ranking difference based on all factor contributions
     */
    public void calculateOverallDifference() {
        double totalDifference = 0.0;
        
        for (FactorContribution contribution : factorContributions) {
            totalDifference += contribution.getContributionDifference();
        }
        
        this.overallDifference = totalDifference;
        
        if (totalDifference > 0) {
            this.favoredEntity = "A";
        } else if (totalDifference < 0) {
            this.favoredEntity = "B";
        } else {
            this.favoredEntity = "NEUTRAL";
        }
    }
    
    /**
     * Get factors that favor entity A
     */
    public List<FactorContribution> getFactorsFavoringA() {
        return getFactorsFavoring("A");
    }
    
    /**
     * Get factors that favor entity B
     */
    public List<FactorContribution> getFactorsFavoringB() {
        return getFactorsFavoring("B");
    }
    
    /**
     * Get factors that are neutral
     */
    public List<FactorContribution> getNeutralFactors() {
        return getFactorsFavoring("NEUTRAL");
    }
    
    /**
     * Get factors favoring a specific entity
     */
    private List<FactorContribution> getFactorsFavoring(String entity) {
        List<FactorContribution> factors = new ArrayList<>();
        for (FactorContribution contribution : factorContributions) {
            if (entity.equals(contribution.getFavorsEntity())) {
                factors.add(contribution);
            }
        }
        return factors;
    }
    
    /**
     * Get the most influential factors (by absolute contribution)
     */
    public List<FactorContribution> getMostInfluentialFactors(int count) {
        List<FactorContribution> sorted = new ArrayList<>(factorContributions);
        sorted.sort((a, b) -> Double.compare(
            Math.abs(b.getContributionDifference()), 
            Math.abs(a.getContributionDifference())
        ));
        
        return sorted.subList(0, Math.min(count, sorted.size()));
    }
    
    /**
     * Check if the ranking difference is significant
     */
    public boolean isSignificantDifference() {
        return Math.abs(overallDifference) > 0.1; // Threshold for significance
    }
    
    /**
     * Get a summary of the comparison
     */
    public ComparisonSummary getSummary() {
        ComparisonSummary summary = new ComparisonSummary();
        summary.entityA = entityA;
        summary.entityB = entityB;
        summary.overallDifference = overallDifference;
        summary.favoredEntity = favoredEntity;
        summary.significantDifference = isSignificantDifference();
        summary.factorsForA = getFactorsFavoringA().size();
        summary.factorsForB = getFactorsFavoringB().size();
        summary.neutralFactors = getNeutralFactors().size();
        summary.mostInfluentialFactor = getMostInfluentialFactors(1).isEmpty() ? 
            null : getMostInfluentialFactors(1).get(0);
        
        return summary;
    }
    
    @Override
    public String toString() {
        return "RankingComparison{" +
               "entityA='" + entityA + '\'' +
               ", entityB='" + entityB + '\'' +
               ", overallDifference=" + overallDifference +
               ", favoredEntity='" + favoredEntity + '\'' +
               ", factorCount=" + factorContributions.size() +
               '}';
    }
    
    /**
     * Summary of a ranking comparison
     */
    public static class ComparisonSummary {
        public String entityA;
        public String entityB;
        public double overallDifference;
        public String favoredEntity;
        public boolean significantDifference;
        public int factorsForA;
        public int factorsForB;
        public int neutralFactors;
        public FactorContribution mostInfluentialFactor;
        
        @Override
        public String toString() {
            return String.format("Entity %s vs %s: %s favored by %.2f " +
                               "(A: %d factors, B: %d factors, Neutral: %d factors)",
                               entityA, entityB, favoredEntity, Math.abs(overallDifference),
                               factorsForA, factorsForB, neutralFactors);
        }
    }
}