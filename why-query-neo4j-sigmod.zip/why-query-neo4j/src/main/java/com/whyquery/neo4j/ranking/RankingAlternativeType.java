package com.whyquery.neo4j.ranking;

/**
 * Types of ranking alternatives that can be suggested
 */
public enum RankingAlternativeType {
    
    /**
     * Adjust weights of existing ranking factors
     */
    WEIGHT_ADJUSTMENT,
    
    /**
     * Add new ranking factors to the query
     */
    ADD_FACTOR,
    
    /**
     * Remove problematic ranking factors
     */
    REMOVE_FACTOR,
    
    /**
     * Change the direction (ASC/DESC) of ranking factors
     */
    DIRECTION_CHANGE,
    
    /**
     * Replace the ranking algorithm entirely
     */
    ALGORITHM_CHANGE,
    
    /**
     * Combine multiple ranking factors differently
     */
    FACTOR_COMBINATION,
    
    /**
     * Add secondary or tertiary ranking factors
     */
    HIERARCHICAL_RANKING,
    
    /**
     * Apply normalization to ranking factors
     */
    NORMALIZATION,
    
    /**
     * Use conditional ranking based on entity properties
     */
    CONDITIONAL_RANKING,
    
    /**
     * Apply filtering before ranking
     */
    PRE_FILTER_RANKING
}