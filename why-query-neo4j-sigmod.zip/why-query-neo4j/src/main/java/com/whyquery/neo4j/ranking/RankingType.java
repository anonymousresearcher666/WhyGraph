package com.whyquery.neo4j.ranking;

/**
 * Types of ranking patterns detected in Cypher queries
 */
public enum RankingType {
    
    /**
     * No ranking detected - results returned in arbitrary order
     */
    NO_RANKING,
    
    /**
     * Explicit ranking using ORDER BY clause
     */
    EXPLICIT_ORDER_BY,
    
    /**
     * Implicit ranking due to LIMIT without ORDER BY
     */
    IMPLICIT_LIMIT,
    
    /**
     * Implicit ranking based on node degree or connectivity
     */
    IMPLICIT_DEGREE,
    
    /**
     * Implicit ranking based on aggregation functions
     */
    IMPLICIT_AGGREGATION,
    
    /**
     * Implicit ranking based on property values
     */
    IMPLICIT_PROPERTY,
    
    /**
     * Implicit ranking based on path length or distance
     */
    IMPLICIT_PATH,
    
    /**
     * Custom ranking logic detected
     */
    CUSTOM,
    
    /**
     * Generic ranking strategy applied when no explicit ranking exists
     */
    IMPLICIT_GENERIC
}