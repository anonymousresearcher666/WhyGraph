package com.whyquery.neo4j.ranking;

import java.util.*;

/**
 * Represents an alternative ranking approach with a concrete query modification
 */
public class RankingAlternative {
    
    private RankingAlternativeType type;
    private String title;
    private String description;
    private String modifiedQuery;
    private double effectivenessScore;
    private Map<String, Object> metadata;
    private List<String> tags;
    
    public RankingAlternative() {
        this.metadata = new HashMap<>();
        this.tags = new ArrayList<>();
    }
    
    public RankingAlternativeType getType() {
        return type;
    }
    
    public void setType(RankingAlternativeType type) {
        this.type = type;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getModifiedQuery() {
        return modifiedQuery;
    }
    
    public void setModifiedQuery(String modifiedQuery) {
        this.modifiedQuery = modifiedQuery;
    }
    
    public double getEffectivenessScore() {
        return effectivenessScore;
    }
    
    public void setEffectivenessScore(double effectivenessScore) {
        this.effectivenessScore = effectivenessScore;
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    public List<String> getTags() {
        return tags;
    }
    
    public void setTags(List<String> tags) {
        this.tags = tags;
    }
    
    public void addTag(String tag) {
        this.tags.add(tag);
    }
    
    /**
     * Check if this alternative is considered high priority
     */
    public boolean isHighPriority() {
        return effectivenessScore >= 0.7;
    }
    
    /**
     * Check if this alternative is experimental
     */
    public boolean isExperimental() {
        return tags.contains("experimental") || effectivenessScore < 0.3;
    }
    
    /**
     * Get a summary description combining title and effectiveness
     */
    public String getSummary() {
        return String.format("%s (effectiveness: %.1f%%)", title, effectivenessScore * 100);
    }
    
    /**
     * Compare effectiveness with another alternative
     */
    public int compareEffectiveness(RankingAlternative other) {
        return Double.compare(this.effectivenessScore, other.effectivenessScore);
    }
    
    @Override
    public String toString() {
        return "RankingAlternative{" +
               "type=" + type +
               ", title='" + title + '\'' +
               ", effectivenessScore=" + effectivenessScore +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        RankingAlternative that = (RankingAlternative) o;
        
        return Objects.equals(title, that.title) &&
               Objects.equals(modifiedQuery, that.modifiedQuery);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(title, modifiedQuery);
    }
}