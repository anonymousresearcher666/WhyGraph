package com.whyquery.neo4j.ranking;

import java.util.*;

/**
 * Represents a ranking strategy with ranked entities and explanations
 */
public class RankingStrategy {
    
    private String name;
    private String description;
    private String explanation;
    private boolean applicable;
    private String error;
    private List<RankedEntity> rankedEntities;
    
    public RankingStrategy(String name, String description) {
        this.name = name;
        this.description = description;
        this.applicable = false;
        this.rankedEntities = new ArrayList<>();
    }
    
    public void addRankedEntity(String entity, int rank, double score, String reason) {
        rankedEntities.add(new RankedEntity(entity, rank, score, reason));
    }
    
    public double getVariance() {
        if (rankedEntities.size() < 2) return 0.0;
        
        double mean = rankedEntities.stream()
            .mapToDouble(RankedEntity::getScore)
            .average()
            .orElse(0.0);
        
        return rankedEntities.stream()
            .mapToDouble(e -> Math.pow(e.getScore() - mean, 2))
            .average()
            .orElse(0.0);
    }
    
    public String generateExplanation() {
        if (!applicable) {
            return "Strategy '" + name + "' not applicable: " + error;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("Ranking Strategy: ").append(name).append("\n");
        sb.append("Description: ").append(description).append("\n");
        sb.append("Explanation: ").append(explanation).append("\n\n");
        
        sb.append("Top 5 Results:\n");
        rankedEntities.stream()
            .limit(5)
            .forEach(entity -> 
                sb.append(String.format("%d. %s (score: %.1f) - %s\n", 
                    entity.getRank(), entity.getEntity(), entity.getScore(), entity.getReason()))
            );
        
        if (rankedEntities.size() > 5) {
            sb.append("... and ").append(rankedEntities.size() - 5).append(" more\n");
        }
        
        return sb.toString();
    }
    
    public String generateCypherQuery(String entityLabel, String entityProperty) {
        switch (name) {
            case "Connectivity Ranking":
                return String.format(
                    "MATCH (n:%s) " +
                    "RETURN n.%s as entity, size((n)-[]-()) as connectivity " +
                    "ORDER BY connectivity DESC, entity ASC",
                    entityLabel, entityProperty
                );
                
            case "Temporal Ranking":
                return String.format(
                    "MATCH (n:%s) WHERE n.released IS NOT NULL " +
                    "RETURN n.%s as entity, n.released as year " +
                    "ORDER BY year DESC",
                    entityLabel, entityProperty
                );
                
            case "Relationship Weight Ranking":
                return String.format(
                    "MATCH (n:%s)-[r]->() " +
                    "WITH n.%s as entity, " +
                    "     sum(coalesce(r.salary, 0) + coalesce(r.budget, 0) + coalesce(r.fee, 0)) as total " +
                    "WHERE total > 0 " +
                    "RETURN entity, total " +
                    "ORDER BY total DESC",
                    entityLabel, entityProperty
                );
                
            default:
                return String.format(
                    "MATCH (n:%s) " +
                    "RETURN n.%s as entity " +
                    "ORDER BY entity ASC",
                    entityLabel, entityProperty
                );
        }
    }
    
    // Getters and setters
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }
    public boolean isApplicable() { return applicable; }
    public void setApplicable(boolean applicable) { this.applicable = applicable; }
    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
    public List<RankedEntity> getRankedEntities() { return rankedEntities; }
    
    /**
     * Individual ranked entity
     */
    public static class RankedEntity {
        private String entity;
        private int rank;
        private double score;
        private String reason;
        
        public RankedEntity(String entity, int rank, double score, String reason) {
            this.entity = entity;
            this.rank = rank;
            this.score = score;
            this.reason = reason;
        }
        
        // Getters
        public String getEntity() { return entity; }
        public int getRank() { return rank; }
        public double getScore() { return score; }
        public String getReason() { return reason; }
    }
}