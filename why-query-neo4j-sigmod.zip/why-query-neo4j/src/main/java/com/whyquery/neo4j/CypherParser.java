package com.whyquery.neo4j;

import org.neo4j.graphdb.ExecutionPlanDescription;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Cypher query parser that relies on Neo4j's official parser/plan generation.
 *
 * The approach is:
 * 1. Run the statement with EXPLAIN to let Neo4j parse and plan it.
 * 2. Convert data from the execution plan (identifiers, labels, expand expressions, etc.) into a QueryGraph.
 * 3. Enhance the collected metadata with inline pattern hints (labels/properties) from the original query text.
 *
 * This keeps the implementation aligned with Neo4j's canonical parser while still producing the lightweight
 * QueryGraph structure used by the Why-* procedures.
 */
public final class CypherParser {

    private static final Pattern INLINE_NODE_PATTERN = Pattern.compile(
        "\\((?<var>[a-zA-Z_][a-zA-Z0-9_]*)?(?<labels>(?::[a-zA-Z_][a-zA-Z0-9_]*)*)\\s*(?<props>\\{[^}]+\\})?\\)"
    );

    private static final Pattern INLINE_RELATIONSHIP_PATTERN = Pattern.compile(
        "(?<leftNode>\\([^)]*\\))\\s*(?<leftArrow><-)?-\\[(?<relContent>[^]]*)]\\s*(?<rightArrow>(->)|(<-))?\\s*(?<rightNode>\\([^)]*\\))"
    );

    private static final Pattern REL_TYPE_PATTERN = Pattern.compile(":(?<type>[A-Za-z_][A-Za-z0-9_|:]*)");
    private static final Pattern PROPERTY_ENTRY_PATTERN = Pattern.compile("([a-zA-Z_][a-zA-Z0-9_]*)\\s*:\\s*([^,}]+)");

    private CypherParser() {
    }

    public static QueryGraph parse(String cypherQuery, Transaction tx) {
        Objects.requireNonNull(tx, "Transaction is required for parsing");
        Objects.requireNonNull(cypherQuery, "Cypher query cannot be null");

        QueryGraph queryGraph = new QueryGraph();
        queryGraph.setOriginalCypherQuery(cypherQuery);

        PlanQueryGraphBuilder builder = new PlanQueryGraphBuilder(cypherQuery);

        // Use EXPLAIN to force Neo4j to parse/plan the query and give us the plan tree.
        try (Result result = tx.execute(asExplainQuery(cypherQuery))) {
            ExecutionPlanDescription plan = result.getExecutionPlanDescription();
            if (plan != null) {
                builder.extractFromPlan(plan);
            }
        } catch (Exception e) {
            // A malformed query will surface here – we still fall back to inline hints so callers
            // receive a minimal QueryGraph rather than failing entirely.
        }

        // Inline parsing gives us property literal hints that are not exposed via plan metadata.
        builder.applyInlinePatternHints();
        builder.materializeInto(queryGraph);

        ensureGraphNotEmpty(queryGraph, cypherQuery);
        return queryGraph;
    }

    private static String asExplainQuery(String query) {
        String trimmed = query.trim();
        if (trimmed.regionMatches(true, 0, "EXPLAIN", 0, 7) ||
            trimmed.regionMatches(true, 0, "PROFILE", 0, 7)) {
            return trimmed;
        }
        return "EXPLAIN " + query;
    }

    private static void ensureGraphNotEmpty(QueryGraph queryGraph, String cypherQuery) {
        if (queryGraph.numVertices() == 0) {
            List<String> labels = List.of("Query");
            Map<String, Object> props = Map.of("text", cypherQuery);
            queryGraph.addVertex(1, "query_root", labels, props);
        }
    }

    private static final class PlanQueryGraphBuilder {
        private final String originalQuery;
        private final Map<String, NodeDescriptor> nodeDescriptors = new LinkedHashMap<>();
        private final LinkedHashSet<RelationshipDescriptor> relationships = new LinkedHashSet<>();
        private final Map<Integer, NodeToken> nodeTokensByStart = new HashMap<>();
        private int anonymousCounter = 0;

        PlanQueryGraphBuilder(String originalQuery) {
            this.originalQuery = originalQuery;
        }

        void extractFromPlan(ExecutionPlanDescription root) {
            traverse(root);
        }

        private void traverse(ExecutionPlanDescription plan) {
            if (plan == null) {
                return;
            }
            captureNodeMetadata(plan);
            captureRelationshipMetadata(plan);
            for (ExecutionPlanDescription child : plan.getChildren()) {
                traverse(child);
            }
        }

        private void captureNodeMetadata(ExecutionPlanDescription plan) {
            Map<String, Object> arguments = plan.getArguments();
            if (arguments == null || arguments.isEmpty()) {
                return;
            }
            Collection<String> labels = extractLabels(arguments);
            if (labels.isEmpty()) {
                return;
            }
            for (String identifier : plan.getIdentifiers()) {
                NodeDescriptor descriptor = ensureDescriptor(identifier);
                descriptor.labels.addAll(labels);
            }
        }

        private Collection<String> extractLabels(Map<String, Object> arguments) {
            LinkedHashSet<String> labels = new LinkedHashSet<>();
            Object single = arguments.get("label");
            if (single instanceof String) {
                addSanitizedLabels(labels, (String) single);
            }

            Object multiple = arguments.get("labels");
            if (multiple instanceof Collection<?>) {
                for (Object value : (Collection<?>) multiple) {
                    if (value instanceof String) {
                        addSanitizedLabels(labels, (String) value);
                    }
                }
            } else if (multiple instanceof String) {
                for (String token : ((String) multiple).split(",")) {
                    addSanitizedLabels(labels, token);
                }
            }

            // Index operations expose the label in Index/IndexName arguments (e.g., ":Person(name)")
            Object indexArg = arguments.getOrDefault("Index", arguments.get("index"));
            if (indexArg == null) {
                indexArg = arguments.get("IndexName");
            }
            if (indexArg instanceof String) {
                Matcher matcher = Pattern.compile(":(?<label>[A-Za-z_][A-Za-z0-9_]*)").matcher((String) indexArg);
                if (matcher.find()) {
                    addSanitizedLabels(labels, matcher.group("label"));
                }
            }

            return labels;
        }

        private void captureRelationshipMetadata(ExecutionPlanDescription plan) {
            Map<String, Object> arguments = plan.getArguments();
            if (arguments == null || arguments.isEmpty()) {
                return;
            }
            Object expandExpression = arguments.get("ExpandExpression");
            if (expandExpression instanceof String) {
                parseExpandExpression((String) expandExpression);
            }

            Object expandInto = arguments.get("ExpandInto");
            if (expandInto instanceof String) {
                parseExpandExpression((String) expandInto);
            }
        }

        private void parseExpandExpression(String expression) {
            Pattern pattern = Pattern.compile(
                "\\((?<start>[A-Za-z_][A-Za-z0-9_]*)\\)\\s*(?<left><-)?-\\[(?<rel>[A-Za-z_][A-Za-z0-9_]*)?(?::(?<type>[^]]+))?]\\s*(?<rightArrow>(->)|(<-))?\\s*\\((?<end>[A-Za-z_][A-Za-z0-9_]*)\\)"
            );
            Matcher matcher = pattern.matcher(expression.replaceAll("\\s+", ""));
            if (!matcher.find()) {
                return;
            }

            String start = matcher.group("start");
            String end = matcher.group("end");
            String type = matcher.group("type");
            boolean leftArrow = matcher.group("left") != null;
            String rightArrowToken = matcher.group("rightArrow");
            boolean rightArrow = rightArrowToken != null;
            boolean directed = leftArrow || rightArrow;
            boolean reversed = (leftArrow && rightArrowToken == null) || "<-".equals(rightArrowToken);

            NodeDescriptor startDescriptor = ensureDescriptor(start);
            NodeDescriptor endDescriptor = ensureDescriptor(end);
            relationships.add(new RelationshipDescriptor(
                reversed ? endDescriptor.identifier : startDescriptor.identifier,
                reversed ? startDescriptor.identifier : endDescriptor.identifier,
                sanitizeRelationshipType(type),
                directed
            ));
        }

        void applyInlinePatternHints() {
            captureInlineNodes();
            captureInlineRelationships();
        }

        private void captureInlineNodes() {
            Matcher matcher = INLINE_NODE_PATTERN.matcher(originalQuery);
            while (matcher.find()) {
                String identifier = matcher.group("var");
                if (identifier == null || identifier.isBlank()) {
                    identifier = generateAnonymousIdentifier();
                }
                NodeDescriptor descriptor = ensureDescriptor(identifier);

                String labelsGroup = matcher.group("labels");
                if (labelsGroup != null && !labelsGroup.isBlank()) {
                    for (String rawLabel : labelsGroup.split(":")) {
                        addSanitizedLabels(descriptor.labels, rawLabel);
                    }
                }

                String props = matcher.group("props");
                if (props != null && !props.isBlank()) {
                    descriptor.properties.putAll(parsePropertiesBlock(props));
                }

                nodeTokensByStart.putIfAbsent(matcher.start(), new NodeToken(matcher.start(), matcher.end(), identifier));
            }
        }

        private void captureInlineRelationships() {
            Matcher matcher = INLINE_RELATIONSHIP_PATTERN.matcher(originalQuery);
            while (matcher.find()) {
                NodeToken leftToken = resolveOrCreateToken(matcher.start("leftNode"), matcher.group("leftNode"));
                NodeToken rightToken = resolveOrCreateToken(matcher.start("rightNode"), matcher.group("rightNode"));
                if (leftToken == null || rightToken == null) {
                    continue;
                }

                boolean leftArrow = matcher.group("leftArrow") != null;
                String rightArrowToken = matcher.group("rightArrow");
                boolean rightArrow = rightArrowToken != null;
                boolean directed = leftArrow || rightArrow;
                boolean reversed = (leftArrow && rightArrowToken == null) || "<-".equals(rightArrowToken);

                String relationshipType = parseRelationshipType(matcher.group("relContent"));
                String source = reversed ? rightToken.identifier : leftToken.identifier;
                String target = reversed ? leftToken.identifier : rightToken.identifier;

                relationships.add(new RelationshipDescriptor(source, target, relationshipType, directed));
            }
        }

        private NodeToken resolveOrCreateToken(int startIndex, String nodeText) {
            NodeToken existing = nodeTokensByStart.get(startIndex);
            if (existing != null) {
                return existing;
            }
            Matcher matcher = INLINE_NODE_PATTERN.matcher(nodeText);
            if (!matcher.matches()) {
                return null;
            }
            String identifier = matcher.group("var");
            if (identifier == null || identifier.isBlank()) {
                identifier = generateAnonymousIdentifier();
            }
            NodeDescriptor descriptor = ensureDescriptor(identifier);

            String labelsGroup = matcher.group("labels");
            if (labelsGroup != null && !labelsGroup.isBlank()) {
                for (String rawLabel : labelsGroup.split(":")) {
                    addSanitizedLabels(descriptor.labels, rawLabel);
                }
            }

            String props = matcher.group("props");
            if (props != null && !props.isBlank()) {
                descriptor.properties.putAll(parsePropertiesBlock(props));
            }

            NodeToken token = new NodeToken(startIndex, startIndex + nodeText.length(), identifier);
            nodeTokensByStart.put(startIndex, token);
            return token;
        }

        void materializeInto(QueryGraph queryGraph) {
            if (nodeDescriptors.isEmpty()) {
                String identifier = generateAnonymousIdentifier();
                NodeDescriptor descriptor = ensureDescriptor(identifier);
                descriptor.labels.add("Node");
            }

            int nextId = 1;
            Map<String, Integer> identifierToId = new HashMap<>();
            for (NodeDescriptor descriptor : nodeDescriptors.values()) {
                List<String> labels = descriptor.labels.isEmpty()
                    ? Collections.singletonList("Node")
                    : new ArrayList<>(descriptor.labels);
                Map<String, Object> properties = descriptor.properties.isEmpty()
                    ? new HashMap<>()
                    : new LinkedHashMap<>(descriptor.properties);
                queryGraph.addVertex(nextId, descriptor.identifier, labels, properties);
                identifierToId.put(descriptor.identifier, nextId);
                nextId++;
            }

            for (RelationshipDescriptor rel : relationships) {
                Integer sourceId = identifierToId.get(rel.source);
                Integer targetId = identifierToId.get(rel.target);
                if (sourceId == null || targetId == null) {
                    continue;
                }
                String type = rel.type != null ? rel.type : "RELATIONSHIP";
                queryGraph.addEdge(sourceId, targetId, type, new HashMap<>());
            }
        }

        private NodeDescriptor ensureDescriptor(String identifier) {
            return nodeDescriptors.computeIfAbsent(identifier, NodeDescriptor::new);
        }

        private String generateAnonymousIdentifier() {
            anonymousCounter += 1;
            return "__anon_node_" + anonymousCounter;
        }

        private String sanitizeLabel(String raw) {
            if (raw == null) {
                return "";
            }
            String cleaned = raw.replace("`", "").trim();
            if (cleaned.isEmpty()) {
                return "";
            }
            // Ignore Neo4j Bloom/system labels that should not leak into rewrite queries.
            if (cleaned.startsWith("_Bloom_") || "_Bloom_Perspective_".equals(cleaned)) {
                return "";
            }
            // Drop overly generic ontology labels that overconstrain rewritten queries.
            if ("Entity".equals(cleaned)) {
                return "";
            }
            return cleaned;
        }

        private void addSanitizedLabels(Set<String> labels, String raw) {
            if (raw == null) {
                return;
            }
            for (String token : raw.split(":")) {
                String label = sanitizeLabel(token);
                if (!label.isEmpty()) {
                    labels.add(label);
                }
            }
        }

        private String sanitizeRelationshipType(String rawType) {
            if (rawType == null || rawType.isBlank()) {
                return null;
            }
            String type = rawType;
            int braceIndex = type.indexOf('{');
            if (braceIndex >= 0) {
                type = type.substring(0, braceIndex);
            }
            int pipeIndex = type.indexOf('|');
            if (pipeIndex >= 0) {
                type = type.substring(0, pipeIndex);
            }
            return type.trim();
        }

        private Map<String, Object> parsePropertiesBlock(String block) {
            Map<String, Object> properties = new LinkedHashMap<>();
            String inner = block.substring(1, block.length() - 1);
            Matcher matcher = PROPERTY_ENTRY_PATTERN.matcher(inner);
            while (matcher.find()) {
                String key = matcher.group(1).trim();
                String literal = matcher.group(2).trim();
                properties.put(key, parseLiteral(literal));
            }
            return properties;
        }

        private Object parseLiteral(String literal) {
            if (literal == null) {
                return null;
            }
            String trimmed = literal.trim();
            if ((trimmed.startsWith("'") && trimmed.endsWith("'")) ||
                (trimmed.startsWith("\"") && trimmed.endsWith("\""))) {
                return trimmed.substring(1, trimmed.length() - 1);
            }
            if ("true".equalsIgnoreCase(trimmed) || "false".equalsIgnoreCase(trimmed)) {
                return Boolean.parseBoolean(trimmed);
            }
            if (trimmed.startsWith("$")) {
                return trimmed;
            }
            try {
                if (trimmed.contains(".")) {
                    return Double.parseDouble(trimmed);
                }
                return Long.parseLong(trimmed);
            } catch (NumberFormatException ignore) {
                return trimmed;
            }
        }

        private String parseRelationshipType(String relContent) {
            if (relContent == null) {
                return null;
            }
            Matcher matcher = REL_TYPE_PATTERN.matcher(relContent);
            if (matcher.find()) {
                String type = matcher.group("type");
                if (type != null && type.contains("|")) {
                    type = type.substring(0, type.indexOf('|'));
                }
                return sanitizeRelationshipType(type);
            }
            return null;
        }
    }

    private static final class NodeDescriptor {
        private final String identifier;
        private final LinkedHashSet<String> labels = new LinkedHashSet<>();
        private final LinkedHashMap<String, Object> properties = new LinkedHashMap<>();

        private NodeDescriptor(String identifier) {
            this.identifier = identifier;
        }
    }

    private static final class RelationshipDescriptor {
        private final String source;
        private final String target;
        private final String type;
        private final boolean directed;

        private RelationshipDescriptor(String source, String target, String type, boolean directed) {
            this.source = source;
            this.target = target;
            this.type = type;
            this.directed = directed;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof RelationshipDescriptor)) return false;
            RelationshipDescriptor that = (RelationshipDescriptor) o;
            return directed == that.directed &&
                   Objects.equals(source, that.source) &&
                   Objects.equals(target, that.target) &&
                   Objects.equals(type, that.type);
        }

        @Override
        public int hashCode() {
            return Objects.hash(source, target, type, directed);
        }
    }

    private static final class NodeToken {
        private final int start;
        private final int end;
        private final String identifier;

        private NodeToken(int start, int end, String identifier) {
            this.start = start;
            this.end = end;
            this.identifier = identifier;
        }
    }
}
