package com.whyquery.neo4j;

import java.util.*;

/**
 * Builds context-aware prompts for LLM-powered natural language explanations
 * 
 * Creates specialized prompts for different types of why-query analysis,
 * incorporating technical results, graph context, and domain-specific guidance.
 */
public class ExplanationPromptBuilder {
    
    private static final String BASE_CONTEXT = 
        "You are an expert graph database analyst helping users understand why their Cypher queries " +
        "behave unexpectedly. Provide clear, actionable explanations in plain English. " +
        "Focus on practical solutions and avoid overly technical jargon.\n\n";
    
    /**
     * Build prompt for explaining why a query returns empty results
     */
    public String buildWhyEmptyPrompt(String originalQuery, 
                                    Map<String, Object> technicalResult,
                                    Map<String, Object> statistics) {
        
        StringBuilder prompt = new StringBuilder(BASE_CONTEXT);
        
        prompt.append("## Task: Explain Why Query Returns Empty Results\n\n");
        
        prompt.append("**User's Original Query:**\n```cypher\n")
              .append(originalQuery)
              .append("\n```\n\n");
        
        prompt.append("**Technical Analysis Results:**\n");
        
        // Add differential graph information
        Map<String, Object> diffGraph = (Map<String, Object>) technicalResult.get("differentialGraph");
        if (diffGraph != null) {
            
            // Missing vertices
            List<Map<String, Object>> missingVertices = (List<Map<String, Object>>) diffGraph.get("vertices");
            if (missingVertices != null && !missingVertices.isEmpty()) {
                prompt.append("- Missing Components Found:\n");
                for (Map<String, Object> vertex : missingVertices) {
                    prompt.append("  * ").append(vertex.get("reason")).append("\n");
                    if (vertex.get("suggestion") != null) {
                        prompt.append("    Solution: ").append(vertex.get("suggestion")).append("\n");
                    }
                }
                prompt.append("\n");
            }
            
            // Missing edges
            List<Map<String, Object>> missingEdges = (List<Map<String, Object>>) diffGraph.get("edges");
            if (missingEdges != null && !missingEdges.isEmpty()) {
                prompt.append("- Missing Relationships Found:\n");
                for (Map<String, Object> edge : missingEdges) {
                    prompt.append("  * ").append(edge.get("reason")).append("\n");
                    if (edge.get("suggestion") != null) {
                        prompt.append("    Solution: ").append(edge.get("suggestion")).append("\n");
                    }
                }
                prompt.append("\n");
            }
            
            // Available vs required labels
            List<String> queryLabels = (List<String>) diffGraph.get("query_labels");
            List<String> dataLabels = (List<String>) diffGraph.get("data_labels");
            if (queryLabels != null && dataLabels != null) {
                prompt.append("- Labels in Query: ").append(queryLabels).append("\n");
                prompt.append("- Labels Available in Database: ").append(dataLabels).append("\n\n");
            }
        }
        
        // Add performance statistics
        if (statistics != null) {
            Object implementation = statistics.get("implementation");
            Object computeTime = statistics.get("computation_time_ms");
            Object analyzedNodes = statistics.get("analyzed_nodes");
            
            if (implementation != null) {
                prompt.append("- Analysis Engine: ").append(implementation).append("\n");
            }
            if (computeTime != null) {
                prompt.append("- Analysis Time: ").append(computeTime).append("ms\n");
            }
            if (analyzedNodes != null) {
                prompt.append("- Graph Size Analyzed: ").append(analyzedNodes).append(" nodes\n");
            }
            prompt.append("\n");
        }
        
        prompt.append("## Your Task:\n");
        prompt.append("1. Explain in 2-3 sentences why this query returned no results\n");
        prompt.append("2. Provide 2-3 specific, actionable solutions the user can try\n");
        prompt.append("3. If the issue is missing data, suggest what data they might need to add\n");
        prompt.append("4. If the issue is overly restrictive constraints, suggest how to relax them\n");
        prompt.append("5. Keep your explanation under 200 words and easy to understand\n\n");
        
        prompt.append("Focus on the most likely cause and the easiest solution to try first.");
        
        return prompt.toString();
    }
    
    /**
     * Build prompt guiding the LLM to propose minimal rewrites for why-empty,
     * grounded in schema + diagnostics.
     */
    public String buildWhyEmptyRewritePrompt(String originalQuery,
                                             Map<String, Object> technicalResult,
                                             Map<String, Object> statistics,
                                             Map<String, Object> schemaInfo) {
        
        StringBuilder prompt = new StringBuilder(BASE_CONTEXT);
        prompt.append("## Task: Suggest the smallest possible Cypher rewrites that would produce results, ");
        prompt.append("using ONLY the provided schema and diagnostics. Preserve the original intent.\n\n");
        
        prompt.append("**User's Original Query:**\n```cypher\n")
              .append(originalQuery)
              .append("\n```\n\n");
        
        prompt.append("**Diagnostics (from Why-Empty):**\n");
        if (technicalResult != null) {
            Object analysisType = technicalResult.get("analysis_type");
            if (analysisType != null) {
                prompt.append("- Analysis type: ").append(analysisType).append("\n");
            }
            Object message = technicalResult.get("message");
            if (message != null) {
                prompt.append("- Message: ").append(message).append("\n");
            }
            List<Map<String, Object>> schemaViolations = (List<Map<String, Object>>) technicalResult.get("schema_violations");
            if (schemaViolations != null && !schemaViolations.isEmpty()) {
                prompt.append("- Schema Violations:\n");
                for (Map<String, Object> v : schemaViolations) {
                    prompt.append("  * ").append(v.get("edge")).append("\n");
                }
            }
            List<Map<String, Object>> missingEdges = (List<Map<String, Object>>) technicalResult.get("edges");
            if (missingEdges != null && !missingEdges.isEmpty()) {
                prompt.append("- Missing relationships:\n");
                for (Map<String, Object> e : missingEdges) {
                    prompt.append("  * ").append(e.get("reason")).append("\n");
                }
            }
            List<Map<String, Object>> missingVertices = (List<Map<String, Object>>) technicalResult.get("vertices");
            if (missingVertices != null && !missingVertices.isEmpty()) {
                prompt.append("- Missing nodes:\n");
                for (Map<String, Object> v : missingVertices) {
                    prompt.append("  * ").append(v.get("reason")).append("\n");
                }
            }
            Map<String, Object> heuristics = (Map<String, Object>) technicalResult.get("heuristic_estimates");
            if (heuristics != null && !heuristics.isEmpty()) {
                prompt.append("- Heuristic estimates (from analyzer, do not invent new ones): ").append(heuristics).append("\n");
            }
            prompt.append("\n");
        }
        
        prompt.append("**Schema Snapshot (only use these labels/relationships/properties):**\n");
        if (schemaInfo != null) {
            Object labels = schemaInfo.get("labels");
            Object rels = schemaInfo.get("relationshipTypes");
            Map<String, Object> properties = (Map<String, Object>) schemaInfo.get("properties");
            if (labels != null) {
                prompt.append("- Labels: ").append(labels).append("\n");
            }
            if (rels != null) {
                prompt.append("- Relationship types: ").append(rels).append("\n");
            }
            if (properties != null && !properties.isEmpty()) {
                prompt.append("- Properties (names only): ").append(properties.keySet()).append("\n");
            }
        } else {
            prompt.append("- Schema unavailable. Avoid inventing schema elements.\n");
        }
        prompt.append("\n");
        
        prompt.append("**Instructions:**\n");
        prompt.append("1) Keep the structural pattern as close as possible to the original.\n");
        prompt.append("2) Only use labels/relationships/properties present in the schema snapshot; do NOT invent new ones.\n");
        prompt.append("3) Do NOT use wildcard relationships (e.g., `[:*]`); pick from the provided relationship types.\n");
        prompt.append("4) Offer up to 3 rewrites, ordered from minimal change to more relaxed.\n");
        prompt.append("5) Before listing rewrites, provide a one-sentence meaning/intent of the original query.\n");
        prompt.append("6) For each rewrite, include: the Cypher, what changed, why it should return data, a one-sentence meaning/intent of the rewrite, and a HEURISTIC outcome estimate (broaden/narrow and a qualitative magnitude like small/medium/large). Use the provided heuristics if available; do NOT invent data or run queries.\n");
        prompt.append("7) Do NOT return write queries or call procedures; stay within MATCH/OPTIONAL MATCH/WHERE/RETURN.\n");
        prompt.append("8) Prefer relaxing/removing predicates, optionalizing edges, or swapping to existing labels/rels.\n");
        prompt.append("9) If nothing is possible with the schema, say so.\n\n");
        
        prompt.append("Respond in concise markdown with numbered suggestions.");
        
        return prompt.toString();
    }
    
    /**
     * Build prompt for explaining why a query returns too few results
     */
    public String buildWhySoFewPrompt(String originalQuery,
                                    List<Map<String, Object>> modifications,
                                    Map<String, Object> statistics,
                                    long currentCount,
                                    long targetCount) {
        
        StringBuilder prompt = new StringBuilder(BASE_CONTEXT);
        
        prompt.append("## Task: Explain Why Query Returns Too Few Results\n\n");
        
        prompt.append("**User's Original Query:**\n```cypher\n")
              .append(originalQuery)
              .append("\n```\n\n");
        
        prompt.append("**Current Situation:**\n");
        prompt.append("- Query currently returns: ").append(currentCount).append(" results\n");
        prompt.append("- User expected at least: ").append(targetCount).append(" results\n");
        prompt.append("- Gap to fill: ").append(targetCount - currentCount).append(" additional results\n\n");
        
        prompt.append("**Suggested Modifications (schema-validated, at most 5):**\n");
        int shown = 0;
        if (modifications != null) {
            for (Map<String, Object> mod : modifications) {
                if (shown >= 5) break;
                String type = (String) mod.get("type");
                String suggestion = (String) mod.get("suggestion");
                Object impact = mod.get("potential_increase");
                String validation = (String) mod.getOrDefault("validation_status", "VALID");
                if (suggestion != null) {
                    prompt.append("- [").append(type).append("] ").append(suggestion);
                    if (impact != null) {
                        prompt.append(" (could add ~").append(impact).append(" results)");
                    }
                    prompt.append(" [validation: ").append(validation).append("]\n");
                    shown++;
                } else if ("rewrite_optional_relationship".equals(type) && mod.get("suggested_query") != null) {
                    prompt.append("- [rewrite_optional_relationship] propose optional edge rewrite:\n");
                    prompt.append("```cypher\n").append(mod.get("suggested_query")).append("\n```\n");
                    shown++;
                }
            }
        }
        if (shown == 0) {
            prompt.append("- No schema-valid modifications identified; may require more data or looser constraints.\n");
        }
        prompt.append("\n");
        
        // Add performance context
        if (statistics != null) {
            Object implementation = statistics.get("implementation");
            if (implementation != null) {
                prompt.append("- Analysis performed using: ").append(implementation).append(" engine\n");
            }
            Object currentCard = statistics.get("current_cardinality");
            if (currentCard != null) {
                prompt.append("- Planner current cardinality estimate: ").append(currentCard).append("\n");
            }
        }
        
        prompt.append("## Your Task:\n");
        prompt.append("1. Explain why the query returns fewer results than expected\n");
        prompt.append("2. Prioritize the top 2-3 modifications by likelihood of success\n");
        prompt.append("3. Provide specific Cypher query modifications where applicable\n");
        prompt.append("4. Explain the trade-offs (e.g., more results but potentially less relevant)\n");
        prompt.append("5. Suggest data quality checks if the issue might be missing data\n");
        prompt.append("6. Keep explanation under 250 words\n\n");
        
        prompt.append("Focus on solutions that are easy to implement and most likely to work.");
        
        return prompt.toString();
    }
    
    /**
     * Build prompt for explaining why a query returns too many results
     */
    public String buildWhySoManyPrompt(String originalQuery,
                                     double cardinalityBound,
                                     Map<String, Object> boundedSubgraph,
                                     Map<String, Object> statistics) {
        
        StringBuilder prompt = new StringBuilder(BASE_CONTEXT);
        
        prompt.append("## Task: Explain Why Query Returns Too Many Results\n\n");
        
        prompt.append("**User's Original Query:**\n```cypher\n")
              .append(originalQuery)
              .append("\n```\n\n");
        
        prompt.append("**Analysis Results:**\n");
        prompt.append("- Estimated cardinality bound: ").append(String.format("%.1f", cardinalityBound)).append("\n");
        
        if (boundedSubgraph != null) {
            Object estimatedCount = boundedSubgraph.get("estimated_result_count");
            Object threshold = boundedSubgraph.get("threshold");
            Object excessFactor = boundedSubgraph.get("excess_factor");
            
            if (estimatedCount != null && threshold != null) {
                prompt.append("- Estimated result count: ").append(estimatedCount).append("\n");
                prompt.append("- User's threshold: ").append(threshold).append("\n");
                if (excessFactor != null) {
                    prompt.append("- Excess factor: ").append(String.format("%.1fx", ((Number) excessFactor).doubleValue())).append(" too many\n");
                }
            }
            
            // High cardinality components
            List<Map<String, Object>> highCardNodes = (List<Map<String, Object>>) boundedSubgraph.get("high_cardinality_nodes");
            if (highCardNodes != null && !highCardNodes.isEmpty()) {
                prompt.append("\n**High-Cardinality Node Types:**\n");
                for (Map<String, Object> node : highCardNodes) {
                    prompt.append("- Label: ").append(node.get("label"))
                          .append(" (").append(node.get("count")).append(" nodes, ")
                          .append(String.format("%.1fx contribution", ((Number) node.get("contribution_factor")).doubleValue()))
                          .append(")\n");
                }
            }
            
            List<Map<String, Object>> highCardEdges = (List<Map<String, Object>>) boundedSubgraph.get("high_cardinality_edges");
            if (highCardEdges != null && !highCardEdges.isEmpty()) {
                prompt.append("\n**High-Cardinality Relationship Types:**\n");
                for (Map<String, Object> edge : highCardEdges) {
                    prompt.append("- Type: ").append(edge.get("type"))
                          .append(" (avg degree: ").append(String.format("%.1f", ((Number) edge.get("average_degree")).doubleValue()))
                          .append(", ").append(String.format("%.1fx multiplier", ((Number) edge.get("cardinality_multiplier")).doubleValue()))
                          .append(")\n");
                }
            }
            
            // Optimization suggestions
            List<String> optimizations = (List<String>) boundedSubgraph.get("optimization_suggestions");
            if (optimizations != null && !optimizations.isEmpty()) {
                prompt.append("\n**Automatic Suggestions:**\n");
                for (String opt : optimizations) {
                    prompt.append("- ").append(opt).append("\n");
                }
            }
            
            Object modsObj = boundedSubgraph.get("suggested_modifications");
            if (modsObj instanceof List<?>) {
                List<?> mods = (List<?>) modsObj;
                if (!mods.isEmpty()) {
                    prompt.append("\n**Suggested Modifications (from search/fallback):**\n");
                    for (Object o : mods) {
                        if (o instanceof Map) {
                            Map<?, ?> m = (Map<?, ?>) o;
                            Object desc = m.get("description");
                            if (desc != null) {
                                prompt.append("- ").append(desc).append("\n");
                                continue;
                            }
                            Object op = m.get("operation");
                            if (op != null) {
                                prompt.append("- ").append(op).append("\n");
                                continue;
                            }
                        }
                        prompt.append("- ").append(String.valueOf(o)).append("\n");
                    }
                }
            }
        }
        
        prompt.append("\n## Your Task:\n");
        prompt.append("1. Explain the root cause of high result cardinality in simple terms\n");
        prompt.append("2. Identify which parts of the query contribute most to the explosion\n");
        prompt.append("3. Provide 3-4 specific solutions, ordered by effectiveness:\n");
        prompt.append("   - Add WHERE constraints to filter results\n");
        prompt.append("   - Add selective label or property predicates that preserve query intent\n");
        prompt.append("   - Improve relationship direction specificity\n");
        prompt.append("   - Add property constraints for selectivity\n");
        prompt.append("4. Show concrete Cypher examples for the top 2 solutions\n");
        prompt.append("5. Keep explanation under 300 words\n\n");
        
        prompt.append("Focus on the most impactful changes that preserve query intent.");
        
        return prompt.toString();
    }
    
    /**
     * Build prompt for explaining advanced C++ algorithm results
     */
    public String buildAdvancedPrompt(String originalQuery,
                                    String algorithm,
                                    Map<String, Object> result,
                                    Map<String, Object> statistics) {
        
        StringBuilder prompt = new StringBuilder(BASE_CONTEXT);
        
        prompt.append("## Task: Explain Advanced Graph Algorithm Results\n\n");
        
        prompt.append("**User's Original Query:**\n```cypher\n")
              .append(originalQuery)
              .append("\n```\n\n");
        
        prompt.append("**Algorithm Used:** ").append(algorithm).append("\n\n");
        
        prompt.append("**Technical Results:**\n");
        
        if (result != null) {
            String rawResult = (String) result.get("raw_result");
            if (rawResult != null) {
                // Extract key metrics from JSON result
                if (rawResult.contains("cardinality_bound")) {
                    prompt.append("- Advanced cardinality analysis performed\n");
                }
                if (rawResult.contains("vertex_mapping")) {
                    prompt.append("- Graph pattern matching analysis completed\n");
                }
                if (rawResult.contains("parallel_efficiency")) {
                    prompt.append("- Multi-threaded performance analysis conducted\n");
                }
                if (rawResult.contains("modifications")) {
                    prompt.append("- Query optimization suggestions generated\n");
                }
                if (rawResult.contains("quality_score")) {
                    prompt.append("- Solution quality metrics calculated\n");
                }
                
                // Add performance metrics
                if (rawResult.contains("nodes_explored")) {
                    prompt.append("- Search space optimization applied\n");
                }
                if (rawResult.contains("pruning_ratio")) {
                    prompt.append("- Intelligent pruning strategies used\n");
                }
            }
        }
        
        if (statistics != null) {
            Object cppTime = statistics.get("cpp_computation_time_ms");
            Object implementation = statistics.get("implementation");
            Object algorithmType = statistics.get("algorithm_type");
            
            if (cppTime != null) {
                prompt.append("- C++ computation time: ").append(cppTime).append("ms\n");
            }
            if (algorithmType != null) {
                prompt.append("- Algorithm variant: ").append(algorithmType).append("\n");
            }
        }
        
        prompt.append("\n## Algorithm Context:\n");
        
        if (algorithm.toLowerCase().contains("bounded_mcs")) {
            prompt.append("This used a Bounded Maximum Common Subgraph algorithm with statistical sampling.\n");
            prompt.append("It provides cardinality estimates with confidence bounds and quality metrics.\n\n");
        } else if (algorithm.toLowerCase().contains("parallel_mcs")) {
            prompt.append("This used a multi-threaded Maximum Common Subgraph algorithm.\n");
            prompt.append("It analyzes graph patterns using parallel processing for accuracy and speed.\n\n");
        } else if (algorithm.toLowerCase().contains("query_modification")) {
            prompt.append("This used an A* search algorithm for optimal query modifications.\n");
            prompt.append("It finds minimal-cost changes to achieve your target result count.\n\n");
        }
        
        prompt.append("## Your Task:\n");
        prompt.append("1. Translate the technical algorithm results into practical insights\n");
        prompt.append("2. Explain what the advanced analysis revealed about the query behavior\n");
        prompt.append("3. Highlight the key findings that basic analysis might have missed\n");
        prompt.append("4. If optimization suggestions were generated, prioritize them by impact\n");
        prompt.append("5. Explain the confidence/quality of the results in simple terms\n");
        prompt.append("6. Keep explanation under 250 words but be thorough\n\n");
        
        prompt.append("Focus on actionable insights that justify using the advanced algorithm.");
        
        return prompt.toString();
    }
    
    /**
     * Build a domain-specific prompt based on query patterns
     */
    public String buildDomainSpecificContext(String query) {
        String lowerQuery = query.toLowerCase();
        
        // Movie/Entertainment domain
        if (lowerQuery.contains("acted_in") || lowerQuery.contains("movie") || lowerQuery.contains("actor")) {
            return "\n**Domain Context:** This appears to be a movie/entertainment recommendation query. " +
                   "Common issues include incomplete cast data, missing movie metadata, or overly restrictive " +
                   "filtering criteria that eliminate valid recommendations.\n";
        }
        
        // Social network domain
        if (lowerQuery.contains("friend") || lowerQuery.contains("knows") || lowerQuery.contains("follows")) {
            return "\n**Domain Context:** This appears to be a social network analysis query. " +
                   "Common issues include sparse connection graphs, privacy constraints limiting visibility, " +
                   "or relationship asymmetry (follower vs. friend relationships).\n";
        }
        
        // E-commerce domain
        if (lowerQuery.contains("purchased") || lowerQuery.contains("product") || lowerQuery.contains("customer")) {
            return "\n**Domain Context:** This appears to be an e-commerce recommendation query. " +
                   "Common issues include seasonal purchasing patterns, incomplete transaction history, " +
                   "or product catalog inconsistencies affecting recommendations.\n";
        }
        
        // General graph query
        return "\n**Domain Context:** This appears to be a general graph traversal query. " +
               "Focus on graph connectivity, node/relationship availability, and constraint selectivity.\n";
    }
}
