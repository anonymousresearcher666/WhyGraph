package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Represents a comparison between two paths showing cost differences
 * across multiple metrics.
 */
public class PathComparison {
    
    private final PathInstance pathA;
    private final PathInstance pathB;
    private final Map<String, CostMetric> costMetrics;
    private String favoredPath; // "A", "B", or "NEUTRAL"
    private double overallDifference;
    
    public PathComparison(PathInstance pathA, PathInstance pathB) {
        this.pathA = pathA;
        this.pathB = pathB;
        this.costMetrics = new LinkedHashMap<>();
    }
    
    public PathInstance getPathA() {
        return pathA;
    }
    
    public PathInstance getPathB() {
        return pathB;
    }
    
    public Map<String, CostMetric> getCostMetrics() {
        return costMetrics;
    }
    
    public void addCostMetric(String name, double valueA, double valueB) {
        CostMetric metric = new CostMetric(name, valueA, valueB);
        costMetrics.put(name, metric);
        calculateOverallDifference();
    }
    
    public String getFavoredPath() {
        return favoredPath;
    }
    
    public double getOverallDifference() {
        return overallDifference;
    }
    
    /**
     * Calculate overall difference based on all metrics
     */
    private void calculateOverallDifference() {
        double totalDifference = 0.0;
        int metricCount = 0;
        
        for (CostMetric metric : costMetrics.values()) {
            if (!metric.isNeutral()) {
                totalDifference += metric.getNormalizedDifference();
                metricCount++;
            }
        }
        
        if (metricCount > 0) {
            overallDifference = totalDifference / metricCount;
        } else {
            overallDifference = 0.0;
        }
        
        // Determine favored path
        if (Math.abs(overallDifference) < 0.1) {
            favoredPath = "NEUTRAL";
        } else if (overallDifference > 0) {
            favoredPath = "A";
        } else {
            favoredPath = "B";
        }
    }
    
    /**
     * Get metrics where path A is better
     */
    public List<CostMetric> getMetricsFavoringA() {
        return getMetricsFavoring("A");
    }
    
    /**
     * Get metrics where path B is better
     */
    public List<CostMetric> getMetricsFavoringB() {
        return getMetricsFavoring("B");
    }
    
    /**
     * Get neutral metrics
     */
    public List<CostMetric> getNeutralMetrics() {
        return getMetricsFavoring("NEUTRAL");
    }
    
    /**
     * Get metrics favoring a specific path
     */
    private List<CostMetric> getMetricsFavoring(String path) {
        List<CostMetric> metrics = new ArrayList<>();
        for (CostMetric metric : costMetrics.values()) {
            if (path.equals(metric.getFavoredPath())) {
                metrics.add(metric);
            }
        }
        return metrics;
    }
    
    /**
     * Get the most significant difference
     */
    public CostMetric getMostSignificantDifference() {
        return costMetrics.values().stream()
            .max(Comparator.comparing(m -> Math.abs(m.getNormalizedDifference())))
            .orElse(null);
    }
    
    /**
     * Get metrics sorted by significance
     */
    public List<CostMetric> getMetricsBySignificance() {
        List<CostMetric> sorted = new ArrayList<>(costMetrics.values());
        sorted.sort((a, b) -> Double.compare(
            Math.abs(b.getNormalizedDifference()), 
            Math.abs(a.getNormalizedDifference())
        ));
        return sorted;
    }
    
    /**
     * Check if the difference is significant
     */
    public boolean hasSignificantDifference() {
        return Math.abs(overallDifference) > 0.2;
    }
    
    /**
     * Get a summary of the comparison
     */
    public ComparisonSummary getSummary() {
        ComparisonSummary summary = new ComparisonSummary();
        summary.favoredPath = favoredPath;
        summary.overallDifference = overallDifference;
        summary.significantDifference = hasSignificantDifference();
        summary.metricsForA = getMetricsFavoringA().size();
        summary.metricsForB = getMetricsFavoringB().size();
        summary.neutralMetrics = getNeutralMetrics().size();
        summary.mostSignificantMetric = getMostSignificantDifference();
        
        return summary;
    }
    
    @Override
    public String toString() {
        return "PathComparison{" +
               "favoredPath='" + favoredPath + '\'' +
               ", overallDifference=" + String.format("%.3f", overallDifference) +
               ", metricCount=" + costMetrics.size() +
               ", significant=" + hasSignificantDifference() +
               '}';
    }
    
    /**
     * Individual cost metric comparison
     */
    public static class CostMetric {
        private final String name;
        private final double valueA;
        private final double valueB;
        private final double difference;
        private final double normalizedDifference;
        private final String favoredPath;
        
        public CostMetric(String name, double valueA, double valueB) {
            this.name = name;
            this.valueA = valueA;
            this.valueB = valueB;
            this.difference = valueA - valueB;
            
            // Normalize difference (between -1 and 1)
            double maxValue = Math.max(Math.abs(valueA), Math.abs(valueB));
            if (maxValue > 0) {
                this.normalizedDifference = difference / maxValue;
            } else {
                this.normalizedDifference = 0.0;
            }
            
            // Determine favored path (lower is usually better for costs)
            if (Math.abs(normalizedDifference) < 0.05) {
                this.favoredPath = "NEUTRAL";
            } else if (valueA < valueB) {
                this.favoredPath = "A";
            } else {
                this.favoredPath = "B";
            }
        }
        
        public String getName() {
            return name;
        }
        
        public double getValueA() {
            return valueA;
        }
        
        public double getValueB() {
            return valueB;
        }
        
        public double getDifference() {
            return difference;
        }
        
        public double getNormalizedDifference() {
            return normalizedDifference;
        }
        
        public String getFavoredPath() {
            return favoredPath;
        }
        
        public boolean isNeutral() {
            return "NEUTRAL".equals(favoredPath);
        }
        
        public boolean isSignificant() {
            return Math.abs(normalizedDifference) > 0.1;
        }
        
        @Override
        public String toString() {
            return String.format("%s: A=%.2f, B=%.2f, favors %s", 
                               name, valueA, valueB, favoredPath);
        }
    }
    
    /**
     * Summary of path comparison
     */
    public static class ComparisonSummary {
        public String favoredPath;
        public double overallDifference;
        public boolean significantDifference;
        public int metricsForA;
        public int metricsForB;
        public int neutralMetrics;
        public CostMetric mostSignificantMetric;
        
        @Override
        public String toString() {
            return String.format("Path %s favored by %.2f (A:%d, B:%d, Neutral:%d metrics)",
                               favoredPath, Math.abs(overallDifference), 
                               metricsForA, metricsForB, neutralMetrics);
        }
    }
}