package com.whyquery.neo4j.paths;

import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.util.*;

/**
 * Analyzes and compares path costs using different metrics to explain
 * why certain paths were chosen over others.
 */
public class PathCostAnalyzer {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    private final Neo4jStatistics statistics;
    
    public PathCostAnalyzer(GraphDatabaseService db, Transaction tx, Neo4jStatistics statistics) {
        this.db = db;
        this.tx = tx;
        this.statistics = statistics;
    }
    
    /**
     * Compare costs of different paths between the same start and end nodes
     */
    public PathComparison comparePaths(PathInstance pathA, PathInstance pathB, 
                                     PathAnalysis analysis) {
        PathComparison comparison = new PathComparison(pathA, pathB);
        
        // Calculate different cost metrics
        comparison.addCostMetric("Hop Count", (double) pathA.getLength(), (double) pathB.getLength());
        comparison.addCostMetric("Total Cost", pathA.getCost(), pathB.getCost());
        comparison.addCostMetric("Average Cost per Hop", pathA.getAverageCostPerHop(), pathB.getAverageCostPerHop());
        
        // Calculate relationship type diversity cost
        double diversityA = calculateRelationshipDiversity(pathA);
        double diversityB = calculateRelationshipDiversity(pathB);
        comparison.addCostMetric("Relationship Diversity", diversityA, diversityB);
        
        // Calculate path efficiency
        double efficiencyA = calculatePathEfficiency(pathA, analysis);
        double efficiencyB = calculatePathEfficiency(pathB, analysis);
        comparison.addCostMetric("Path Efficiency", efficiencyA, efficiencyB);
        
        // Calculate centrality-based cost (if nodes are important)
        double centralityA = calculateCentralityCost(pathA);
        double centralityB = calculateCentralityCost(pathB);
        comparison.addCostMetric("Centrality Cost", centralityA, centralityB);
        
        return comparison;
    }
    
    /**
     * Analyze why a specific path was chosen by the algorithm
     */
    public PathSelectionReason analyzePathSelection(PathInstance chosenPath, 
                                                   List<PathInstance> alternativePaths,
                                                   PathAnalysis analysis) {
        PathSelectionReason reason = new PathSelectionReason();
        reason.setChosenPath(chosenPath);
        reason.setAlternativePaths(alternativePaths);
        
        // Determine the primary selection criterion based on algorithm type
        switch (analysis.getAlgorithmType()) {
            case SHORTEST_PATH:
                reason.setPrimaryCriterion("Minimum hop count");
                reason.setSecondaryFactors(Arrays.asList("Relationship availability", "Path existence"));
                break;
            case WEIGHTED_SHORTEST_PATH:
                reason.setPrimaryCriterion("Minimum total weight");
                reason.setSecondaryFactors(Arrays.asList("Weight property values", "Path feasibility"));
                break;
            case VARIABLE_LENGTH:
                reason.setPrimaryCriterion("Length constraints satisfied");
                reason.setSecondaryFactors(Arrays.asList("Relationship type filters", "Pattern matching"));
                break;
            default:
                reason.setPrimaryCriterion("First path found");
                reason.setSecondaryFactors(Arrays.asList("Traversal order", "Index usage"));
                break;
        }
        
        // Compare chosen path with alternatives
        for (PathInstance alternative : alternativePaths) {
            PathComparison comparison = comparePaths(chosenPath, alternative, analysis);
            reason.addComparison(comparison);
        }
        
        // Identify the decisive factors
        reason.setDecisiveFactors(identifyDecisiveFactors(chosenPath, alternativePaths, analysis));
        
        return reason;
    }
    
    /**
     * Calculate relationship type diversity (lower is more consistent)
     */
    private double calculateRelationshipDiversity(PathInstance path) {
        Set<String> uniqueTypes = path.getUniqueRelationshipTypes();
        if (path.getLength() == 0) return 0.0;
        
        // Shannon diversity index
        Map<String, Integer> typeCounts = new HashMap<>();
        for (String type : path.getRelationshipTypes()) {
            typeCounts.put(type, typeCounts.getOrDefault(type, 0) + 1);
        }
        
        double diversity = 0.0;
        int totalRels = path.getRelationshipTypes().size();
        
        for (int count : typeCounts.values()) {
            double proportion = (double) count / totalRels;
            if (proportion > 0) {
                diversity -= proportion * Math.log(proportion) / Math.log(2);
            }
        }
        
        return diversity;
    }
    
    /**
     * Calculate path efficiency based on various factors
     */
    private double calculatePathEfficiency(PathInstance path, PathAnalysis analysis) {
        double efficiency = 1.0;
        
        // Length efficiency (shorter is better for most cases)
        if (path.getLength() > 0) {
            efficiency /= Math.log(path.getLength() + 1);
        }
        
        // Cost efficiency (lower cost per hop is better)
        if (path.getCost() > 0) {
            efficiency /= path.getAverageCostPerHop();
        }
        
        // Relationship type efficiency (fewer types often better)
        Set<String> uniqueTypes = path.getUniqueRelationshipTypes();
        if (!uniqueTypes.isEmpty()) {
            efficiency /= Math.sqrt(uniqueTypes.size());
        }
        
        // Cycle penalty (cycles usually reduce efficiency)
        if (path.hasCycles()) {
            efficiency *= 0.8;
        }
        
        return efficiency;
    }
    
    /**
     * Calculate centrality-based cost (paths through important nodes)
     */
    private double calculateCentralityCost(PathInstance path) {
        double centralityCost = 0.0;
        
        // This would ideally use actual centrality measures from the database
        // For now, we'll use a simplified approach based on node degree
        for (String nodeId : path.getNodeIds()) {
            try {
                // Query to get node degree (simplified)
                String degreeQuery = "MATCH (n) WHERE id(n) = " + nodeId + 
                                   " RETURN size((n)-[]-()) as degree";
                
                try (Result result = tx.execute(degreeQuery)) {
                    if (result.hasNext()) {
                        Map<String, Object> row = result.next();
                        Object degree = row.get("degree");
                        if (degree instanceof Number) {
                            // Higher degree nodes have higher centrality cost
                            centralityCost += Math.log(((Number) degree).doubleValue() + 1);
                        }
                    }
                }
            } catch (Exception e) {
                // If query fails, assign neutral cost
                centralityCost += 1.0;
            }
        }
        
        return centralityCost;
    }
    
    /**
     * Identify the decisive factors in path selection
     */
    private List<String> identifyDecisiveFactors(PathInstance chosenPath, 
                                               List<PathInstance> alternatives,
                                               PathAnalysis analysis) {
        List<String> factors = new ArrayList<>();
        
        if (alternatives.isEmpty()) {
            factors.add("Only path available");
            return factors;
        }
        
        // Check if chosen path is shortest
        boolean isShortest = alternatives.stream()
            .allMatch(alt -> chosenPath.getLength() <= alt.getLength());
        if (isShortest && chosenPath.getLength() < alternatives.get(0).getLength()) {
            factors.add("Shortest path by hop count");
        }
        
        // Check if chosen path has lowest cost
        boolean isLowestCost = alternatives.stream()
            .allMatch(alt -> chosenPath.getCost() <= alt.getCost());
        if (isLowestCost && chosenPath.getCost() < alternatives.get(0).getCost()) {
            factors.add("Lowest total cost");
        }
        
        // Check for constraint satisfaction
        PathConstraints constraints = analysis.getConstraints();
        if (constraints != null) {
            if (constraints.hasLengthConstraints()) {
                boolean satisfiesLength = chosenPath.getLength() >= constraints.getMinLength() &&
                                        chosenPath.getLength() <= constraints.getMaxLength();
                boolean alternativeViolatesLength = alternatives.stream()
                    .anyMatch(alt -> alt.getLength() < constraints.getMinLength() || 
                                   alt.getLength() > constraints.getMaxLength());
                
                if (satisfiesLength && alternativeViolatesLength) {
                    factors.add("Satisfies length constraints");
                }
            }
            
            if (constraints.hasRelationshipTypeConstraints()) {
                boolean satisfiesTypes = chosenPath.getRelationshipTypes().stream()
                    .allMatch(type -> constraints.getAllowedRelationshipTypes().isEmpty() ||
                                    constraints.getAllowedRelationshipTypes().contains(type));
                
                if (satisfiesTypes) {
                    factors.add("Uses allowed relationship types");
                }
            }
        }
        
        // Check for efficiency
        double chosenEfficiency = calculatePathEfficiency(chosenPath, analysis);
        boolean isMostEfficient = alternatives.stream()
            .allMatch(alt -> chosenEfficiency >= calculatePathEfficiency(alt, analysis));
        if (isMostEfficient) {
            factors.add("Most efficient path");
        }
        
        // Check for relationship consistency
        double chosenDiversity = calculateRelationshipDiversity(chosenPath);
        boolean isLeastDiverse = alternatives.stream()
            .allMatch(alt -> chosenDiversity <= calculateRelationshipDiversity(alt));
        if (isLeastDiverse && chosenPath.getUniqueRelationshipTypes().size() == 1) {
            factors.add("Uses consistent relationship types");
        }
        
        if (factors.isEmpty()) {
            factors.add("First path found by traversal algorithm");
        }
        
        return factors;
    }
    
    /**
     * Generate alternative path strategies with cost analysis
     */
    public List<PathStrategy> generateAlternativeStrategies(PathAnalysis analysis) {
        List<PathStrategy> strategies = new ArrayList<>();
        
        // Strategy 1: Optimize for shortest path
        PathStrategy shortestStrategy = new PathStrategy();
        shortestStrategy.setName("Minimize Hop Count");
        shortestStrategy.setDescription("Find paths with the fewest relationships");
        shortestStrategy.setCostFunction("hop_count");
        shortestStrategy.setModifiedQuery(convertToShortestPath(analysis.getOriginalQuery()));
        shortestStrategy.setExpectedBenefit("Fastest traversal, minimal network distance");
        strategies.add(shortestStrategy);
        
        // Strategy 2: Optimize for weighted shortest path
        if (hasWeightableProperties(analysis)) {
            PathStrategy weightedStrategy = new PathStrategy();
            weightedStrategy.setName("Minimize Total Cost");
            weightedStrategy.setDescription("Find paths with lowest cumulative weight");
            weightedStrategy.setCostFunction("total_weight");
            weightedStrategy.setModifiedQuery(convertToWeightedPath(analysis.getOriginalQuery()));
            weightedStrategy.setExpectedBenefit("Optimal cost-efficiency, considers relationship weights");
            strategies.add(weightedStrategy);
        }
        
        // Strategy 3: Optimize for relationship type consistency
        PathStrategy consistentStrategy = new PathStrategy();
        consistentStrategy.setName("Consistent Relationship Types");
        consistentStrategy.setDescription("Prefer paths using fewer relationship types");
        consistentStrategy.setCostFunction("type_diversity");
        consistentStrategy.setModifiedQuery(addRelationshipTypeConstraints(analysis.getOriginalQuery()));
        consistentStrategy.setExpectedBenefit("More predictable paths, easier to understand");
        strategies.add(consistentStrategy);
        
        // Strategy 4: Avoid high-degree nodes (if applicable)
        PathStrategy avoidHubsStrategy = new PathStrategy();
        avoidHubsStrategy.setName("Avoid Hub Nodes");
        avoidHubsStrategy.setDescription("Find paths that avoid highly connected nodes");
        avoidHubsStrategy.setCostFunction("centrality_penalty");
        avoidHubsStrategy.setModifiedQuery(addCentralityConstraints(analysis.getOriginalQuery()));
        avoidHubsStrategy.setExpectedBenefit("More diverse paths, reduced bottlenecks");
        strategies.add(avoidHubsStrategy);
        
        return strategies;
    }
    
    /**
     * Check if query can use weighted paths
     */
    private boolean hasWeightableProperties(PathAnalysis analysis) {
        // Check if relationships might have weight properties
        return analysis.getOriginalQuery().toLowerCase().contains("cost") ||
               analysis.getOriginalQuery().toLowerCase().contains("weight") ||
               analysis.getOriginalQuery().toLowerCase().contains("distance") ||
               analysis.getOriginalQuery().toLowerCase().contains("length");
    }
    
    /**
     * Convert query to use shortest path
     */
    private String convertToShortestPath(String originalQuery) {
        // Simple conversion - wrap path pattern in shortestPath()
        if (originalQuery.toLowerCase().contains("shortestpath")) {
            return originalQuery; // Already using shortest path
        }
        
        // Find path pattern and wrap it
        String pattern = "\\(\\w*\\)-\\[[^\\]]*\\]-\\(\\w*\\)";
        if (originalQuery.matches(".*" + pattern + ".*")) {
            return originalQuery.replaceFirst(pattern, "shortestPath($0)");
        }
        
        return originalQuery + " /* Consider using shortestPath() */";
    }
    
    /**
     * Convert query to use weighted shortest path
     */
    private String convertToWeightedPath(String originalQuery) {
        // Add weight consideration to shortest path
        if (originalQuery.toLowerCase().contains("shortestpath")) {
            return originalQuery + " /* Consider adding {weight: r.cost} to relationships */";
        }
        
        return convertToShortestPath(originalQuery) + " /* Add weight property */";
    }
    
    /**
     * Add relationship type constraints
     */
    private String addRelationshipTypeConstraints(String originalQuery) {
        // Suggest constraining relationship types
        return originalQuery + " /* Consider constraining relationship types like [:SPECIFIC_TYPE] */";
    }
    
    /**
     * Add centrality constraints
     */
    private String addCentralityConstraints(String originalQuery) {
        // Suggest avoiding high-degree nodes
        return originalQuery + " /* Consider adding WHERE size((n)-[]-()) < 100 to avoid hubs */";
    }
}