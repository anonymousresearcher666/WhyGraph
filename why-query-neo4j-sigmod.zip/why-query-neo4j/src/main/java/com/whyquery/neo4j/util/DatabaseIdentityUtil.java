package com.whyquery.neo4j.util;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.util.Map;

/**
 * Resolves a stable, filesystem-safe identifier for the currently bound Neo4j database.
 */
public final class DatabaseIdentityUtil {

    private DatabaseIdentityUtil() {
    }

    public static String resolveDatabaseKey(GraphDatabaseService db) {
        String override = System.getProperty("why.database.key");
        if (override == null || override.isBlank()) {
            override = System.getenv("WHY_DATABASE_KEY");
        }
        if (override != null && !override.isBlank()) {
            return sanitize(override);
        }

        String discovered = null;
        if (db != null) {
            discovered = resolveFromDbInfo(db);
            if (discovered == null || discovered.isBlank()) {
                discovered = resolveFromToString(db);
            }
        }
        if (discovered == null || discovered.isBlank()) {
            discovered = "neo4j";
        }
        return sanitize(discovered);
    }

    private static String resolveFromDbInfo(GraphDatabaseService db) {
        try (Transaction tx = db.beginTx();
             Result res = tx.execute("CALL db.info() YIELD name RETURN name")) {
            if (res.hasNext()) {
                Map<String, Object> row = res.next();
                Object value = row.get("name");
                tx.commit();
                return value == null ? null : value.toString();
            }
            tx.commit();
        } catch (Exception ignored) {
            // Fallback to other strategies below.
        }
        return null;
    }

    private static String resolveFromToString(GraphDatabaseService db) {
        try {
            String raw = String.valueOf(db);
            if (raw == null || raw.isBlank()) {
                return null;
            }
            int idx = raw.lastIndexOf('/');
            if (idx >= 0 && idx + 1 < raw.length()) {
                return raw.substring(idx + 1);
            }
            return raw;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String sanitize(String raw) {
        String cleaned = raw == null ? "" : raw.trim();
        if (cleaned.isEmpty()) {
            return "neo4j";
        }
        return cleaned.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}

