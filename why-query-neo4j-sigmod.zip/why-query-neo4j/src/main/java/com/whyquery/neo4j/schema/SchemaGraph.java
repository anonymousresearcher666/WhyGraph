package com.whyquery.neo4j.schema;

import java.util.*;

/**
 * Schema graph derived from database metadata. Tracks allowed triples
 * (srcLabel, relationshipType, dstLabel) together with basic statistics
 * that are used for pruning, bounds, and heuristics.
 */
public class SchemaGraph {

    public static final class SchemaTriple {
        private final String sourceLabel;
        private final String relationshipType;
        private final String targetLabel;

        public SchemaTriple(String sourceLabel, String relationshipType, String targetLabel) {
            this.sourceLabel = sourceLabel;
            this.relationshipType = relationshipType;
            this.targetLabel = targetLabel;
        }

        public String getSourceLabel() {
            return sourceLabel;
        }

        public String getRelationshipType() {
            return relationshipType;
        }

        public String getTargetLabel() {
            return targetLabel;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof SchemaTriple)) return false;
            SchemaTriple that = (SchemaTriple) o;
            return Objects.equals(sourceLabel, that.sourceLabel) &&
                   Objects.equals(relationshipType, that.relationshipType) &&
                   Objects.equals(targetLabel, that.targetLabel);
        }

        @Override
        public int hashCode() {
            return Objects.hash(sourceLabel, relationshipType, targetLabel);
        }

        @Override
        public String toString() {
            return "(" + sourceLabel + ")-[:" + relationshipType + "]->(" + targetLabel + ")";
        }
    }

    public static final class TripleStats {
        private final long edgeCount;
        private final double avgOutDegree;
        private final double avgInDegree;
        private final double maxOutDegree;
        private final double maxInDegree;
        private final double minOutDegree;
        private final double minInDegree;

        public TripleStats(long edgeCount, double avgOutDegree, double avgInDegree) {
            this(edgeCount, avgOutDegree, avgInDegree, -1.0, -1.0);
        }

        public TripleStats(long edgeCount, double avgOutDegree, double avgInDegree,
                           double maxOutDegree, double maxInDegree) {
            this(edgeCount, avgOutDegree, avgInDegree, maxOutDegree, maxInDegree, -1.0, -1.0);
        }

        public TripleStats(long edgeCount, double avgOutDegree, double avgInDegree,
                           double maxOutDegree, double maxInDegree,
                           double minOutDegree, double minInDegree) {
            this.edgeCount = edgeCount;
            this.avgOutDegree = avgOutDegree;
            this.avgInDegree = avgInDegree;
            this.maxOutDegree = maxOutDegree;
            this.maxInDegree = maxInDegree;
            this.minOutDegree = minOutDegree;
            this.minInDegree = minInDegree;
        }

        public long getEdgeCount() {
            return edgeCount;
        }

        public double getAvgOutDegree() {
            return avgOutDegree;
        }

        public double getAvgInDegree() {
            return avgInDegree;
        }

        public double getMaxOutDegree() {
            return maxOutDegree;
        }

        public double getMaxInDegree() {
            return maxInDegree;
        }

        /** Minimum observed out-degree via this triple, or -1.0 if not collected (Proposition 2's L(e), predicate-free lower bound). */
        public double getMinOutDegree() {
            return minOutDegree;
        }

        /** Minimum observed in-degree via this triple, or -1.0 if not collected. */
        public double getMinInDegree() {
            return minInDegree;
        }
    }

    public static final class SchemaConsistencyResult {
        private final boolean consistent;
        private final List<SchemaPattern.EdgePattern> violations;

        private SchemaConsistencyResult(boolean consistent, List<SchemaPattern.EdgePattern> violations) {
            this.consistent = consistent;
            this.violations = violations;
        }

        public static SchemaConsistencyResult consistent() {
            return new SchemaConsistencyResult(true, List.of());
        }

        public static SchemaConsistencyResult inconsistent(List<SchemaPattern.EdgePattern> violations) {
            return new SchemaConsistencyResult(false, violations);
        }

        public boolean isConsistent() {
            return consistent;
        }

        public List<SchemaPattern.EdgePattern> getViolations() {
            return violations;
        }
    }

    public static final class SchemaBounds {
        private final long lowerBound;
        private final long upperBound;

        public SchemaBounds(long lowerBound, long upperBound) {
            this.lowerBound = Math.max(0, lowerBound);
            this.upperBound = Math.max(0, upperBound);
        }

        public long getLowerBound() {
            return lowerBound;
        }

        public long getUpperBound() {
            return upperBound;
        }
    }

    /**
     * Compatibility snapshot capturing schema-consistent triples per edge pattern.
     */
    public static final class SchemaCompatibility {
        private final Map<SchemaPattern.EdgePattern, List<SchemaTriple>> compatibleTriples;

        private SchemaCompatibility(Map<SchemaPattern.EdgePattern, List<SchemaTriple>> compatibleTriples) {
            this.compatibleTriples = compatibleTriples;
        }

        public boolean isConsistent() {
            return compatibleTriples.values().stream().noneMatch(List::isEmpty);
        }

        public Map<SchemaPattern.EdgePattern, List<SchemaTriple>> getCompatibleTriples() {
            return compatibleTriples;
        }

        public int getTotalCompatibleTriples() {
            return compatibleTriples.values().stream().mapToInt(List::size).sum();
        }

        public int getEdgeCount() {
            return compatibleTriples.size();
        }
    }

    private final Map<SchemaTriple, TripleStats> tripleStats;
    private final Map<String, Long> labelCounts;

    public SchemaGraph(Map<SchemaTriple, TripleStats> tripleStats, Map<String, Long> labelCounts) {
        this.tripleStats = tripleStats != null ? tripleStats : new HashMap<>();
        this.labelCounts = labelCounts != null ? labelCounts : new HashMap<>();
    }
    
    public int getTripleCount() {
        return tripleStats.size();
    }

    public long getLabelCount(String label) {
        if (label == null || label.isEmpty() || SchemaPattern.ANY_LABEL.equals(label)) {
            return labelCounts.values().stream().mapToLong(Long::longValue).sum();
        }
        return labelCounts.getOrDefault(label, 0L);
    }

    public long getTotalNodeCount() {
        return labelCounts.values().stream().mapToLong(Long::longValue).sum();
    }
    
    public TripleStats getTripleStats(String sourceLabel, String relationshipType, String targetLabel) {
        SchemaTriple triple = new SchemaTriple(sourceLabel, relationshipType, targetLabel);
        return tripleStats.get(triple);
    }
    
    public Map<SchemaTriple, TripleStats> getSchemaTriples() {
        return tripleStats;
    }

    public boolean isEdgeAllowed(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (tripleStats.isEmpty()) {
            return true; // No schema loaded – treat all edges as allowed
        }
        if (relType == null || relType.isEmpty()) {
            return true; // Cypher pattern without explicit rel type
        }
        for (String src : expandLabels(srcLabels)) {
            for (String dst : expandLabels(dstLabels)) {
                SchemaTriple triple = new SchemaTriple(src, relType, dst);
                if (tripleStats.containsKey(triple)) {
                    return true;
                }
            }
        }
        return false;
    }

    public SchemaConsistencyResult checkPattern(SchemaPattern pattern) {
        if (pattern == null || pattern.isEmpty()) {
            return SchemaConsistencyResult.consistent();
        }

        List<SchemaPattern.EdgePattern> violations = new ArrayList<>();
        for (SchemaPattern.EdgePattern edge : pattern.getEdges()) {
            if (!isEdgeAllowed(edge.getSourceLabels(), edge.getRelationshipType(), edge.getTargetLabels())) {
                violations.add(edge);
            }
        }

        if (violations.isEmpty()) {
            return SchemaConsistencyResult.consistent();
        }
        return SchemaConsistencyResult.inconsistent(violations);
    }

    public SchemaBounds estimateBounds(SchemaPattern pattern) {
        if (pattern == null || pattern.isEmpty()) {
            long total = labelCounts.values().stream().reduce(0L, Long::sum);
            return new SchemaBounds(total, total);
        }

        long upper = Long.MAX_VALUE;
        long lower = Long.MAX_VALUE;

        for (SchemaPattern.EdgePattern edge : pattern.getEdges()) {
            long edgeUpper = 0;
            long edgeLower = Long.MAX_VALUE;

            for (String src : expandLabels(edge.getSourceLabels())) {
                for (String dst : expandLabels(edge.getTargetLabels())) {
                    SchemaTriple triple = new SchemaTriple(src, edge.getRelationshipType(), dst);
                    TripleStats stats = tripleStats.get(triple);
                    if (stats != null) {
                        edgeUpper = Math.max(edgeUpper, stats.getEdgeCount());
                        edgeLower = Math.min(edgeLower, Math.max(1L, (long) Math.ceil(stats.getEdgeCount() * 0.1)));
                    }
                }
            }

            if (edgeUpper == 0) {
                return new SchemaBounds(0, 0);
            }

            upper = Math.min(upper, edgeUpper);
            lower = Math.min(lower, edgeLower);
        }

        if (upper == Long.MAX_VALUE) {
            upper = labelCounts.values().stream().reduce(0L, Long::sum);
        }
        if (lower == Long.MAX_VALUE) {
            lower = 1L;
        }

        return new SchemaBounds(lower, upper);
    }

    /**
     * Sound existence/count certificate for a predicate-free tree pattern
     * (paper Proposition 2: "Safe lower bound, predicate-free tree core").
     * This is the dual of {@link #estimateBounds}'s upper bound, with every
     * max replaced by a min and no heuristic slack -- unlike
     * {@code SchemaBounds}'s {@code lowerBound} field (an unsound 10%-of-edge-count
     * ranking heuristic), a positive return value here is a proof that
     * {@code |Q(G)| >= } the returned count, not an estimate.
     * <p>
     * Callers MUST verify before calling that the query places no predicate
     * or cardinality-changing clause on the pattern; this method does not
     * have access to that part of the AST. The method itself verifies the
     * structural hypotheses: a genuine tree, exact labels/types, and global
     * relationship-type uniqueness. Returns
     * 0 (a valid but uninformative bound, never an unsound positive one) if
     * the tree check fails, the root's label is missing or not singular, or
     * any tree edge lacks a collected minimum degree.
     *
     * @param pattern the query's structural pattern; must already be a tree
     * @param rootNodeId the {@code sourceId}/{@code targetId} to root the tree at
     * @param rootLabel the root variable's single required label
     */
    public long estimateSafeLowerBound(SchemaPattern pattern, int rootNodeId, String rootLabel) {
        if (pattern == null || pattern.isEmpty() || rootLabel == null || rootLabel.isEmpty()
            || SchemaPattern.ANY_LABEL.equals(rootLabel)) {
            return 0L;
        }
        List<SchemaPattern.EdgePattern> edges = pattern.getEdges();

        // Proposition 2 is defined only for one fixed label per node and one
        // fixed relationship type per edge.  Expanding ANY or conjunctive
        // labels into several schema triples is unsafe: minima for separate
        // populations do not imply a minimum for their intersection.
        Set<Integer> nodeIds = new HashSet<>();
        Set<String> seenPairs = new HashSet<>();
        Map<Integer, String> exactLabels = new HashMap<>();
        for (SchemaPattern.EdgePattern edge : edges) {
            String relationshipType = edge.getRelationshipType();
            if (relationshipType == null || relationshipType.isBlank()
                || SchemaPattern.ANY_LABEL.equals(relationshipType)
                || relationshipType.indexOf('|') >= 0 || relationshipType.indexOf('*') >= 0) {
                return 0L;
            }
            if (!hasExactlyOneFixedLabel(edge.getSourceLabels())
                || !hasExactlyOneFixedLabel(edge.getTargetLabels())) {
                return 0L;
            }
            String sourceLabel = edge.getSourceLabels().iterator().next();
            String targetLabel = edge.getTargetLabels().iterator().next();
            if (!recordExactLabel(exactLabels, edge.getSourceId(), sourceLabel)
                || !recordExactLabel(exactLabels, edge.getTargetId(), targetLabel)) {
                return 0L;
            }
            nodeIds.add(edge.getSourceId());
            nodeIds.add(edge.getTargetId());
            int low = Math.min(edge.getSourceId(), edge.getTargetId());
            int high = Math.max(edge.getSourceId(), edge.getTargetId());
            String pairKey = low + "--" + high;
            if (!seenPairs.add(pairKey)) {
                return 0L;
            }
        }
        if (nodeIds.size() != edges.size() + 1) {
            return 0L;
        }
        if (!nodeIds.contains(rootNodeId)) {
            return 0L;
        }
        if (!rootLabel.equals(exactLabels.get(rootNodeId))) {
            return 0L;
        }
        Map<Integer, List<SchemaPattern.EdgePattern>> adjacency = new HashMap<>();
        for (SchemaPattern.EdgePattern edge : edges) {
            adjacency.computeIfAbsent(edge.getSourceId(), k -> new ArrayList<>()).add(edge);
            adjacency.computeIfAbsent(edge.getTargetId(), k -> new ArrayList<>()).add(edge);
        }
        // Relationship-uniqueness check: under Cypher's default DIFFERENT
        // RELATIONSHIPS semantics, no single relationship instance may bind
        // to two different pattern atoms. A relationship instance has
        // exactly one type, so two tree edges can only ever be forced onto
        // the same instance if they share a relationship type -- REGARDLESS
        // of whether they are adjacent in the query graph. Node-local
        // adjacency is not enough to rule this out: nothing prevents two
        // *different* query variables reached via *different* types from
        // both resolving to the same graph node (Cypher restricts repeated
        // relationships, not repeated nodes), after which their own
        // same-typed children compete for that node's relationships too.
        // E.g. (r)-[:T1]->(a),(r)-[:T3]->(c),(a)-[:T2]->(b),(c)-[:T2]->(d):
        // no node has two same-typed edges, yet if r's only T1- and
        // T3-neighbor is the same node m, a and c both bind to m, and if m
        // has one outgoing T2 edge, b and d collide on it -- 0 real rows,
        // confirmed live, though nothing here is node-adjacent. The only
        // check sufficient against every node-binding, not just the
        // node-local one, is global: no relationship type may appear on
        // more than one edge anywhere in the tree.
        Set<String> typesInTree = new HashSet<>();
        for (SchemaPattern.EdgePattern edge : edges) {
            if (!typesInTree.add(edge.getRelationshipType())) {
                return 0L;
            }
        }
        // Rooted BFS: at each step, record which side of the edge is the
        // already-bound (parent) node, since the needed degree direction
        // depends on it -- if the parent is the edge's declared source we
        // need its min OUT-degree, if the parent is the edge's declared
        // target we need its min IN-degree. This is not symmetric and
        // hardcoding one direction (as an earlier draft of this method did)
        // silently mis-scores half of all realistic trees.
        Set<Integer> visited = new HashSet<>();
        Deque<Integer> frontier = new ArrayDeque<>();
        frontier.push(rootNodeId);
        visited.add(rootNodeId);
        long product = -1L; // set once the root count is known, below

        long rootCount = labelCounts.getOrDefault(rootLabel, 0L);
        if (rootCount <= 0) {
            return 0L;
        }
        product = rootCount;

        while (!frontier.isEmpty()) {
            int current = frontier.pop();
            for (SchemaPattern.EdgePattern edge : adjacency.getOrDefault(current, List.of())) {
                int other = edge.getSourceId() == current ? edge.getTargetId() : edge.getSourceId();
                if (!visited.add(other)) {
                    continue;
                }
                frontier.push(other);

                boolean parentIsSource = edge.getSourceId() == current;
                String sourceLabel = edge.getSourceLabels().iterator().next();
                String targetLabel = edge.getTargetLabels().iterator().next();
                TripleStats stats = tripleStats.get(
                    new SchemaTriple(sourceLabel, edge.getRelationshipType(), targetLabel));
                if (stats == null) {
                    return 0L;
                }
                double exactMin = parentIsSource
                    ? stats.getMinOutDegree()
                    : stats.getMinInDegree();
                if (exactMin <= 0 || exactMin != Math.rint(exactMin)) {
                    return 0L; // no collected minimum, or a genuine minimum of 0: no positive certificate
                }
                long minimumDegree = (long) exactMin;
                // Overflow guard: real graphs never make this product
                // legitimately exceed Long.MAX_VALUE, so clamp rather than wrap.
                if (product > Long.MAX_VALUE / minimumDegree) {
                    return Long.MAX_VALUE;
                }
                product = product * minimumDegree;
            }
        }
        if (!visited.containsAll(nodeIds)) {
            return 0L; // disconnected: not a single tree
        }
        return product;
    }

    private static boolean hasExactlyOneFixedLabel(Set<String> labels) {
        if (labels == null || labels.size() != 1) {
            return false;
        }
        String label = labels.iterator().next();
        return label != null && !label.isBlank() && !SchemaPattern.ANY_LABEL.equals(label);
    }

    private static boolean recordExactLabel(Map<Integer, String> labels, int nodeId, String label) {
        String previous = labels.putIfAbsent(nodeId, label);
        return previous == null || previous.equals(label);
    }

    /**
     * Compute schema-compatible triples T_S(e) for every edge pattern and return
     * a compatibility snapshot.
     */
    public SchemaCompatibility analyzeCompatibility(SchemaPattern pattern) {
        Map<SchemaPattern.EdgePattern, List<SchemaTriple>> compatibility = new LinkedHashMap<>();
        if (pattern == null || pattern.isEmpty()) {
            return new SchemaCompatibility(compatibility);
        }

        for (SchemaPattern.EdgePattern edge : pattern.getEdges()) {
            List<SchemaTriple> triples = findCompatibleTriples(edge.getSourceLabels(), edge.getRelationshipType(), edge.getTargetLabels());
            compatibility.put(edge, triples);
        }
        return new SchemaCompatibility(compatibility);
    }

    /**
     * Measure how much the set of compatible triples changes between two states.
     */
    public double deltaCompatibleTriples(SchemaCompatibility before, SchemaCompatibility after) {
        if (tripleStats.isEmpty()) {
            return 0.0; // No schema information -> no penalty
        }
        if (after == null || !after.isConsistent()) {
            return Double.POSITIVE_INFINITY;
        }
        if (before == null) {
            return after.getTotalCompatibleTriples();
        }
        return Math.abs(after.getTotalCompatibleTriples() - before.getTotalCompatibleTriples());
    }

    private List<SchemaTriple> findCompatibleTriples(Set<String> srcLabels, String relType, Set<String> dstLabels) {
        if (tripleStats.isEmpty()) {
            return List.of(new SchemaTriple(
                SchemaPattern.ANY_LABEL,
                relType != null ? relType : SchemaPattern.ANY_LABEL,
                SchemaPattern.ANY_LABEL
            ));
        }

        List<SchemaTriple> compatible = new ArrayList<>();
        for (SchemaTriple triple : tripleStats.keySet()) {
            if (relType != null && !relType.isEmpty() && !relType.equals(triple.getRelationshipType())) {
                continue;
            }
            if (!matchesLabels(srcLabels, triple.getSourceLabel())) {
                continue;
            }
            if (!matchesLabels(dstLabels, triple.getTargetLabel())) {
                continue;
            }
            compatible.add(triple);
        }
        return compatible;
    }

    private boolean matchesLabels(Set<String> patternLabels, String schemaLabel) {
        if (patternLabels == null || patternLabels.isEmpty()) {
            return true;
        }
        if (patternLabels.contains(SchemaPattern.ANY_LABEL)) {
            return true;
        }
        return patternLabels.contains(schemaLabel);
    }

    private List<String> expandLabels(Set<String> labels) {
        if (labels == null || labels.isEmpty()) {
            return List.of(SchemaPattern.ANY_LABEL);
        }
        if (labels.contains(SchemaPattern.ANY_LABEL)) {
            if (labelCounts.isEmpty()) {
                return List.of(SchemaPattern.ANY_LABEL);
            }
            return new ArrayList<>(labelCounts.keySet());
        }
        return new ArrayList<>(labels);
    }
}
