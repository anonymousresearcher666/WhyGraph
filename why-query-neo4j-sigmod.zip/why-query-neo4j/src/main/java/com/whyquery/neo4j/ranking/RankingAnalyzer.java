package com.whyquery.neo4j.ranking;

import com.whyquery.neo4j.ast.*;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.util.*;

/**
 * Analyzes ranking in Cypher queries to explain why certain results appear in unexpected order.
 * Handles both explicit ORDER BY clauses and implicit ranking patterns.
 */
public class RankingAnalyzer {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    private final Neo4jStatistics statistics;
    
    public RankingAnalyzer(GraphDatabaseService db, Transaction tx, Neo4jStatistics statistics) {
        this.db = db;
        this.tx = tx;
        this.statistics = statistics;
    }
    
    /**
     * Analyzes the ranking logic in a Cypher query
     */
    public RankingAnalysis analyzeRanking(CypherAST ast, String originalQuery) {
        RankingAnalysis analysis = new RankingAnalysis();
        analysis.setOriginalQuery(originalQuery);
        
        // Extract ORDER BY clauses
        List<ASTNode> orderByNodes = ast.getNodesByType(NodeType.ORDER_BY);
        
        if (!orderByNodes.isEmpty()) {
            // Explicit ranking via ORDER BY
            analysis.setRankingType(RankingType.EXPLICIT_ORDER_BY);
            extractOrderByFactors(orderByNodes, analysis);
        } else {
            // Check for implicit ranking patterns
            analysis.setRankingType(detectImplicitRanking(ast));
            extractImplicitFactors(ast, analysis);
        }
        
        // Calculate current ranking factors from database
        calculateCurrentRankingFactors(analysis);
        
        // Temporarily disable generic ranking to fix syntax issues
        // TODO: Re-enable after fixing query generation
        // if (analysis.getRankingType() == RankingType.NO_RANKING || 
        //     analysis.getRankingFactors().isEmpty()) {
        //     generateGenericRankingStrategies(analysis, originalQuery);
        // }
        
        return analysis;
    }
    
    /**
     * Extract ranking factors from ORDER BY clauses
     */
    private void extractOrderByFactors(List<ASTNode> orderByNodes, RankingAnalysis analysis) {
        for (ASTNode orderByNode : orderByNodes) {
            String expression = orderByNode.getAttribute("expression", String.class);
            String direction = orderByNode.getAttribute("direction", String.class);
            
            if (expression != null) {
                RankingFactor factor = parseRankingExpression(expression, direction);
                if (factor != null) {
                    analysis.addRankingFactor(factor);
                }
            }
        }
    }
    
    /**
     * Parse a ranking expression to create a RankingFactor
     */
    private RankingFactor parseRankingExpression(String expression, String direction) {
        RankingFactor factor = new RankingFactor();
        factor.setExpression(expression);
        factor.setDirection(direction != null ? direction : "ASC");
        
        // Determine factor type and weight
        if (expression.contains(".")) {
            // Property-based ranking: variable.property
            String[] parts = expression.split("\\.");
            if (parts.length == 2) {
                factor.setType(RankingFactorType.PROPERTY);
                factor.setVariable(parts[0]);
                factor.setProperty(parts[1]);
                factor.setWeight(1.0); // Default weight
            }
        } else if (expression.startsWith("count(")) {
            // Count-based ranking
            factor.setType(RankingFactorType.COUNT);
            factor.setWeight(1.0);
        } else if (expression.startsWith("size(")) {
            // Size-based ranking (collection size)
            factor.setType(RankingFactorType.SIZE);
            factor.setWeight(1.0);
        } else {
            // Generic expression
            factor.setType(RankingFactorType.EXPRESSION);
            factor.setWeight(1.0);
        }
        
        return factor;
    }
    
    /**
     * Detect implicit ranking patterns in the query
     */
    private RankingType detectImplicitRanking(CypherAST ast) {
        // Check for LIMIT without ORDER BY (suggests default ordering)
        List<ASTNode> limitNodes = ast.getNodesByType(NodeType.LIMIT);
        if (!limitNodes.isEmpty()) {
            return RankingType.IMPLICIT_LIMIT;
        }
        
        // Check for aggregation functions that might imply ranking
        List<ASTNode> returnNodes = ast.getNodesByType(NodeType.RETURN);
        for (ASTNode returnNode : returnNodes) {
            for (ASTNode child : ast.getChildren(returnNode.getId())) {
                if (isAggregationFunction(child)) {
                    return RankingType.IMPLICIT_AGGREGATION;
                }
            }
        }
        
        // Check for degree-based patterns (high connectivity)
        if (hasHighConnectivityPattern(ast)) {
            return RankingType.IMPLICIT_DEGREE;
        }
        
        return RankingType.NO_RANKING;
    }
    
    /**
     * Extract implicit ranking factors
     */
    private void extractImplicitFactors(CypherAST ast, RankingAnalysis analysis) {
        switch (analysis.getRankingType()) {
            case IMPLICIT_DEGREE:
                addDegreeRankingFactors(ast, analysis);
                break;
            case IMPLICIT_AGGREGATION:
                addAggregationRankingFactors(ast, analysis);
                break;
            case IMPLICIT_LIMIT:
                addDefaultRankingFactors(ast, analysis);
                break;
            default:
                // No implicit ranking detected
                break;
        }
    }
    
    /**
     * Add degree-based ranking factors
     */
    private void addDegreeRankingFactors(CypherAST ast, RankingAnalysis analysis) {
        Set<String> variables = ast.getVariables();
        for (String variable : variables) {
            RankingFactor factor = new RankingFactor();
            factor.setType(RankingFactorType.DEGREE);
            factor.setVariable(variable);
            factor.setExpression("degree(" + variable + ")");
            factor.setDirection("DESC"); // High degree typically ranks higher
            factor.setWeight(1.0);
            analysis.addRankingFactor(factor);
        }
    }
    
    /**
     * Add aggregation-based ranking factors
     */
    private void addAggregationRankingFactors(CypherAST ast, RankingAnalysis analysis) {
        List<ASTNode> returnNodes = ast.getNodesByType(NodeType.RETURN);
        for (ASTNode returnNode : returnNodes) {
            for (ASTNode child : ast.getChildren(returnNode.getId())) {
                if (isAggregationFunction(child)) {
                    RankingFactor factor = new RankingFactor();
                    factor.setType(RankingFactorType.AGGREGATION);
                    factor.setExpression(getNodeExpression(child));
                    factor.setDirection("DESC"); // Higher aggregated values typically rank higher
                    factor.setWeight(1.0);
                    analysis.addRankingFactor(factor);
                }
            }
        }
    }
    
    /**
     * Add default ranking factors (when LIMIT is used without ORDER BY)
     */
    private void addDefaultRankingFactors(CypherAST ast, RankingAnalysis analysis) {
        // Neo4j's default ordering is typically by internal ID
        RankingFactor factor = new RankingFactor();
        factor.setType(RankingFactorType.INTERNAL_ID);
        factor.setExpression("id(node)");
        factor.setDirection("ASC");
        factor.setWeight(1.0);
        analysis.addRankingFactor(factor);
    }
    
    /**
     * Calculate current ranking factor values from the database
     */
    private void calculateCurrentRankingFactors(RankingAnalysis analysis) {
        for (RankingFactor factor : analysis.getRankingFactors()) {
            try {
                // Execute a query to get factor values for sample entities
                String sampleQuery = buildSampleQuery(analysis.getOriginalQuery(), factor);
                
                try (Result result = tx.execute(sampleQuery)) {
                    List<Map<String, Object>> factorValues = new ArrayList<>();
                    while (result.hasNext()) {
                        Map<String, Object> row = result.next();
                        factorValues.add(row);
                    }
                    factor.setSampleValues(factorValues);
                }
            } catch (Exception e) {
                // Log error but continue with other factors
                System.err.println("Error calculating factor values for: " + factor.getExpression() + " - " + e.getMessage());
            }
        }
    }
    
    /**
     * Build a sample query to get factor values
     */
    /**
     * Generate generic ranking strategies when no explicit ranking exists
     */
    private void generateGenericRankingStrategies(RankingAnalysis analysis, String originalQuery) {
        try {
            // Extract entity information from the query
            String entityLabel = extractEntityLabel(originalQuery);
            String entityProperty = extractEntityProperty(originalQuery);
            
            if (entityLabel != null && entityProperty != null) {
                GenericRankingEngine engine = new GenericRankingEngine(db, tx);
                RankingStrategy strategy = engine.generateRanking(entityLabel, entityProperty);
                
                // Convert strategy to ranking factors
                if (strategy.isApplicable()) {
                    analysis.setRankingType(RankingType.IMPLICIT_GENERIC);
                    
                    RankingFactor factor = new RankingFactor();
                    factor.setType(RankingFactorType.GENERIC);
                    factor.setExpression(strategy.getName());
                    factor.setDirection("DESC");
                    factor.setWeight(1.0);
                    
                    // Add sample values from strategy
                    strategy.getRankedEntities().stream()
                        .limit(5)
                        .forEach(entity -> {
                            Map<String, Object> sample = new HashMap<>();
                            sample.put("entity", entity.getEntity());
                            sample.put("factor_value", entity.getScore());
                            sample.put("rank", entity.getRank());
                            sample.put("reason", entity.getReason());
                            factor.addSampleValue(sample);
                        });
                    
                    analysis.addRankingFactor(factor);
                    analysis.setGenericStrategy(strategy);
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to generate generic ranking strategies: " + e.getMessage());
        }
    }
    
    private String extractEntityLabel(String query) {
        // Simple pattern matching for MATCH (n:Label)
        String[] patterns = {"MATCH \\(\\w+:(\\w+)\\)", "\\(\\w+:(\\w+)\\)"};
        for (String pattern : patterns) {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(query);
            if (m.find()) {
                return m.group(1);
            }
        }
        return null;
    }
    
    private String extractEntityProperty(String query) {
        // Look for common property patterns
        String[] patterns = {"RETURN \\w+\\.(\\w+)", "\\w+\\.(\\w+)"};
        for (String pattern : patterns) {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(query);
            if (m.find()) {
                String prop = m.group(1);
                if (prop.equals("title") || prop.equals("name") || prop.equals("id")) {
                    return prop;
                }
            }
        }
        return "title"; // Default fallback
    }

    private String buildSampleQuery(String originalQuery, RankingFactor factor) {
        // Extract the MATCH and WHERE parts of the original query
        String matchPart = extractMatchClause(originalQuery);
        String wherePart = extractWhereClause(originalQuery);
        
        StringBuilder query = new StringBuilder();
        query.append(matchPart);
        
        if (wherePart != null && !wherePart.trim().isEmpty()) {
            query.append(" ").append(wherePart);
        }
        
        // Add the ranking factor expression to RETURN
        query.append(" RETURN ");
        if (factor.getVariable() != null) {
            query.append(factor.getVariable()).append(", ");
        }
        query.append(factor.getExpression()).append(" as factor_value");
        query.append(" LIMIT 20"); // Sample size
        
        return query.toString();
    }
    
    /**
     * Extract MATCH clause from query
     */
    private String extractMatchClause(String query) {
        String[] parts = query.split("\\s+");
        StringBuilder match = new StringBuilder();
        boolean inMatch = false;
        
        for (String part : parts) {
            if (part.toUpperCase().equals("MATCH")) {
                inMatch = true;
                match.append(part).append(" ");
            } else if (inMatch && isClauseKeyword(part.toUpperCase())) {
                break;
            } else if (inMatch) {
                match.append(part).append(" ");
            }
        }
        
        return match.toString().trim();
    }
    
    /**
     * Extract WHERE clause from query
     */
    private String extractWhereClause(String query) {
        int whereIndex = query.toUpperCase().indexOf("WHERE");
        if (whereIndex == -1) return null;
        
        int nextClauseIndex = findNextClauseIndex(query, whereIndex + 5);
        if (nextClauseIndex == -1) {
            return query.substring(whereIndex);
        } else {
            return query.substring(whereIndex, nextClauseIndex);
        }
    }
    
    /**
     * Find the index of the next Cypher clause
     */
    private int findNextClauseIndex(String query, int startIndex) {
        String[] keywords = {"RETURN", "ORDER", "LIMIT", "WITH", "CREATE", "MERGE", "DELETE", "SET"};
        int minIndex = Integer.MAX_VALUE;
        
        for (String keyword : keywords) {
            int index = query.toUpperCase().indexOf(keyword, startIndex);
            if (index != -1 && index < minIndex) {
                minIndex = index;
            }
        }
        
        return minIndex == Integer.MAX_VALUE ? -1 : minIndex;
    }
    
    /**
     * Check if a word is a Cypher clause keyword
     */
    private boolean isClauseKeyword(String word) {
        return Arrays.asList("WHERE", "RETURN", "ORDER", "LIMIT", "WITH", "CREATE", "MERGE", "DELETE", "SET")
                .contains(word.toUpperCase());
    }
    
    /**
     * Check if a node represents an aggregation function
     */
    private boolean isAggregationFunction(ASTNode node) {
        return node.getType() == NodeType.COUNT ||
               node.getType() == NodeType.SUM ||
               node.getType() == NodeType.AVG ||
               node.getType() == NodeType.MIN ||
               node.getType() == NodeType.MAX ||
               node.getType() == NodeType.COLLECT;
    }
    
    /**
     * Check if the query has patterns suggesting high connectivity ranking
     */
    private boolean hasHighConnectivityPattern(CypherAST ast) {
        // Look for variable-length relationships or degree patterns
        List<ASTNode> relationshipNodes = ast.getNodesByType(NodeType.RELATIONSHIP);
        for (ASTNode rel : relationshipNodes) {
            String type = rel.getAttribute("type", String.class);
            if (type != null && type.contains("*")) {
                return true; // Variable-length relationship
            }
        }
        
        return false;
    }
    
    /**
     * Get string representation of AST node expression
     */
    private String getNodeExpression(ASTNode node) {
        switch (node.getType()) {
            case COUNT:
                return "count(*)";
            case SUM:
                return "sum(" + getChildExpression(node) + ")";
            case AVG:
                return "avg(" + getChildExpression(node) + ")";
            case MIN:
                return "min(" + getChildExpression(node) + ")";
            case MAX:
                return "max(" + getChildExpression(node) + ")";
            default:
                return node.toString();
        }
    }
    
    /**
     * Get expression of the first child node
     */
    private String getChildExpression(ASTNode node) {
        // This would need to be implemented based on the AST structure
        // For now, return a placeholder
        return "expression";
    }
}