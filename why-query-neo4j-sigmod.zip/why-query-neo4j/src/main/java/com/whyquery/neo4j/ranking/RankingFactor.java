package com.whyquery.neo4j.ranking;

import java.util.*;

/**
 * Represents a single ranking factor that contributes to the overall ranking of query results
 */
public class RankingFactor {
    
    private RankingFactorType type;
    private String variable;
    private String property;
    private String expression;
    private String direction; // ASC or DESC
    private double weight;
    private List<Map<String, Object>> sampleValues;
    private Map<String, Object> metadata;
    
    public RankingFactor() {
        this.sampleValues = new ArrayList<>();
        this.metadata = new HashMap<>();
        this.direction = "ASC";
        this.weight = 1.0;
    }
    
    public RankingFactor(RankingFactorType type, String expression, String direction, double weight) {
        this();
        this.type = type;
        this.expression = expression;
        this.direction = direction;
        this.weight = weight;
    }
    
    public RankingFactorType getType() {
        return type;
    }
    
    public void setType(RankingFactorType type) {
        this.type = type;
    }
    
    public String getVariable() {
        return variable;
    }
    
    public void setVariable(String variable) {
        this.variable = variable;
    }
    
    public String getProperty() {
        return property;
    }
    
    public void setProperty(String property) {
        this.property = property;
    }
    
    public String getExpression() {
        return expression;
    }
    
    public void setExpression(String expression) {
        this.expression = expression;
    }
    
    public String getDirection() {
        return direction;
    }
    
    public void setDirection(String direction) {
        this.direction = direction;
    }
    
    public double getWeight() {
        return weight;
    }
    
    public void setWeight(double weight) {
        this.weight = weight;
    }
    
    public List<Map<String, Object>> getSampleValues() {
        return sampleValues;
    }
    
    public void setSampleValues(List<Map<String, Object>> sampleValues) {
        this.sampleValues = sampleValues;
    }
    
    public void addSampleValue(Map<String, Object> value) {
        this.sampleValues.add(value);
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    /**
     * Calculate the contribution of this factor to the overall ranking score
     */
    public double calculateContribution(Object value) {
        if (value == null) return 0.0;
        
        double numericValue = convertToNumeric(value);
        double contribution = weight * numericValue;
        
        // Lower values should win for ASC, higher values should win for DESC.
        if ("ASC".equalsIgnoreCase(direction)) {
            contribution = -contribution;
        }
        
        return contribution;
    }
    
    /**
     * Convert a value to numeric for ranking calculations
     */
    private double convertToNumeric(Object value) {
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        } else if (value instanceof String) {
            try {
                return Double.parseDouble((String) value);
            } catch (NumberFormatException e) {
                // For string values, use hash code as numeric representation
                return ((String) value).hashCode();
            }
        } else if (value instanceof Boolean) {
            return ((Boolean) value) ? 1.0 : 0.0;
        } else {
            return value.hashCode();
        }
    }
    
    /**
     * Get the range of values for this factor
     */
    public ValueRange getValueRange() {
        if (sampleValues.isEmpty()) {
            return new ValueRange(0.0, 0.0);
        }
        
        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        
        for (Map<String, Object> sample : sampleValues) {
            Object value = sample.get("factor_value");
            if (value != null) {
                double numericValue = convertToNumeric(value);
                min = Math.min(min, numericValue);
                max = Math.max(max, numericValue);
            }
        }
        
        return new ValueRange(min, max);
    }
    
    /**
     * Check if this factor is likely causing unexpected ranking
     */
    public boolean isLikelyProblem() {
        ValueRange range = getValueRange();
        
        // Factor might be problematic if:
        // 1. Very small value range (low discrimination)
        // 2. Very large weight compared to others
        // 3. Unexpected direction for the factor type
        
        double rangeSize = range.getMax() - range.getMin();
        
        // Low discrimination
        if (rangeSize < 0.1 && type != RankingFactorType.INTERNAL_ID) {
            return true;
        }
        
        // Very high weight
        if (weight > 10.0) {
            return true;
        }
        
        return false;
    }
    
    @Override
    public String toString() {
        return "RankingFactor{" +
               "type=" + type +
               ", expression='" + expression + '\'' +
               ", direction='" + direction + '\'' +
               ", weight=" + weight +
               '}';
    }
    
    /**
     * Value range for a ranking factor
     */
    public static class ValueRange {
        private final double min;
        private final double max;
        
        public ValueRange(double min, double max) {
            this.min = min;
            this.max = max;
        }
        
        public double getMin() {
            return min;
        }
        
        public double getMax() {
            return max;
        }
        
        public double getRange() {
            return max - min;
        }
    }
}
