package com.whyquery.neo4j.schema;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.whyquery.neo4j.util.DatabaseIdentityUtil;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.schema.ConstraintDefinition;
import org.neo4j.graphdb.schema.ConstraintType;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.storageengine.api.TransactionIdStore;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.WeakHashMap;

/**
 * Comprehensive database schema cache that reads ALL schema information at startup
 * and provides fast access to actual database values, types, and statistics.
 * NO HARDCODED VALUES - everything comes from the actual database schema.
 */
public class DatabaseSchemaCache {
    private static final Map<GraphDatabaseService, DatabaseSchemaCache> SHARED_CACHES =
        Collections.synchronizedMap(new WeakHashMap<>());
    
    private final GraphDatabaseService db;
    
    // Schema structure
    private final Map<String, Set<String>> labelToProperties = new ConcurrentHashMap<>();
    private final Map<String, Map<String, PropertyInfo>> propertyDetails = new ConcurrentHashMap<>();
    private final Map<String, Long> labelCounts = new ConcurrentHashMap<>();
    private final Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> tripleStats = new ConcurrentHashMap<>();
    private final Map<String, Long> relationshipTypeCounts = new ConcurrentHashMap<>();
    private final Map<String, Map<String, MinMax>> numericRanges = new ConcurrentHashMap<>();
    private final Map<String, Map<String, List<Double>>> histogramBoundaries = new ConcurrentHashMap<>();
    private final Map<String, Map<String, List<Object>>> commonValues = new ConcurrentHashMap<>();
    private final Set<String> allLabels = ConcurrentHashMap.newKeySet();
    private final Set<String> allProperties = ConcurrentHashMap.newKeySet();
    private final Map<String, Set<String>> keyProperties = new ConcurrentHashMap<>();
    /**
     * Max-degree witnesses: for a schema triple, a direction and a key property
     * of the endpoint label, the key value of one node attaining the maximum
     * degree (ties broken by key value). Used only to choose the constant of a
     * why-many key restriction; it never enters a bound.
     */
    private final Map<String, Map<String, Object>> degreeWitnesses = new ConcurrentHashMap<>();
    private final Map<String, Set<String>> functionalRelationships = new ConcurrentHashMap<>();
    
    // Cache metadata
    private long lastRefresh = 0;
    /** Last committed Neo4j transaction observed both before and after the snapshot scan. */
    private volatile long snapshotTransactionId = -1L;
    /** False when writes overlapped the multi-query snapshot build. */
    private volatile boolean snapshotBuildConsistent = false;
    /** Stable database key persisted with the snapshot to prevent cross-database reuse. */
    private volatile String snapshotDatabaseKey;
    private final long CACHE_TTL = 300_000; // 5 minutes
    private boolean isInitialized = false;
    private final String databaseKey;
    private final Path snapshotPath;
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private final boolean enableLoad;
    private final boolean snapshotOnlyMode;
    
    public static class MinMax {
        public Object min;
        public Object max;
        public MinMax() {
        }
        public MinMax(Object min, Object max) {
            this.min = min;
            this.max = max;
        }
    }
    
    public static class PropertyInfo {
        private final String type;
        private final List<Object> commonValues;
        private final long totalCount;
        private final long nullCount;
        private final double selectivity;
        private final Object minValue;
        private final Object maxValue;
        
        public PropertyInfo(String type, List<Object> commonValues, long totalCount, 
                          long nullCount, double selectivity, Object minValue, Object maxValue) {
            this.type = type;
            this.commonValues = new ArrayList<>(commonValues);
            this.totalCount = totalCount;
            this.nullCount = nullCount;
            this.selectivity = selectivity;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }
        
        public String getType() { return type; }
        public List<Object> getCommonValues() { return new ArrayList<>(commonValues); }
        public long getTotalCount() { return totalCount; }
        public long getNullCount() { return nullCount; }
        public double getSelectivity() { return selectivity; }
        public Object getMinValue() { return minValue; }
        public Object getMaxValue() { return maxValue; }
        
        public Object getAlternativeValue(Object originalValue) {
            // Find a different value from common values
            for (Object value : commonValues) {
                if (value != null && !value.equals(originalValue)) {
                    return value;
                }
            }
            
            // If no alternative found, return first available or type-appropriate default
            if (!commonValues.isEmpty() && commonValues.get(0) != null) {
                return commonValues.get(0);
            }
            
            // Return type-appropriate default
            switch (type.toLowerCase()) {
                case "integer":
                case "long":
                    return 1L;
                case "float":
                case "double":
                    return 1.0;
                case "boolean":
                    return true;
                default:
                    return "default_value";
            }
        }
        
        public String getDefaultValueAsString() {
            if (!commonValues.isEmpty() && commonValues.get(0) != null) {
                Object value = commonValues.get(0);
                if (value instanceof String) {
                    return "'" + value + "'";
                } else {
                    return value.toString();
                }
            }
            
            // Return type-appropriate default
            switch (type.toLowerCase()) {
                case "integer":
                case "long":
                    return "1";
                case "float":
                case "double":
                    return "1.0";
                case "boolean":
                    return "true";
                default:
                    return "'default_value'";
            }
        }
    }
    
    public DatabaseSchemaCache(GraphDatabaseService db) {
        this(db, true);
    }

    public static DatabaseSchemaCache getShared(GraphDatabaseService db) {
        if (db == null) {
            throw new IllegalArgumentException("GraphDatabaseService cannot be null");
        }
        DatabaseSchemaCache cached = SHARED_CACHES.get(db);
        if (cached != null) {
            return cached;
        }
        synchronized (SHARED_CACHES) {
            DatabaseSchemaCache current = SHARED_CACHES.get(db);
            if (current != null) {
                return current;
            }
            DatabaseSchemaCache created = new DatabaseSchemaCache(db, true);
            SHARED_CACHES.put(db, created);
            return created;
        }
    }

    public DatabaseSchemaCache(GraphDatabaseService db, boolean enableLoad) {
        this.db = db;
        this.enableLoad = enableLoad;
        this.snapshotOnlyMode = resolveSnapshotOnlyMode();
        this.databaseKey = DatabaseIdentityUtil.resolveDatabaseKey(db);
        this.snapshotPath = resolveSnapshotPath();
        System.out.println("SCHEMA_CACHE: Initializing comprehensive database schema cache...");
        if (enableLoad) {
            boolean loadedFromDisk = loadSnapshotFromDisk();
            if (!loadedFromDisk) {
                if (snapshotOnlyMode) {
                    System.out.println(
                        "SCHEMA_CACHE: Snapshot-only mode enabled but snapshot missing at "
                            + snapshotPath
                            + ". Bootstrapping from live database once and persisting snapshot."
                    );
                    refreshAllSchemaInformation(true);
                } else {
                    refreshAllSchemaInformation();
                }
            }
            System.out.println("SCHEMA_CACHE: Initialization complete. Found " + allLabels.size() + 
                             " labels and " + allProperties.size() + " unique properties.");
        } else {
            System.out.println("SCHEMA_CACHE: Loading disabled by configuration; using empty schema cache.");
            this.lastRefresh = System.currentTimeMillis();
        }
        this.isInitialized = true;
    }

    public Path getSnapshotPath() {
        return snapshotPath;
    }

    private Path resolveSnapshotPath() {
        String override = System.getProperty("why.schema.snapshot.path");
        if (override == null || override.isBlank()) {
            override = System.getenv("WHY_SCHEMA_SNAPSHOT_PATH");
        }
        if (override != null && !override.isBlank()) {
            return Paths.get(override);
        }

        File pluginDir = resolvePluginDirectory();
        if (pluginDir != null) {
            return pluginDir.toPath().resolve("why_schema_cache." + databaseKey + ".json");
        }

        return Paths.get(System.getProperty("java.io.tmpdir"), "why_schema_cache." + databaseKey + ".json");
    }

    private Path resolveLegacySnapshotPath() {
        File pluginDir = resolvePluginDirectory();
        if (pluginDir != null) {
            return pluginDir.toPath().resolve("why_schema_cache.json");
        }
        return Paths.get(System.getProperty("java.io.tmpdir"), "why_schema_cache.json");
    }

    private File resolvePluginDirectory() {
        try {
            File jar = new File(DatabaseSchemaCache.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI());
            File parent = jar.getParentFile();
            if (parent != null && parent.isDirectory()) {
                return parent;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private boolean resolveSnapshotOnlyMode() {
        String value = System.getProperty("why.schema.snapshot.only");
        if (value == null || value.isBlank()) {
            value = System.getenv("WHY_SCHEMA_SNAPSHOT_ONLY");
        }
        if (value == null || value.isBlank()) {
            return true;
        }
        return "1".equals(value) || "true".equalsIgnoreCase(value) || "yes".equalsIgnoreCase(value);
    }
    
    /**
     * Refresh all schema information from the database
     */
    public synchronized void refreshAllSchemaInformation() {
        refreshAllSchemaInformation(false);
    }

    private synchronized void refreshAllSchemaInformation(boolean forceLiveRefresh) {
        if (!enableLoad) {
            return;
        }
        System.out.println("SCHEMA_CACHE: Starting comprehensive schema refresh...");
        long startTime = System.currentTimeMillis();

        // Clear existing data
        labelToProperties.clear();
        propertyDetails.clear();
        labelCounts.clear();
        tripleStats.clear();
        relationshipTypeCounts.clear();
        allLabels.clear();
        allProperties.clear();
        numericRanges.clear();
        histogramBoundaries.clear();
        commonValues.clear();
        keyProperties.clear();
        degreeWitnesses.clear();
        functionalRelationships.clear();

        boolean loaded = false;
        boolean loadedFromLive = false;
        boolean allowLiveRefresh = !snapshotOnlyMode || forceLiveRefresh;
        if (allowLiveRefresh) {
            try (Transaction tx = db.beginTx()) {
                Map<String, Object> summary = rebuildSnapshotFromDatabase(tx, Map.of(
                    "preserve_structure", false,
                    "include_common_values", true,
                    "include_numeric_ranges", true,
                    "include_histograms", true,
                    "include_distinct_counts", true,
                    "include_properties", true,
                    "include_triples", true
                ));
                tx.commit();
                loaded = "SUCCESS".equals(summary.get("status"));
                loadedFromLive = loaded;
                if (loaded) {
                    System.out.println("SCHEMA_CACHE: Refreshed schema cache from live database.");
                }
            } catch (Exception e) {
                System.err.println("SCHEMA_CACHE: Live refresh failed, falling back to snapshot: " + e.getMessage());
            }
        } else {
            System.out.println("SCHEMA_CACHE: Snapshot-only mode enabled; skipping live schema refresh.");
        }
        if (!loaded) {
            loaded = loadSnapshotFromDisk();
        }
        if (!loaded) {
            System.out.println("SCHEMA_CACHE: No live schema refresh or snapshot available; schema cache remains empty.");
        }

        lastRefresh = System.currentTimeMillis();
        long duration = lastRefresh - startTime;
        System.out.println("SCHEMA_CACHE: Schema refresh completed in " + duration + "ms");

        // Print summary and persist snapshot
        printCacheSummary();
        if (loadedFromLive) {
            persistSnapshotToDisk();
        }
    }
    
    /**
     * Load all labels from the database
     */
    private void loadAllLabels() {
        if (!enableLoad) {
            return;
        }
        try (Transaction tx = db.beginTx()) {
            System.out.println("SCHEMA_CACHE: Loading all labels...");
            
            String query = "CALL db.labels() YIELD label RETURN label ORDER BY label";
            Result result = tx.execute(query);
            
            while (result.hasNext()) {
                String label = (String) result.next().get("label");
                if (label != null && !label.trim().isEmpty()) {
                    allLabels.add(label);
                    labelToProperties.put(label, ConcurrentHashMap.newKeySet());
                }
            }
            
            System.out.println("SCHEMA_CACHE: Found " + allLabels.size() + " labels: " + allLabels);
            
        } catch (Exception e) {
            System.err.println("SCHEMA_CACHE: ERROR loading labels: " + e.getMessage());
        }
    }
    
    /**
     * Load all properties for each label
     */
    private void loadAllPropertiesForLabels() {
        if (!enableLoad) {
            return;
        }
        for (String label : allLabels) {
            try (Transaction tx = db.beginTx()) {
                System.out.println("SCHEMA_CACHE: Loading properties for label: " + label);
                
                String query = "MATCH (n:" + label + ") " +
                             "UNWIND keys(n) as property " +
                             "RETURN DISTINCT property ORDER BY property";
                
                Result result = tx.execute(query);
                Set<String> labelProperties = labelToProperties.get(label);
                
                while (result.hasNext()) {
                    String property = (String) result.next().get("property");
                    if (property != null && !property.trim().isEmpty()) {
                        labelProperties.add(property);
                        allProperties.add(property);
                    }
                }
                
                System.out.println("SCHEMA_CACHE: Label " + label + " has properties: " + labelProperties);
                
            } catch (Exception e) {
                System.err.println("SCHEMA_CACHE: ERROR loading properties for " + label + ": " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadRangesAndValuesFromSnapshot() {
        if (!enableLoad) {
            return;
        }
        try {
            if (!Files.exists(snapshotPath)) {
                System.out.println("SCHEMA_CACHE: No snapshot found for ranges/values: " + snapshotPath);
                return;
            }
            Map<String, Object> snapshot = OBJECT_MAPPER.readValue(Files.readAllBytes(snapshotPath), Map.class);
            Object rangesObj = snapshot.get("numericRanges");
            if (rangesObj instanceof Map) {
                Map<String, Map<String, Map<String, Object>>> ranges = (Map<String, Map<String, Map<String, Object>>>) rangesObj;
                for (Map.Entry<String, Map<String, Map<String, Object>>> entry : ranges.entrySet()) {
                    Map<String, MinMax> inner = new HashMap<>();
                    for (Map.Entry<String, Map<String, Object>> p : entry.getValue().entrySet()) {
                        inner.put(p.getKey(), new MinMax(p.getValue().get("min"), p.getValue().get("max")));
                    }
                    numericRanges.put(entry.getKey(), inner);
                }
            }
            Object commonObj = snapshot.get("commonValues");
            if (commonObj instanceof Map) {
                commonValues.putAll((Map<String, Map<String, List<Object>>>) commonObj);
            }
        } catch (Exception e) {
            System.err.println("SCHEMA_CACHE: Failed to load ranges/values from snapshot: " + e.getMessage());
        }
    }

    private void loadNumericRanges() {
        // Deprecated: no live DB queries for ranges. Use snapshot-based loading instead.
    }
    
    /**
     * Load detailed information for each property of each label
     */
    private void loadPropertyDetails() {
        // Deprecated: live DB scans removed. Use snapshot-based loading instead.
    }
    
    /**
     * Load detailed information for a specific property
     */
    private PropertyInfo loadPropertyInfo(String label, String property) {
        // Deprecated: no live DB queries allowed. Property details must come from snapshot.
        return null;
    }
    
    /**
     * Load node counts for each label
     */
    private void loadLabelCounts() {
        for (String label : allLabels) {
            try (Transaction tx = db.beginTx()) {
                String query = "MATCH (n:" + label + ") RETURN count(n) as count";
                Result result = tx.execute(query);
                
                if (result.hasNext()) {
                    long count = ((Number) result.next().get("count")).longValue();
                    labelCounts.put(label, count);
                    System.out.println("SCHEMA_CACHE: Label " + label + " has " + count + " nodes");
                }
                
            } catch (Exception e) {
                System.err.println("SCHEMA_CACHE: ERROR loading count for " + label + ": " + e.getMessage());
            }
        }
    }
    
    /**
     * Print comprehensive cache summary
     */
    private void printCacheSummary() {
        System.out.println("SCHEMA_CACHE: ========== CACHE SUMMARY ==========");
        System.out.println("SCHEMA_CACHE: Total Labels: " + allLabels.size());
        System.out.println("SCHEMA_CACHE: Total Unique Properties: " + allProperties.size());
        
        for (String label : allLabels) {
            Set<String> props = labelToProperties.get(label);
            Long count = labelCounts.get(label);
            System.out.println("SCHEMA_CACHE: " + label + " (" + count + " nodes, " + props.size() + " properties)");
        }
        System.out.println("SCHEMA_CACHE: ===============================");
    }
    
    // Public API methods
    
    public boolean isInitialized() {
        return isInitialized;
    }
    
    public long getLastRefreshTimestamp() {
        return lastRefresh;
    }

    public long getSnapshotTransactionId() {
        return snapshotTransactionId;
    }

    /**
     * Return Neo4j's durable last-committed transaction id, or {@code -1} when
     * the hosting runtime does not expose the kernel transaction store.
     */
    public long getCurrentTransactionId() {
        if (db == null) {
            return -1L;
        }
        try {
            if (db instanceof GraphDatabaseAPI) {
                TransactionIdStore store = ((GraphDatabaseAPI) db).getDependencyResolver()
                    .resolveDependency(TransactionIdStore.class);
                return store.getLastCommittedTransactionId();
            }
        } catch (Exception e) {
            System.err.println("SCHEMA_CACHE: Cannot read committed transaction id: " + e.getMessage());
        }
        return -1L;
    }

    /**
     * True exactly when the snapshot was built without an intervening commit,
     * belongs to this database, and no later transaction has committed.
     * Test caches created with live loading disabled contain no persisted
     * certificate state and are treated as stable fixtures.
     */
    public boolean isSnapshotFresh() {
        if (isUnversionedTestFixture()) {
            return true;
        }
        long currentTransactionId = getCurrentTransactionId();
        return snapshotBuildConsistent
            && snapshotTransactionId >= 0L
            && currentTransactionId == snapshotTransactionId
            && Objects.equals(snapshotDatabaseKey, databaseKey);
    }

    public String getSnapshotFreshnessStatus() {
        if (isUnversionedTestFixture()) {
            return "test_fixture";
        }
        if (!snapshotBuildConsistent) {
            return snapshotTransactionId >= 0L
                ? "concurrent_write_during_rebuild"
                : "unversioned_snapshot";
        }
        if (!Objects.equals(snapshotDatabaseKey, databaseKey)) {
            return "database_mismatch";
        }
        long currentTransactionId = getCurrentTransactionId();
        if (currentTransactionId < 0L) {
            return "transaction_version_unavailable";
        }
        if (currentTransactionId != snapshotTransactionId) {
            return "transaction_advanced";
        }
        return "fresh";
    }

    private boolean isUnversionedTestFixture() {
        return !enableLoad && !snapshotBuildConsistent && snapshotTransactionId < 0L;
    }
    
    public int getLabelCount() {
        return allLabels.size();
    }
    
    public int getPropertyCount() {
        return allProperties.size();
    }
    
    public Map<String, Long> getLabelNodeCounts() {
        checkCacheExpiry();
        return new HashMap<>(labelCounts);
    }

    public Map<String, PropertyInfo> getPropertyDetailsForLabel(String label) {
        checkCacheExpiry();
        Map<String, PropertyInfo> details = propertyDetails.get(label);
        if (details == null) {
            return Collections.emptyMap();
        }
        return new HashMap<>(details);
    }
    
    public Set<String> getAllLabels() {
        checkCacheExpiry();
        return new HashSet<>(allLabels);
    }
    
    public Set<String> getPropertiesForLabel(String label) {
        checkCacheExpiry();
        return new HashSet<>(labelToProperties.getOrDefault(label, Collections.emptySet()));
    }

    public Set<String> getKeyPropertiesForLabel(String label) {
        checkCacheExpiry();
        return new HashSet<>(keyProperties.getOrDefault(label, Collections.emptySet()));
    }

    public boolean isKeyProperty(String label, String property) {
        if (label == null || property == null) {
            return false;
        }
        return keyProperties.getOrDefault(label, Collections.emptySet()).contains(property);
    }

    public boolean isFunctionalRelationship(String label, String relType) {
        if (label == null || relType == null) {
            return false;
        }
        return functionalRelationships.getOrDefault(label, Collections.emptySet()).contains(relType);
    }
    
    public PropertyInfo getPropertyInfo(String label, String property) {
        checkCacheExpiry();
        Map<String, PropertyInfo> labelProps = propertyDetails.get(label);
        return labelProps != null ? labelProps.get(property) : null;
    }
    
    public List<Object> getCommonValuesForProperty(String label, String property) {
        Map<String, List<Object>> byProp = commonValues.get(label);
        if (byProp != null && byProp.containsKey(property)) {
            return new ArrayList<>(byProp.get(property));
        }
        PropertyInfo info = getPropertyInfo(label, property);
        return info != null ? info.getCommonValues() : new ArrayList<>();
    }

    /** Finite, sorted quantile boundaries captured during the offline snapshot rebuild. */
    public List<Double> getHistogramBoundaries(String label, String property) {
        checkCacheExpiry();
        Map<String, List<Double>> byProperty = histogramBoundaries.get(label);
        if (byProperty == null) {
            return Collections.emptyList();
        }
        return new ArrayList<>(byProperty.getOrDefault(property, Collections.emptyList()));
    }
    
    public String getPropertyType(String label, String property) {
        PropertyInfo info = getPropertyInfo(label, property);
        return info != null ? info.getType() : null;
    }
    
    public Object getAlternativeValue(String label, String property, Object originalValue) {
        PropertyInfo info = getPropertyInfo(label, property);
        return info != null ? info.getAlternativeValue(originalValue) : "alternative_value";
    }
    
    public String getDefaultValueAsString(String label, String property) {
        PropertyInfo info = getPropertyInfo(label, property);
        return info != null ? info.getDefaultValueAsString() : "'default_value'";
    }
    
    public double getPropertySelectivity(String label, String property) {
        PropertyInfo info = getPropertyInfo(label, property);
        return info != null ? info.getSelectivity() : 0.5; // reasonable default
    }
    
    public long getLabelCount(String label) {
        checkCacheExpiry();
        return labelCounts.getOrDefault(label, 0L);
    }

    public Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> getSchemaTripleStats() {
        checkCacheExpiry();
        return new HashMap<>(tripleStats);
    }
    
    public long getRelationshipCount(String relType) {
        checkCacheExpiry();
        if (relType == null || relType.isBlank()) {
            return relationshipTypeCounts.values().stream().mapToLong(Long::longValue).sum();
        }
        return relationshipTypeCounts.getOrDefault(relType, 0L);
    }

    public Map<String, Long> getLabelCountsSnapshot() {
        checkCacheExpiry();
        return new HashMap<>(labelCounts);
    }

    public SchemaGraph buildSchemaGraph() {
        return new SchemaGraph(getSchemaTripleStats(), getLabelCountsSnapshot());
    }

    private static String cypherName(String name) {
        if (name == null) {
            return "``";
        }
        return "`" + name.replace("`", "``") + "`";
    }

    private static int intOpt(Map<String, Object> options, String key, int def) {
        if (options == null) {
            return def;
        }
        Object v = options.get(key);
        if (v instanceof Number) {
            return ((Number) v).intValue();
        }
        if (v instanceof String) {
            try {
                return Integer.parseInt((String) v);
            } catch (NumberFormatException ignored) {
            }
        }
        return def;
    }

    private static boolean boolOpt(Map<String, Object> options, String key, boolean def) {
        if (options == null) {
            return def;
        }
        Object v = options.get(key);
        if (v instanceof Boolean) {
            return (Boolean) v;
        }
        if (v instanceof String) {
            return Boolean.parseBoolean((String) v);
        }
        return def;
    }

    private static String detectType(Object v) {
        if (v == null) {
            return "String";
        }
        if (v instanceof Boolean) {
            return "Boolean";
        }
        if (v instanceof Float || v instanceof Double) {
            return "Double";
        }
        if (v instanceof Number) {
            return "Integer";
        }
        return "String";
    }

    /**
     * Explicitly rebuild and persist a schema snapshot from live data.
     * This is intended for periodic offline snapshot updates; it is NOT used during A* search.
     */
    public synchronized Map<String, Object> rebuildSnapshotFromDatabase(Transaction tx, Map<String, Object> options) {
        long start = System.currentTimeMillis();
        Map<String, Object> out = new HashMap<>();
        long buildStartTransactionId = getCurrentTransactionId();
        snapshotBuildConsistent = false;
        snapshotTransactionId = -1L;
        snapshotDatabaseKey = databaseKey;
        // Explicit rebuild is an administrative operation and must work
        // even when this instance was created with enableLoad=false.
        if (tx == null) {
            out.put("status", "ERROR");
            out.put("message", "Transaction is required");
            return out;
        }

        int topK = intOpt(options, "top_k", intOpt(options, "topK", 10));
        boolean includeCommon = boolOpt(options, "include_common_values", true);
        boolean includeRanges = boolOpt(options, "include_numeric_ranges", true);
        boolean includeHistograms = boolOpt(options, "include_histograms", true);
        int histogramBuckets = Math.max(2, Math.min(32, intOpt(options, "histogram_buckets", 8)));
        boolean includeDistinct = boolOpt(options, "include_distinct_counts", true);
        boolean includeProperties = boolOpt(options, "include_properties", true);
        boolean includeTriples = boolOpt(options, "include_triples", true);
        boolean includeMaxDegrees = boolOpt(options, "include_max_degrees", true);
        boolean persistSnapshot = boolOpt(options, "persist_snapshot", true);
        // Bulk grouping by endpoint can exceed Neo4j's transaction memory pool
        // on SF1/SF10. Exact maxima are therefore filled by bounded per-triple
        // scans after edge counts have been collected.
        boolean useBulkMaxDegreeAggregation = false;
        boolean preserveStructure = boolOpt(options, "preserve_structure", true) &&
            !boolOpt(options, "reset_structure", false);

        // Key caps are proof-critical. Re-discover them from the same database
        // snapshot as the counts instead of carrying possibly stale/manual
        // declarations across rebuilds.
        keyProperties.clear();
        degreeWitnesses.clear();

        if (!preserveStructure) {
            labelToProperties.clear();
            propertyDetails.clear();
            labelCounts.clear();
            tripleStats.clear();
            relationshipTypeCounts.clear();
            numericRanges.clear();
            histogramBoundaries.clear();
            commonValues.clear();
            allLabels.clear();
            allProperties.clear();
        } else {
            // Keep schema structure (labels/properties/triples) from the existing snapshot,
            // and only refresh statistics fields (counts, selectivities, top-k values, etc.).
            propertyDetails.clear();
            labelCounts.clear();
            relationshipTypeCounts.clear();
            numericRanges.clear();
            histogramBoundaries.clear();
            commonValues.clear();
        }

        // Labels (only infer from DB if we are not preserving an existing schema structure)
        if (!preserveStructure || allLabels.isEmpty()) {
            Result labelsRes = tx.execute("CALL db.labels() YIELD label RETURN label ORDER BY label");
            while (labelsRes.hasNext()) {
                Object labelObj = labelsRes.next().get("label");
                if (labelObj == null) {
                    continue;
                }
                String label = String.valueOf(labelObj);
                if (label.isBlank()) {
                    continue;
                }
                allLabels.add(label);
                labelToProperties.put(label, ConcurrentHashMap.newKeySet());
            }
        }

        loadSinglePropertyNodeKeys(tx);

        // Label counts + properties + property stats
        for (String label : new ArrayList<>(allLabels)) {
            String lbl = cypherName(label);

            try (Result countRes = tx.execute("MATCH (n:" + lbl + ") RETURN count(n) AS c")) {
                if (countRes.hasNext()) {
                    Object c = countRes.next().get("c");
                    if (c instanceof Number) {
                        labelCounts.put(label, ((Number) c).longValue());
                    }
                }
            }

            if (!includeProperties) {
                continue;
            }

            // Only infer properties from DB when not preserving structure OR when label has no known props.
            Set<String> knownProps = labelToProperties.getOrDefault(label, Collections.emptySet());
            if (!preserveStructure || knownProps.isEmpty()) {
                try (Result propRes = tx.execute(
                    "MATCH (n:" + lbl + ") UNWIND keys(n) AS p RETURN DISTINCT p AS p ORDER BY p")) {
                    while (propRes.hasNext()) {
                        Object p = propRes.next().get("p");
                        if (p == null) {
                            continue;
                        }
                        String prop = String.valueOf(p);
                        if (prop.isBlank()) {
                            continue;
                        }
                        labelToProperties.computeIfAbsent(label, k -> ConcurrentHashMap.newKeySet()).add(prop);
                        allProperties.add(prop);
                    }
                }
            } else {
                allProperties.addAll(knownProps);
            }

            Map<String, PropertyInfo> byProp = new ConcurrentHashMap<>();
            for (String prop : labelToProperties.getOrDefault(label, Collections.emptySet())) {
                String propExpr = "n." + cypherName(prop);

                String type = "String";
                try (Result sampleRes = tx.execute(
                    "MATCH (n:" + lbl + ") WHERE " + propExpr + " IS NOT NULL RETURN " + propExpr + " AS v LIMIT 1")) {
                    if (sampleRes.hasNext()) {
                        Object v = sampleRes.next().get("v");
                        type = detectType(v);
                    }
                } catch (Exception ignored) {
                }

                long total = labelCounts.getOrDefault(label, 0L);
                long nonNull = 0L;
                long distinct = 0L;
                try (Result nnRes = tx.execute(
                    "MATCH (n:" + lbl + ") WHERE " + propExpr + " IS NOT NULL RETURN count(n) AS c")) {
                    if (nnRes.hasNext()) {
                        Object c = nnRes.next().get("c");
                        if (c instanceof Number) {
                            nonNull = ((Number) c).longValue();
                        }
                    }
                } catch (Exception ignored) {
                }

                if (includeDistinct) {
                    try (Result dRes = tx.execute(
                        "MATCH (n:" + lbl + ") WHERE " + propExpr + " IS NOT NULL RETURN count(DISTINCT " + propExpr + ") AS d")) {
                        if (dRes.hasNext()) {
                            Object d = dRes.next().get("d");
                            if (d instanceof Number) {
                                distinct = ((Number) d).longValue();
                            }
                        }
                    } catch (Exception ignored) {
                    }
                }

                // Exact snapshot-wide uniqueness is as sound for the current,
                // freshness-gated graph as a declared single-property key:
                // every equality predicate can match at most one labelled
                // node. Any later write invalidates the entire certificate.
                if (total > 0L && nonNull == total && distinct == total) {
                    keyProperties.computeIfAbsent(label, ignored -> ConcurrentHashMap.newKeySet())
                        .add(prop);
                }

                long nullCount = Math.max(0L, total - nonNull);
                double selectivity = 0.1;
                if (distinct > 0) {
                    selectivity = 1.0 / (double) distinct;
                } else if (nonNull > 0) {
                    // Unknown distinct: at least non-null fraction.
                    selectivity = Math.min(1.0, Math.max(0.000001, (double) nonNull / (double) Math.max(1L, total)));
                }

                Object min = null;
                Object max = null;
                if ((includeRanges || includeHistograms) && ("Integer".equals(type) || "Double".equals(type))) {
                    StringBuilder aggregates = new StringBuilder("min(" + propExpr + ") AS min, max(" + propExpr + ") AS max");
                    if (includeHistograms) {
                        for (int i = 1; i < histogramBuckets; i++) {
                            double quantile = (double) i / (double) histogramBuckets;
                            aggregates.append(", percentileDisc(toFloat(").append(propExpr).append("), ")
                                .append(String.format(Locale.ROOT, "%.8f", quantile))
                                .append(") AS q").append(i);
                        }
                    }
                    try (Result mmRes = tx.execute(
                        "MATCH (n:" + lbl + ") WHERE " + propExpr + " IS NOT NULL RETURN " + aggregates)) {
                        if (mmRes.hasNext()) {
                            Map<String, Object> row = mmRes.next();
                            min = row.get("min");
                            max = row.get("max");
                            if (includeHistograms) {
                                SortedSet<Double> boundaries = new TreeSet<>();
                                if (min instanceof Number) boundaries.add(((Number) min).doubleValue());
                                for (int i = 1; i < histogramBuckets; i++) {
                                    Object q = row.get("q" + i);
                                    if (q instanceof Number) boundaries.add(((Number) q).doubleValue());
                                }
                                if (max instanceof Number) boundaries.add(((Number) max).doubleValue());
                                if (!boundaries.isEmpty()) {
                                    histogramBoundaries.computeIfAbsent(label, k -> new ConcurrentHashMap<>())
                                        .put(prop, new ArrayList<>(boundaries));
                                }
                            }
                        }
                    } catch (Exception ignored) {
                    }
                }

                List<Object> common = new ArrayList<>();
                if (includeCommon && topK > 0) {
                    try (Result topRes = tx.execute(
                        "MATCH (n:" + lbl + ") WHERE " + propExpr + " IS NOT NULL " +
                            "RETURN " + propExpr + " AS v, count(*) AS c " +
                            "ORDER BY c DESC LIMIT $k",
                        Map.of("k", topK))) {
                        while (topRes.hasNext()) {
                            Object v = topRes.next().get("v");
                            if (v != null) {
                                common.add(v);
                            }
                        }
                    } catch (Exception ignored) {
                    }
                }

                byProp.put(prop, new PropertyInfo(type, common, total, nullCount, selectivity, min, max));
                if (includeCommon && !common.isEmpty()) {
                    commonValues.computeIfAbsent(label, k -> new ConcurrentHashMap<>()).put(prop, common);
                }
                if (includeRanges && min != null && max != null) {
                    numericRanges.computeIfAbsent(label, k -> new ConcurrentHashMap<>()).put(prop, new MinMax(min, max));
                }
            }
            propertyDetails.put(label, byProp);
        }

        if (includeTriples) {
            if (preserveStructure && !tripleStats.isEmpty()) {
                // Refresh edge counts for the EXISTING (schema-provided) triples only.
                Map<String, List<SchemaGraph.SchemaTriple>> byRel = new HashMap<>();
                for (SchemaGraph.SchemaTriple t : new ArrayList<>(tripleStats.keySet())) {
                    byRel.computeIfAbsent(t.getRelationshipType(), k -> new ArrayList<>()).add(t);
                }
                for (Map.Entry<String, List<SchemaGraph.SchemaTriple>> entry : byRel.entrySet()) {
                    String relType = entry.getKey();
                    if (relType == null || relType.isBlank()) {
                        continue;
                    }
                    String rel = cypherName(relType);
                    Map<String, Long> pairCounts = new HashMap<>();
                    Map<String, Double> pairMaxOut = new HashMap<>();
                    Map<String, Double> pairMaxIn = new HashMap<>();
                    try (Result rs = tx.execute(
                        "MATCH (a)-[r:" + rel + "]->(b) " +
                            "RETURN labels(a) AS s, labels(b) AS t, count(r) AS c")) {
                        while (rs.hasNext()) {
                            Map<String, Object> row = rs.next();
                            Object cObj = row.get("c");
                            long c = cObj instanceof Number ? ((Number) cObj).longValue() : 0L;
                            @SuppressWarnings("unchecked")
                            List<String> sLabels = (List<String>) row.get("s");
                            @SuppressWarnings("unchecked")
                            List<String> tLabels = (List<String>) row.get("t");
                            if (sLabels == null || sLabels.isEmpty()) {
                                sLabels = List.of(SchemaPattern.ANY_LABEL);
                            }
                            if (tLabels == null || tLabels.isEmpty()) {
                                tLabels = List.of(SchemaPattern.ANY_LABEL);
                            }
                            for (String s : sLabels) {
                                for (String t : tLabels) {
                                    pairCounts.merge(s + "->" + t, c, Long::sum);
                                }
                            }
                        }
                    } catch (Exception e) {
                        System.err.println("SCHEMA_CACHE: Failed to refresh edge counts for " + relType + ": " + e.getMessage());
                    }

                    if (includeMaxDegrees && useBulkMaxDegreeAggregation) {
                        try (Result rs = tx.execute(
                            "MATCH (a)-[r:" + rel + "]->(b) " +
                                "WITH a, labels(a) AS ss, labels(b) AS ts, count(r) AS d " +
                                "UNWIND ss AS s UNWIND ts AS t " +
                                "RETURN s, t, max(d) AS m")) {
                            while (rs.hasNext()) {
                                Map<String, Object> row = rs.next();
                                Object m = row.get("m");
                                if (m instanceof Number) {
                                    pairMaxOut.put(row.get("s") + "->" + row.get("t"), ((Number) m).doubleValue());
                                }
                            }
                        } catch (Exception e) {
                            System.err.println("SCHEMA_CACHE: Failed to refresh max out-degree for " + relType + ": " + e.getMessage());
                        }
                        try (Result rs = tx.execute(
                            "MATCH (a)-[r:" + rel + "]->(b) " +
                                "WITH b, labels(a) AS ss, labels(b) AS ts, count(r) AS d " +
                                "UNWIND ss AS s UNWIND ts AS t " +
                                "RETURN s, t, max(d) AS m")) {
                            while (rs.hasNext()) {
                                Map<String, Object> row = rs.next();
                                Object m = row.get("m");
                                if (m instanceof Number) {
                                    pairMaxIn.put(row.get("s") + "->" + row.get("t"), ((Number) m).doubleValue());
                                }
                            }
                        } catch (Exception e) {
                            System.err.println("SCHEMA_CACHE: Failed to refresh max in-degree for " + relType + ": " + e.getMessage());
                        }
                    }

                    for (SchemaGraph.SchemaTriple t : entry.getValue()) {
                        String pairKey = t.getSourceLabel() + "->" + t.getTargetLabel();
                        long c = pairCounts.getOrDefault(pairKey, 0L);
                        long srcN = labelCounts.getOrDefault(t.getSourceLabel(), 0L);
                        long dstN = labelCounts.getOrDefault(t.getTargetLabel(), 0L);
                        double avgOut = srcN > 0 ? (double) c / (double) srcN : (double) c;
                        double avgIn = dstN > 0 ? (double) c / (double) dstN : (double) c;
                        tripleStats.put(t, new SchemaGraph.TripleStats(
                            c,
                            avgOut,
                            avgIn,
                            pairMaxOut.getOrDefault(pairKey, -1.0),
                            pairMaxIn.getOrDefault(pairKey, -1.0)
                        ));
                        relationshipTypeCounts.merge(relType, c, Long::sum);
                    }
                }
            } else {
                // Infer triples from observed data (NOT schema) when asked to reset structure.
                Result relTypesRes = tx.execute("CALL db.relationshipTypes() YIELD relationshipType RETURN relationshipType ORDER BY relationshipType");
                while (relTypesRes.hasNext()) {
                    Object rt = relTypesRes.next().get("relationshipType");
                    if (rt == null) {
                        continue;
                    }
                    String relType = String.valueOf(rt);
                    if (relType.isBlank()) {
                        continue;
                    }
                    String rel = cypherName(relType);
                    Map<String, Double> pairMaxOut = new HashMap<>();
                    Map<String, Double> pairMaxIn = new HashMap<>();
                    if (includeMaxDegrees && useBulkMaxDegreeAggregation) {
                        try (Result degreeRes = tx.execute(
                            "MATCH (a)-[r:" + rel + "]->(b) " +
                                "WITH a, labels(a) AS ss, labels(b) AS ts, count(r) AS d " +
                                "UNWIND ss AS s UNWIND ts AS t RETURN s, t, max(d) AS m")) {
                            while (degreeRes.hasNext()) {
                                Map<String, Object> row = degreeRes.next();
                                if (row.get("m") instanceof Number) {
                                    pairMaxOut.put(row.get("s") + "->" + row.get("t"), ((Number) row.get("m")).doubleValue());
                                }
                            }
                        } catch (Exception e) {
                            System.err.println("SCHEMA_CACHE: Failed to infer max out-degree for " + relType + ": " + e.getMessage());
                        }
                        try (Result degreeRes = tx.execute(
                            "MATCH (a)-[r:" + rel + "]->(b) " +
                                "WITH b, labels(a) AS ss, labels(b) AS ts, count(r) AS d " +
                                "UNWIND ss AS s UNWIND ts AS t RETURN s, t, max(d) AS m")) {
                            while (degreeRes.hasNext()) {
                                Map<String, Object> row = degreeRes.next();
                                if (row.get("m") instanceof Number) {
                                    pairMaxIn.put(row.get("s") + "->" + row.get("t"), ((Number) row.get("m")).doubleValue());
                                }
                            }
                        } catch (Exception e) {
                            System.err.println("SCHEMA_CACHE: Failed to infer max in-degree for " + relType + ": " + e.getMessage());
                        }
                    }
                    try (Result rs = tx.execute(
                        "MATCH (a)-[r:" + rel + "]->(b) " +
                            "RETURN labels(a) AS s, labels(b) AS t, count(r) AS c")) {
                        while (rs.hasNext()) {
                            Map<String, Object> row = rs.next();
                            Object cObj = row.get("c");
                            long c = cObj instanceof Number ? ((Number) cObj).longValue() : 0L;
                            @SuppressWarnings("unchecked")
                            List<String> sLabels = (List<String>) row.get("s");
                            @SuppressWarnings("unchecked")
                            List<String> tLabels = (List<String>) row.get("t");
                            if (sLabels == null || sLabels.isEmpty()) {
                                sLabels = List.of(SchemaPattern.ANY_LABEL);
                            }
                            if (tLabels == null || tLabels.isEmpty()) {
                                tLabels = List.of(SchemaPattern.ANY_LABEL);
                            }
                            for (String s : sLabels) {
                                for (String t : tLabels) {
                                    SchemaGraph.SchemaTriple triple = new SchemaGraph.SchemaTriple(s, relType, t);
                                    String pairKey = s + "->" + t;
                                    long srcN = labelCounts.getOrDefault(s, 0L);
                                    long dstN = labelCounts.getOrDefault(t, 0L);
                                    double avgOut = srcN > 0 ? (double) c / (double) srcN : (double) c;
                                    double avgIn = dstN > 0 ? (double) c / (double) dstN : (double) c;
                                    tripleStats.put(triple, new SchemaGraph.TripleStats(
                                        c,
                                        avgOut,
                                        avgIn,
                                        pairMaxOut.getOrDefault(pairKey, -1.0),
                                        pairMaxIn.getOrDefault(pairKey, -1.0)
                                    ));
                                }
                            }
                            relationshipTypeCounts.merge(relType, c, Long::sum);
                        }
                    } catch (Exception e) {
                        System.err.println("SCHEMA_CACHE: Failed to compute triple stats for " + relType + ": " + e.getMessage());
                    }
                }
            }
        }

        if (includeTriples && includeMaxDegrees) {
            for (SchemaGraph.SchemaTriple triple : new ArrayList<>(tripleStats.keySet())) {
                SchemaGraph.TripleStats current = tripleStats.get(triple);
                if (current == null) {
                    continue;
                }
                double maxOut = computeExactMaxDegree(tx, triple, true);
                double maxIn = computeExactMaxDegree(tx, triple, false);
                double minOut = computeExactMinDegree(tx, triple, true);
                double minIn = computeExactMinDegree(tx, triple, false);
                tripleStats.put(triple, new SchemaGraph.TripleStats(
                    current.getEdgeCount(),
                    current.getAvgOutDegree(),
                    current.getAvgInDegree(),
                    maxOut,
                    maxIn,
                    minOut,
                    minIn
                ));
                collectDegreeWitnesses(tx, triple, true);
                collectDegreeWitnesses(tx, triple, false);
            }
        }

        long buildEndTransactionId = getCurrentTransactionId();
        snapshotBuildConsistent = buildStartTransactionId >= 0L
            && buildStartTransactionId == buildEndTransactionId;
        snapshotTransactionId = snapshotBuildConsistent ? buildEndTransactionId : -1L;
        lastRefresh = System.currentTimeMillis();
        if (persistSnapshot && snapshotBuildConsistent) {
            persistSnapshotToDisk();
        }

        out.put("status", snapshotBuildConsistent ? "SUCCESS" : "STALE");
        if (!snapshotBuildConsistent) {
            out.put("message", "A commit overlapped snapshot construction; retry the rebuild");
        }
        out.put("schema_snapshot_path", snapshotPath.toString());
        out.put("labels", allLabels.size());
        out.put("properties", allProperties.size());
        out.put("key_properties", keyProperties.values().stream().mapToInt(Set::size).sum());
        out.put("triples", tripleStats.size());
        out.put("degree_witnesses", degreeWitnesses.size());
        out.put("snapshot_transaction_id", snapshotTransactionId);
        out.put("snapshot_fresh", isSnapshotFresh());
        out.put("snapshot_freshness_status", getSnapshotFreshnessStatus());
        out.put("duration_ms", System.currentTimeMillis() - start);
        return out;
    }

    /**
     * Discover only single-property node uniqueness/key constraints. A
     * composite uniqueness constraint does not make either component unique
     * by itself and therefore cannot justify the n_safe(x) <= 1 cap.
     */
    private void loadSinglePropertyNodeKeys(Transaction tx) {
        try {
            for (ConstraintDefinition constraint : tx.schema().getConstraints()) {
                ConstraintType type = constraint.getConstraintType();
                if (type != ConstraintType.UNIQUENESS && type != ConstraintType.NODE_KEY) {
                    continue;
                }
                List<String> properties = new ArrayList<>();
                constraint.getPropertyKeys().forEach(properties::add);
                if (properties.size() != 1) {
                    continue;
                }
                String label = constraint.getLabel().name();
                String property = properties.get(0);
                if (!label.isBlank() && !property.isBlank()) {
                    keyProperties.computeIfAbsent(label, ignored -> ConcurrentHashMap.newKeySet())
                        .add(property);
                }
            }
        } catch (Exception e) {
            // Fail closed: missing catalog support merely disables key-based
            // tightening; it never invents a proof-critical key.
            System.err.println("SCHEMA_CACHE: Failed to discover key constraints: " + e.getMessage());
            keyProperties.clear();
        }
    }

    private static String witnessKey(String label, String rel, String other,
                                     boolean outgoing, String property) {
        return label + "|" + rel + "|" + other + "|" + (outgoing ? "out" : "in") + "|" + property;
    }

    private void collectDegreeWitnesses(Transaction tx,
                                        SchemaGraph.SchemaTriple triple,
                                        boolean outgoing) {
        String endpoint = outgoing ? triple.getSourceLabel() : triple.getTargetLabel();
        String other = outgoing ? triple.getTargetLabel() : triple.getSourceLabel();
        Set<String> keys = keyProperties.getOrDefault(endpoint, Collections.emptySet());
        if (keys.isEmpty()) {
            return;
        }
        String rel = cypherName(triple.getRelationshipType());
        String pattern = outgoing
            ? "(n)-[:" + rel + "]->(:" + cypherName(other) + ")"
            : "(:" + cypherName(other) + ")-[:" + rel + "]->(n)";
        for (String property : new TreeSet<>(keys)) {
            String prop = "n." + cypherName(property);
            String query = "MATCH (n:" + cypherName(endpoint) + ") WHERE " + prop + " IS NOT NULL " +
                "WITH n, count { " + pattern + " } AS d WHERE d > 0 " +
                "RETURN " + prop + " AS v, d ORDER BY d DESC, v ASC LIMIT 1";
            try (Result result = tx.execute(query)) {
                if (result.hasNext()) {
                    Map<String, Object> row = result.next();
                    Object value = row.get("v");
                    Object degree = row.get("d");
                    if ((value instanceof String || value instanceof Number || value instanceof Boolean)
                        && degree instanceof Number) {
                        Map<String, Object> witness = new HashMap<>();
                        witness.put("value", value);
                        witness.put("degree", ((Number) degree).longValue());
                        degreeWitnesses.put(
                            witnessKey(endpoint, triple.getRelationshipType(), other, outgoing, property),
                            witness);
                    }
                }
            } catch (Exception e) {
                System.err.println("SCHEMA_CACHE: Failed degree witness for " + triple + ": " + e.getMessage());
            }
        }
    }

    /**
     * Key value of a max-degree node of {@code label} for the given relationship
     * type and direction, or null. {@code otherLabels} empty means any neighbour
     * label; among several matching triples the largest degree wins.
     */
    public Object getDegreeWitnessValue(String label, String relType, Collection<String> otherLabels,
                                        boolean outgoing, String property) {
        if (label == null || relType == null || property == null) {
            return null;
        }
        String prefix = label + "|" + relType + "|";
        String suffix = "|" + (outgoing ? "out" : "in") + "|" + property;
        Object best = null;
        long bestDegree = -1L;
        for (String key : new TreeSet<>(degreeWitnesses.keySet())) {
            if (!key.startsWith(prefix) || !key.endsWith(suffix)) continue;
            String other = key.substring(prefix.length(), key.length() - suffix.length());
            if (otherLabels != null && !otherLabels.isEmpty() && !otherLabels.contains(other)) continue;
            Map<String, Object> witness = degreeWitnesses.get(key);
            Object degree = witness == null ? null : witness.get("degree");
            long d = degree instanceof Number ? ((Number) degree).longValue() : 0L;
            if (witness != null && witness.get("value") != null && d > bestDegree) {
                best = witness.get("value");
                bestDegree = d;
            }
        }
        return best;
    }

    private double computeExactMaxDegree(Transaction tx,
                                         SchemaGraph.SchemaTriple triple,
                                         boolean outgoing) {
        String source = cypherName(triple.getSourceLabel());
        String target = cypherName(triple.getTargetLabel());
        String rel = cypherName(triple.getRelationshipType());
        String query;
        if (outgoing) {
            query = "MATCH (n:" + source + ") " +
                "WITH n, count { (n)-[:" + rel + "]->(:" + target + ") } AS d " +
                "RETURN coalesce(max(d), 0) AS m";
        } else {
            query = "MATCH (n:" + target + ") " +
                "WITH n, count { (:" + source + ")-[:" + rel + "]->(n) } AS d " +
                "RETURN coalesce(max(d), 0) AS m";
        }
        try (Result result = tx.execute(query)) {
            if (result.hasNext()) {
                Object value = result.next().get("m");
                if (value instanceof Number) {
                    return ((Number) value).doubleValue();
                }
            }
        } catch (Exception e) {
            System.err.println(
                "SCHEMA_CACHE: Failed exact " + (outgoing ? "out" : "in") +
                    " max-degree for " + triple + ": " + e.getMessage()
            );
        }
        return -1.0;
    }

    /**
     * Minimum observed degree via this triple, over every node carrying the
     * relevant label -- including nodes with zero matching edges, since
     * {@code count{}} returns 0 rather than excluding them. This is the dual
     * of {@link #computeExactMaxDegree}: sound as a lower bound (Proposition 2,
     * predicate-free tree patterns) only while no node/edge of this triple has
     * been deleted since the snapshot, the mirror image of the max-degree
     * bound's insert-freshness requirement.
     */
    private double computeExactMinDegree(Transaction tx,
                                         SchemaGraph.SchemaTriple triple,
                                         boolean outgoing) {
        String source = cypherName(triple.getSourceLabel());
        String target = cypherName(triple.getTargetLabel());
        String rel = cypherName(triple.getRelationshipType());
        String query;
        if (outgoing) {
            query = "MATCH (n:" + source + ") " +
                "WITH n, count { (n)-[:" + rel + "]->(:" + target + ") } AS d " +
                "RETURN coalesce(min(d), 0) AS m";
        } else {
            query = "MATCH (n:" + target + ") " +
                "WITH n, count { (:" + source + ")-[:" + rel + "]->(n) } AS d " +
                "RETURN coalesce(min(d), 0) AS m";
        }
        try (Result result = tx.execute(query)) {
            if (result.hasNext()) {
                Object value = result.next().get("m");
                if (value instanceof Number) {
                    return ((Number) value).doubleValue();
                }
            }
        } catch (Exception e) {
            System.err.println(
                "SCHEMA_CACHE: Failed exact " + (outgoing ? "out" : "in") +
                    " min-degree for " + triple + ": " + e.getMessage()
            );
        }
        return -1.0;
    }

    private void loadSchemaTriples() {
        try (Transaction tx = db.beginTx()) {
            String query = "MATCH (s)-[r]->(t) RETURN labels(s) as srcLabels, type(r) as relType, labels(t) as dstLabels";
            Result result = tx.execute(query);
            while (result.hasNext()) {
                Map<String, Object> row = result.next();
                @SuppressWarnings("unchecked")
                List<String> srcLabels = (List<String>) row.get("srcLabels");
                @SuppressWarnings("unchecked")
                List<String> dstLabels = (List<String>) row.get("dstLabels");
                String relType = (String) row.get("relType");

                if (relType == null) {
                    continue;
                }

                List<String> sources = (srcLabels == null || srcLabels.isEmpty())
                    ? List.of(SchemaPattern.ANY_LABEL)
                    : srcLabels;
                List<String> targets = (dstLabels == null || dstLabels.isEmpty())
                    ? List.of(SchemaPattern.ANY_LABEL)
                    : dstLabels;

                for (String src : sources) {
                    for (String dst : targets) {
                        SchemaGraph.SchemaTriple triple = new SchemaGraph.SchemaTriple(src, relType, dst);
                        tripleStats.compute(triple, (key, existing) -> {
                            long newCount = (existing == null ? 0 : existing.getEdgeCount()) + 1;
                            double avgOut = newCount / Math.max(1.0, labelCounts.getOrDefault(src, 1L));
                            double avgIn = newCount / Math.max(1.0, labelCounts.getOrDefault(dst, 1L));
                            return new SchemaGraph.TripleStats(newCount, avgOut, avgIn);
                        });
                        relationshipTypeCounts.merge(relType, 1L, Long::sum);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("SCHEMA_CACHE: ERROR loading schema triples: " + e.getMessage());
        }
    }

    private static class SchemaTripleDTO {
        public String sourceLabel;
        public String relationshipType;
        public String targetLabel;
        public long edgeCount;
        public double avgOutDegree;
        public double avgInDegree;
        public double maxOutDegree;
        public double maxInDegree;
        public double minOutDegree = -1.0;
        public double minInDegree = -1.0;

        SchemaTripleDTO() {
        }

        SchemaTripleDTO(SchemaGraph.SchemaTriple triple, SchemaGraph.TripleStats stats) {
            this.sourceLabel = triple.getSourceLabel();
            this.relationshipType = triple.getRelationshipType();
            this.targetLabel = triple.getTargetLabel();
            this.edgeCount = stats.getEdgeCount();
            this.avgOutDegree = stats.getAvgOutDegree();
            this.avgInDegree = stats.getAvgInDegree();
            this.maxOutDegree = stats.getMaxOutDegree();
            this.maxInDegree = stats.getMaxInDegree();
            this.minOutDegree = stats.getMinOutDegree();
            this.minInDegree = stats.getMinInDegree();
        }
    }

    private static class SchemaSnapshot {
        public long lastRefresh;
        public long snapshotTransactionId = -1L;
        public boolean snapshotBuildConsistent = false;
        public String databaseKey;
        public Map<String, Set<String>> labelToProperties;
        public Map<String, Map<String, PropertyInfoDTO>> propertyDetails;
        public Map<String, Long> labelCounts;
        public List<SchemaTripleDTO> triples;
        public Map<String, Map<String, MinMax>> numericRanges;
        public Map<String, Map<String, List<Double>>> histogramBoundaries;
        public Map<String, Map<String, List<Object>>> commonValues;
        public Map<String, Set<String>> keyProperties;
        public Map<String, Set<String>> functionalRelationships;
        public Map<String, Map<String, Object>> degreeWitnesses;

        static SchemaSnapshot fromState(long lastRefresh,
                                        long snapshotTransactionId,
                                        boolean snapshotBuildConsistent,
                                        String databaseKey,
                                        Map<String, Set<String>> labelProps,
                                        Map<String, Map<String, PropertyInfo>> propertyInfos,
                                        Map<String, Long> labelCounts,
                                        Map<SchemaGraph.SchemaTriple, SchemaGraph.TripleStats> triples,
                                        Map<String, Map<String, MinMax>> numericRanges,
                                        Map<String, Map<String, List<Double>>> histogramBoundaries,
                                        Map<String, Map<String, List<Object>>> commonValues,
                                        Map<String, Set<String>> keyProperties,
                                        Map<String, Set<String>> functionalRelationships) {
            SchemaSnapshot snapshot = new SchemaSnapshot();
            snapshot.lastRefresh = lastRefresh;
            snapshot.snapshotTransactionId = snapshotTransactionId;
            snapshot.snapshotBuildConsistent = snapshotBuildConsistent;
            snapshot.databaseKey = databaseKey;
            snapshot.labelToProperties = new HashMap<>();
            labelProps.forEach((label, props) -> snapshot.labelToProperties.put(label, new HashSet<>(props)));

            snapshot.propertyDetails = new HashMap<>();
            propertyInfos.forEach((label, propMap) -> {
                Map<String, PropertyInfoDTO> dtoMap = new HashMap<>();
                propMap.forEach((prop, info) -> dtoMap.put(prop, PropertyInfoDTO.from(info)));
                snapshot.propertyDetails.put(label, dtoMap);
            });

            snapshot.labelCounts = new HashMap<>(labelCounts);
            snapshot.triples = new ArrayList<>();
            triples.forEach((triple, stats) -> snapshot.triples.add(new SchemaTripleDTO(triple, stats)));
            snapshot.numericRanges = new HashMap<>(numericRanges);
            snapshot.histogramBoundaries = new HashMap<>(histogramBoundaries);
            snapshot.commonValues = new HashMap<>(commonValues);
            snapshot.keyProperties = new HashMap<>();
            keyProperties.forEach((label, props) -> snapshot.keyProperties.put(label, new HashSet<>(props)));
            snapshot.functionalRelationships = new HashMap<>();
            functionalRelationships.forEach((label, rels) -> snapshot.functionalRelationships.put(label, new HashSet<>(rels)));
            return snapshot;
        }
    }

    private static class PropertyInfoDTO {
        public String type;
        public List<Object> commonValues;
        public long totalCount;
        public long nullCount;
        public double selectivity;
        public Object minValue;
        public Object maxValue;

        static PropertyInfoDTO from(PropertyInfo info) {
            PropertyInfoDTO dto = new PropertyInfoDTO();
            dto.type = info.getType();
            dto.commonValues = info.getCommonValues();
            dto.totalCount = info.getTotalCount();
            dto.nullCount = info.getNullCount();
            dto.selectivity = info.getSelectivity();
            dto.minValue = info.getMinValue();
            dto.maxValue = info.getMaxValue();
            return dto;
        }

        PropertyInfo toPropertyInfo() {
            return new PropertyInfo(type, commonValues, totalCount, nullCount, selectivity, minValue, maxValue);
        }
    }


    private void checkCacheExpiry() {
        if (!enableLoad) {
            return;
        }
        // In snapshot-only mode, avoid periodic reloading in request hot paths.
        if (snapshotOnlyMode) {
            return;
        }
        if (System.currentTimeMillis() - lastRefresh > CACHE_TTL) {
            System.out.println("SCHEMA_CACHE: Cache expired, refreshing" +
                (snapshotOnlyMode ? " from snapshot only..." : "..."));
            refreshAllSchemaInformation();
        }
    }
    
    public void forceRefresh() {
        refreshAllSchemaInformation();
    }

    private boolean loadSnapshotFromDisk() {
        if (!enableLoad) {
            return false;
        }
        try {
            Path pathToLoad = snapshotPath;
            if (!Files.exists(pathToLoad)) {
                Path legacyPath = resolveLegacySnapshotPath();
                if (legacyPath != null && !legacyPath.equals(snapshotPath) && Files.exists(legacyPath)) {
                    pathToLoad = legacyPath;
                    System.out.println("SCHEMA_CACHE: Falling back to legacy snapshot path: " + legacyPath);
                } else {
                    return false;
                }
            }
            byte[] bytes = Files.readAllBytes(pathToLoad);
            SchemaSnapshot snapshot = OBJECT_MAPPER.readValue(bytes, SchemaSnapshot.class);
            applySnapshot(snapshot);
            System.out.println("SCHEMA_CACHE: Loaded schema snapshot from disk: " + pathToLoad);
            if (!pathToLoad.equals(snapshotPath)) {
                persistSnapshotToDisk();
            }
            return true;
        } catch (Exception e) {
            System.err.println("SCHEMA_CACHE: Failed to load schema snapshot: " + e.getMessage());
            return false;
        }
    }

    private void persistSnapshotToDisk() {
        try {
            Path parent = snapshotPath.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            SchemaSnapshot snapshot = SchemaSnapshot.fromState(
                lastRefresh,
                snapshotTransactionId,
                snapshotBuildConsistent,
                snapshotDatabaseKey,
                labelToProperties,
                propertyDetails,
                labelCounts,
                tripleStats,
                numericRanges,
                histogramBoundaries,
                commonValues,
                keyProperties,
                functionalRelationships
            );
            snapshot.degreeWitnesses = new TreeMap<>(degreeWitnesses);
            byte[] bytes = OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsBytes(snapshot);
            Files.write(snapshotPath, bytes);
            System.out.println("SCHEMA_CACHE: Persisted schema snapshot to " + snapshotPath);
        } catch (Exception e) {
            System.err.println("SCHEMA_CACHE: Failed to persist schema snapshot: " + e.getMessage());
        }
    }

    private void applySnapshot(SchemaSnapshot snapshot) {
        labelToProperties.clear();
        propertyDetails.clear();
        labelCounts.clear();
        tripleStats.clear();
        relationshipTypeCounts.clear();
        allLabels.clear();
        allProperties.clear();
        numericRanges.clear();
        histogramBoundaries.clear();
        commonValues.clear();
        keyProperties.clear();
        degreeWitnesses.clear();
        functionalRelationships.clear();

        snapshotTransactionId = snapshot.snapshotTransactionId;
        snapshotBuildConsistent = snapshot.snapshotBuildConsistent;
        snapshotDatabaseKey = snapshot.databaseKey;

        snapshot.labelToProperties.forEach((label, props) -> {
            labelToProperties.put(label, ConcurrentHashMap.newKeySet());
            labelToProperties.get(label).addAll(props);
            allLabels.add(label);
            allProperties.addAll(props);
        });

        snapshot.propertyDetails.forEach((label, propMap) -> {
            Map<String, PropertyInfo> infoMap = new ConcurrentHashMap<>();
            propMap.forEach((prop, dto) -> infoMap.put(prop, dto.toPropertyInfo()));
            propertyDetails.put(label, infoMap);
        });

        labelCounts.putAll(snapshot.labelCounts);

        for (SchemaTripleDTO tripleDto : snapshot.triples) {
            SchemaGraph.SchemaTriple triple = new SchemaGraph.SchemaTriple(
                tripleDto.sourceLabel, tripleDto.relationshipType, tripleDto.targetLabel);
            double maxOut = tripleDto.maxOutDegree > 0.0 ? tripleDto.maxOutDegree : -1.0;
            double maxIn = tripleDto.maxInDegree > 0.0 ? tripleDto.maxInDegree : -1.0;
            // Unlike max, a genuine minimum of exactly 0 is common and meaningful
            // (some node has no matching edge -- Proposition 2's bound is correctly
            // uninformative there), so the "not collected" sentinel check is >= 0
            // against the -1.0 default, not > 0.
            double minOut = tripleDto.minOutDegree >= 0.0 ? tripleDto.minOutDegree : -1.0;
            double minIn = tripleDto.minInDegree >= 0.0 ? tripleDto.minInDegree : -1.0;
            SchemaGraph.TripleStats stats = new SchemaGraph.TripleStats(
                tripleDto.edgeCount, tripleDto.avgOutDegree, tripleDto.avgInDegree,
                maxOut, maxIn, minOut, minIn);
            tripleStats.put(triple, stats);
            if (tripleDto.relationshipType != null && !tripleDto.relationshipType.isBlank()) {
                relationshipTypeCounts.merge(tripleDto.relationshipType, tripleDto.edgeCount, Long::sum);
            }
        }

        if (snapshot.numericRanges != null) {
            numericRanges.putAll(snapshot.numericRanges);
        }
        if (snapshot.histogramBoundaries != null) {
            histogramBoundaries.putAll(snapshot.histogramBoundaries);
        }
        if (snapshot.commonValues != null) {
            commonValues.putAll(snapshot.commonValues);
        }
        if (snapshot.degreeWitnesses != null) {
            degreeWitnesses.putAll(snapshot.degreeWitnesses);
        }
        if (snapshot.keyProperties != null) {
            snapshot.keyProperties.forEach((label, props) -> {
                keyProperties.put(label, ConcurrentHashMap.newKeySet());
                keyProperties.get(label).addAll(props);
            });
        }
        if (snapshot.functionalRelationships != null) {
            snapshot.functionalRelationships.forEach((label, rels) -> {
                functionalRelationships.put(label, ConcurrentHashMap.newKeySet());
                functionalRelationships.get(label).addAll(rels);
            });
        }

        long loadedAt = System.currentTimeMillis();
        if (snapshot.lastRefresh > 0 && !snapshotOnlyMode) {
            lastRefresh = snapshot.lastRefresh;
        } else {
            lastRefresh = loadedAt;
        }
    }
}
