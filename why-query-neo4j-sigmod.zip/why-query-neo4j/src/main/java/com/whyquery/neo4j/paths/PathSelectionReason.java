package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Explains why a specific path was selected by the path algorithm
 */
public class PathSelectionReason {
    
    private PathInstance chosenPath;
    private List<PathInstance> alternativePaths;
    private String primaryCriterion;
    private List<String> secondaryFactors;
    private List<String> decisiveFactors;
    private List<PathComparison> comparisons;
    
    public PathSelectionReason() {
        this.alternativePaths = new ArrayList<>();
        this.secondaryFactors = new ArrayList<>();
        this.decisiveFactors = new ArrayList<>();
        this.comparisons = new ArrayList<>();
    }
    
    public PathInstance getChosenPath() {
        return chosenPath;
    }
    
    public void setChosenPath(PathInstance chosenPath) {
        this.chosenPath = chosenPath;
    }
    
    public List<PathInstance> getAlternativePaths() {
        return alternativePaths;
    }
    
    public void setAlternativePaths(List<PathInstance> alternativePaths) {
        this.alternativePaths = alternativePaths;
    }
    
    public void addAlternativePath(PathInstance path) {
        this.alternativePaths.add(path);
    }
    
    public String getPrimaryCriterion() {
        return primaryCriterion;
    }
    
    public void setPrimaryCriterion(String primaryCriterion) {
        this.primaryCriterion = primaryCriterion;
    }
    
    public List<String> getSecondaryFactors() {
        return secondaryFactors;
    }
    
    public void setSecondaryFactors(List<String> secondaryFactors) {
        this.secondaryFactors = secondaryFactors;
    }
    
    public void addSecondaryFactor(String factor) {
        this.secondaryFactors.add(factor);
    }
    
    public List<String> getDecisiveFactors() {
        return decisiveFactors;
    }
    
    public void setDecisiveFactors(List<String> decisiveFactors) {
        this.decisiveFactors = decisiveFactors;
    }
    
    public void addDecisiveFactor(String factor) {
        this.decisiveFactors.add(factor);
    }
    
    public List<PathComparison> getComparisons() {
        return comparisons;
    }
    
    public void setComparisons(List<PathComparison> comparisons) {
        this.comparisons = comparisons;
    }
    
    public void addComparison(PathComparison comparison) {
        this.comparisons.add(comparison);
    }
    
    /**
     * Check if there were alternative paths available
     */
    public boolean hasAlternatives() {
        return !alternativePaths.isEmpty();
    }
    
    /**
     * Check if the chosen path is clearly superior
     */
    public boolean isClearChoice() {
        if (!hasAlternatives()) return true;
        
        // Check if chosen path beats alternatives on primary criterion
        return comparisons.stream().allMatch(comp -> 
            "A".equals(comp.getFavoredPath()) || "NEUTRAL".equals(comp.getFavoredPath())
        );
    }
    
    /**
     * Get the most competitive alternative path
     */
    public PathInstance getMostCompetitiveAlternative() {
        if (comparisons.isEmpty()) return null;
        
        return comparisons.stream()
            .min(Comparator.comparing(comp -> Math.abs(comp.getOverallDifference())))
            .map(PathComparison::getPathB)
            .orElse(null);
    }
    
    /**
     * Get comparison with the most competitive alternative
     */
    public PathComparison getMostCompetitiveComparison() {
        if (comparisons.isEmpty()) return null;
        
        return comparisons.stream()
            .min(Comparator.comparing(comp -> Math.abs(comp.getOverallDifference())))
            .orElse(null);
    }
    
    /**
     * Get all factors that contributed to the selection
     */
    public List<String> getAllContributingFactors() {
        List<String> allFactors = new ArrayList<>();
        allFactors.add(primaryCriterion);
        allFactors.addAll(secondaryFactors);
        allFactors.addAll(decisiveFactors);
        return allFactors;
    }
    
    /**
     * Get selection confidence score (0-1)
     */
    public double getSelectionConfidence() {
        if (!hasAlternatives()) {
            return 1.0; // No alternatives, fully confident
        }
        
        if (comparisons.isEmpty()) {
            return 0.5; // No comparison data
        }
        
        // Calculate confidence based on how much better chosen path is
        double totalAdvantage = 0.0;
        int significantComparisons = 0;
        
        for (PathComparison comparison : comparisons) {
            if (comparison.hasSignificantDifference()) {
                if ("A".equals(comparison.getFavoredPath())) {
                    totalAdvantage += Math.abs(comparison.getOverallDifference());
                } else {
                    totalAdvantage -= Math.abs(comparison.getOverallDifference());
                }
                significantComparisons++;
            }
        }
        
        if (significantComparisons == 0) {
            return 0.5; // No significant differences
        }
        
        double averageAdvantage = totalAdvantage / significantComparisons;
        
        // Convert to confidence score (0-1)
        return Math.max(0.0, Math.min(1.0, 0.5 + averageAdvantage));
    }
    
    /**
     * Generate a summary of the selection reason
     */
    public SelectionSummary getSummary() {
        SelectionSummary summary = new SelectionSummary();
        summary.primaryCriterion = primaryCriterion;
        summary.hasAlternatives = hasAlternatives();
        summary.alternativeCount = alternativePaths.size();
        summary.isClearChoice = isClearChoice();
        summary.confidence = getSelectionConfidence();
        summary.decisiveFactorCount = decisiveFactors.size();
        summary.mostCompetitiveAlternative = getMostCompetitiveAlternative();
        
        return summary;
    }
    
    @Override
    public String toString() {
        return "PathSelectionReason{" +
               "primaryCriterion='" + primaryCriterion + '\'' +
               ", alternativeCount=" + alternativePaths.size() +
               ", decisiveFactors=" + decisiveFactors.size() +
               ", confidence=" + String.format("%.2f", getSelectionConfidence()) +
               '}';
    }
    
    /**
     * Summary of path selection reasoning
     */
    public static class SelectionSummary {
        public String primaryCriterion;
        public boolean hasAlternatives;
        public int alternativeCount;
        public boolean isClearChoice;
        public double confidence;
        public int decisiveFactorCount;
        public PathInstance mostCompetitiveAlternative;
        
        @Override
        public String toString() {
            if (!hasAlternatives) {
                return "Only path available: " + primaryCriterion;
            } else if (isClearChoice) {
                return String.format("Clear choice: %s (confidence: %.1f%%, %d alternatives)", 
                                   primaryCriterion, confidence * 100, alternativeCount);
            } else {
                return String.format("Competitive choice: %s (confidence: %.1f%%, %d factors, %d alternatives)",
                                   primaryCriterion, confidence * 100, decisiveFactorCount, alternativeCount);
            }
        }
    }
}