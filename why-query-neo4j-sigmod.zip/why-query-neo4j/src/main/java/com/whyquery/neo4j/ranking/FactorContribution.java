package com.whyquery.neo4j.ranking;

/**
 * Represents the contribution of a single ranking factor to the difference
 * between two entities in a ranking comparison.
 */
public class FactorContribution {
    
    private final RankingFactor factor;
    private Object valueA;
    private Object valueB;
    private double contributionDifference;
    private String favorsEntity; // "A", "B", or "NEUTRAL"
    
    public FactorContribution(RankingFactor factor) {
        this.factor = factor;
    }
    
    public RankingFactor getFactor() {
        return factor;
    }
    
    public Object getValueA() {
        return valueA;
    }
    
    public void setValueA(Object valueA) {
        this.valueA = valueA;
    }
    
    public Object getValueB() {
        return valueB;
    }
    
    public void setValueB(Object valueB) {
        this.valueB = valueB;
    }
    
    public double getContributionDifference() {
        return contributionDifference;
    }
    
    public void setContributionDifference(double contributionDifference) {
        this.contributionDifference = contributionDifference;
    }
    
    public String getFavorsEntity() {
        return favorsEntity;
    }
    
    public void setFavorsEntity(String favorsEntity) {
        this.favorsEntity = favorsEntity;
    }
    
    /**
     * Get the absolute contribution magnitude
     */
    public double getAbsoluteContribution() {
        return Math.abs(contributionDifference);
    }
    
    /**
     * Check if this factor makes a significant contribution
     */
    public boolean isSignificantContribution() {
        return getAbsoluteContribution() > 0.1;
    }
    
    /**
     * Get a human-readable description of the value difference
     */
    public String getValueDifferenceDescription() {
        if (valueA == null && valueB == null) {
            return "Both values are null";
        } else if (valueA == null) {
            return "Entity A has null value, Entity B has " + valueB;
        } else if (valueB == null) {
            return "Entity A has " + valueA + ", Entity B has null value";
        } else {
            return String.format("Entity A: %s, Entity B: %s", valueA, valueB);
        }
    }
    
    /**
     * Get a description of how this factor affects ranking
     */
    public String getImpactDescription() {
        if ("NEUTRAL".equals(favorsEntity)) {
            return "No ranking impact (values are equal)";
        }
        
        String direction = factor.getDirection();
        String favoredEntity = getFavorsEntity();
        double impact = getAbsoluteContribution();
        
        return String.format("Favors Entity %s by %.2f points (%s ordering)", 
                           favoredEntity, impact, direction);
    }
    
    /**
     * Get formatted string showing the contribution calculation
     */
    public String getCalculationDetails() {
        double scoreA = factor.calculateContribution(valueA);
        double scoreB = factor.calculateContribution(valueB);
        
        return String.format("%s: A=%.2f, B=%.2f, Difference=%.2f (weight=%.2f, direction=%s)",
                           factor.getExpression(), scoreA, scoreB, contributionDifference,
                           factor.getWeight(), factor.getDirection());
    }
    
    @Override
    public String toString() {
        return "FactorContribution{" +
               "factor=" + factor.getExpression() +
               ", valueA=" + valueA +
               ", valueB=" + valueB +
               ", contributionDifference=" + contributionDifference +
               ", favorsEntity='" + favorsEntity + '\'' +
               '}';
    }
}