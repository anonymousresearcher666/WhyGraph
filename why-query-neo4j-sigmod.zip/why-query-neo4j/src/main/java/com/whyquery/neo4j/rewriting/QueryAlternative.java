package com.whyquery.neo4j.rewriting;

import java.util.List;

/**
 * Represents a single query rewriting alternative with its associated costs and metrics
 */
public class QueryAlternative {
    
    private final String rewrittenQuery;
    private final List<ModificationStep> modifications;
    private final long actualCardinality;
    private final double performanceCost;
    private final double semanticDistance;
    private final double fScore;
    private final int iterations;
    private final String explanation;
    
    // Cost breakdown
    private final long estCost;
    private final long estimatedRows;
    private final double executionTimeEstimate;
    private final double modificationComplexity;
    
    public QueryAlternative(String rewrittenQuery, 
                           List<ModificationStep> modifications,
                           long actualCardinality,
                           double performanceCost,
                           double semanticDistance,
                           double fScore,
                           int iterations,
                           String explanation,
                           long estCost,
                           long estimatedRows,
                           double executionTimeEstimate,
                           double modificationComplexity) {
        this.rewrittenQuery = rewrittenQuery;
        this.modifications = modifications;
        this.actualCardinality = actualCardinality;
        this.performanceCost = performanceCost;
        this.semanticDistance = semanticDistance;
        this.fScore = fScore;
        this.iterations = iterations;
        this.explanation = explanation;
        this.estCost = estCost;
        this.estimatedRows = estimatedRows;
        this.executionTimeEstimate = executionTimeEstimate;
        this.modificationComplexity = modificationComplexity;
    }
    
    // Getters
    public String getRewrittenQuery() { return rewrittenQuery; }
    public List<ModificationStep> getModifications() { return modifications; }
    public long getActualCardinality() { return actualCardinality; }
    public double getPerformanceCost() { return performanceCost; }
    public double getSemanticDistance() { return semanticDistance; }
    public double getFScore() { return fScore; }
    public int getIterations() { return iterations; }
    public String getExplanation() { return explanation; }
    /**
     * @deprecated Kept for old result serializers. This now returns the
     * EXPLAIN-only estimated plan-work proxy, not runtime DB hits.
     */
    @Deprecated
    public long getDbHits() { return estCost; }
    public long getEstCost() { return estCost; }
    public long getEstimatedRows() { return estimatedRows; }
    public double getExecutionTimeEstimate() { return executionTimeEstimate; }
    public double getModificationComplexity() { return modificationComplexity; }
    
    /**
     * Get a cost summary for user comparison
     */
    public String getCostSummary() {
        return String.format("Performance: %.2f, Semantic Distance: %.2f, Est. plan work: %d, Est. Time: %.3fs, Modifications: %d",
                           performanceCost, semanticDistance, estCost, executionTimeEstimate, modifications.size());
    }
    
    /**
     * Get modification summary
     */
    public String getModificationSummary() {
        if (modifications.isEmpty()) {
            return "No modifications";
        }
        
        StringBuilder summary = new StringBuilder();
        for (int i = 0; i < modifications.size(); i++) {
            if (i > 0) summary.append(", ");
            summary.append(modifications.get(i).getDescription());
        }
        return summary.toString();
    }
    
    /**
     * Calculate overall score for ranking (lower is better)
     */
    public double getOverallScore() {
        // Weighted combination of different cost factors
        return (performanceCost * 0.4) + 
               (semanticDistance * 0.3) + 
               (modificationComplexity * 0.2) + 
               (Math.log(estCost + 1) * 0.1);
    }
    
    @Override
    public String toString() {
        return String.format("QueryAlternative{query='%s', cardinality=%d, cost=%.2f, distance=%.2f, modifications=%d}",
                           rewrittenQuery, actualCardinality, performanceCost, semanticDistance, modifications.size());
    }
}
