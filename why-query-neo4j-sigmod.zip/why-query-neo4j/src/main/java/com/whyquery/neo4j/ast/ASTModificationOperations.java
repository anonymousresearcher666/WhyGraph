package com.whyquery.neo4j.ast;

import java.util.*;

/**
 * AST Modification Operations following Definition 3 from the unified framework.
 * Implements transformation functions θ: A_Q → A_Q' that transform AST nodes 
 * while preserving validity according to Definition 4.
 */
public class ASTModificationOperations {
    
    /**
     * Delete a node from the AST pattern while maintaining connectivity
     * DeleteNode(A_Q, n) = A_Q' where n ∈ N_Node is removed
     */
    public static ModificationResult deleteNode(CypherAST ast, String nodeId) {
        ModificationResult result = new ModificationResult();
        
        ASTNode nodeToDelete = ast.getNode(nodeId);
        if (nodeToDelete == null || nodeToDelete.getType() != NodeType.NODE) {
            result.addError("Node not found or not a NODE type: " + nodeId);
            return result;
        }
        
        CypherAST modifiedAST = ast.deepCopy();
        
        try {
            // Find all relationships connected to this node
            List<ASTNode> connectedRelationships = findConnectedRelationships(modifiedAST, nodeId);
            
            // Remove the node and its connected relationships
            removeNodeAndConnections(modifiedAST, nodeId, connectedRelationships);
            
            // Create bridging relationships if necessary to maintain pattern connectivity
            createBridgingRelationships(modifiedAST, connectedRelationships);

            // Remove empty patterns/matches created by deletion
            removeEmptyPatternsAndMatches(modifiedAST);
            
            // Update variable references throughout the AST
            updateVariableReferences(modifiedAST, nodeToDelete.getAttribute("variable", String.class));
            
            result.setModifiedAST(modifiedAST);
            result.addChange("Deleted node: " + nodeId);
            
        } catch (Exception e) {
            result.addError("Failed to delete node: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Delete a relationship from the AST pattern
     * DeleteRelationship(A_Q, r) = A_Q' where r ∈ N_Relationship is removed
     */
    public static ModificationResult deleteRelationship(CypherAST ast, String relationshipId) {
        ModificationResult result = new ModificationResult();
        
        ASTNode relToDelete = ast.getNode(relationshipId);
        if (relToDelete == null || relToDelete.getType() != NodeType.RELATIONSHIP) {
            result.addError("Relationship not found or not a RELATIONSHIP type: " + relationshipId);
            return result;
        }
        
        CypherAST modifiedAST = ast.deepCopy();
        
        try {
            // Find the pattern containing this relationship
            ASTNode parentPattern = findParentPattern(modifiedAST, relationshipId);
            if (parentPattern != null) {
                // Remove the relationship from the pattern
                removeFromParent(modifiedAST, relationshipId);
                
                // Check if the pattern becomes disconnected and handle accordingly
                handlePatternDisconnection(modifiedAST, parentPattern);
            }

            removeEmptyPatternsAndMatches(modifiedAST);
            
            String relVariable = relToDelete.getAttribute("variable", String.class);
            updateVariableReferences(modifiedAST, relVariable);
            
            result.setModifiedAST(modifiedAST);
            result.addChange("Deleted relationship: " + relationshipId);
            
        } catch (Exception e) {
            result.addError("Failed to delete relationship: " + e.getMessage());
        }
        
        return result;
    }

    /**
     * Replace a relationship type with a new type.
     */
    public static ModificationResult replaceRelationshipType(CypherAST ast, String relationshipId, String newType) {
        ModificationResult result = new ModificationResult();

        ASTNode rel = ast.getNode(relationshipId);
        if (rel == null || rel.getType() != NodeType.RELATIONSHIP) {
            result.addError("Relationship not found or not a RELATIONSHIP type: " + relationshipId);
            return result;
        }
        if (newType == null || newType.isBlank()) {
            result.addError("New relationship type is required");
            return result;
        }

        CypherAST modifiedAST = ast.deepCopy();
        ASTNode modifiedRel = modifiedAST.getNode(relationshipId);
        try {
            String oldType = modifiedRel.getAttribute("type", String.class);
            modifiedRel.setAttribute("type", newType);
            result.setModifiedAST(modifiedAST);
            result.addChange("Replaced relationship type '" + oldType + "' with '" + newType + "'");
        } catch (Exception e) {
            result.addError("Failed to replace relationship type: " + e.getMessage());
        }

        return result;
    }

    /**
     * Flip a directed relationship (OUT <-> IN). Undirected relationships are unchanged.
     */
    public static ModificationResult flipRelationshipDirection(CypherAST ast, String relationshipId) {
        ModificationResult result = new ModificationResult();

        ASTNode rel = ast.getNode(relationshipId);
        if (rel == null || rel.getType() != NodeType.RELATIONSHIP) {
            result.addError("Relationship not found or not a RELATIONSHIP type: " + relationshipId);
            return result;
        }

        CypherAST modifiedAST = ast.deepCopy();
        ASTNode modifiedRel = modifiedAST.getNode(relationshipId);
        try {
            String direction = modifiedRel.getAttribute("direction", String.class);
            if ("OUT".equalsIgnoreCase(direction)) {
                modifiedRel.setAttribute("direction", "IN");
            } else if ("IN".equalsIgnoreCase(direction)) {
                modifiedRel.setAttribute("direction", "OUT");
            } else {
                result.addError("Relationship is undirected; cannot flip direction");
                return result;
            }
            result.setModifiedAST(modifiedAST);
            result.addChange("Flipped relationship direction for: " + relationshipId);
        } catch (Exception e) {
            result.addError("Failed to flip relationship direction: " + e.getMessage());
        }

        return result;
    }
    
    /**
     * Delete a predicate from the WHERE clause
     * DeletePredicate(A_Q, p) = A_Q' where p ∈ N_Predicate is removed
     */
    public static ModificationResult deletePredicate(CypherAST ast, String predicateId) {
        ModificationResult result = new ModificationResult();
        
        ASTNode predToDelete = ast.getNode(predicateId);
        if (predToDelete == null) {
            result.addError("Predicate not found: " + predicateId);
            return result;
        }
        
        CypherAST modifiedAST = ast.deepCopy();
        
        try {
            // Simply remove the node from the AST
            modifiedAST.removeNode(predicateId);
            
            result.setModifiedAST(modifiedAST);
            result.addChange("Deleted predicate: " + predicateId);
            
        } catch (Exception e) {
            result.addError("Failed to delete predicate: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Relax a label constraint by removing a label from a node
     * RelaxLabel(A_Q, n, l) = A_Q' where label l removed from node n
     */
    public static ModificationResult relaxLabel(CypherAST ast, String nodeId, String labelToRemove) {
        ModificationResult result = new ModificationResult();
        
        ASTNode node = ast.getNode(nodeId);
        if (node == null || node.getType() != NodeType.NODE) {
            result.addError("Node not found or not a NODE type: " + nodeId);
            return result;
        }
        
        CypherAST modifiedAST = ast.deepCopy();
        ASTNode modifiedNode = modifiedAST.getNode(nodeId);
        
        try {
            List<String> labels = modifiedNode.getAttribute("labels", List.class);
            if (labels != null && labels.contains(labelToRemove)) {
                List<String> newLabels = new ArrayList<>(labels);
                newLabels.remove(labelToRemove);
                modifiedNode.setAttribute("labels", newLabels);
                
                result.setModifiedAST(modifiedAST);
                result.addChange("Removed label '" + labelToRemove + "' from node: " + nodeId);
            } else {
                result.addWarning("Label '" + labelToRemove + "' not found on node: " + nodeId);
                // Still set the AST even if label wasn't found - the goal is achieved
                result.setModifiedAST(modifiedAST);
            }
            
        } catch (Exception e) {
            result.addError("Failed to relax label: " + e.getMessage());
        }
        
        return result;
    }

    /**
     * Replace endpoint label(s) with a schema-repair label.
     */
    public static ModificationResult repairEndLabel(CypherAST ast, String nodeId, String replacementLabel) {
        ModificationResult result = new ModificationResult();

        ASTNode node = ast.getNode(nodeId);
        if (node == null || node.getType() != NodeType.NODE) {
            result.addError("Node not found or not a NODE type: " + nodeId);
            return result;
        }
        if (replacementLabel == null || replacementLabel.isBlank() || "*".equals(replacementLabel)) {
            result.addError("Replacement label is required");
            return result;
        }

        CypherAST modifiedAST = ast.deepCopy();
        ASTNode modifiedNode = modifiedAST.getNode(nodeId);

        try {
            List<String> newLabels = new ArrayList<>();
            newLabels.add(replacementLabel);
            modifiedNode.setAttribute("labels", newLabels);
            result.setModifiedAST(modifiedAST);
            result.addChange("Repaired endpoint label to '" + replacementLabel + "' on node: " + nodeId);
        } catch (Exception e) {
            result.addError("Failed to repair endpoint label: " + e.getMessage());
        }

        return result;
    }

    /**
     * Replace both endpoint labels of one relationship together, in a single AST copy.
     * Used only when no single-endpoint repair reaches a schema-compatible triple: the two
     * labels are taken from one real schema triple, so the result is compatible by
     * construction, the same soundness guarantee {@link #repairEndLabel} gives one side.
     */
    public static ModificationResult repairBothEndLabels(CypherAST ast,
                                                          String firstNodeId, String firstLabel,
                                                          String secondNodeId, String secondLabel) {
        ModificationResult result = new ModificationResult();

        ASTNode firstNode = ast.getNode(firstNodeId);
        ASTNode secondNode = ast.getNode(secondNodeId);
        if (firstNode == null || firstNode.getType() != NodeType.NODE
            || secondNode == null || secondNode.getType() != NodeType.NODE) {
            result.addError("Endpoint node not found or not a NODE type: " + firstNodeId + ", " + secondNodeId);
            return result;
        }
        if (firstLabel == null || firstLabel.isBlank() || "*".equals(firstLabel)
            || secondLabel == null || secondLabel.isBlank() || "*".equals(secondLabel)) {
            result.addError("Both replacement labels are required");
            return result;
        }

        CypherAST modifiedAST = ast.deepCopy();
        ASTNode modifiedFirst = modifiedAST.getNode(firstNodeId);
        ASTNode modifiedSecond = modifiedAST.getNode(secondNodeId);

        try {
            modifiedFirst.setAttribute("labels", new ArrayList<>(List.of(firstLabel)));
            modifiedSecond.setAttribute("labels", new ArrayList<>(List.of(secondLabel)));
            result.setModifiedAST(modifiedAST);
            result.addChange("Repaired endpoint label to '" + firstLabel + "' on node: " + firstNodeId);
            result.addChange("Repaired endpoint label to '" + secondLabel + "' on node: " + secondNodeId);
        } catch (Exception e) {
            result.addError("Failed to repair both endpoint labels: " + e.getMessage());
        }

        return result;
    }

    /**
     * Replace the property key of one predicate, keeping its operator and literal:
     * RepairPropertyKey(A_Q, p, k') = A_Q' where p's property access v.k becomes v.k'.
     * Used only for a key that no node of the variable's label carries.
     */
    public static ModificationResult repairPropertyKey(CypherAST ast, String predicateId, String newKey) {
        ModificationResult result = new ModificationResult();
        ASTNode predicate = ast != null ? ast.getNode(predicateId) : null;
        if (predicate == null) {
            result.addError("Predicate not found: " + predicateId);
            return result;
        }
        if (newKey == null || newKey.isBlank()) {
            result.addError("Replacement property key is required");
            return result;
        }
        CypherAST modified = ast.deepCopy();
        ASTNode property = null;
        for (ASTNode child : modified.getChildren(predicateId)) {
            if (child != null && child.getType() == NodeType.PROPERTY) {
                property = child;
                break;
            }
        }
        if (property == null) {
            result.addError("Predicate has no property access: " + predicateId);
            return result;
        }
        String oldKey = property.getAttribute("name", String.class);
        property.setAttribute("name", newKey);
        result.setModifiedAST(modified);
        result.addChange("Repaired property key '" + oldKey + "' to '" + newKey + "' in predicate: " + predicateId);
        return result;
    }

    /** Rename one inline property-map key of a node pattern, keeping its value. */
    public static ModificationResult repairInlinePropertyKey(CypherAST ast, String nodeId, String oldKey, String newKey) {
        ModificationResult result = new ModificationResult();
        ASTNode node = ast != null ? ast.getNode(nodeId) : null;
        if (node == null || node.getType() != NodeType.NODE || oldKey == null || newKey == null || newKey.isBlank()) {
            result.addError("Inline property key repair needs a node, the old key and a new key");
            return result;
        }
        CypherAST modified = ast.deepCopy();
        ASTNode modifiedNode = modified.getNode(nodeId);
        Map<String, Object> props = modifiedNode.getAttribute("properties", Map.class);
        if (props == null || !props.containsKey(oldKey) || props.containsKey(newKey)) {
            result.addError("Inline key '" + oldKey + "' not repairable on node: " + nodeId);
            return result;
        }
        Map<String, Object> renamed = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : props.entrySet()) {
            renamed.put(e.getKey().equals(oldKey) ? newKey : e.getKey(), e.getValue());
        }
        modifiedNode.setAttribute("properties", renamed);
        result.setModifiedAST(modified);
        result.addChange("Repaired inline property key '" + oldKey + "' to '" + newKey + "' on node: " + nodeId);
        return result;
    }

    /**
     * Relax a property constraint by expanding it to a range
     * RelaxProperty(A_Q, p, range) = A_Q' where predicate p expanded to range
     */
    public static ModificationResult relaxProperty(CypherAST ast, String predicateId, Object[] range) {
        ModificationResult result = new ModificationResult();
        
        ASTNode predicate = ast.getNode(predicateId);
        if (predicate == null) {
            result.addError("Predicate not found: " + predicateId);
            return result;
        }
        
        CypherAST modifiedAST = ast.deepCopy();
        
        try {
            // Convert equality predicate to range predicate
            convertToRangePredicate(modifiedAST, predicateId, range);
            
            result.setModifiedAST(modifiedAST);
            result.addChange("Relaxed property predicate to range: " + Arrays.toString(range));
            
        } catch (Exception e) {
            result.addError("Failed to relax property: " + e.getMessage());
        }
        
        return result;
    }

    /** Replace only the numeric literal of an existing comparison predicate. */
    public static ModificationResult replacePredicateThreshold(CypherAST ast,
                                                               String predicateId,
                                                               Object threshold) {
        ModificationResult result = new ModificationResult();
        ASTNode predicate = ast != null ? ast.getNode(predicateId) : null;
        if (predicate == null || !isPredicateType(predicate.getType())) {
            result.addError("Comparison predicate not found: " + predicateId);
            return result;
        }
        CypherAST modified = ast.deepCopy();
        ASTNode literal = null;
        for (ASTNode child : modified.getChildren(predicateId)) {
            if (child != null && child.getType() == NodeType.LITERAL) {
                literal = child;
                break;
            }
        }
        if (literal == null) {
            result.addError("Comparison predicate has no literal: " + predicateId);
            return result;
        }
        literal.setAttribute("value", threshold);
        result.setModifiedAST(modified);
        result.addChange("Changed predicate threshold to histogram boundary " + threshold);
        return result;
    }
    
    /**
     * Relax inline node property constraints (from pattern maps)
     */
    public static ModificationResult relaxNodeProperty(CypherAST ast, String nodeId, String propertyName) {
        ModificationResult result = new ModificationResult();
        
        ASTNode node = ast.getNode(nodeId);
        if (node == null || node.getType() != NodeType.NODE) {
            result.addError("Node not found or not a NODE type: " + nodeId);
            return result;
        }
        if (propertyName == null || propertyName.isEmpty()) {
            result.addError("Property name required for inline property relaxation");
            return result;
        }
        
        CypherAST modifiedAST = ast.deepCopy();
        ASTNode modifiedNode = modifiedAST.getNode(nodeId);
        
        try {
            Map<String, Object> properties = modifiedNode.getAttribute("properties", Map.class);
            if (properties == null || !properties.containsKey(propertyName)) {
                result.addWarning("Inline property '" + propertyName + "' not found on node: " + nodeId);
                result.setModifiedAST(modifiedAST);
                return result;
            }
            
            Map<String, Object> newProps = new HashMap<>(properties);
            Object removed = newProps.remove(propertyName);
            if (newProps.isEmpty()) {
                modifiedNode.removeAttribute("properties");
            } else {
                modifiedNode.setAttribute("properties", newProps);
            }
            
            result.setModifiedAST(modifiedAST);
            result.addChange("Removed inline property '" + propertyName + "'" +
                (removed != null ? " (value: " + removed + ")" : ""));
            
        } catch (Exception e) {
            result.addError("Failed to relax inline property: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Convert a MATCH clause to OPTIONAL MATCH
     * OptionalMatch(A_Q, m) = A_Q' where Match m becomes OptionalMatch
     */
    public static ModificationResult makeOptionalMatch(CypherAST ast, String matchId) {
        ModificationResult result = new ModificationResult();
        
        ASTNode matchNode = ast.getNode(matchId);
        if (matchNode == null || matchNode.getType() != NodeType.MATCH) {
            result.addError("Match node not found or not a MATCH type: " + matchId);
            return result;
        }
        
        CypherAST modifiedAST = ast.deepCopy();
        try {
            // OPTIONAL MATCH itself supplies nulls for unmatched variables. Keep
            // the existing pattern, WHERE, and RETURN topology unchanged.
            modifiedAST.replaceNodeType(matchId, NodeType.OPTIONAL_MATCH);
            
            result.setModifiedAST(modifiedAST);
            result.addChange("Converted MATCH to OPTIONAL MATCH: " + matchId);
            
        } catch (Exception e) {
            result.addError("Failed to make optional match: " + e.getMessage());
        }
        
        return result;
    }
    
    // Helper methods
    
    private static List<ASTNode> findConnectedRelationships(CypherAST ast, String nodeId) {
        List<ASTNode> connected = new ArrayList<>();
        String nodeVariable = ast.getNode(nodeId).getAttribute("variable", String.class);
        
        for (ASTNode node : ast.getAllNodes()) {
            if (node.getType() == NodeType.RELATIONSHIP) {
                // Check if this relationship connects to our node
                if (isRelationshipConnectedToNode(ast, node.getId(), nodeVariable)) {
                    connected.add(node);
                }
            }
        }
        
        return connected;
    }
    
    private static boolean isRelationshipConnectedToNode(CypherAST ast, String relationshipId, String nodeVariable) {
        // Find the pattern containing this relationship and check adjacent nodes
        ASTNode pattern = findParentPattern(ast, relationshipId);
        if (pattern == null) return false;
        
        List<ASTNode> patternElements = ast.getChildren(pattern.getId());
        
        // Find position of relationship in pattern
        int relIndex = -1;
        for (int i = 0; i < patternElements.size(); i++) {
            if (patternElements.get(i).getId().equals(relationshipId)) {
                relIndex = i;
                break;
            }
        }
        
        if (relIndex == -1) return false;
        
        // Check adjacent nodes
        if (relIndex > 0) {
            ASTNode prevNode = patternElements.get(relIndex - 1);
            if (prevNode.getType() == NodeType.NODE) {
                String prevVariable = prevNode.getAttribute("variable", String.class);
                if (nodeVariable.equals(prevVariable)) return true;
            }
        }
        
        if (relIndex < patternElements.size() - 1) {
            ASTNode nextNode = patternElements.get(relIndex + 1);
            if (nextNode.getType() == NodeType.NODE) {
                String nextVariable = nextNode.getAttribute("variable", String.class);
                if (nodeVariable.equals(nextVariable)) return true;
            }
        }
        
        return false;
    }
    
    private static void removeNodeAndConnections(CypherAST ast, String nodeId, List<ASTNode> connectedRelationships) {
        // Remove connected relationships first
        for (ASTNode rel : connectedRelationships) {
            removeFromParent(ast, rel.getId());
        }
        
        // Remove the node
        removeFromParent(ast, nodeId);
    }
    
    private static void createBridgingRelationships(CypherAST ast, List<ASTNode> removedRelationships) {
        if (removedRelationships.size() < 2) return;
        
        // Create variable-length path relationships to bridge disconnected parts
        // This is a simplified implementation - real implementation would be more sophisticated
        String bridgeId = ast.addNode(NodeType.RELATIONSHIP, new HashMap<String, Object>() {{
            put("types", Arrays.asList("*"));
            put("direction", "BOTH");
            put("length", Arrays.asList(1, 2));
        }});
        
        // Add to appropriate pattern
        // Implementation would need to find the right pattern and position
    }
    
    private static void updateVariableReferences(CypherAST ast, String removedVariable) {
        if (removedVariable == null) return;
        
        // Remove references from RETURN clause
        for (ASTNode returnNode : ast.getNodesByType(NodeType.RETURN)) {
            List<ASTNode> projections = ast.getChildren(returnNode.getId());
            List<String> toRemove = new ArrayList<>();
            
            for (ASTNode projection : projections) {
                if (projection.getType() == NodeType.PROPERTY) {
                    String variable = projection.getAttribute("variable", String.class);
                    if (removedVariable.equals(variable)) {
                        toRemove.add(projection.getId());
                    }
                } else if (projection.getType() == NodeType.VARIABLE) {
                    String variable = projection.getAttribute("name", String.class);
                    if (removedVariable.equals(variable)) {
                        toRemove.add(projection.getId());
                    }
                }
            }
            
            // Remove the projections
            for (String projId : toRemove) {
                removeFromParent(ast, projId);
            }
            ensureReturnProjection(ast, returnNode.getId(), removedVariable);
        }
        
        // Remove predicates referencing this variable
        removePredicatesReferencingVariable(ast, removedVariable);
    }

    private static void removeEmptyPatternsAndMatches(CypherAST ast) {
        for (ASTNode pattern : ast.getNodesByType(NodeType.PATTERN)) {
            List<ASTNode> patternChildren = ast.getChildren(pattern.getId());
            if (patternChildren == null || patternChildren.isEmpty()) {
                removeFromParent(ast, pattern.getId());
            }
        }

        for (ASTNode match : ast.getNodesByType(NodeType.MATCH)) {
            List<ASTNode> matchChildren = ast.getChildren(match.getId());
            if (matchChildren == null || matchChildren.isEmpty()) {
                removeFromParent(ast, match.getId());
            }
        }

        for (ASTNode match : ast.getNodesByType(NodeType.OPTIONAL_MATCH)) {
            List<ASTNode> matchChildren = ast.getChildren(match.getId());
            if (matchChildren == null || matchChildren.isEmpty()) {
                removeFromParent(ast, match.getId());
            }
        }
    }

    private static void ensureReturnProjection(CypherAST ast, String returnId, String removedVariable) {
        List<ASTNode> projections = ast.getChildren(returnId);
        if (projections != null && !projections.isEmpty()) {
            return;
        }

        String fallbackVariable = findFallbackVariable(ast, removedVariable);
        if (fallbackVariable != null) {
            String varId = ast.addNode(NodeType.VARIABLE, Map.of("name", fallbackVariable));
            ast.addEdge(returnId, varId);
        } else {
            String literalId = ast.addNode(NodeType.LITERAL, Map.of("value", 1));
            ast.addEdge(returnId, literalId);
        }
    }

    private static String findFallbackVariable(CypherAST ast, String removedVariable) {
        Set<String> referenced = new HashSet<>();
        for (List<String> children : ast.getEdges().values()) {
            referenced.addAll(children);
        }

        for (ASTNode node : ast.getNodesByType(NodeType.NODE)) {
            if (!referenced.contains(node.getId())) {
                continue;
            }
            String var = node.getAttribute("variable", String.class);
            if (var != null && !var.isBlank() && !var.equals(removedVariable)) {
                return var;
            }
        }

        for (ASTNode rel : ast.getNodesByType(NodeType.RELATIONSHIP)) {
            if (!referenced.contains(rel.getId())) {
                continue;
            }
            String var = rel.getAttribute("variable", String.class);
            if (var != null && !var.isBlank() && !var.equals(removedVariable)) {
                return var;
            }
        }

        return null;
    }
    
    private static void removePredicatesReferencingVariable(CypherAST ast, String variable) {
        List<String> toRemove = new ArrayList<>();
        
        for (ASTNode node : ast.getAllNodes()) {
            if (node.getType() == NodeType.PROPERTY) {
                String nodeVariable = node.getAttribute("variable", String.class);
                if (variable.equals(nodeVariable)) {
                    // Find the predicate containing this property
                    String predicateId = findPredicateContaining(ast, node.getId());
                    if (predicateId != null) {
                        toRemove.add(predicateId);
                    }
                }
            }
        }
        
        for (String predicateId : toRemove) {
            removePredicate(ast, predicateId);
        }
    }
    
    private static ASTNode findParentPattern(CypherAST ast, String nodeId) {
        for (Map.Entry<String, List<String>> edge : ast.getEdges().entrySet()) {
            if (edge.getValue().contains(nodeId)) {
                ASTNode parent = ast.getNode(edge.getKey());
                if (parent.getType() == NodeType.PATTERN) {
                    return parent;
                }
            }
        }
        return null;
    }
    
    private static void removeFromParent(CypherAST ast, String nodeId) {
        for (Map.Entry<String, List<String>> edge : ast.getEdges().entrySet()) {
            edge.getValue().remove(nodeId);
        }
    }
    
    private static void handlePatternDisconnection(CypherAST ast, ASTNode pattern) {
        // Check if pattern is still connected after relationship removal
        // If not, create bridging elements or split into multiple patterns
        // This is a simplified implementation
    }
    
    private static void removePredicate(CypherAST ast, String predicateId) {
        // Find parent logical operator (AND, OR)
        String parentId = findParentLogicalOperator(ast, predicateId);
        
        if (parentId != null) {
            ASTNode parent = ast.getNode(parentId);
            List<String> children = ast.getEdges().get(parentId);
            
            if (children.size() == 2) {
                // Binary operator with two operands
                children.remove(predicateId);
                
                // Replace parent with remaining operand
                String remainingChild = children.get(0);
                replaceNodeInParent(ast, parentId, remainingChild);
            } else if (children.size() > 2) {
                // Multiple operands, just remove this one
                children.remove(predicateId);
            }
        } else {
            // Direct child of WHERE clause
            removeFromParent(ast, predicateId);
        }
    }
    
    private static void convertToRangePredicate(CypherAST ast, String predicateId, Object[] range) {
        ASTNode predicate = ast.getNode(predicateId);
        if (range == null || range.length != 2) {
            throw new IllegalArgumentException("A range requires two endpoints");
        }
        List<ASTNode> operands = ast.getChildren(predicateId);
        if (predicate == null || operands.size() != 2
            || operands.get(0).getType() != NodeType.PROPERTY
            || operands.get(1).getType() != NodeType.LITERAL) {
            throw new IllegalArgumentException("Expected a property-to-literal comparison");
        }
        // A half-line must remain a half-line when weakened. A bounded interval
        // would discard previously matching values beyond its other endpoint.
        switch (predicate.getType()) {
            case GREATER_THAN: case GREATER_THAN_OR_EQUAL:
                operands.get(1).setAttribute("value", range[0]);
                return;
            case LESS_THAN: case LESS_THAN_OR_EQUAL:
                operands.get(1).setAttribute("value", range[1]);
                return;
            case EQUALS:
                break;
            default:
                throw new IllegalArgumentException("Comparison cannot be weakened to a range");
        }
        
        // Create new range predicate structure
        // Example: age = 30 becomes age >= 25 AND age <= 35
        if (range != null && range.length == 2) {
            String andId = ast.addNode(NodeType.AND, new HashMap<>());
            
            // Create >= predicate
            String geId = ast.addNode(NodeType.GREATER_THAN_OR_EQUAL, new HashMap<>());
            String minLiteralId = ast.addNode(NodeType.LITERAL, new HashMap<String, Object>() {{
                put("value", range[0]);
            }});
            
            // Create <= predicate  
            String leId = ast.addNode(NodeType.LESS_THAN_OR_EQUAL, new HashMap<>());
            String maxLiteralId = ast.addNode(NodeType.LITERAL, new HashMap<String, Object>() {{
                put("value", range[1]);
            }});
            
            // Build the tree structure
            ast.addEdge(andId, geId);
            ast.addEdge(andId, leId);
            ast.addEdge(geId, operands.get(0).getId());
            String propertyCopyId = ast.addNode(NodeType.PROPERTY,
                new HashMap<>(operands.get(0).getAttributes()));
            ast.addEdge(leId, propertyCopyId);
            ast.addEdge(geId, minLiteralId);
            ast.addEdge(leId, maxLiteralId);
            
            // Replace the original predicate
            replaceNodeInParent(ast, predicateId, andId);
            // Unreachable equality nodes must not survive: bound and predicate
            // analyses traverse all nodes, rather than only the rendered tree.
            ast.removeNode(predicateId);
            ast.removeNode(operands.get(1).getId());
        }
    }
    
    private static String findPredicateContaining(CypherAST ast, String nodeId) {
        // Find the predicate node that contains this property reference
        for (Map.Entry<String, List<String>> edge : ast.getEdges().entrySet()) {
            if (edge.getValue().contains(nodeId)) {
                ASTNode parent = ast.getNode(edge.getKey());
                if (isPredicateType(parent.getType())) {
                    return parent.getId();
                }
            }
        }
        return null;
    }
    
    private static boolean isPredicateType(NodeType type) {
        return type == NodeType.EQUALS || type == NodeType.GREATER_THAN || 
               type == NodeType.LESS_THAN || type == NodeType.GREATER_THAN_OR_EQUAL ||
               type == NodeType.LESS_THAN_OR_EQUAL || type == NodeType.NOT_EQUALS ||
               type == NodeType.IN || type == NodeType.CONTAINS;
    }
    
    private static String findParentLogicalOperator(CypherAST ast, String nodeId) {
        for (Map.Entry<String, List<String>> edge : ast.getEdges().entrySet()) {
            if (edge.getValue().contains(nodeId)) {
                ASTNode parent = ast.getNode(edge.getKey());
                if (parent.getType() == NodeType.AND || parent.getType() == NodeType.OR) {
                    return parent.getId();
                }
            }
        }
        return null;
    }
    
    private static void replaceNodeInParent(CypherAST ast, String oldNodeId, String newNodeId) {
        for (Map.Entry<String, List<String>> edge : ast.getEdges().entrySet()) {
            List<String> children = edge.getValue();
            for (int i = 0; i < children.size(); i++) {
                if (children.get(i).equals(oldNodeId)) {
                    children.set(i, newNodeId);
                }
            }
        }
    }
    
    /**
     * Result of an AST modification operation
     */
    public static class ModificationResult {
        private CypherAST modifiedAST;
        private final List<String> changes = new ArrayList<>();
        private final List<String> errors = new ArrayList<>();
        private final List<String> warnings = new ArrayList<>();
        
        public void setModifiedAST(CypherAST ast) {
            this.modifiedAST = ast;
        }
        
        public CypherAST getModifiedAST() {
            return modifiedAST;
        }
        
        public void addChange(String change) {
            changes.add(change);
        }
        
        public void addError(String error) {
            errors.add(error);
        }
        
        public void addWarning(String warning) {
            warnings.add(warning);
        }
        
        public boolean isSuccessful() {
            return errors.isEmpty() && modifiedAST != null;
        }
        
        public List<String> getChanges() {
            return changes;
        }
        
        public List<String> getErrors() {
            return errors;
        }
        
        public List<String> getWarnings() {
            return warnings;
        }
    }
    
    // ========== NEW RESTRICTION OPERATIONS for WHY_MANY ==========
    
    /**
     * Add a predicate constraint to restrict results
     */
    public static ModificationResult addPredicate(CypherAST ast, String nodeId, String property, Object[] range) {
        ModificationResult result = new ModificationResult();
        
        try {
            CypherAST modifiedAST = ast.deepCopy();
            
            // Find or create WHERE clause
            ASTNode whereNode = findOrCreateWhereClause(modifiedAST);
            
            // Create the predicate based on range type
            if (range != null && range.length > 0) {
                String predicateType = (String) range[0];
                
                switch (predicateType) {
                    case "RANGE":
                        addRangePredicate(modifiedAST, whereNode, nodeId, property, range);
                        break;
                    case "NOT_NULL":
                        addNotNullPredicate(modifiedAST, whereNode, nodeId, property);
                        break;
                    case "EXISTS":
                        addExistsPredicate(modifiedAST, whereNode, nodeId, property);
                        break;
                    case "EQUALS":
                        addEqualsPredicate(modifiedAST, whereNode, nodeId, property, range);
                        break;
                    default:
                        break;
                }
            }
            
            result.setModifiedAST(modifiedAST);
            result.addChange("Added predicate: " + property);
            
        } catch (Exception e) {
            result.addError("Failed to add predicate: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Add a LIMIT clause to restrict result count
     */
    public static ModificationResult addLimit(CypherAST ast, Object[] limitValues) {
        ModificationResult result = new ModificationResult();
        
        try {
            CypherAST modifiedAST = ast.deepCopy();
            
            // Check if LIMIT already exists
            if (!modifiedAST.getNodesByType(NodeType.LIMIT).isEmpty()) {
                result.addWarning("LIMIT clause already exists");
                result.setModifiedAST(modifiedAST);
                return result;
            }
            
            // Add LIMIT clause
            if (limitValues != null && limitValues.length > 0) {
                int limitValue = (Integer) limitValues[0];
                
                String limitNodeId = modifiedAST.addNode(NodeType.LIMIT, Map.of("value", limitValue));
                
                // Connect to query root
                connectToQueryRoot(modifiedAST, limitNodeId);
                
                result.setModifiedAST(modifiedAST);
                result.addChange("Added LIMIT " + limitValue);
            }
            
        } catch (Exception e) {
            result.addError("Failed to add LIMIT: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Add ORDER BY clause 
     */
    public static ModificationResult addOrderBy(CypherAST ast, String property, Object[] orderValues) {
        ModificationResult result = new ModificationResult();
        
        try {
            CypherAST modifiedAST = ast.deepCopy();
            
            // Check if ORDER BY already exists
            if (!modifiedAST.getNodesByType(NodeType.ORDER_BY).isEmpty()) {
                result.addWarning("ORDER BY clause already exists");
                result.setModifiedAST(modifiedAST);
                return result;
            }
            
            if (property != null && orderValues != null && orderValues.length > 0) {
                String direction = (String) orderValues[0];
                
                String orderNodeId = modifiedAST.addNode(NodeType.ORDER_BY, 
                    Map.of("property", property, "direction", direction));
                
                connectToQueryRoot(modifiedAST, orderNodeId);
                
                result.setModifiedAST(modifiedAST);
                result.addChange("Added ORDER BY " + property + " " + direction);
            }
            
        } catch (Exception e) {
            result.addError("Failed to add ORDER BY: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Add label to a node for more specificity
     */
    public static ModificationResult addLabel(CypherAST ast, String nodeId, String label) {
        ModificationResult result = new ModificationResult();
        
        try {
            CypherAST modifiedAST = ast.deepCopy();
            ASTNode node = modifiedAST.getNode(nodeId);
            
            if (node != null && node.getType() == NodeType.NODE) {
                List<String> labels = node.getAttribute("labels", List.class);
                if (labels == null) {
                    labels = new ArrayList<>();
                }
                
                if (!labels.contains(label)) {
                    labels.add(label);
                    node.setAttribute("labels", labels);
                    
                    result.setModifiedAST(modifiedAST);
                    result.addChange("Added label: " + label);
                }
            }
            
        } catch (Exception e) {
            result.addError("Failed to add label: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Add relationship constraint
     */
    public static ModificationResult addRelationship(CypherAST ast, String nodeId, String relType) {
        ModificationResult result = new ModificationResult();
        
        try {
            CypherAST modifiedAST = ast.deepCopy();
            ASTNode anchorNode = modifiedAST.getNode(nodeId);
            if (anchorNode == null || anchorNode.getType() != NodeType.NODE) {
                result.addError("Target node not found for relationship addition: " + nodeId);
                return result;
            }
            
            ASTNode patternNode = findParentPattern(modifiedAST, nodeId);
            if (patternNode == null) {
                result.addError("Unable to locate pattern for node: " + nodeId);
                return result;
            }
            
            List<String> patternChildren = modifiedAST.getEdges().get(patternNode.getId());
            if (patternChildren == null) {
                result.addError("Pattern structure missing for node: " + nodeId);
                return result;
            }
            
            int anchorIndex = patternChildren.indexOf(nodeId);
            if (anchorIndex < 0) {
                result.addError("Node " + nodeId + " not part of expected pattern");
                return result;
            }
            
            String baseVar = anchorNode.getAttribute("variable", String.class);
            String newVar = generateFreshVariableName(modifiedAST, baseVar != null ? baseVar + "_rel" : "n_rel");
            Map<String, Object> newNodeAttrs = new HashMap<>();
            newNodeAttrs.put("variable", newVar);
            String newNodeId = modifiedAST.addNode(NodeType.NODE, newNodeAttrs);
            
            Map<String, Object> relAttrs = new HashMap<>();
            if (relType != null && !relType.isEmpty()) {
                relAttrs.put("type", relType);
            }
            relAttrs.put("direction", "OUT");
            String relationshipId = modifiedAST.addNode(NodeType.RELATIONSHIP, relAttrs);
            
            modifiedAST.addEdge(patternNode.getId(), relationshipId);
            modifiedAST.addEdge(patternNode.getId(), newNodeId);
            moveChild(patternChildren, relationshipId, anchorIndex + 1);
            moveChild(patternChildren, newNodeId, anchorIndex + 2);
            
            result.setModifiedAST(modifiedAST);
            String relDesc = relType != null ? ":" + relType : "";
            result.addChange("Added relationship " + relDesc + " from " +
                (baseVar != null ? baseVar : nodeId) + " to " + newVar);
            
        } catch (Exception e) {
            result.addError("Failed to add relationship: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * Restrict property range
     */
    public static ModificationResult restrictProperty(CypherAST ast, String nodeId, String property, Object[] range) {
        ModificationResult result = new ModificationResult();
        
        try {
            CypherAST modifiedAST = ast.deepCopy();
            ASTNode targetNode = modifiedAST.getNode(nodeId);
            if (targetNode == null || targetNode.getType() != NodeType.NODE) {
                result.addError("Target node not found for property restriction: " + nodeId);
                return result;
            }
            if (property == null || property.trim().isEmpty()) {
                result.addError("Property name is required for restriction");
                return result;
            }
            
            ASTNode whereNode = findOrCreateWhereClause(modifiedAST);
            boolean applied = applyRestrictionPredicate(modifiedAST, whereNode, nodeId, property, range);
            
            result.setModifiedAST(modifiedAST);
            if (applied) {
                String variable = getVariableForNode(modifiedAST, nodeId);
                result.addChange("Restricted property '" + property + "' on " +
                    (variable != null ? variable : nodeId));
            } else {
                result.addWarning("No restriction predicate generated for property '" + property + "'");
            }
            
        } catch (Exception e) {
            result.addError("Failed to restrict property: " + e.getMessage());
        }
        
        return result;
    }
    
    // Helper methods for restriction operations
    
    private static ASTNode findOrCreateWhereClause(CypherAST ast) {
        ASTNode lastPatternClause = null;
        for (ASTNode child : ast.getChildren(ast.getRoot().getId())) {
            if (child.getType() == NodeType.MATCH || child.getType() == NodeType.OPTIONAL_MATCH
                    || child.getType() == NodeType.WHERE) lastPatternClause = child;
        }
        if (lastPatternClause != null && lastPatternClause.getType() == NodeType.WHERE) {
            return lastPatternClause;
        }
        
        // Create new WHERE clause
        String whereNodeId = ast.addNode(NodeType.WHERE, new HashMap<>());
        connectToQueryRoot(ast, whereNodeId);
        return ast.getNode(whereNodeId);
    }
    
    private static void addRangePredicate(CypherAST ast, ASTNode whereNode, String nodeId, String property, Object[] range) {
        if (range.length >= 3) {
            Object min = range[1];
            Object max = range[2];
            
            String variable = getVariableForNode(ast, nodeId);
            if (variable == null) {
                return;
            }
            
            // >= predicate
            String geNodeId = ast.addNode(NodeType.GREATER_THAN_OR_EQUAL, new HashMap<>());
            String propNodeIdGE = ast.addNode(NodeType.PROPERTY, Map.of("variable", variable, "name", property));
            String minNodeId = ast.addNode(NodeType.LITERAL, Map.of("value", min));
            ast.addEdge(geNodeId, propNodeIdGE);
            ast.addEdge(geNodeId, minNodeId);
            ast.addEdge(whereNode.getId(), geNodeId);
            
            // <= predicate
            String leNodeId = ast.addNode(NodeType.LESS_THAN_OR_EQUAL, new HashMap<>());
            String propNodeIdLE = ast.addNode(NodeType.PROPERTY, Map.of("variable", variable, "name", property));
            String maxNodeId = ast.addNode(NodeType.LITERAL, Map.of("value", max));
            ast.addEdge(leNodeId, propNodeIdLE);
            ast.addEdge(leNodeId, maxNodeId);
            ast.addEdge(whereNode.getId(), leNodeId);
        }
    }
    
    private static void addNotNullPredicate(CypherAST ast, ASTNode whereNode, String nodeId, String property) {
        String variable = getVariableForNode(ast, nodeId);
        if (variable != null) {
            String isNotNullNodeId = ast.addNode(NodeType.IS_NOT_NULL, new HashMap<>());
            String propNodeId = ast.addNode(NodeType.PROPERTY, Map.of("variable", variable, "name", property));
            
            ast.addEdge(isNotNullNodeId, propNodeId);
            ast.addEdge(whereNode.getId(), isNotNullNodeId);
        }
    }
    
    private static void addExistsPredicate(CypherAST ast, ASTNode whereNode, String nodeId, String property) {
        String variable = getVariableForNode(ast, nodeId);
        if (variable != null) {
            String existsNodeId = ast.addNode(NodeType.EXISTS, new HashMap<>());
            String propNodeId = ast.addNode(NodeType.PROPERTY, Map.of("variable", variable, "name", property));
            
            ast.addEdge(existsNodeId, propNodeId);
            ast.addEdge(whereNode.getId(), existsNodeId);
        }
    }
    
    private static void addEqualsPredicate(CypherAST ast, ASTNode whereNode, String nodeId, String property, Object[] range) {
        if (range.length < 2) {
            return;
        }
        Object value = range[1];
        String variable = getVariableForNode(ast, nodeId);
        if (variable == null) {
            return;
        }
        String equalsNodeId = ast.addNode(NodeType.EQUALS, new HashMap<>());
        String propNodeId = ast.addNode(NodeType.PROPERTY, Map.of("variable", variable, "name", property));
        String literalNodeId = ast.addNode(NodeType.LITERAL, Map.of("value", value));
        
        ast.addEdge(equalsNodeId, propNodeId);
        ast.addEdge(equalsNodeId, literalNodeId);
        ast.addEdge(whereNode.getId(), equalsNodeId);
    }
    
    private static String getVariableForNode(CypherAST ast, String nodeId) {
        ASTNode node = ast.getNode(nodeId);
        return node != null ? node.getAttribute("variable", String.class) : null;
    }
    
    private static void connectToQueryRoot(CypherAST ast, String nodeId) {
        // Connect the new node to the query structure
        List<ASTNode> queryNodes = ast.getNodesByType(NodeType.QUERY);
        if (!queryNodes.isEmpty()) {
            String queryId = queryNodes.get(0).getId();
            ast.addEdge(queryId, nodeId);
            reorderQueryChildren(ast, queryId);
        }
    }

    private static void reorderQueryChildren(CypherAST ast, String queryId) {
        List<String> children = ast.getEdges().get(queryId);
        if (children == null || children.size() < 2) {
            return;
        }

        Map<String, Integer> originalIndex = new HashMap<>();
        for (int i = 0; i < children.size(); i++) {
            originalIndex.put(children.get(i), i);
        }

        children.sort((a, b) -> {
            ASTNode nodeA = ast.getNode(a);
            ASTNode nodeB = ast.getNode(b);
            int orderA = clauseOrder(nodeA != null ? nodeA.getType() : null);
            int orderB = clauseOrder(nodeB != null ? nodeB.getType() : null);
            if (orderA != orderB) {
                return Integer.compare(orderA, orderB);
            }
            return Integer.compare(originalIndex.getOrDefault(a, 0), originalIndex.getOrDefault(b, 0));
        });
    }

    private static int clauseOrder(NodeType type) {
        if (type == null) {
            return 100;
        }
        switch (type) {
            case MATCH:
            case OPTIONAL_MATCH:
            case WHERE:
                // These clauses form a scope-sensitive sequence. Preserve their
                // original order when inserting a final filter before RETURN.
                return 10;
            case WITH:
                return 25;
            case RETURN:
                return 30;
            case ORDER_BY:
                return 40;
            case SKIP:
                return 45;
            case LIMIT:
                return 50;
            default:
                return 100;
        }
    }
    
    private static boolean applyRestrictionPredicate(CypherAST ast, ASTNode whereNode,
                                                     String nodeId, String property, Object[] range) {
        if (range == null || range.length == 0) {
            addNotNullPredicate(ast, whereNode, nodeId, property);
            return true;
        }
        
        Object first = range[0];
        if (first instanceof String) {
            String mode = ((String) first).toUpperCase(Locale.ROOT);
            switch (mode) {
                case "EQUALS":
                    if (range.length >= 2) {
                        addEqualsPredicate(ast, whereNode, nodeId, property, range);
                        return true;
                    }
                    break;
                case "RANGE":
                    if (range.length >= 3) {
                        addRangePredicate(ast, whereNode, nodeId, property, range);
                        return true;
                    }
                    break;
                case "NOT_NULL":
                    addNotNullPredicate(ast, whereNode, nodeId, property);
                    return true;
                case "EXISTS":
                    addExistsPredicate(ast, whereNode, nodeId, property);
                    return true;
                default:
                    break;
            }
        } else if (range.length == 1) {
            addEqualsPredicate(ast, whereNode, nodeId, property, new Object[]{null, range[0]});
            return true;
        } else if (range.length >= 2) {
            addRangePredicate(ast, whereNode, nodeId, property, new Object[]{"RANGE", range[0], range[1]});
            return true;
        }
        
        return false;
    }
    
    private static String generateFreshVariableName(CypherAST ast, String base) {
        String prefix = (base != null && !base.isBlank()) ? base : "n";
        prefix = prefix.replaceAll("[^A-Za-z0-9_]", "_");
        if (prefix.isBlank()) {
            prefix = "n";
        }
        Set<String> existing = ast.getVariables();
        String candidate = prefix;
        int counter = 1;
        while (existing.contains(candidate)) {
            candidate = prefix + "_" + counter++;
        }
        return candidate;
    }
    
    private static void moveChild(List<String> children, String childId, int targetIndex) {
        if (children == null || childId == null) {
            return;
        }
        if (!children.remove(childId)) {
            return;
        }
        int index = Math.max(0, Math.min(targetIndex, children.size()));
        children.add(index, childId);
    }
}
