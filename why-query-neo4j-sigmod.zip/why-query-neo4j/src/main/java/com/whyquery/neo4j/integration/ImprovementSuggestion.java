package com.whyquery.neo4j.integration;

import java.util.*;

/**
 * Represents a concrete improvement suggestion for a query,
 * combining insights from both ranking and path analysis.
 */
public class ImprovementSuggestion {
    
    private String category; // "Ranking", "Path", "Combined"
    private String title;
    private String description;
    private String modifiedQuery;
    private double effectiveness;
    private List<String> benefits;
    private List<String> tradeoffs;
    private String rationale;
    private SuggestionPriority priority;
    private Map<String, Object> metadata;
    
    public ImprovementSuggestion() {
        this.benefits = new ArrayList<>();
        this.tradeoffs = new ArrayList<>();
        this.metadata = new HashMap<>();
        this.effectiveness = 0.5;
        this.priority = SuggestionPriority.MEDIUM;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
        updatePriorityFromEffectiveness();
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getModifiedQuery() {
        return modifiedQuery;
    }
    
    public void setModifiedQuery(String modifiedQuery) {
        this.modifiedQuery = modifiedQuery;
    }
    
    public double getEffectiveness() {
        return effectiveness;
    }
    
    public void setEffectiveness(double effectiveness) {
        this.effectiveness = effectiveness;
        updatePriorityFromEffectiveness();
    }
    
    public List<String> getBenefits() {
        return benefits;
    }
    
    public void setBenefits(List<String> benefits) {
        this.benefits = benefits;
    }
    
    public void addBenefit(String benefit) {
        this.benefits.add(benefit);
    }
    
    public List<String> getTradeoffs() {
        return tradeoffs;
    }
    
    public void setTradeoffs(List<String> tradeoffs) {
        this.tradeoffs = tradeoffs;
    }
    
    public void addTradeoff(String tradeoff) {
        this.tradeoffs.add(tradeoff);
    }
    
    public String getRationale() {
        return rationale;
    }
    
    public void setRationale(String rationale) {
        this.rationale = rationale;
    }
    
    public SuggestionPriority getPriority() {
        return priority;
    }
    
    public void setPriority(SuggestionPriority priority) {
        this.priority = priority;
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    /**
     * Update priority based on effectiveness score
     */
    private void updatePriorityFromEffectiveness() {
        if (effectiveness >= 0.8) {
            priority = SuggestionPriority.CRITICAL;
        } else if (effectiveness >= 0.6) {
            priority = SuggestionPriority.HIGH;
        } else if (effectiveness >= 0.4) {
            priority = SuggestionPriority.MEDIUM;
        } else {
            priority = SuggestionPriority.LOW;
        }
    }
    
    /**
     * Get the impact level of this suggestion
     */
    public ImpactLevel getImpactLevel() {
        if (effectiveness >= 0.8) {
            return ImpactLevel.MAJOR;
        } else if (effectiveness >= 0.6) {
            return ImpactLevel.MODERATE;
        } else if (effectiveness >= 0.4) {
            return ImpactLevel.MINOR;
        } else {
            return ImpactLevel.MINIMAL;
        }
    }
    
    /**
     * Check if this suggestion should be applied automatically
     */
    public boolean isAutoApplicable() {
        return effectiveness >= 0.9 && tradeoffs.isEmpty();
    }
    
    /**
     * Get a formatted description of benefits vs tradeoffs
     */
    public String getBenefitTradeoffSummary() {
        StringBuilder summary = new StringBuilder();
        
        if (!benefits.isEmpty()) {
            summary.append("Benefits: ").append(String.join(", ", benefits));
        }
        
        if (!tradeoffs.isEmpty()) {
            if (summary.length() > 0) {
                summary.append(" | ");
            }
            summary.append("Tradeoffs: ").append(String.join(", ", tradeoffs));
        }
        
        return summary.toString();
    }
    
    /**
     * Generate a comprehensive suggestion report
     */
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        
        report.append("=== ").append(category).append(" Improvement Suggestion ===\n");
        report.append("Title: ").append(title).append("\n");
        report.append("Priority: ").append(priority).append(" (").append(String.format("%.0f%%", effectiveness * 100)).append(" effectiveness)\n");
        report.append("Impact: ").append(getImpactLevel()).append("\n\n");
        
        report.append("Description:\n").append(description).append("\n\n");
        
        if (rationale != null && !rationale.trim().isEmpty()) {
            report.append("Rationale:\n").append(rationale).append("\n\n");
        }
        
        if (!benefits.isEmpty() || !tradeoffs.isEmpty()) {
            report.append("Analysis:\n").append(getBenefitTradeoffSummary()).append("\n\n");
        }
        
        if (modifiedQuery != null && !modifiedQuery.trim().isEmpty()) {
            report.append("Modified Query:\n").append(modifiedQuery).append("\n");
        }
        
        return report.toString();
    }
    
    /**
     * Compare suggestions by effectiveness and priority
     */
    public int compareTo(ImprovementSuggestion other) {
        // First compare by priority
        int priorityComparison = this.priority.compareTo(other.priority);
        if (priorityComparison != 0) {
            return -priorityComparison; // Reverse for descending order
        }
        
        // Then by effectiveness
        return Double.compare(other.effectiveness, this.effectiveness);
    }
    
    @Override
    public String toString() {
        return "ImprovementSuggestion{" +
               "category='" + category + '\'' +
               ", title='" + title + '\'' +
               ", effectiveness=" + String.format("%.2f", effectiveness) +
               ", priority=" + priority +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        ImprovementSuggestion that = (ImprovementSuggestion) o;
        
        return Objects.equals(category, that.category) &&
               Objects.equals(title, that.title) &&
               Objects.equals(modifiedQuery, that.modifiedQuery);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(category, title, modifiedQuery);
    }
    
    /**
     * Suggestion priority levels
     */
    public enum SuggestionPriority {
        CRITICAL,
        HIGH,
        MEDIUM,
        LOW
    }
    
    /**
     * Impact levels for suggestions
     */
    public enum ImpactLevel {
        MAJOR,
        MODERATE,
        MINOR,
        MINIMAL
    }
}