package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Represents an alternative path approach with concrete query modifications
 */
public class PathAlternative {
    
    private PathAlternativeType type;
    private String title;
    private String description;
    private String modifiedQuery;
    private double effectivenessScore;
    private List<String> benefits;
    private List<String> tradeoffs;
    private Map<String, Object> metadata;
    
    public PathAlternative() {
        this.benefits = new ArrayList<>();
        this.tradeoffs = new ArrayList<>();
        this.metadata = new HashMap<>();
        this.effectivenessScore = 0.5; // Default neutral score
    }
    
    public PathAlternativeType getType() {
        return type;
    }
    
    public void setType(PathAlternativeType type) {
        this.type = type;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getModifiedQuery() {
        return modifiedQuery;
    }
    
    public void setModifiedQuery(String modifiedQuery) {
        this.modifiedQuery = modifiedQuery;
    }
    
    public double getEffectivenessScore() {
        return effectivenessScore;
    }
    
    public void setEffectivenessScore(double effectivenessScore) {
        this.effectivenessScore = effectivenessScore;
    }
    
    public List<String> getBenefits() {
        return benefits;
    }
    
    public void setBenefits(List<String> benefits) {
        this.benefits = benefits;
    }
    
    public void addBenefit(String benefit) {
        this.benefits.add(benefit);
    }
    
    public List<String> getTradeoffs() {
        return tradeoffs;
    }
    
    public void setTradeoffs(List<String> tradeoffs) {
        this.tradeoffs = tradeoffs;
    }
    
    public void addTradeoff(String tradeoff) {
        this.tradeoffs.add(tradeoff);
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }
    
    /**
     * Check if this alternative is highly recommended
     */
    public boolean isHighlyRecommended() {
        return effectivenessScore >= 0.8;
    }
    
    /**
     * Check if this alternative is experimental
     */
    public boolean isExperimental() {
        return effectivenessScore < 0.4;
    }
    
    /**
     * Get the priority level of this alternative
     */
    public AlternativePriority getPriority() {
        if (effectivenessScore >= 0.8) {
            return AlternativePriority.HIGH;
        } else if (effectivenessScore >= 0.6) {
            return AlternativePriority.MEDIUM;
        } else if (effectivenessScore >= 0.4) {
            return AlternativePriority.LOW;
        } else {
            return AlternativePriority.EXPERIMENTAL;
        }
    }
    
    /**
     * Get a summary of benefits and tradeoffs
     */
    public String getBenefitTradeoffSummary() {
        StringBuilder summary = new StringBuilder();
        
        if (!benefits.isEmpty()) {
            summary.append("Benefits: ").append(String.join(", ", benefits));
        }
        
        if (!tradeoffs.isEmpty()) {
            if (summary.length() > 0) {
                summary.append("; ");
            }
            summary.append("Tradeoffs: ").append(String.join(", ", tradeoffs));
        }
        
        return summary.toString();
    }
    
    /**
     * Get the net benefit score (benefits vs tradeoffs)
     */
    public double getNetBenefitScore() {
        // Simple scoring: benefits add points, tradeoffs subtract
        double score = benefits.size() * 0.3 - tradeoffs.size() * 0.2;
        return Math.max(0.0, Math.min(1.0, 0.5 + score));
    }
    
    /**
     * Check if this alternative addresses a specific concern
     */
    public boolean addressesConcern(String concern) {
        String lowerConcern = concern.toLowerCase();
        
        // Check if any benefit addresses the concern
        return benefits.stream().anyMatch(benefit -> 
            benefit.toLowerCase().contains(lowerConcern)
        ) || description.toLowerCase().contains(lowerConcern);
    }
    
    /**
     * Generate a comprehensive description
     */
    public String getFullDescription() {
        StringBuilder fullDesc = new StringBuilder();
        
        fullDesc.append(title).append(": ").append(description);
        
        fullDesc.append("\nEffectiveness: ").append(String.format("%.0f%%", effectivenessScore * 100));
        fullDesc.append(" (").append(getPriority().toString().toLowerCase()).append(" priority)");
        
        if (!benefits.isEmpty() || !tradeoffs.isEmpty()) {
            fullDesc.append("\n").append(getBenefitTradeoffSummary());
        }
        
        return fullDesc.toString();
    }
    
    /**
     * Compare effectiveness with another alternative
     */
    public int compareEffectiveness(PathAlternative other) {
        return Double.compare(this.effectivenessScore, other.effectivenessScore);
    }
    
    @Override
    public String toString() {
        return "PathAlternative{" +
               "type=" + type +
               ", title='" + title + '\'' +
               ", effectiveness=" + String.format("%.2f", effectivenessScore) +
               ", priority=" + getPriority() +
               '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        PathAlternative that = (PathAlternative) o;
        
        return Objects.equals(title, that.title) &&
               Objects.equals(modifiedQuery, that.modifiedQuery) &&
               type == that.type;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(type, title, modifiedQuery);
    }
    
    /**
     * Priority levels for path alternatives
     */
    public enum AlternativePriority {
        HIGH,
        MEDIUM,
        LOW,
        EXPERIMENTAL
    }
}