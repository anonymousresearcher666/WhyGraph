package com.whyquery.neo4j.rewriting;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/**
 * Confidence-interval model for estimated cardinalities.
 * Intervals are multiplicative around the point estimate using pre-calibrated factors.
 */
public class EstimatorConfidenceModel {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public static final class Interval {
        public final long lower;
        public final long upper;
        public final double confidenceLevel;
        public final double factor;

        Interval(long lower, long upper, double confidenceLevel, double factor) {
            this.lower = lower;
            this.upper = upper;
            this.confidenceLevel = confidenceLevel;
            this.factor = factor;
        }

        public long width() {
            return Math.max(0L, upper - lower);
        }
    }

    public static final class QuantileBand {
        public final double q10;
        public final double q90;

        QuantileBand(double q10, double q90) {
            this.q10 = q10;
            this.q90 = Math.max(q10, q90);
        }
    }

    private final double confidenceLevel;
    private final double globalFactor;
    private final double quantileInflation;
    private final Map<WhyMode, Double> modeFactors = new EnumMap<>(WhyMode.class);
    private final Map<WhyMode, QuantileBand> modeQuantiles = new EnumMap<>(WhyMode.class);
    private final Map<WhyMode, Map<String, QuantileBand>> modeOpQuantiles = new EnumMap<>(WhyMode.class);

    private EstimatorConfidenceModel(double confidenceLevel, double globalFactor, double quantileInflation) {
        this.confidenceLevel = boundedConfidence(confidenceLevel);
        this.globalFactor = boundedFactor(globalFactor);
        this.quantileInflation = boundedInflation(quantileInflation);
    }

    public static EstimatorConfidenceModel loadFromConfiguredPath() {
        String configured = System.getProperty("why.estimator.ci.path");
        if (configured == null || configured.isBlank()) {
            configured = System.getenv("WHY_ESTIMATOR_CI_PATH");
        }
        if (configured == null || configured.isBlank()) {
            return defaultModel();
        }
        try {
            Path path = Paths.get(configured);
            if (!Files.exists(path)) {
                return defaultModel();
            }
            JsonNode root = OBJECT_MAPPER.readTree(Files.readAllBytes(path));
            double level = root.path("confidence_level").asDouble(0.95);
            double global = root.path("global_factor").asDouble(1.8);
            double inflate = root.path("quantile_inflation").asDouble(
                    parseInflationOverride(System.getProperty("why.estimator.ci.inflate")));
            EstimatorConfidenceModel model = new EstimatorConfidenceModel(level, global, inflate);
            JsonNode modes = root.get("mode_factors");
            if (modes != null && modes.isObject()) {
                putModeFactor(model, modes, "WHY_EMPTY", WhyMode.WHY_EMPTY);
                putModeFactor(model, modes, "WHY_FEW", WhyMode.WHY_FEW);
                putModeFactor(model, modes, "WHY_MANY", WhyMode.WHY_MANY);
                putModeFactor(model, modes, "WHY_NOT", WhyMode.WHY_NOT);
            }
            JsonNode qModes = root.get("mode_log_residual_quantiles");
            if (qModes != null && qModes.isObject()) {
                putQuantileBand(model.modeQuantiles, qModes, "WHY_EMPTY", WhyMode.WHY_EMPTY);
                putQuantileBand(model.modeQuantiles, qModes, "WHY_FEW", WhyMode.WHY_FEW);
                putQuantileBand(model.modeQuantiles, qModes, "WHY_MANY", WhyMode.WHY_MANY);
                putQuantileBand(model.modeQuantiles, qModes, "WHY_NOT", WhyMode.WHY_NOT);
            }
            JsonNode qByOp = root.get("mode_operation_log_residual_quantiles");
            if (qByOp != null && qByOp.isObject()) {
                putOpQuantiles(model, qByOp, "WHY_EMPTY", WhyMode.WHY_EMPTY);
                putOpQuantiles(model, qByOp, "WHY_FEW", WhyMode.WHY_FEW);
                putOpQuantiles(model, qByOp, "WHY_MANY", WhyMode.WHY_MANY);
                putOpQuantiles(model, qByOp, "WHY_NOT", WhyMode.WHY_NOT);
            }
            return model;
        } catch (Exception ignored) {
            return defaultModel();
        }
    }

    private static void putModeFactor(EstimatorConfidenceModel model, JsonNode modes, String key, WhyMode mode) {
        JsonNode value = modes.get(key);
        if (value == null || !value.isNumber()) {
            return;
        }
        model.modeFactors.put(mode, boundedFactor(value.asDouble()));
    }

    private static EstimatorConfidenceModel defaultModel() {
        return new EstimatorConfidenceModel(
                0.95,
                1.8,
                parseInflationOverride(System.getProperty("why.estimator.ci.inflate")));
    }

    public Interval interval(long estimatedRows, WhyMode mode) {
        return interval(estimatedRows, mode, null);
    }

    public Interval interval(long estimatedRows, WhyMode mode, String operationFamily) {
        if (estimatedRows < 0) {
            return new Interval(-1L, -1L, confidenceLevel, factor(mode));
        }
        QuantileBand quantileBand = selectQuantileBand(mode, operationFamily);
        if (quantileBand != null) {
            double centerLog = Math.log1p(Math.max(0L, estimatedRows));
            double mid = (quantileBand.q10 + quantileBand.q90) / 2.0;
            double half = (quantileBand.q90 - quantileBand.q10) / 2.0;
            double adjHalf = half * quantileInflation;
            double lowQ = mid - adjHalf;
            double highQ = mid + adjHalf;
            long lower = Math.max(0L, (long) Math.floor(Math.expm1(centerLog + lowQ)));
            long upper = Math.max(lower, (long) Math.ceil(Math.expm1(centerLog + highQ)));
            return new Interval(lower, upper, confidenceLevel, -1.0);
        }
        double factor = factor(mode);
        double center = Math.max(1.0, (double) estimatedRows);
        long lower = Math.max(0L, (long) Math.floor(center / factor));
        long upper = Math.max(lower, (long) Math.ceil(center * factor));
        return new Interval(lower, upper, confidenceLevel, factor);
    }

    private double factor(WhyMode mode) {
        return modeFactors.getOrDefault(mode, globalFactor);
    }

    private QuantileBand selectQuantileBand(WhyMode mode, String operationFamily) {
        if (mode != null && operationFamily != null) {
            Map<String, QuantileBand> opBands = modeOpQuantiles.get(mode);
            if (opBands != null) {
                QuantileBand qb = opBands.get(operationFamily.toUpperCase());
                if (qb != null) {
                    return qb;
                }
            }
        }
        if (mode != null) {
            return modeQuantiles.get(mode);
        }
        return null;
    }

    private static void putQuantileBand(Map<WhyMode, QuantileBand> target, JsonNode parent, String key, WhyMode mode) {
        JsonNode node = parent.get(key);
        if (node == null || !node.isObject()) {
            return;
        }
        JsonNode q10 = node.get("q10");
        JsonNode q90 = node.get("q90");
        if (q10 == null || q90 == null || !q10.isNumber() || !q90.isNumber()) {
            return;
        }
        target.put(mode, new QuantileBand(q10.asDouble(), q90.asDouble()));
    }

    private static void putOpQuantiles(EstimatorConfidenceModel model, JsonNode parent, String key, WhyMode mode) {
        JsonNode modeNode = parent.get(key);
        if (modeNode == null || !modeNode.isObject()) {
            return;
        }
        Map<String, QuantileBand> opMap = new HashMap<>();
        modeNode.fields().forEachRemaining(entry -> {
            JsonNode node = entry.getValue();
            if (node == null || !node.isObject()) {
                return;
            }
            JsonNode q10 = node.get("q10");
            JsonNode q90 = node.get("q90");
            if (q10 == null || q90 == null || !q10.isNumber() || !q90.isNumber()) {
                return;
            }
            opMap.put(entry.getKey().toUpperCase(), new QuantileBand(q10.asDouble(), q90.asDouble()));
        });
        if (!opMap.isEmpty()) {
            model.modeOpQuantiles.put(mode, opMap);
        }
    }

    private static double boundedConfidence(double value) {
        if (!Double.isFinite(value) || value <= 0.0 || value >= 1.0) {
            return 0.95;
        }
        return value;
    }

    private static double boundedFactor(double value) {
        if (!Double.isFinite(value) || value < 1.0) {
            return 1.8;
        }
        return Math.max(1.0, Math.min(20.0, value));
    }

    private static double boundedInflation(double value) {
        if (!Double.isFinite(value) || value < 1.0) {
            return 1.0;
        }
        return Math.max(1.0, Math.min(5.0, value));
    }

    private static double parseInflationOverride(String raw) {
        if (raw == null || raw.isBlank()) {
            return 1.0;
        }
        try {
            return Double.parseDouble(raw.trim());
        } catch (Exception ignored) {
            return 1.0;
        }
    }
}
