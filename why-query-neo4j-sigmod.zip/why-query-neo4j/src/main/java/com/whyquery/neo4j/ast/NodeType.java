package com.whyquery.neo4j.ast;

/**
 * Node types following Cypher's grammar structure as defined in the unified framework.
 * NodeType = {Query, Match, Where, Return, Pattern, Node, Relationship, Predicate, ...}
 */
public enum NodeType {
    
    // Top-level query structure
    QUERY,
    
    // Clause types
    MATCH,
    OPTIONAL_MATCH,
    WHERE,
    RETURN,
    ORDER_BY,
    LIMIT,
    SKIP,
    WITH,
    CREATE,
    MERGE,
    DELETE,
    SET,
    REMOVE,
    
    // Pattern elements
    PATTERN,
    NODE,
    RELATIONSHIP,
    
    // Expression types
    PREDICATE,
    BINARY_OP,
    UNARY_OP,
    PROPERTY,
    LITERAL,
    VARIABLE,
    FUNCTION,
    PARAMETER,
    
    // Logical operators
    AND,
    OR,
    NOT,
    XOR,
    
    // Comparison operators
    EQUALS,
    NOT_EQUALS,
    LESS_THAN,
    LESS_THAN_OR_EQUAL,
    GREATER_THAN,
    GREATER_THAN_OR_EQUAL,
    
    // String operators
    STARTS_WITH,
    ENDS_WITH,
    CONTAINS,
    REGEX,
    
    // Collection operators
    IN,
    
    // Null operators
    IS_NULL,
    IS_NOT_NULL,
    
    // Existence operators
    EXISTS,
    
    // Arithmetic operators
    PLUS,
    MINUS,
    MULTIPLY,
    DIVIDE,
    MODULO,
    POWER,
    
    // Collection types
    LIST,
    MAP,
    
    // Aggregation functions
    COUNT,
    SUM,
    AVG,
    MIN,
    MAX,
    COLLECT,
    
    // Utility types
    CASE,
    WHEN,
    ELSE,
    COALESCE,
    
    // Path types
    PATH,
    SHORTEST_PATH,
    ALL_SHORTEST_PATHS,
    
    // Projection types
    PROJECTION,
    ALIAS,
    
    // Subquery types
    SUBQUERY,
    UNION,
    UNION_ALL,
    
    // Procedure types
    CALL,
    YIELD,
    
    // Constraint types
    CONSTRAINT,
    INDEX,
    
    // Transaction types
    BEGIN,
    COMMIT,
    ROLLBACK,
    
    // Schema types
    SCHEMA,
    LABEL,
    PROPERTY_KEY,
    RELATIONSHIP_TYPE,
    
    // Special types
    UNKNOWN,
    WILDCARD,
    RANGE
}