package com.whyquery.neo4j.paths;

import java.util.*;

/**
 * Represents constraints on path traversal extracted from Cypher queries
 */
public class PathConstraints {
    
    private int minLength;
    private int maxLength;
    private List<String> allowedRelationshipTypes;
    private List<String> excludedRelationshipTypes;
    private String direction;
    private String weightProperty;
    private Map<String, Object> nodeConstraints;
    private Map<String, Object> relationshipConstraints;
    private boolean allowCycles;
    
    public PathConstraints() {
        this.minLength = 1;
        this.maxLength = Integer.MAX_VALUE;
        this.allowedRelationshipTypes = new ArrayList<>();
        this.excludedRelationshipTypes = new ArrayList<>();
        this.direction = "OUT";
        this.nodeConstraints = new HashMap<>();
        this.relationshipConstraints = new HashMap<>();
        this.allowCycles = true;
    }
    
    public int getMinLength() {
        return minLength;
    }
    
    public void setMinLength(int minLength) {
        this.minLength = minLength;
    }
    
    public int getMaxLength() {
        return maxLength;
    }
    
    public void setMaxLength(int maxLength) {
        this.maxLength = maxLength;
    }
    
    public List<String> getAllowedRelationshipTypes() {
        return allowedRelationshipTypes;
    }
    
    public void setAllowedRelationshipTypes(List<String> allowedRelationshipTypes) {
        this.allowedRelationshipTypes = allowedRelationshipTypes;
    }
    
    public void addAllowedRelationshipType(String type) {
        this.allowedRelationshipTypes.add(type);
    }
    
    public List<String> getExcludedRelationshipTypes() {
        return excludedRelationshipTypes;
    }
    
    public void setExcludedRelationshipTypes(List<String> excludedRelationshipTypes) {
        this.excludedRelationshipTypes = excludedRelationshipTypes;
    }
    
    public void addExcludedRelationshipType(String type) {
        this.excludedRelationshipTypes.add(type);
    }
    
    public String getDirection() {
        return direction;
    }
    
    public void setDirection(String direction) {
        this.direction = direction;
    }
    
    public String getWeightProperty() {
        return weightProperty;
    }
    
    public void setWeightProperty(String weightProperty) {
        this.weightProperty = weightProperty;
    }
    
    public Map<String, Object> getNodeConstraints() {
        return nodeConstraints;
    }
    
    public void setNodeConstraints(Map<String, Object> nodeConstraints) {
        this.nodeConstraints = nodeConstraints;
    }
    
    public void addNodeConstraint(String property, Object value) {
        this.nodeConstraints.put(property, value);
    }
    
    public Map<String, Object> getRelationshipConstraints() {
        return relationshipConstraints;
    }
    
    public void setRelationshipConstraints(Map<String, Object> relationshipConstraints) {
        this.relationshipConstraints = relationshipConstraints;
    }
    
    public void addRelationshipConstraint(String property, Object value) {
        this.relationshipConstraints.put(property, value);
    }
    
    public boolean isAllowCycles() {
        return allowCycles;
    }
    
    public void setAllowCycles(boolean allowCycles) {
        this.allowCycles = allowCycles;
    }
    
    /**
     * Check if length is constrained
     */
    public boolean hasLengthConstraints() {
        return minLength > 1 || maxLength < Integer.MAX_VALUE;
    }
    
    /**
     * Check if relationship types are constrained
     */
    public boolean hasRelationshipTypeConstraints() {
        return !allowedRelationshipTypes.isEmpty() || !excludedRelationshipTypes.isEmpty();
    }
    
    /**
     * Check if path uses weights
     */
    public boolean isWeighted() {
        return weightProperty != null && !weightProperty.trim().isEmpty();
    }
    
    /**
     * Check if direction is constrained
     */
    public boolean hasDirectionConstraints() {
        return !"BOTH".equals(direction);
    }
    
    /**
     * Check if nodes have constraints
     */
    public boolean hasNodeConstraints() {
        return !nodeConstraints.isEmpty();
    }
    
    /**
     * Check if relationships have constraints
     */
    public boolean hasRelationshipConstraints() {
        return !relationshipConstraints.isEmpty();
    }
    
    /**
     * Get the total number of constraints
     */
    public int getConstraintCount() {
        int count = 0;
        
        if (hasLengthConstraints()) count++;
        if (hasRelationshipTypeConstraints()) count++;
        if (isWeighted()) count++;
        if (hasDirectionConstraints()) count++;
        if (hasNodeConstraints()) count++;
        if (hasRelationshipConstraints()) count++;
        if (!allowCycles) count++;
        
        return count;
    }
    
    /**
     * Get constraint complexity score
     */
    public double getComplexityScore() {
        double complexity = 0.0;
        
        // Length constraints
        if (hasLengthConstraints()) {
            complexity += 1.0;
            if (maxLength > 10) {
                complexity += Math.log(maxLength) / Math.log(2);
            }
        }
        
        // Relationship type constraints
        if (hasRelationshipTypeConstraints()) {
            complexity += 1.0 + (allowedRelationshipTypes.size() * 0.2);
        }
        
        // Weight constraints
        if (isWeighted()) {
            complexity += 2.0;
        }
        
        // Direction constraints
        if (hasDirectionConstraints()) {
            complexity += 0.5;
        }
        
        // Property constraints
        complexity += nodeConstraints.size() * 0.5;
        complexity += relationshipConstraints.size() * 0.5;
        
        // Cycle constraints
        if (!allowCycles) {
            complexity += 1.0;
        }
        
        return complexity;
    }
    
    /**
     * Generate a description of the constraints
     */
    public String getDescription() {
        List<String> descriptions = new ArrayList<>();
        
        if (hasLengthConstraints()) {
            if (minLength == maxLength) {
                descriptions.add("exactly " + minLength + " hops");
            } else if (maxLength == Integer.MAX_VALUE) {
                descriptions.add("at least " + minLength + " hops");
            } else {
                descriptions.add(minLength + "-" + maxLength + " hops");
            }
        }
        
        if (hasRelationshipTypeConstraints()) {
            if (!allowedRelationshipTypes.isEmpty()) {
                descriptions.add("relationship types: " + String.join(", ", allowedRelationshipTypes));
            }
            if (!excludedRelationshipTypes.isEmpty()) {
                descriptions.add("excluding: " + String.join(", ", excludedRelationshipTypes));
            }
        }
        
        if (isWeighted()) {
            descriptions.add("weighted by " + weightProperty);
        }
        
        if (hasDirectionConstraints()) {
            descriptions.add("direction: " + direction.toLowerCase());
        }
        
        if (!allowCycles) {
            descriptions.add("no cycles");
        }
        
        if (descriptions.isEmpty()) {
            return "no constraints";
        } else {
            return String.join(", ", descriptions);
        }
    }
    
    @Override
    public String toString() {
        return "PathConstraints{" +
               "length=[" + minLength + "-" + (maxLength == Integer.MAX_VALUE ? "∞" : maxLength) + "], " +
               "relationshipTypes=" + allowedRelationshipTypes.size() + ", " +
               "direction='" + direction + '\'' +
               ", weighted=" + isWeighted() +
               ", constraints=" + getConstraintCount() +
               '}';
    }
}