package com.whyquery.neo4j.ranking;

import com.whyquery.neo4j.ast.*;
import com.whyquery.neo4j.statistics.Neo4jStatistics;
import com.whyquery.neo4j.rewriting.ModificationOperation;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;

import java.util.*;

/**
 * Generates alternative ranking approaches and concrete Cypher query modifications
 * to address ranking-related issues.
 */
public class AlternativeRankingGenerator {
    
    private final GraphDatabaseService db;
    private final Transaction tx;
    private final Neo4jStatistics statistics;
    
    public AlternativeRankingGenerator(GraphDatabaseService db, Transaction tx, Neo4jStatistics statistics) {
        this.db = db;
        this.tx = tx;
        this.statistics = statistics;
    }
    
    /**
     * Generate alternative ranking suggestions based on analysis
     */
    public List<RankingAlternative> generateAlternatives(RankingAnalysis analysis, 
                                                        RankingComparison comparison,
                                                        List<Object> desiredEntities,
                                                        String desiredVariable) {
        List<RankingAlternative> alternatives = new ArrayList<>();
        
        // Generate weight adjustment alternatives
        alternatives.addAll(generateWeightAdjustments(analysis, comparison));
        
        // Generate factor addition alternatives
        alternatives.addAll(generateFactorAdditions(analysis));
        
        // Generate direction change alternatives
        alternatives.addAll(generateDirectionChanges(analysis, comparison));
        
        // Generate completely different ranking approaches
        alternatives.addAll(generateAlternativeApproaches(analysis));

        // Generate desired-order alignment if requested
        alternatives.addAll(generateDesiredOrderingAlternatives(analysis, desiredEntities, desiredVariable));
        
        // Sort by estimated effectiveness
        alternatives.sort((a, b) -> Double.compare(b.getEffectivenessScore(), a.getEffectivenessScore()));
        
        return alternatives;
    }
    
    /**
     * Generate alternatives that adjust weights of existing factors
     */
    private List<RankingAlternative> generateWeightAdjustments(RankingAnalysis analysis, 
                                                             RankingComparison comparison) {
        List<RankingAlternative> alternatives = new ArrayList<>();
        
        if (comparison == null || analysis.getRankingFactors().isEmpty()) {
            return alternatives;
        }
        
        // Find the most problematic factor
        List<FactorContribution> influential = comparison.getMostInfluentialFactors(3);
        
        for (FactorContribution contribution : influential) {
            RankingFactor problematicFactor = contribution.getFactor();
            
            // Suggest reducing weight of problematic factor
            RankingAlternative alternative = new RankingAlternative();
            alternative.setType(RankingAlternativeType.WEIGHT_ADJUSTMENT);
            alternative.setTitle("Reduce impact of " + problematicFactor.getExpression());
            alternative.setDescription(String.format(
                "Reduce the weight of '%s' from %.2f to %.2f to balance ranking",
                problematicFactor.getExpression(), 
                problematicFactor.getWeight(),
                problematicFactor.getWeight() * 0.5));
            
            // Create modified query
            String modifiedQuery = createWeightAdjustedQuery(analysis.getOriginalQuery(), 
                                                           problematicFactor, 0.5);
            alternative.setModifiedQuery(modifiedQuery);
            alternative.setEffectivenessScore(0.7);
            
            alternatives.add(alternative);
        }
        
        return alternatives;
    }

    private List<RankingAlternative> generateDesiredOrderingAlternatives(RankingAnalysis analysis,
                                                                         List<Object> desiredEntities,
                                                                         String desiredVariable) {
        List<RankingAlternative> alternatives = new ArrayList<>();
        if (desiredEntities == null || desiredEntities.isEmpty()) {
            return alternatives;
        }
        String targetVar = desiredVariable;
        if (targetVar == null || targetVar.isBlank()) {
            // try to infer from existing factors
            if (!analysis.getRankingFactors().isEmpty()) {
                targetVar = analysis.getRankingFactors().get(0).getVariable();
            }
        }
        if (targetVar == null || targetVar.isBlank()) {
            return alternatives;
        }
        RankingAlternative alt = new RankingAlternative();
        alt.setType(RankingAlternativeType.ADD_FACTOR);
        alt.setTitle("Prioritize desired entities in ranking");
        alt.setDescription("Boost specific entities to the top of the ranking using CASE-based ordering");
        alt.setModifiedQuery(addDesiredOrdering(analysis.getOriginalQuery(), targetVar, desiredEntities));
        alt.setEffectivenessScore(0.85);
        alternatives.add(alt);
        return alternatives;
    }
    
    /**
     * Generate alternatives that add new ranking factors
     */
    private List<RankingAlternative> generateFactorAdditions(RankingAnalysis analysis) {
        List<RankingAlternative> alternatives = new ArrayList<>();
        
        // Get schema information for suggestions
        Set<String> availableProperties = getAvailableProperties(analysis.getOriginalQuery());
        Set<String> variables = extractVariables(analysis.getOriginalQuery());
        
        // Suggest common ranking factors
        for (String variable : variables) {
            // Degree-based ranking
            RankingAlternative degreeAlt = new RankingAlternative();
            degreeAlt.setType(RankingAlternativeType.ADD_FACTOR);
            degreeAlt.setTitle("Add connectivity-based ranking");
            degreeAlt.setDescription(String.format(
                "Add node degree as a ranking factor for variable '%s'", variable));
            degreeAlt.setModifiedQuery(addFactorToQuery(analysis.getOriginalQuery(), 
                String.format("size((%s)-[]-())", variable), "DESC"));
            degreeAlt.setEffectivenessScore(0.6);
            alternatives.add(degreeAlt);
            
            // ID-based ranking (for consistent ordering)
            RankingAlternative idAlt = new RankingAlternative();
            idAlt.setType(RankingAlternativeType.ADD_FACTOR);
            idAlt.setTitle("Add consistent ID-based ordering");
            idAlt.setDescription(String.format(
                "Add internal ID as secondary ranking factor for variable '%s'", variable));
            idAlt.setModifiedQuery(addFactorToQuery(analysis.getOriginalQuery(), 
                String.format("id(%s)", variable), "ASC"));
            idAlt.setEffectivenessScore(0.4);
            alternatives.add(idAlt);
        }
        
        // Suggest property-based ranking for available properties
        for (String property : availableProperties) {
            if (isNumericProperty(property)) {
                RankingAlternative propAlt = new RankingAlternative();
                propAlt.setType(RankingAlternativeType.ADD_FACTOR);
                propAlt.setTitle("Add " + property + " ranking");
                propAlt.setDescription(String.format(
                    "Add property '%s' as a ranking factor", property));
                propAlt.setModifiedQuery(addFactorToQuery(analysis.getOriginalQuery(), 
                    property, "DESC"));
                propAlt.setEffectivenessScore(0.5);
                alternatives.add(propAlt);
            }
        }
        
        return alternatives;
    }
    
    /**
     * Generate alternatives that change ranking directions
     */
    private List<RankingAlternative> generateDirectionChanges(RankingAnalysis analysis, 
                                                            RankingComparison comparison) {
        List<RankingAlternative> alternatives = new ArrayList<>();
        
        if (comparison == null) return alternatives;
        
        // Find factors that might benefit from direction reversal
        for (FactorContribution contribution : comparison.getFactorContributions()) {
            if (contribution.isSignificantContribution()) {
                RankingFactor factor = contribution.getFactor();
                String currentDirection = factor.getDirection();
                String newDirection = "ASC".equals(currentDirection) ? "DESC" : "ASC";
                
                RankingAlternative alternative = new RankingAlternative();
                alternative.setType(RankingAlternativeType.DIRECTION_CHANGE);
                alternative.setTitle("Reverse " + factor.getExpression() + " ordering");
                alternative.setDescription(String.format(
                    "Change ordering of '%s' from %s to %s",
                    factor.getExpression(), currentDirection, newDirection));
                alternative.setModifiedQuery(changeFactorDirection(analysis.getOriginalQuery(), 
                                                                  factor, newDirection));
                alternative.setEffectivenessScore(0.8);
                
                alternatives.add(alternative);
            }
        }
        
        return alternatives;
    }
    
    /**
     * Generate completely different ranking approaches
     */
    private List<RankingAlternative> generateAlternativeApproaches(RankingAnalysis analysis) {
        List<RankingAlternative> alternatives = new ArrayList<>();
        
        // Random ordering for comparison
        RankingAlternative randomAlt = new RankingAlternative();
        randomAlt.setType(RankingAlternativeType.ALGORITHM_CHANGE);
        randomAlt.setTitle("Random ordering");
        randomAlt.setDescription("Use random ordering to see baseline comparison");
        randomAlt.setModifiedQuery(addRandomOrdering(analysis.getOriginalQuery()));
        randomAlt.setEffectivenessScore(0.2);
        alternatives.add(randomAlt);
        
        // Text-based ordering (if applicable)
        if (hasTextProperties(analysis.getOriginalQuery())) {
            RankingAlternative textAlt = new RankingAlternative();
            textAlt.setType(RankingAlternativeType.ALGORITHM_CHANGE);
            textAlt.setTitle("Alphabetical ordering");
            textAlt.setDescription("Use alphabetical ordering of text properties");
            textAlt.setModifiedQuery(addAlphabeticalOrdering(analysis.getOriginalQuery()));
            textAlt.setEffectivenessScore(0.3);
            alternatives.add(textAlt);
        }
        
        // Temporal ordering (if applicable)
        if (hasTemporalProperties(analysis.getOriginalQuery())) {
            RankingAlternative temporalAlt = new RankingAlternative();
            temporalAlt.setType(RankingAlternativeType.ALGORITHM_CHANGE);
            temporalAlt.setTitle("Temporal ordering");
            temporalAlt.setDescription("Order by creation or modification time");
            temporalAlt.setModifiedQuery(addTemporalOrdering(analysis.getOriginalQuery()));
            temporalAlt.setEffectivenessScore(0.6);
            alternatives.add(temporalAlt);
        }
        
        return alternatives;
    }
    
    /**
     * Create a query with adjusted weight for a specific factor
     */
    private String createWeightAdjustedQuery(String originalQuery, RankingFactor factor, 
                                           double weightMultiplier) {
        String expression = factor.getExpression();
        String direction = factor.getDirection();
        double newWeight = factor.getWeight() * weightMultiplier;
        
        // Find and replace the ORDER BY clause
        String modifiedExpression = String.format("(%s * %.2f)", expression, newWeight);
        return replaceOrderByExpression(originalQuery, expression, modifiedExpression, direction);
    }
    
    /**
     * Add a new ranking factor to the query
     */
    private String addFactorToQuery(String originalQuery, String factorExpression, String direction) {
        int orderByIndex = originalQuery.toUpperCase().indexOf("ORDER BY");
        
        if (orderByIndex != -1) {
            // Add as secondary factor
            int nextClauseIndex = findNextClauseIndex(originalQuery, orderByIndex + 8);
            String orderByPart;
            String remainder = "";
            
            if (nextClauseIndex != -1) {
                orderByPart = originalQuery.substring(orderByIndex, nextClauseIndex);
                remainder = originalQuery.substring(nextClauseIndex);
            } else {
                orderByPart = originalQuery.substring(orderByIndex);
            }
            
            String beforeOrderBy = originalQuery.substring(0, orderByIndex);
            String newOrderBy = orderByPart + ", " + factorExpression + " " + direction;
            
            return beforeOrderBy + newOrderBy + remainder;
        } else {
            // Add ORDER BY clause
            int returnIndex = originalQuery.toUpperCase().lastIndexOf("RETURN");
            if (returnIndex != -1) {
                int nextClauseIndex = findNextClauseIndex(originalQuery, returnIndex + 6);
                if (nextClauseIndex != -1) {
                    String beforeNext = originalQuery.substring(0, nextClauseIndex);
                    String afterNext = originalQuery.substring(nextClauseIndex);
                    return beforeNext + " ORDER BY " + factorExpression + " " + direction + " " + afterNext;
                } else {
                    return originalQuery + " ORDER BY " + factorExpression + " " + direction;
                }
            } else {
                return originalQuery + " ORDER BY " + factorExpression + " " + direction;
            }
        }
    }
    
    /**
     * Change the direction of a specific factor in the query
     */
    private String changeFactorDirection(String originalQuery, RankingFactor factor, 
                                       String newDirection) {
        String expression = factor.getExpression();
        String currentDirection = factor.getDirection();
        
        // Replace the direction in ORDER BY clause
        String orderByPattern = expression + "\\s+" + currentDirection;
        String replacement = expression + " " + newDirection;
        
        return originalQuery.replaceAll("(?i)" + orderByPattern, replacement);
    }
    
    /**
     * Replace ORDER BY expression with modified version
     */
    private String replaceOrderByExpression(String originalQuery, String oldExpression, 
                                          String newExpression, String direction) {
        String pattern = "(?i)" + oldExpression.replaceAll("\\(", "\\\\(").replaceAll("\\)", "\\\\)");
        String replacement = newExpression;
        
        return originalQuery.replaceAll(pattern, replacement);
    }
    
    /**
     * Add random ordering to query
     */
    private String addRandomOrdering(String originalQuery) {
        return replaceOrAddOrderBy(originalQuery, "rand()", "ASC");
    }
    
    /**
     * Add alphabetical ordering to query
     */
    private String addAlphabeticalOrdering(String originalQuery) {
        // Find a text property to order by
        Set<String> textProperties = findTextProperties(originalQuery);
        if (!textProperties.isEmpty()) {
            String textProp = textProperties.iterator().next();
            return replaceOrAddOrderBy(originalQuery, textProp, "ASC");
        } else {
            return originalQuery;
        }
    }
    
    /**
     * Add temporal ordering to query
     */
    private String addTemporalOrdering(String originalQuery) {
        // Find a temporal property to order by
        Set<String> temporalProperties = findTemporalProperties(originalQuery);
        if (!temporalProperties.isEmpty()) {
            String temporalProp = temporalProperties.iterator().next();
            return replaceOrAddOrderBy(originalQuery, temporalProp, "DESC");
        } else {
            return originalQuery;
        }
    }
    
    /**
     * Replace existing ORDER BY or add new one
     */
    private String replaceOrAddOrderBy(String originalQuery, String expression, String direction) {
        int orderByIndex = originalQuery.toUpperCase().indexOf("ORDER BY");
        
        if (orderByIndex != -1) {
            // Replace existing ORDER BY
            int nextClauseIndex = findNextClauseIndex(originalQuery, orderByIndex + 8);
            String beforeOrderBy = originalQuery.substring(0, orderByIndex);
            String afterOrderBy = nextClauseIndex != -1 ? originalQuery.substring(nextClauseIndex) : "";
            
            return beforeOrderBy + "ORDER BY " + expression + " " + direction + " " + afterOrderBy;
        } else {
            // Add new ORDER BY
            return addFactorToQuery(originalQuery, expression, direction);
        }
    }
    
    /**
     * Get available properties from query and schema
     */
    private Set<String> getAvailableProperties(String query) {
        Set<String> properties = new HashSet<>();
        
        // Extract variables and get their properties from schema
        Set<String> variables = extractVariables(query);
        for (String variable : variables) {
            // Add common properties that might exist
            properties.add(variable + ".name");
            properties.add(variable + ".title");
            properties.add(variable + ".rating");
            properties.add(variable + ".score");
            properties.add(variable + ".value");
            properties.add(variable + ".created");
            properties.add(variable + ".updated");
        }
        
        return properties;
    }
    
    /**
     * Extract variables from query
     */
    private Set<String> extractVariables(String query) {
        Set<String> variables = new HashSet<>();
        
        // Simple regex to find variables in patterns like (variable)
        String[] parts = query.split("[\\(\\)\\[\\]]");
        for (String part : parts) {
            String trimmed = part.trim();
            if (trimmed.matches("[a-zA-Z][a-zA-Z0-9_]*") && 
                !isKeyword(trimmed.toUpperCase())) {
                variables.add(trimmed);
            }
        }
        
        return variables;
    }
    
    /**
     * Check if property is likely numeric
     */
    private boolean isNumericProperty(String property) {
        String lowerProp = property.toLowerCase();
        return lowerProp.contains("rating") || lowerProp.contains("score") || 
               lowerProp.contains("value") || lowerProp.contains("count") ||
               lowerProp.contains("size") || lowerProp.contains("amount");
    }
    
    /**
     * Check if query has text properties
     */
    private boolean hasTextProperties(String query) {
        return query.toLowerCase().contains("name") || 
               query.toLowerCase().contains("title") ||
               query.toLowerCase().contains("description");
    }

    private String addDesiredOrdering(String query, String variable, List<Object> desiredEntities) {
        StringBuilder list = new StringBuilder("[");
        boolean first = true;
        for (Object o : desiredEntities) {
            if (!first) list.append(", ");
            if (o instanceof Number || o instanceof Boolean) {
                list.append(o.toString());
            } else {
                list.append("'").append(o.toString().replace("'", "\\'")).append("'");
            }
            first = false;
        }
        list.append("]");
        String caseExpr = String.format("CASE WHEN id(%s) IN %s THEN 0 ELSE 1 END", variable, list);
        if (query.toUpperCase().contains("ORDER BY")) {
            return query.replaceFirst("(?i)ORDER BY", "ORDER BY " + caseExpr + ", ");
        }
        return query + " ORDER BY " + caseExpr;
    }
    
    /**
     * Check if query has temporal properties
     */
    private boolean hasTemporalProperties(String query) {
        return query.toLowerCase().contains("created") || 
               query.toLowerCase().contains("updated") ||
               query.toLowerCase().contains("timestamp") ||
               query.toLowerCase().contains("date");
    }
    
    /**
     * Find text properties in query
     */
    private Set<String> findTextProperties(String query) {
        Set<String> textProps = new HashSet<>();
        Set<String> variables = extractVariables(query);
        
        for (String variable : variables) {
            if (query.toLowerCase().contains(variable + ".name")) {
                textProps.add(variable + ".name");
            }
            if (query.toLowerCase().contains(variable + ".title")) {
                textProps.add(variable + ".title");
            }
        }
        
        return textProps;
    }
    
    /**
     * Find temporal properties in query
     */
    private Set<String> findTemporalProperties(String query) {
        Set<String> temporalProps = new HashSet<>();
        Set<String> variables = extractVariables(query);
        
        for (String variable : variables) {
            if (query.toLowerCase().contains(variable + ".created")) {
                temporalProps.add(variable + ".created");
            }
            if (query.toLowerCase().contains(variable + ".updated")) {
                temporalProps.add(variable + ".updated");
            }
        }
        
        return temporalProps;
    }
    
    /**
     * Find the index of the next Cypher clause
     */
    private int findNextClauseIndex(String query, int startIndex) {
        String[] keywords = {"LIMIT", "SKIP", "WITH", "UNION", "CREATE", "MERGE", "DELETE", "SET"};
        int minIndex = Integer.MAX_VALUE;
        
        for (String keyword : keywords) {
            int index = query.toUpperCase().indexOf(keyword, startIndex);
            if (index != -1 && index < minIndex) {
                minIndex = index;
            }
        }
        
        return minIndex == Integer.MAX_VALUE ? -1 : minIndex;
    }
    
    /**
     * Check if a word is a Cypher keyword
     */
    private boolean isKeyword(String word) {
        Set<String> keywords = new HashSet<>(Arrays.asList(
            "MATCH", "WHERE", "RETURN", "ORDER", "BY", "LIMIT", "SKIP", "WITH",
            "CREATE", "MERGE", "DELETE", "SET", "REMOVE", "AND", "OR", "NOT",
            "ASC", "DESC", "COUNT", "SUM", "AVG", "MIN", "MAX", "DISTINCT"
        ));
        return keywords.contains(word);
    }
}
