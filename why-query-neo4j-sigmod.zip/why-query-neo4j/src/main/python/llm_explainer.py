#!/usr/bin/env python3
"""
LLM-powered explanations for Neo4j Why-Query Plugin
Integrates with various LLM providers for natural language explanations
"""

import os
import json
import sys
import tiktoken
from llama_index.core import Settings
from llama_index.core.llms import ChatMessage
from llama_index.llms.anthropic import *
from llama_index.llms.gemini import *
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import *

class WhyQueryLLMExplainer:
    def __init__(self, config_path=None):
        """Initialize LLM explainer with configuration"""
        if config_path is None:
            config_path = os.environ.get("WHY_LLM_CONFIG")
        if config_path is None:
            plugin_dir = os.environ.get("NEO4J_PLUGINS_DIR")
            if plugin_dir:
                candidate = os.path.join(plugin_dir, "whygraph-llm-config.json")
                if os.path.exists(candidate):
                    config_path = candidate
        if config_path is None:
            config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'resources', 'llm-config.json'))
        
        with open(config_path, 'r') as f:
            self.config = json.load(f)
        self.config.setdefault('api_keys', {})
        default_prompts = {
            'why_empty': "Explain why a Cypher query returns empty results in actionable, simple terms.",
            'why_so_many': "Explain why a Cypher query returns too many results and suggest how to reduce them.",
            'why_so_few': "Explain why a Cypher query returns too few results and how to increase them.",
            'advanced_analysis': "Explain the advanced algorithm output in plain language with recommendations.",
            'why_empty_rewrite': "Suggest the smallest Cypher rewrites that would produce results, using only the provided schema and diagnostics.",
        }
        user_prompts = self.config.get('prompts')
        if not isinstance(user_prompts, dict):
            user_prompts = {}
        self.prompts = {**default_prompts, **user_prompts}
        self.config['prompts'] = self.prompts
        
        self.config.setdefault('llm_settings', {})
        self._setup_environment()
        self.model_name = self.config['llm_settings'].get('default_model', 'ollama_qwen2.5:latest')
        self.llm = None
    
    def _setup_environment(self):
        """Setup environment variables for API keys"""
        api_keys = self.config.get('api_keys', {})
        
        for key, env_var in api_keys.items():
            if key.endswith('_env'):
                value = os.getenv(env_var, '')
                if value:
                    os.environ[env_var] = value
        
        if 'google_credentials_path' in api_keys:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = api_keys['google_credentials_path']
    
    def get_tokenizer_and_limit(self, model_name):
        """Get tokenizer and token limit for the specified model"""
        if model_name in ['gpt-4-turbo', 'gpt-4o', 'gpt-4o-2024-08-06', 'gpt-4o-mini-2024-07-18']:
            max_tokens = 128000
            tokenizer = tiktoken.encoding_for_model(model_name)
        elif model_name.startswith("claude"):
            tokenizer = Anthropic().tokenizer
            Settings.tokenizer = tokenizer
            tokenizer = None
            max_tokens = 200000
        elif model_name.startswith("gemini"):
            tokenizer = None
            max_tokens = 1000000
        elif model_name.startswith("llama") or model_name.startswith("ollama_"):
            tokenizer = None
            max_tokens = 4096
        else:
            raise ValueError(f"Unknown model: {model_name}")
        return tokenizer, max_tokens

    def tokenize_input(self, input_text, model_name):
        """Tokenize and truncate input if needed"""
        tokenizer, max_tokens = self.get_tokenizer_and_limit(model_name)
        if tokenizer:
            tokenized_input = tokenizer.encode(input_text)
            token_count = len(tokenized_input)

            if token_count > max_tokens:
                print(f"Warning: Input exceeds maximum token limit of {max_tokens} tokens. Truncating input.")
                tokenized_input = tokenized_input[:max_tokens]
                input_text = tokenizer.decode(tokenized_input)

        return input_text

    def create_llm(self, model_name="gpt-4"):
        """Create LLM instance based on model name"""
        timeout = self.config['llm_settings'].get('timeout_seconds', 30)
        
        if model_name.startswith("gpt"):
            llm = OpenAI(model=model_name, timeout=timeout)
        elif model_name.startswith("claude"):
            llm = Anthropic(model=model_name, timeout=timeout, max_tokens=4000)
        elif model_name.startswith("gemini"):
            llm = Gemini(model="models/" + model_name)
        elif model_name.startswith("ollama_"):
            m_name = model_name[7:]
            llm = Ollama(model=m_name, request_timeout=timeout)
        else:
            raise ValueError(f"Unknown model: {model_name}")
        return llm

    def query_remote_llm(self, input_text, system_prompt, llm):
        """Query the LLM with system and user messages"""
        messages = [
            ChatMessage(role="system", content=system_prompt),
            ChatMessage(role="user", content=input_text),
        ]
        response = llm.chat(messages)
        return response

    def explain_why_empty(self, query, analysis_result, schema_info=""):
        """Generate explanation for empty query results"""
        if not self.config['llm_settings'].get('enabled', False):
            return "LLM explanations disabled in configuration"
        
        system_prompt = self.prompts['why_empty']
        missing_labels = []
        missing_relationships = []
        
        if isinstance(analysis_result, dict):
            for vertex in analysis_result.get('vertices', []):
                reason = vertex.get('reason')
                label = vertex.get('label')
                if reason and label:
                    missing_labels.append(f"- {label}: {reason}")
            for edge in analysis_result.get('edges', []):
                reason = edge.get('reason')
                rel_type = edge.get('type')
                if reason and rel_type:
                    missing_relationships.append(f"- {rel_type}: {reason}")
        
        available_labels = analysis_result.get('data_labels', []) if isinstance(analysis_result, dict) else []
        available_relationships = analysis_result.get('data_relationship_types', []) if isinstance(analysis_result, dict) else []
        
        user_prompt = f"""
Query: {query}

ALGORITHMIC ANALYSIS RESULTS:
{json.dumps(analysis_result, indent=2) if isinstance(analysis_result, dict) else analysis_result}

Missing Labels: {chr(10).join(missing_labels) if missing_labels else 'None identified'}
Missing Relationships: {chr(10).join(missing_relationships) if missing_relationships else 'None identified'}
Available Labels: {', '.join(available_labels)}
Available Relationships: {', '.join(available_relationships)}
"""
        
        try:
            if self.llm is None:
                self.llm = self.create_llm(self.model_name)
            user_prompt = self.tokenize_input(user_prompt, self.model_name)
            response = self.query_remote_llm(user_prompt, system_prompt, self.llm)
            return response.message.content
        except Exception as e:
            return f"LLM explanation failed: {str(e)}"
    
    def suggest_why_empty_rewrite(self, query, analysis_result, schema_info=None):
        """Generate minimal rewrite suggestions for empty query results."""
        if not self.config['llm_settings'].get('enabled', False):
            return "LLM explanations disabled in configuration"
        
        system_prompt = self.prompts.get('why_empty_rewrite', self.prompts['why_empty'])
        
        schema_labels = []
        schema_relationships = []
        schema_properties = []
        if isinstance(schema_info, dict):
            schema_labels = schema_info.get('labels', [])
            schema_relationships = schema_info.get('relationshipTypes', [])
            props = schema_info.get('properties', {})
            if isinstance(props, dict):
                schema_properties = list(props.keys())
        
        user_prompt = f"""
Original Query:
```cypher
{query}
```

Diagnostics:
{json.dumps(analysis_result, indent=2)}

Schema (use only these elements):
- Labels: {', '.join(schema_labels)}
- Relationships: {', '.join(schema_relationships)}
- Properties: {', '.join(schema_properties)}

Instructions:
- Propose up to 3 minimal MATCH/OPTIONAL MATCH/WHERE/RETURN rewrites, no writes or procedure calls.
- Stay as close as possible to the original intent; prefer relaxing predicates or swapping to existing labels/rels.
- Do NOT invent labels/relationships/properties that are not in the schema list above.
- Do NOT use wildcard relationships like [:*]; choose only from the provided relationship types.
- If the diagnostics include heuristic_estimates, use them as-is. Otherwise, give a qualitative HEURISTIC outcome estimate (broaden/narrow + small/medium/large). Do NOT assume execution or invent database state.
- First, provide a one-sentence meaning/intent of the original query.
- For each rewrite, include: cypher, what changed, a one-sentence meaning/intent of the rewrite, why it should return data, and the heuristic estimate.
"""
        try:
            if self.llm is None:
                self.llm = self.create_llm(self.model_name)
            user_prompt = self.tokenize_input(user_prompt, self.model_name)
            response = self.query_remote_llm(user_prompt, system_prompt, self.llm)
            return response.message.content
        except Exception as e:
            return f"LLM rewrite suggestion failed: {str(e)}"

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python llm_explainer.py '<prompt>' <analysis_type> '<analysis_json>'")
        sys.exit(1)
    prompt = sys.argv[1]
    analysis_type = sys.argv[2]
    analysis_json = json.loads(sys.argv[3])
    original_query = analysis_json.get("original_query", "")
    technical_result = analysis_json.get("technical_result", {})
    explainer = WhyQueryLLMExplainer()
    if analysis_type == "why_empty":
        explanation = explainer.explain_why_empty(original_query, technical_result)
    elif analysis_type in ("why_empty_rewrite", "why-empty-rewrite"):
        schema_info = technical_result.get("schema") if isinstance(technical_result, dict) else None
        explanation = explainer.suggest_why_empty_rewrite(original_query, technical_result, schema_info)
    elif analysis_type in ("why_so_few", "why-so-few"):
        explanation = explainer.explain_why_empty(original_query, technical_result)
    else:
        explanation = explainer.explain_why_empty(original_query, technical_result)
    print(explanation)
