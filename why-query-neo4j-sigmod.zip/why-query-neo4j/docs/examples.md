# WhyGraph Examples

These are the compact examples worth keeping in the repo after cleanup.

## Why-empty

```cypher
CALL why.empty(
  'MATCH (p:Person {name:"NonExistent"})-[:LIVES_IN]->(c) RETURN p, c',
  {use_schema:true}
);
```

## Why-so-few

```cypher
CALL why.so_few(
  'MATCH (p:Person {country:"Iceland"}) RETURN p',
  100,
  {use_schema:true}
);
```

## Why-so-many

```cypher
CALL why.so_many(
  'MATCH (p:Person)-[:KNOWS]->(f) RETURN p, f',
  1000,
  {allow_add_limit:true}
);
```

## Why-not

```cypher
CALL why.not(
  'MATCH (p:Person)-[:WORKS_AT]->(c:Company) RETURN p, c',
  {
    p: {labels: ["Person"], properties: {name: "Alice"}},
    c: {labels: ["Company"], properties: {name: "Acme"}}
  },
  {}
);
```

## Cardinality Estimation

```cypher
RETURN why.estimate_cardinality(
  'MATCH (p:Person)-[:LIVES_IN]->(c:City) RETURN p'
) AS estimatedCount;
```
