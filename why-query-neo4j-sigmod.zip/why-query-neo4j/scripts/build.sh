#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

echo "🔨 Building WhyGraph Neo4j plugin..."
mvn -Dmaven.test.skip=true clean package

find_latest_jar() {
    shopt -s nullglob
    local candidates=("$PROJECT_ROOT"/target/whygraph-plugin-*.jar)
    shopt -u nullglob
    local latest=""
    for jar in "${candidates[@]}"; do
        if [[ -z "$latest" || "$jar" -nt "$latest" ]]; then
            latest="$jar"
        fi
    done
    printf "%s" "$latest"
}

JAR_PATH="$(find_latest_jar)"
if [[ -z "$JAR_PATH" ]]; then
    echo "❌ Build completed but no plugin JAR was found in target/. Check Maven output."
    exit 1
fi

echo "✅ Build complete: ${JAR_PATH#$PROJECT_ROOT/}"
echo "   (Run scripts/install.sh /path/to/dbms to deploy to Neo4j Desktop)"
