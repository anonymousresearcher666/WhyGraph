#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

usage() {
    cat <<'USAGE'
Usage: scripts/install.sh [/path/to/neo4j-desktop-dbms]

Arguments:
  /path/to/neo4j-desktop-dbms   Absolute path to the dbms-* directory created by Neo4j Desktop.
                               If omitted, the script uses $NEO4J_DESKTOP_DBMS when set.

Examples:
  scripts/install.sh "/Users/me/Library/Application Support/Neo4j Desktop/Application/relate-data/dbmss/dbms-abc123"
  NEO4J_DESKTOP_DBMS="/path/to/dbms-xyz" scripts/install.sh
USAGE
}

DBMS_DIR="${1:-${NEO4J_DESKTOP_DBMS:-}}"
if [[ -z "$DBMS_DIR" ]]; then
    echo "❌ No Neo4j Desktop DBMS path provided."
    usage
    exit 1
fi

if [[ ! -d "$DBMS_DIR" ]]; then
    echo "❌ DBMS path does not exist: $DBMS_DIR"
    exit 1
fi

PLUGINS_DIR="$DBMS_DIR/plugins"
mkdir -p "$PLUGINS_DIR"

find_latest_jar() {
    shopt -s nullglob
    local candidates=("$PROJECT_ROOT"/target/whygraph-plugin-*.jar)
    shopt -u nullglob
    local latest=""
    for jar in "${candidates[@]}"; do
        if [[ -z "$latest" || "$jar" -nt "$latest" ]]; then
            latest="$jar"
        fi
    done
    printf "%s" "$latest"
}

JAR_PATH="$(find_latest_jar)"
if [[ -z "$JAR_PATH" ]]; then
    echo "ℹ️  No plugin JAR found. Building one now..."
    "$PROJECT_ROOT/scripts/build.sh"
    JAR_PATH="$(find_latest_jar)"
fi

if [[ -z "$JAR_PATH" ]]; then
    echo "❌ Failed to locate plugin JAR after building."
    exit 1
fi

echo "📦 Installing $(basename "$JAR_PATH") to $PLUGINS_DIR"
cp "$JAR_PATH" "$PLUGINS_DIR/"

echo ""
echo "✅ Installation complete."
echo "   Plugin location: $PLUGINS_DIR/$(basename "$JAR_PATH")"
echo ""
echo "Next steps:"
echo "1. Restart the corresponding Neo4j Desktop DBMS so it loads the new plugin."
echo "2. In Neo4j Browser run:"
echo "     SHOW PROCEDURES YIELD name WHERE name STARTS WITH 'why.' RETURN name;"
echo "   to confirm it is available."
