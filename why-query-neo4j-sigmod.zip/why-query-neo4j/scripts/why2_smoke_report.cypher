// Why2 smoke test + unified report
// Run after DBMS restart with updated plugin loaded.
// Expected build tag: why2-2026-04-27-r3

// 0) Procedure availability
SHOW PROCEDURES YIELD name, signature
WHERE name STARTS WITH 'why2.'
RETURN name, signature
ORDER BY name;

// 1) Statistics profile (includes S_path status)
CALL why2.statistics()
YIELD profile
RETURN profile;

// Optional: refresh S_path entries before tests
CALL why2.refreshStatistics({path_min_len:1, path_max_len:3})
YIELD profile
RETURN profile;

// 2) Why-Empty
CALL why2.empty(
  "MATCH (p:NRPerson)-[:ERwasBornIn]->(c:NRCity) WHERE p.name='This_Person_Does_Not_Exist' RETURN p,c",
  {strict_core:true, use_planner_stats:true, use_formal_bounds:true}
)
YIELD status, payload, diagnostics, errorMessage
RETURN
  'WHY_EMPTY' AS mode,
  status,
  diagnostics['why2_build_tag'] AS build_tag,
  payload['suggested_rewrite_queries'] AS rewrites,
  payload['answer_closeness'] AS closeness,
  payload['goal_estimate'] AS goal_estimate,
  diagnostics['rewriting_failure_code'] AS failure_code,
  diagnostics,
  errorMessage;

// 3) Why-Few
CALL why2.few(
  "MATCH (p:NRPerson)-[:ERhasInterest]->(t:NRTopic) RETURN p,t",
  {target_min_rows:500},
  {strict_core:true, use_planner_stats:true, use_formal_bounds:true}
)
YIELD status, payload, diagnostics, errorMessage
RETURN
  'WHY_FEW' AS mode,
  status,
  diagnostics['why2_build_tag'] AS build_tag,
  payload['suggested_rewrite_queries'] AS rewrites,
  payload['answer_closeness'] AS closeness,
  payload['goal_estimate'] AS goal_estimate,
  diagnostics['rewriting_failure_code'] AS failure_code,
  diagnostics,
  errorMessage;

// 4) Why-Many
CALL why2.many(
  "MATCH (p:NRPerson)-[:ERhasInterest]->(t:NRTopic) RETURN p,t",
  {target_max_rows:200},
  {strict_core:true, use_planner_stats:true, use_formal_bounds:true}
)
YIELD status, payload, diagnostics, errorMessage
RETURN
  'WHY_MANY' AS mode,
  status,
  diagnostics['why2_build_tag'] AS build_tag,
  payload['suggested_rewrite_queries'] AS rewrites,
  payload['answer_closeness'] AS closeness,
  payload['goal_estimate'] AS goal_estimate,
  diagnostics['rewriting_failure_code'] AS failure_code,
  diagnostics,
  errorMessage;

// 5) Why-Not (single witness)
CALL why2.not(
  "MATCH (p:NRPerson)-[:ERwasBornIn]->(c:NRCity) WHERE p.name='This_Person_Does_Not_Exist' RETURN p,c",
  {witnesses:[{p:{properties:{name:'Diederik_Korteweg'}}}]},
  {strict_core:true, use_planner_stats:true, use_formal_bounds:true}
)
YIELD status, payload, diagnostics, errorMessage
RETURN
  'WHY_NOT' AS mode,
  status,
  diagnostics['why2_build_tag'] AS build_tag,
  payload['suggested_rewrite_queries'] AS rewrites,
  payload['answer_closeness'] AS closeness,
  payload['witness_recovery'] AS witness_recovery,
  payload['goal_estimate'] AS goal_estimate,
  diagnostics['rewriting_failure_code'] AS failure_code,
  diagnostics,
  errorMessage;
