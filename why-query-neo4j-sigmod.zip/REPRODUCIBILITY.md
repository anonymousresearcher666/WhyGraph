# Reproducing the final campaign

Two distinct checks are supported: recomputing results from the recorded evidence,
and rerunning the experiments on loaded Neo4j databases. Historical evidence is
explicitly dated and must not be substituted for the final run.

## Offline evidence checks

Use Python 3.13 with PyYAML and the Neo4j Python driver (6.0.3 in the campaign).
Unpack the archive, then work from its top-level directory. Expand compressed
JSON/JSONL files before invoking the original scripts; the compressed originals
remain the manifest-hashed evidence.

```bash
python3 - <<'PY'
import gzip
from pathlib import Path
for p in Path('evaluation').rglob('*.gz'):
    with gzip.open(p, 'rb') as src:
        p.with_suffix('').write_bytes(src.read())
PY
python3 PAPER/sigmod2027/rerun/verify_campaign.py \
  --dir evaluation/vldb/final_SIGMOD27FINAL \
  --output /tmp/whygraph-verification.json
python3 PAPER/sigmod2027/rerun/summarize_rerun.py \
  --dir evaluation/vldb/final_SIGMOD27FINAL --tag SIGMOD27FINAL \
  --json /tmp/whygraph-numbers.json --md /tmp/whygraph-numbers.md
python3 PAPER/sigmod2027/rerun/experiment_figures.py \
  --summary /tmp/whygraph-numbers.json --output-dir /tmp/whygraph-figures
```

The last command regenerates the three paper figure snippets and their TikZ/PGFPlots
preamble. Include that preamble and the snippets in a two-column LaTeX document
to render them. Plot limits expand when necessary to include every data point.

The verifier checks workload/profile coverage, duplicate rows, calibration-count
coverage, isolation files, successful snapshot reconstruction and freshness, and
Java source hashes. Failed repairs are retained; completeness does not require
all queries to succeed. SHA-256 hashes in MANIFEST.json protect the packaged bytes.
The exact deployed binary is included as `bin/whygraph-plugin-1.0.0.jar` and
checked against the campaign hash. A fresh Maven package may have different
ZIP timestamps; source hashes identify the corresponding evaluated source.

The correctness revision retains frozen input calibration and independent LLM runs
from the preceding campaign. Their generator inputs remain frozen; the retained files and
original hashes are listed in `retained_evidence_provenance.json` and checked by
the verifier. All engine-dependent repair, snapshot construction and isolation measurements are rerun. The corrected builder adds degree witnesses that legacy snapshots lack. WHY_REBUILD_ONCE=true rebuilds once per dataset and pinned binary, then requires freshness for reuse within that campaign.

## Build and tests

```bash
cd why-query-neo4j
mvn test
mvn -DskipTests package
```

Build/test with JDK 17. The recorded Neo4j server runtime and memory settings
are in environment_SIGMOD27FINAL.json. The campaign uses Neo4j Community
2026.02.2; install a compatible server Java runtime separately.
The Maven compile API and JAR manifest identify Neo4j 5.13.0; the recorded
measurements use the 2026.02.2 server and Java 24.0.1.
Memory configuration entries list explicit heap/page-cache settings; an empty
entry denotes server defaults rather than a shared fixed memory budget.

## Live rerun

The public database releases and the loaded Neo4j stores are not bundled. The
runner expects populated databases and frozen schema vocabulary in the four
community_instances directories named in rerun_sigmod2027.sh. It stops these
instances and deploys the new plugin, running one database at a time. It rebuilds
all statistics for the existing declared schema, records freshness and build
cost, and never substitutes old outputs after a failed rebuild.

Set NEO4J_PASSWORD in the environment. For the LLM baseline, run Ollama with
gpt-oss:20b on localhost:11434. Start in a fresh output directory/tag when testing
a different source build; do not resume results from a different jar. Set
`WHY_RERUN_OUT` and `WHY_RERUN_LOG` to separate output and log directories.
`WHY_REUSE_SNAPSHOT=true` checks freshness of an unchanged frozen snapshot instead
of rebuilding it; `WHY_RETAIN_LLM=true` skips independent LLM generation. Use these
only with explicit retained-evidence provenance and matching frozen inputs.

The expert intent-preservation study has no participant results. Its protocol,
form generator and analyzer are supplied under PAPER/sigmod2027/rerun/intent_study.
Only generate forms after the final computational campaign has passed verification.

## Corrected bag-cardinality contract and matched audits

Upper bounds count physical relationship choices, including parallel edges,
self-loops, and omitted cycle atoms. Child key equality does not remove edge
multiplicity. Directed fixed-length connected patterns and edge-free products
form the certificate scope; undirected atoms and edge-bearing disconnected
patterns fail closed. Label/type alternatives are outside the formal core.
Nonconjunctive filters, optional patterns and aggregation
are also rejected before any key cap or schema-zero result. A conservative
input flag survives parser regeneration. Regression tests cover these cases
and the old multigraph counterexamples.

For why-many, `upper_target_certified` certifies the ceiling only;
`target_certified` remains false and `target_validation_required` is true.
Independent validation must establish both nonemptiness and the ceiling.
Certificates assume runtime-triple coverage of the declared schema within the
queried typed namespace; a freshness check does not establish global schema
conformance. The artifact's exact bound checks test the emitted candidates.
The lower certificate additionally requires a predicate-free typed tree in one
MATCH clause, without shared relationship variables, repeated types or
cardinality-changing clauses. Committed writes disable certificates until a quiescent rebuild; certificate
transactions must have no pending own writes. The isolation runs use reads and
do not measure availability under sustained writes.

```bash
python3 PAPER/sigmod2027/rerun/summarize_revision_audits.py \
  --dir evaluation/vldb/final_SIGMOD27FINAL
```

The revision audits preserve all why-many failure categories and compare
practical FT, FT-EXEC and strict FT on identical shape inputs. The three queue
orders differ only in `frontier_order`; operators, costs, goal tests, budgets,
and admission cutoffs stay fixed. Adaptive learning costs are disabled in all
three arms before measurement. Four repetitions rotate profile order and
shuffle the same 64 inputs. Practical shortcuts remain enabled, so this is an
engine queue-order intervention rather than a theorem about pure A*.
Foreground ratios report paired min/median/max over five repetitions, without
imputing a confidence interval or claiming significance.

The temporal inputs were observed in the preceding campaign. This correctness
rerun is not a newly unseen test. The semantic assessment may be retained only
when every original query and both emitted rewrites match its frozen pairs;
the verifier checks this binding against the current engine outputs.

## Isolated local fixtures used for the correctness revision

The corrected campaign uses independent APFS copies of the stopped YAGO and
SF0.1 user databases. The original system databases, credentials and configuration
are not copied or modified. The new fixtures create their own system database,
listen only on 127.0.0.1, and use authentication disabled for local benchmark
reads. Their heap and page-cache settings match the respective source instances.
`isolated_instance_provenance.json` records the source, copy method and config
hashes; all proof metadata is rebuilt on each new fixture.

On the measurement Mac, `prepare_isolated_instances.py` creates these copies
only when the source processes are stopped and refuses existing destinations.
The standard runner also accepts `WHY_YAGO_HOME`, `WHY_YAGO_URI`,
`WHY_SF01_HOME`, and `WHY_SF01_URI` for independently prepared fixtures.
`WHY_REBUILD_ONCE=true` reuses a snapshot only after a successful build with the
campaign's exact JAR pin and a fresh transaction-version check.

The correctness artifact includes the actual evaluated schema/statistics JSON
under `evaluated_snapshots/`, with transaction identifiers, degree witnesses,
and a hash manifest. Pre-build backups are deliberately kept separate. For a
live rerun, use the corresponding declared-schema JSON to seed the plugin
directory, then rebuild metadata and verify freshness on the newly loaded store.
The saved transaction identifiers do not establish freshness on a different store.
